<?php
if (!defined('ABSPATH')) { exit; }
add_action('pgb_payment_confirmed', function($order_id,$tx,$order){
    if(strtoupper($tx['kind']??'')!=='PRO') return;
    if(!function_exists('wcs_get_subscriptions_for_order')) return;

    $subs=wcs_get_subscriptions_for_order($order_id,['order_type'=>'parent']);
    if(!empty($subs)) return;
    if(!function_exists('wcs_create_subscription')) return;

    $period=(string)($tx['subscription']['_subscription_period']??'month');
    $interval=max(1,(int)($tx['subscription']['_subscription_interval']??1));
    $length=max(0,(int)($tx['subscription']['_subscription_length']??0));
    $start=current_time('mysql',true);

    $subscription=wcs_create_subscription([
        'order_id'=>$order_id,
        'customer_id'=>$order->get_customer_id(),
        'billing_period'=>$period,
        'billing_interval'=>$interval,
        'start_date'=>$start,
        'status'=>'pending',
    ]);
    if(is_wp_error($subscription) || !$subscription) return;

    foreach($order->get_items('line_item') as $item){
        $product=$item->get_product(); if($product) $subscription->add_product($product,$item->get_quantity());
    }
    $subscription->set_address($order->get_address('billing'),'billing');
    $subscription->set_address($order->get_address('shipping'),'shipping');
    $subscription->calculate_totals(false);
    if($length>0 && method_exists($subscription,'update_dates')){
        $next=gmdate('Y-m-d H:i:s',strtotime('+'.$interval.' '.$period));
        $subscription->update_dates(['next_payment'=>$next]);
    }
    $subscription->set_status('active');
    $subscription->save();
    $order->update_meta_data('_pgb_subscription_id',$subscription->get_id());
    $order->save();
},30,3);
