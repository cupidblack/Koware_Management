<?php
if (!defined('ABSPATH')) { exit; }
add_filter('woocommerce_currency', function($currency){
    return $currency;
},999);
add_action('pgb_payment_confirmed', function($order_id,$tx,$order){
    $order->update_meta_data('_pgb_authoritative_currency',$order->get_currency());
    $order->update_meta_data('_pgb_authoritative_amount',$order->get_total());
    $order->save();
},5,3);
