<?php
if (!defined('ABSPATH')) { exit; }

/**
 * WoWonder post-payment fulfillment.
 * This replaces the old external WooCommerce webhook as the authoritative
 * WordPress-side completion handler.
 */
add_action('pgb_payment_confirmed', function($order_id,$tx,$order){
    $cfg=require dirname(__DIR__).'/config/pgb-config.php';
    $c=$cfg['wowonder_db']??[];
    if(empty($c['host'])||empty($c['user'])||empty($c['name'])) return;
    $db=@new mysqli($c['host'],$c['user'],$c['pass'],$c['name']);
    if($db->connect_errno) return;
    $db->set_charset('utf8mb4');

    $wow_order_id=(string)$tx['order_id'];
    $wow_user_id=(int)$tx['userid'];
    $amount=(float)$order->get_total();
    $currency=$order->get_currency();
    $kind=strtoupper((string)$tx['kind']);
    $post_id=(int)($tx['wow_post_id']??0);
    $woo_id=(int)$order_id;
    $method=(string)$order->get_payment_method();
    $product_id=0;
    foreach($order->get_items('line_item') as $item){$product_id=(int)$item->get_product_id();break;}

    /* Authoritative transaction state. */
    $stmt=$db->prepare("UPDATE Wo_Payment_Transactions SET payment_status='completed',payment_method=?,woo_order_id=?,amount=?,currency_code=?,transaction_dt=NOW() WHERE order_id=?");
    if($stmt){$stmt->bind_param('sidss',$method,$woo_id,$amount,$currency,$wow_order_id);$stmt->execute();$stmt->close();}

    /* Wallet top-up. */
    $wallet_product=(int)get_option('bzj_pgb_wallet_product_id',0);
    if($wallet_product && $product_id===$wallet_product && empty($tx['qdw_order_id'])){
        $stmt=$db->prepare("UPDATE Wo_Users SET wallet=wallet+? WHERE user_id=?");
        if($stmt){$stmt->bind_param('di',$amount,$wow_user_id);$stmt->execute();$stmt->close();}
    }

    /* Crowdfund contribution. */
    $fund_product=(int)get_option('bzj_pgb_crowdfund_product_id',0);
    if($fund_product && $product_id===$fund_product && $post_id>0){
        $stmt=$db->prepare("INSERT INTO Wo_Funding_Raise (funding_id,user_id,amount,time) VALUES (?,?,?,?)");
        if($stmt){$now=time();$stmt->bind_param('iidi',$post_id,$wow_user_id,$amount,$now);$stmt->execute();$stmt->close();}
    }

    /* PRO membership activation. */
    $pro_ids=[
        (int)get_option('bzj_pgb_pro_product_id_1',0),
        (int)get_option('bzj_pgb_pro_product_id_2',0),
        (int)get_option('bzj_pgb_pro_product_id_3',0),
        (int)get_option('bzj_pgb_pro_product_id_4',0),
    ];
    if(in_array($product_id,$pro_ids,true) && in_array($post_id,[1,2,3,4],true)){
        $now=time();$is_pro='1';$pro_type=$post_id;
        $stmt=$db->prepare("UPDATE Wo_Users SET pro_time=?,is_pro=?,pro_type=? WHERE user_id=?");
        if($stmt){$stmt->bind_param('isis',$now,$is_pro,$pro_type,$wow_user_id);$stmt->execute();$stmt->close();}
        if(function_exists('bzj_log_activity')){
            $labels=[1=>'Classic Lifestyle',2=>'Silver Lifestyle',3=>'RockStar Lifestyle',4=>'Premium Lifestyle'];
            $label=$labels[$post_id]??'PRO Membership';
            @bzj_log_activity($wow_user_id,$label,$wow_order_id,'purchase',$amount,'Wo_Payment_Transactions');
        }
    }

    /* Market/product purchase records are created only after successful payment. */
    if(in_array($kind,['PRODUCT','MARKET','PURCHASE','SALE'],true)){
        $owner=(int)($tx['product_owner_id']??0);
        $units=max(1,(int)($tx['product_units']??1));
        $name=(string)($tx['product_name']??'Product');
        $price=(float)($tx['product_price']??$amount);
        $data=wp_json_encode(['name'=>$name,'product_id'=>$post_id,'units'=>$units,'currency'=>$currency,'timestamp'=>time()]);
        $exists=$db->prepare("SELECT 1 FROM Wo_Purchases WHERE order_hash_id=? LIMIT 1");
        $already=false;
        if($exists){$exists->bind_param('s',$wow_order_id);$exists->execute();$exists->store_result();$already=$exists->num_rows>0;$exists->close();}
        if(!$already){
            $commission=0.0;$now=time();
            $stmt=$db->prepare("INSERT INTO Wo_Purchases (user_id,order_hash_id,owner_id,data,final_price,commission,price,timestamp,time) VALUES (?,?,?,?,?,?,?,?,?)");
            if($stmt){
                $stmt->bind_param('isisdddii',$wow_user_id,$wow_order_id,$owner,$data,$amount,$commission,$price,$now,$now);
                $stmt->execute();
                $stmt->close();
            }
        }
        /* Owner SALE ledger entry. */
        if($owner>0){
            $sale_kind='SALE';$notes='Product Sale';
            $stmt=$db->prepare("SELECT 1 FROM Wo_Payment_Transactions WHERE order_id=? AND userid=? AND kind='SALE' LIMIT 1");
            $found=false;
            if($stmt){$stmt->bind_param('si',$wow_order_id,$owner);$stmt->execute();$stmt->store_result();$found=$stmt->num_rows>0;$stmt->close();}
            if(!$found){
                $stmt=$db->prepare("INSERT INTO Wo_Payment_Transactions (userid,amount,order_id,kind,currency_code,notes) VALUES (?,?,?,?,?,?)");
                if($stmt){$stmt->bind_param('idssss',$owner,$amount,$wow_order_id,$sale_kind,$currency,$notes);$stmt->execute();$stmt->close();}
            }
            $stmt=$db->prepare("SELECT 1 FROM Wo_Notifications WHERE notifier_id=? AND recipient_id=? AND type='new_orders' AND url='index.php?link1=orders' AND time>=? LIMIT 1");
            $now=time();$found=false;
            if($stmt){$stmt->bind_param('iii',$wow_user_id,$owner,$now-86400);$stmt->execute();$stmt->store_result();$found=$stmt->num_rows>0;$stmt->close();}
            if(!$found){
                $type='new_orders';$url='index.php?link1=orders';
                $stmt=$db->prepare("INSERT INTO Wo_Notifications (notifier_id,recipient_id,type,url,time) VALUES (?,?,?,?,?)");
                if($stmt){$stmt->bind_param('iissi',$wow_user_id,$owner,$type,$url,$now);$stmt->execute();$stmt->close();}
            }
        }
    }
    $db->close();
},10,3);
