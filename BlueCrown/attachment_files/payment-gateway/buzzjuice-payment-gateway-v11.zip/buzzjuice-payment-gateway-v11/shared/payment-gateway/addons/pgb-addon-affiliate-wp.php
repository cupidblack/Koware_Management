<?php
if (!defined('ABSPATH')) { exit; }

/**
 * AffiliateWP integration.
 *
 * The existing bridge resolved attribution from Lifetime Customers, AffiliateWP
 * customer records and the Streams snapshot. v11 keeps that principle but makes
 * payment_complete the only entry point and uses order-level idempotency.
 */
add_action('pgb_payment_confirmed', function($order_id,$tx,$order){
    if($order->get_meta('_affwp_bridge_processed',true)) return;
    if($order->get_meta('_buzzjuice_origin',true)!=='streams') return;
    if(!function_exists('affwp_add_referral')) return;

    global $wpdb;
    $wp_user_id=(int)$order->get_customer_id();
    $customer_id=0;
    if($wp_user_id){
        $customer_id=(int)$wpdb->get_var($wpdb->prepare(
            "SELECT customer_id FROM {$wpdb->prefix}affiliate_wp_customers WHERE user_id=%d LIMIT 1",$wp_user_id
        ));
    }

    $snapshot=(array)($tx['snapshot']??[]);
    if(!$customer_id && !empty($snapshot['customer_email'])){
        $customer_id=(int)$wpdb->get_var($wpdb->prepare(
            "SELECT customer_id FROM {$wpdb->prefix}affiliate_wp_customers WHERE email=%s LIMIT 1",$snapshot['customer_email']
        ));
    }
    if(!$customer_id && function_exists('affwp_add_customer') && $wp_user_id && !empty($snapshot['customer_email'])){
        $new=affwp_add_customer(['user_id'=>$wp_user_id,'email'=>sanitize_email($snapshot['customer_email'])]);
        if($new && !is_wp_error($new)) $customer_id=(int)$new;
    }

    $affiliate_id=0;$source='';
    if($customer_id){
        $affiliate_id=(int)$wpdb->get_var($wpdb->prepare(
            "SELECT affiliate_id FROM {$wpdb->prefix}affiliate_wp_lifetime_customers WHERE affwp_customer_id=%d ORDER BY lifetime_customer_id DESC LIMIT 1",$customer_id
        ));
        if($affiliate_id)$source='LifetimeCustomers';
    }
    if(!$affiliate_id && !empty($snapshot['affwp_affiliate_id'])){
        $affiliate_id=(int)$snapshot['affwp_affiliate_id'];$source='Streams snapshot affiliate_id';
    }
    if(!$affiliate_id && !empty($snapshot['affwp_ref']) && function_exists('affwp_get_affiliate_id_by_ref')){
        $affiliate_id=(int)affwp_get_affiliate_id_by_ref($snapshot['affwp_ref']);$source='AffiliateWP ref';
    }
    if(!$affiliate_id && !empty($snapshot['affwp_visit_id'])){
        $affiliate_id=(int)$wpdb->get_var($wpdb->prepare(
            "SELECT affiliate_id FROM {$wpdb->prefix}affiliate_wp_visits WHERE visit_id=%d LIMIT 1",(int)$snapshot['affwp_visit_id']
        ));
        if($affiliate_id)$source='AffiliateWP visit';
    }
    if(!$affiliate_id) return;

    $existing=(int)$wpdb->get_var($wpdb->prepare(
        "SELECT referral_id FROM {$wpdb->prefix}affiliate_wp_referrals WHERE reference=%s AND context=%s AND affiliate_id=%d LIMIT 1",
        (string)$order_id,'woocommerce',$affiliate_id
    ));
    if($existing){
        $order->update_meta_data('_affwp_bridge_processed',gmdate('c'));
        $order->update_meta_data('_affwp_bridge_referral_id',$existing);
        $order->save(); return;
    }

    $commission=0.0;$items_meta=[];
    foreach($order->get_items('line_item') as $item){
        $product_id=(int)$item->get_product_id();
        $variation_id=(int)$item->get_variation_id();
        $item_total=(float)$item->get_total();
        $rate_raw=get_post_meta($product_id,'_affwp_commission_rate',true);
        $rate_type=get_post_meta($product_id,'_affwp_commission_rate_type',true) ?: 'percentage';
        if($rate_raw!=='' && is_numeric($rate_raw)){
            $rate=(float)$rate_raw;
            $item_commission=$rate_type==='flat' ? $rate : round($item_total*$rate/100,4);
        }elseif(function_exists('affwp_get_affiliate_rate')){
            $rate=(float)affwp_get_affiliate_rate($affiliate_id);
            $item_commission=round($item_total*$rate/100,4);
        }else{$item_commission=0.0;}
        $commission+=$item_commission;
        $items_meta[]=['product_id'=>$product_id,'variation_id'=>$variation_id,'item_total'=>$item_total,'commission'=>$item_commission];
    }
    if($commission<=0) return;

    $args=[
        'affiliate_id'=>$affiliate_id,'amount'=>$commission,'reference'=>(string)$order_id,
        'description'=>'Buzzjuice Streams order #'.$order_id,'context'=>'woocommerce',
        'status'=>'unpaid','customer_id'=>$customer_id
    ];
    $before_unpaid=(float)$wpdb->get_var($wpdb->prepare("SELECT unpaid_earnings FROM {$wpdb->prefix}affiliate_wp_affiliates WHERE affiliate_id=%d",$affiliate_id));
    $ref=affwp_add_referral($args);
    if(!$ref || is_wp_error($ref)) return;
    $after_unpaid=(float)$wpdb->get_var($wpdb->prepare("SELECT unpaid_earnings FROM {$wpdb->prefix}affiliate_wp_affiliates WHERE affiliate_id=%d",$affiliate_id));
    if(($after_unpaid-$before_unpaid)<0.01 && function_exists('affwp_increase_affiliate_unpaid_earnings')){
        @affwp_increase_affiliate_unpaid_earnings($affiliate_id,$commission);
    }

    $order->update_meta_data('_affwp_bridge_processed',gmdate('c'));
    $order->update_meta_data('_affwp_bridge_referral_id',(int)$ref);
    $order->update_meta_data('_affwp_bridge_affiliate_id',$affiliate_id);
    $order->update_meta_data('_affwp_bridge_affiliate_source',$source);
    $order->update_meta_data('_affwp_bridge_commission',wc_format_decimal($commission,4));
    $order->update_meta_data('_affwp_bridge_items',wp_json_encode($items_meta));
    $order->save();
},20,3);
