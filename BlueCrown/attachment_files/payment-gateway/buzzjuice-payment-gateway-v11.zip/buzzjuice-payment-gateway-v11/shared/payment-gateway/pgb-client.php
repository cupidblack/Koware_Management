<?php
/**
 * Generic PGB client helpers. No WordPress bootstrap is required here.
 */
function pgb_client_redirect_response($url,$status=200){
    if(!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    http_response_code($status);
    echo json_encode(['status'=>$status===200?200:'error','url'=>$url],JSON_UNESCAPED_SLASHES);
    exit;
}
