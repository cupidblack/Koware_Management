<?php
if (!defined('ABSPATH')) { exit; }
final class PGB_Auth {
    private $secret,$ttl;
    public function __construct(array $config){$this->secret=(string)($config['handoff_secret']??'');$this->ttl=(int)($config['handoff_ttl']??600);}
    public function enabled(){return strlen($this->secret)>=32;}
    public function make_handoff($wow_order_id,$wow_user_id,$ts=null){
        if(!$this->enabled()) throw new RuntimeException('PGB handoff secret is missing or too short.');
        $ts=$ts?:time(); $nonce=wp_generate_password(24,false,false);
        $payload=$wow_order_id.'|'.(int)$wow_user_id.'|'.$ts.'|'.$nonce;
        $sig=hash_hmac('sha256',$payload,$this->secret);
        return ['wow_order_id'=>$wow_order_id,'wow_user_id'=>(int)$wow_user_id,'ts'=>$ts,'nonce'=>$nonce,'sig'=>$sig];
    }
    public function verify($data){
        if(!$this->enabled()) return new WP_Error('pgb_secret','PGB handoff secret is not configured.');
        $oid=sanitize_text_field($data['wow_order_id']??''); $uid=(int)($data['wow_user_id']??0);
        $ts=(int)($data['ts']??0); $nonce=sanitize_text_field($data['nonce']??''); $sig=(string)($data['sig']??'');
        if(!$oid||!$uid||!$ts||!$nonce||!$sig) return new WP_Error('pgb_bad_handoff','Incomplete checkout handoff.');
        if(abs(time()-$ts)>$this->ttl) return new WP_Error('pgb_expired','Checkout handoff has expired.');
        $expected=hash_hmac('sha256',$oid.'|'.$uid.'|'.$ts.'|'.$nonce,$this->secret);
        if(!hash_equals($expected,$sig)) return new WP_Error('pgb_bad_signature','Invalid checkout handoff signature.');
        return ['wow_order_id'=>$oid,'wow_user_id'=>$uid,'ts'=>$ts,'nonce'=>$nonce];
    }
}
