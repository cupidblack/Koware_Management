<?php
if (!defined('ABSPATH')) { exit; }
final class PGB_Schema {
    public static function meta($key,$value){ return ['key'=>$key,'value'=>$value]; }
    public static function snapshot($snapshot){ return wp_json_encode($snapshot, JSON_UNESCAPED_SLASHES); }
    public static function order_meta(array $tx){
        $m=[
            '_buzzjuice_origin'=>'streams','wow_order_id'=>$tx['wow_order_id'],'wow_user_id'=>(int)$tx['userid'],
            'wow_post_id'=>(int)$tx['wow_post_id'],'qdw_order_id'=>(string)$tx['qdw_order_id'],
            'qdw_transaction_kind'=>(string)$tx['transaction_kind'],'_buzzjuice_pgb_version'=>'11.0.0'
        ];
        if(!empty($tx['snapshot'])) $m['_buzzjuice_affwp_context_snapshot']=self::snapshot($tx['snapshot']);
        if(!empty($tx['subscription'])) foreach($tx['subscription'] as $k=>$v) $m[$k]=$v;
        return $m;
    }
}
