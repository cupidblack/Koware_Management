<?php
if (!defined('ABSPATH')) { exit; }
final class PGB_Bootstrap {
    private static $instance;
    private $config,$logger,$auth,$manager;
    public static function instance(){return self::$instance ?: self::$instance=new self();}
    private function __construct(){
        $this->config=require dirname(__DIR__).'/config/pgb-config.php';
        $this->logger=new PGB_Logger($this->config);
        $this->auth=new PGB_Auth($this->config);
        $this->manager=new PGB_Manager($this->config,$this->logger,$this->auth);
        add_action('template_redirect',[$this,'route'],1);
        add_action('template_redirect',[$this,'redirect'],1000);
        add_action('woocommerce_payment_complete',[$this,'payment_complete'],999,1);
        add_action('woocommerce_order_status_completed',[$this,'completed'],999,1);
        add_action('woocommerce_order_status_failed',[$this,'failed'],999,1);
        add_action('woocommerce_order_status_cancelled',[$this,'cancelled'],999,1);
        add_action('admin_menu',[$this,'admin_menu'],20);
        add_action('admin_init',[$this,'admin_init']);
        add_action('wp_loaded',[$this,'cleanup'],999);
        $this->load_extensions();
    }
    private function load_extensions(){
        foreach(glob(dirname(__DIR__).'/addons/pgb-addon-*.php') ?: [] as $f) require_once $f;
        foreach(glob(dirname(__DIR__).'/integrations/pgb-int-*.php') ?: [] as $f) require_once $f;
    }
    public function redirect(){ $this->manager->redirect_after_purchase(); }
    public function route(){
        $path=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH);
        if(rtrim($path,'/')==='/pgb-checkout'){
            $this->manager->handle_checkout();
        }
    }
    public function payment_complete($id){$this->manager->payment_complete((int)$id);}
    public function completed($id){$this->manager->payment_complete((int)$id);}
    public function failed($id){$this->manager->payment_failed((int)$id,'failed');}
    public function cancelled($id){$this->manager->payment_failed((int)$id,'cancelled');}
    public function admin_menu(){
        add_menu_page('Buzzjuice','Buzzjuice','manage_options','buzzjuice','__return_false','dashicons-admin-generic',58);
        add_submenu_page('buzzjuice','Payment Gateways','Payment Gateways','manage_options','buzzjuice-payment-gateways',[$this,'settings_page']);
    }
    public function admin_init(){
        register_setting('bzj_pgb','bzj_pgb_streams_url',['sanitize_callback'=>'esc_url_raw']);
        register_setting('bzj_pgb','bzj_pgb_market_product_id',['sanitize_callback'=>'absint']);
        register_setting('bzj_pgb','bzj_pgb_pro_product_id_1',['sanitize_callback'=>'absint']);
        register_setting('bzj_pgb','bzj_pgb_pro_product_id_2',['sanitize_callback'=>'absint']);
        register_setting('bzj_pgb','bzj_pgb_pro_product_id_3',['sanitize_callback'=>'absint']);
        register_setting('bzj_pgb','bzj_pgb_pro_product_id_4',['sanitize_callback'=>'absint']);
        register_setting('bzj_pgb','bzj_pgb_wallet_product_id',['sanitize_callback'=>'absint']);
        register_setting('bzj_pgb','bzj_pgb_crowdfund_product_id',['sanitize_callback'=>'absint']);
    }
    public function settings_page(){
        if(!current_user_can('manage_options'))return;
        $fields=[
          'bzj_pgb_streams_url'=>'WoWonder/Streams URL','bzj_pgb_market_product_id'=>'Market Product ID',
          'bzj_pgb_pro_product_id_1'=>'PRO 1 Product/Variation ID','bzj_pgb_pro_product_id_2'=>'PRO 2 Product/Variation ID',
          'bzj_pgb_pro_product_id_3'=>'PRO 3 Product/Variation ID','bzj_pgb_pro_product_id_4'=>'PRO 4 Product/Variation ID',
          'bzj_pgb_wallet_product_id'=>'Wallet Product ID','bzj_pgb_crowdfund_product_id'=>'Crowdfund Product ID'];
        echo '<div class="wrap"><h1>Buzzjuice → Payment Gateways</h1><form method="post" action="options.php">';
        settings_fields('bzj_pgb');echo '<table class="form-table">';
        foreach($fields as $k=>$label){$v=get_option($k,'');$type=strpos($k,'url')!==false?'url':'number';echo '<tr><th><label for="'.esc_attr($k).'">'.esc_html($label).'</label></th><td><input class="regular-text" type="'.$type.'" id="'.esc_attr($k).'" name="'.esc_attr($k).'" value="'.esc_attr($v).'"></td></tr>';}
        echo '</table><p><strong>Security:</strong> set BZJ_PGB_HANDOFF_SECRET in the server environment. Do not store WooCommerce consumer keys/secrets in Streams.</p><p>Logging is controlled by BZJ_PGB_LOGGING and BZJ_PGB_LOG_LEVEL.</p>';
        submit_button('Save Payment Gateway Settings');echo '</form></div>';
    }
    public function cleanup(){ if(is_admin()) return; $this->logger->cleanup((int)$this->config['log_retention_days']);}
    public function logger(){return $this->logger;}
}
