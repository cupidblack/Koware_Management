<?php
if (!defined('ABSPATH')) { exit; }

final class PGB_Logger {
    const DEBUG='debug', INFO='info', WARNING='warning', ERROR='error', CRITICAL='critical';

    private $dir;
    private $enabled;
    private $min;
    private $rank = [self::DEBUG=>0,self::INFO=>1,self::WARNING=>2,self::ERROR=>3,self::CRITICAL=>4];

    public function __construct(array $config) {
        $this->dir = dirname(__DIR__) . '/log/';
        $this->enabled = !empty($config['logging_enabled']);
        $this->min = isset($config['log_level']) ? $config['log_level'] : self::INFO;
        if (!is_dir($this->dir)) { wp_mkdir_p($this->dir); }
        $index = $this->dir . 'index.html';
        if (!file_exists($index)) { @file_put_contents($index, ''); }
        $ht = $this->dir . '.htaccess';
        if (!file_exists($ht)) { @file_put_contents($ht, "Deny from all\n"); }
    }

    public function log($message, $level=self::INFO, array $context=[], $source=null) {
        if (!$this->enabled || ($this->rank[$level] ?? 0) < ($this->rank[$this->min] ?? 1)) return;
        $source = $source ?: __FILE__;
        $name = preg_replace('/[^A-Za-z0-9_.-]/', '-', basename(str_replace('\\','/',$source), '.php')) ?: 'unknown';
        $context = $this->redact($context);
        $line = '[' . gmdate('Y-m-d H:i:s') . ' UTC] [' . strtoupper($level) . '] ' . $message;
        if ($context) $line .= ' | ' . wp_json_encode($context, JSON_UNESCAPED_SLASHES);
        $line .= PHP_EOL;
        $file = $this->dir . $name . '.log';
        if (file_exists($file) && filesize($file) > 10485760) @rename($file, $file . '.' . gmdate('YmdHis'));
        @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
    }
    private function redact($data) {
        if (!is_array($data)) return $data;
        foreach ($data as $k=>$v) {
            $lk=strtolower((string)$k);
            if (preg_match('/password|secret|token|api[_-]?key|consumer|authorization|webhook|private[_-]?key|card|cvv|signature|cookie/', $lk)) {
                $data[$k]='[REDACTED]';
            } elseif (is_array($v)) {
                $data[$k]=$this->redact($v);
            }
        }
        return $data;
    }
    public function cleanup($days=30) {
        $cut=time()-($days*86400);
        foreach (glob($this->dir.'*.log.*') ?: [] as $f) if (@filemtime($f)<$cut) @unlink($f);
    }
}
