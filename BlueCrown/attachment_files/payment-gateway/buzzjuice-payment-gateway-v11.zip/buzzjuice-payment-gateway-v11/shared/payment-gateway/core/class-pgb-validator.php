<?php
if (!defined('ABSPATH')) { exit; }
final class PGB_Validator {
    public static function text($v,$max=255){ return substr(sanitize_text_field((string)$v),0,$max); }
    public static function email($v){ $v=sanitize_email((string)$v); return is_email($v)?$v:''; }
    public static function amount($v){ return is_numeric($v) && (float)$v>=0 ? round((float)$v,2) : null; }
    public static function currency($v){ $v=strtoupper(preg_replace('/[^A-Z]/','',(string)$v)); return preg_match('/^[A-Z]{3}$/',$v)?$v:''; }
    public static function id($v){ return max(0,(int)$v); }
    public static function kind($v){
        $v=strtoupper(preg_replace('/[^A-Z0-9_-]/','',(string)$v));
        return in_array($v,['PRO','WALLET','DONATE','PRODUCT','SALE','PURCHASE','MARKET'],true)?$v:'';
    }
}
