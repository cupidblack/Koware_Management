<?php
if (!defined('ABSPATH')) { exit; }

final class PGB_Manager {
    private $config,$logger,$auth,$db=null;
    public function __construct(array $config,PGB_Logger $logger,PGB_Auth $auth){$this->config=$config;$this->logger=$logger;$this->auth=$auth;}

    public function handle_checkout(){
        $verified=$this->auth->verify($_GET);
        if(is_wp_error($verified)) return $this->fail($verified->get_error_message(),400);
        $tx=$this->get_transaction($verified['wow_order_id']);
        if(!$tx) return $this->fail('Payment transaction was not found.',404);
        if((int)$tx['userid']!==(int)$verified['wow_user_id']) return $this->fail('Checkout identity mismatch.',403);

        if(!empty($tx['woo_order_id'])){
            $order=wc_get_order((int)$tx['woo_order_id']);
            if($order){
                $this->logger->log('Existing WooCommerce order reused',PGB_Logger::INFO,['wow_order_id'=>$tx['order_id'],'woo_order_id'=>$order->get_id()],__FILE__);
                wp_safe_redirect($order->get_checkout_payment_url(false));exit;
            }
        }
        $order=$this->create_order($tx);
        if(is_wp_error($order)) return $this->fail($order->get_error_message(),500);
        $this->update_transaction($tx['order_id'],$order->get_id(),'pending',$order->get_payment_method());
        wp_safe_redirect($order->get_checkout_payment_url(false));exit;
    }

    public function payment_failed($order_id,$status){
        $order=wc_get_order($order_id); if(!$order || $order->get_meta('_buzzjuice_origin',true)!=='streams') return;
        $txid=$order->get_meta('wow_order_id',true); if(!$txid) return;
        $this->update_transaction($txid,$order_id,$status,$order->get_payment_method());
    }

    public function redirect_after_purchase(){
        if(!function_exists('is_wc_endpoint_url') || !is_wc_endpoint_url('order-received')) return;
        $order_id=absint(get_query_var('order-received')); if(!$order_id) return;
        $order=wc_get_order($order_id); if(!$order || !in_array($order->get_status(),['processing','completed'],true)) return;
        if($order->get_meta('_buzzjuice_origin',true)!=='streams' || $order->get_meta('_pgb_post_payment_redirected',true)) return;
        $txid=$order->get_meta('wow_order_id',true); if(!$txid) return;
        $tx=$this->get_transaction($txid); if(!$tx) return;
        $base=$this->config['streams_url'];
        if(!$base) return;
        $kind=strtoupper($tx['kind']??''); $post=(int)($tx['wow_post_id']??0); $qdw=(string)($tx['qdw_order_id']??'');
        if($kind==='PRO'){
            $social=$this->config['buzzsocial_url'];
            $url=$qdw && $social ? $social.'/ProSuccess?paymode=pro' : $base.'/upgraded';
        }elseif($kind==='WALLET'){
            $url=$qdw && !empty($this->config['buzzsocial_url']) ? $this->config['buzzsocial_url'].'/ProSuccess' : $base.'/wallet/';
        }elseif($kind==='DONATE'){
            $url=$post>0 ? $base.'/show_fund/'.rawurlencode((string)$post) : $base.'/purchased';
        }else{
            $url=$base.'/purchased';
        }
        $order->update_meta_data('_pgb_post_payment_redirected',gmdate('c'));$order->save();
        wp_redirect(esc_url_raw(add_query_arg('nocache',time(),$url)));exit;
    }

    public function payment_complete($order_id){
        $order=wc_get_order($order_id); if(!$order) return;
        if($order->get_meta('_buzzjuice_origin',true)!=='streams') return;
        if($order->get_meta('_pgb_fulfilled_at',true)) return;
        $txid=$order->get_meta('wow_order_id',true);
        if(!$txid) return;
        $tx=$this->get_transaction($txid); if(!$tx) return;
        try{
            $this->update_transaction($txid,$order_id,'completed',$order->get_payment_method());
            do_action('pgb_payment_confirmed',$order_id,$tx,$order);
            $order->update_meta_data('_pgb_fulfilled_at',gmdate('c'));
            $order->save();
            $this->logger->log('Payment lifecycle completed',PGB_Logger::INFO,['order_id'=>$order_id,'wow_order_id'=>$txid],__FILE__);
        }catch(Throwable $e){
            $this->logger->log('Payment fulfillment failed',PGB_Logger::CRITICAL,['order_id'=>$order_id,'error'=>$e->getMessage()],__FILE__);
            $order->update_meta_data('_pgb_fulfillment_error',$e->getMessage());$order->save();
        }
    }

    private function create_order(array $tx){
        if(!function_exists('wc_create_order')) return new WP_Error('pgb_wc','WooCommerce is not loaded.');
        $order=wc_create_order(['customer_id'=>(int)$tx['wp_user_id']]);
        if(is_wp_error($order)) return $order;
        $order->set_currency($tx['currency_code']);
        $product_id=$this->resolve_product_id($tx);
        if(!$product_id){$order->delete(true);return new WP_Error('pgb_product','No WooCommerce product mapping exists for this payment type.');}
        $product=wc_get_product($product_id);
        if(!$product){$order->delete(true);return new WP_Error('pgb_product','Mapped WooCommerce product/variation does not exist.');}
        $qty=max(1,(int)$tx['product_units']);$unit=(float)$tx['product_price'];$total=(float)$tx['amount'];
        $item_id=$order->add_product($product,$qty,['subtotal'=>$unit*$qty,'total'=>$total]);
        if(!$item_id){$order->delete(true);return new WP_Error('pgb_item','Unable to add payment item to WooCommerce order.');}
        $billing=$this->billing_from_transaction($tx);
        if($billing) $order->set_address($billing,'billing');
        foreach(PGB_Schema::order_meta($tx) as $k=>$v) $order->update_meta_data($k,$v);
        $order->update_meta_data('_pgb_product_id',$product_id);
        $order->update_meta_data('_pgb_amount_authoritative',wc_format_decimal($total,2));
        $order->update_meta_data('_pgb_currency_authoritative',$tx['currency_code']);
        $order->set_payment_method('');
        $order->set_payment_method_title('WooCommerce Checkout');
        $order->calculate_totals(false);
        $order->set_status('pending');
        $order->save();
        $this->logger->log('Native WooCommerce order created',PGB_Logger::INFO,['wow_order_id'=>$tx['order_id'],'woo_order_id'=>$order->get_id(),'product_id'=>$product_id],__FILE__);
        return $order;
    }

    private function resolve_product_id($tx){
        $kind=strtoupper($tx['kind']);
        $post=(int)$tx['wow_post_id'];
        $map=$this->config['wow_product_ids'];
        if($kind==='PRO') return $map['pro_'.$post]??0;
        if($kind==='WALLET') return $map['wallet']??0;
        if($kind==='DONATE') return $map['crowdfund']??0;
        if(in_array($kind,['PRODUCT','SALE','PURCHASE','MARKET'],true)) return $map['market']??0;
        return 0;
    }

    private function billing_from_transaction($tx){
        $notes=$this->decode_notes($tx['notes']);$email=sanitize_email($notes['email']??'');
        if(!$email) return [];
        return ['first_name'=>sanitize_text_field($notes['first_name']??''),'last_name'=>sanitize_text_field($notes['last_name']??''),'email'=>$email,'phone'=>sanitize_text_field($notes['phone']??'')];
    }

    public function get_transaction($id){
        $db=$this->wow_db(); if(!$db) return null;
        $stmt=$db->prepare("SELECT userid,amount,order_id,kind,currency_code,notes,woo_order_id,payment_status,payment_method FROM Wo_Payment_Transactions WHERE order_id=? LIMIT 1");
        if(!$stmt)return null;$stmt->bind_param('s',$id);$stmt->execute();$r=$stmt->get_result()->fetch_assoc();$stmt->close();
        if(!$r)return null;
        $n=$this->decode_notes($r['notes']??'');
        return array_merge($r,$n,['order_id'=>$r['order_id'],'amount'=>(float)$r['amount'],'userid'=>(int)$r['userid'],'wp_user_id'=>(int)($n['wordpress_user_id']??0),'wow_post_id'=>(int)($n['wow_post_id']??0),'product_price'=>(float)($n['product_price']??$r['amount']),'product_units'=>(int)($n['product_units']??1),'product_owner_id'=>(int)($n['product_owner_id']??0),'subscription'=>(array)($n['subscription']??[]),'snapshot'=>(array)($n['snapshot']??[])]);
    }
    private function decode_notes($notes){
        $notes=(string)$notes;if(strpos($notes,'PGB11:')===0)$notes=substr($notes,6);
        $v=json_decode($notes,true);return is_array($v)?$v:[];
    }
    private function update_transaction($wow_order_id,$woo_id,$status,$method=''){
        $db=$this->wow_db();if(!$db)return false;
        $stmt=$db->prepare("UPDATE Wo_Payment_Transactions SET payment_status=?,payment_method=?,woo_order_id=?,transaction_dt=NOW() WHERE order_id=?");
        if(!$stmt)return false;$stmt->bind_param('ssis',$status,$method,$woo_id,$wow_order_id);$ok=$stmt->execute();$stmt->close();return $ok;
    }
    private function wow_db(){
        if($this->db!==null)return $this->db;
        $c=$this->config['wowonder_db'];if(empty($c['host'])||empty($c['user'])||empty($c['name'])){ $this->logger->log('WoWonder DB configuration missing',PGB_Logger::ERROR,[],__FILE__);return null;}
        $db=@new mysqli($c['host'],$c['user'],$c['pass'],$c['name']);if($db->connect_errno){$this->logger->log('WoWonder DB connection failed',PGB_Logger::ERROR,['error'=>$db->connect_error],__FILE__);return null;}
        $db->set_charset('utf8mb4');$this->db=$db;return $db;
    }
    private function fail($message,$status){$this->logger->log('Checkout request rejected',PGB_Logger::WARNING,['status'=>$status,'message'=>$message],__FILE__);status_header($status);wp_die(esc_html($message),'Buzzjuice Payment Gateway',['response'=>$status]);}
}
