<?php
if (!defined('ABSPATH')) { exit; }

return [
    'version' => '11.0.0',
    'logging_enabled' => (bool) (getenv('BZJ_PGB_LOGGING') !== false ? filter_var(getenv('BZJ_PGB_LOGGING'), FILTER_VALIDATE_BOOLEAN) : true),
    'log_level' => getenv('BZJ_PGB_LOG_LEVEL') ?: 'info',
    'log_retention_days' => max(1, (int) (getenv('BZJ_PGB_LOG_RETENTION_DAYS') ?: 30)),
    'handoff_ttl' => max(60, (int) (getenv('BZJ_PGB_HANDOFF_TTL') ?: 600)),
    'handoff_secret' => getenv('BZJ_PGB_HANDOFF_SECRET') ?: (defined('BUZZ_SSO_SECRET') ? BUZZ_SSO_SECRET : ''),
    'streams_url' => rtrim(getenv('BZJ_STREAMS_URL') ?: get_option('bzj_pgb_streams_url', ''), '/'),
    'store_url' => rtrim(getenv('BZJ_STORE_URL') ?: home_url('/'), '/'),
    'buzzsocial_url' => rtrim(getenv('BZJ_BUZZSOCIAL_URL') ?: '', '/'),
    'wowonder_db' => [
        'host' => getenv('WOWONDER_DB_HOST') ?: '',
        'user' => getenv('WOWONDER_DB_USER') ?: '',
        'pass' => getenv('WOWONDER_DB_PASS') ?: '',
        'name' => getenv('WOWONDER_DB_NAME') ?: '',
    ],
    'wow_product_ids' => [
        'market' => (int) get_option('bzj_pgb_market_product_id', 0),
        'pro_1' => (int) get_option('bzj_pgb_pro_product_id_1', 0),
        'pro_2' => (int) get_option('bzj_pgb_pro_product_id_2', 0),
        'pro_3' => (int) get_option('bzj_pgb_pro_product_id_3', 0),
        'pro_4' => (int) get_option('bzj_pgb_pro_product_id_4', 0),
        'wallet' => (int) get_option('bzj_pgb_wallet_product_id', 0),
        'crowdfund' => (int) get_option('bzj_pgb_crowdfund_product_id', 0),
    ],
];
