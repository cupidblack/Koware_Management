<?php
/**
 * Buzzjuice Payment Gateway Bridge - WoWonder/Streams client.
 * This file intentionally does NOT load WordPress.
 */
require_once dirname(__DIR__, 2) . '/shared/db_helpers.php';

if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
require_once dirname(__DIR__, 2) . '/streams/config.php';
require_once dirname(__DIR__, 2) . '/streams/init.php';

function pgb_stream_log($message,$context=[]){
    $dir=dirname(__DIR__,2).'/shared/payment-gateway/log/';
    if (!is_dir($dir)) @mkdir($dir,0755,true);
    $line='['.gmdate('Y-m-d H:i:s').' UTC] '.$message;
    if($context) $line.=' | '.json_encode($context,JSON_UNESCAPED_SLASHES);
    @file_put_contents($dir.'pgb-client-streams.log',$line.PHP_EOL,FILE_APPEND|LOCK_EX);
}
function pgb_stream_json($status,$data=[]){
    if(!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    http_response_code($status);
    echo json_encode($data,JSON_UNESCAPED_SLASHES);
    exit;
}
if(empty($wo['loggedin'])){
    pgb_stream_json(401,['status'=>'error','message'=>'Authentication required.']);
}
$db=$sqlConnect;
if(!$db) pgb_stream_json(500,['status'=>'error','message'=>'Database connection unavailable.']);

$user_id=(int)($wo['user']['user_id']??0);
$email=filter_var($wo['user']['email']??'',FILTER_VALIDATE_EMAIL);
if(!$user_id||!$email) pgb_stream_json(400,['status'=>'error','message'=>'Invalid user session.']);

$amount=(float)($_POST['amount']??0);
$product_price=(float)($_POST['product_price']??0);
$units=max(1,(int)($_POST['product_units']??1));
$product_name=trim((string)($_POST['product_name']??''));
$product_owner_id=(int)($_POST['product_owner_id']??0);
$kind=strtoupper(preg_replace('/[^A-Z0-9_-]/','',(string)($_POST['transaction_kind']??'')));
$currency=strtoupper(preg_replace('/[^A-Z]/','',(string)($_POST['wow_currency_code']??'')));
$wow_post_id=(int)($_POST['wow_post_id']??0);
$address_id=(int)($_POST['address_id']??0);
$qdw_order_id=trim((string)($_POST['qdw_order_id']??''));
$qdw_transaction_kind=trim((string)($_POST['qdw_transaction_kind']??''));
$wordpress_user_id=0;

if($amount<=0||$product_price<0||$product_name===''||!preg_match('/^[A-Z]{3}$/',$currency)){
    pgb_stream_json(400,['status'=>'error','message'=>'Invalid payment data.']);
}
$map=[
 'PRO'=>[(int)($wo['config']['wow_pro_package_id']??0),(int)($wo['config']['wow_pro_package_id_2']??0),(int)($wo['config']['wow_pro_package_id_3']??0),(int)($wo['config']['wow_pro_package_id_4']??0)],
 'WALLET'=>[(int)($wo['config']['wow_wallet_topup_id']??0)],
 'DONATE'=>[(int)($wo['config']['wow_crowdfund_id']??0)],
 'PRODUCT'=>[(int)($wo['config']['wow_market_id']??0)],
 'MARKET'=>[(int)($wo['config']['wow_market_id']??0)],
];
if(!isset($map[$kind])) pgb_stream_json(400,['status'=>'error','message'=>'Unsupported transaction kind.']);

if($db->query("SHOW COLUMNS FROM Wo_Users LIKE 'wp_user_id'")){
    $stmt=$db->prepare("SELECT wp_user_id FROM Wo_Users WHERE user_id=? LIMIT 1");
    if($stmt){$stmt->bind_param('i',$user_id);$stmt->execute();$r=$stmt->get_result()->fetch_assoc();$wordpress_user_id=(int)($r['wp_user_id']??0);$stmt->close();}
}
if(!$wordpress_user_id) pgb_stream_log('WordPress user mapping missing',['wow_user_id'=>$user_id]);

$subscription=[];
if($kind==='PRO'){
    foreach(($wo['pro_packages']??[]) as $package){
        if((int)($package['id']??0)===$wow_post_id){
            $subscription=[
                '_subscription_period'=>(string)($package['time']??'month'),
                '_subscription_interval'=>max(1,(int)($package['count']??1)),
                '_subscription_length'=>max(0,(int)($package['time_count']??0))
            ];
            break;
        }
    }
    if(!$subscription) $subscription=['_subscription_period'=>'month','_subscription_interval'=>1,'_subscription_length'=>0];
}

$snapshot=[];
foreach(['affwp_ref','affwp_visit','affwp_visit_id','affwp_affiliate_id','affwp_campaign','affwp_coupon','affwp_referrer'] as $k){
    if(isset($_COOKIE[$k]) && $_COOKIE[$k]!=='') $snapshot[$k]=(string)$_COOKIE[$k];
}
$snapshot['http_referer']=$_SERVER['HTTP_REFERER']??'';
$snapshot['timestamp']=gmdate('c');
$snapshot['wp_user_id']=$wordpress_user_id;
$snapshot['customer_email']=$email;
$snapshot['snapshot_version']='3';

$wow_order_id='wow_'.bin2hex(random_bytes(12));
$notes=[
 'pgb_version'=>'11.0.0','product_name'=>$product_name,'product_price'=>$product_price,'product_units'=>$units,
 'product_owner_id'=>$product_owner_id,'wow_post_id'=>$wow_post_id,'address_id'=>$address_id,
 'wordpress_user_id'=>$wordpress_user_id,'wow_user_id'=>$user_id,'email'=>$email,'first_name'=>(string)($wo['user']['first_name']??''),'last_name'=>(string)($wo['user']['last_name']??''),'phone'=>(string)($wo['user']['phone_number']??''),'qdw_order_id'=>$qdw_order_id,
 'qdw_transaction_kind'=>$qdw_transaction_kind,'subscription'=>$subscription,'snapshot'=>$snapshot
];
$notes_json='PGB11:'.json_encode($notes,JSON_UNESCAPED_SLASHES);

$stmt=$db->prepare("INSERT INTO Wo_Payment_Transactions (userid,amount,order_id,kind,currency_code,notes) VALUES (?,?,?,?,?,?)");
if(!$stmt) pgb_stream_json(500,['status'=>'error','message'=>'Unable to prepare transaction.']);
$stmt->bind_param('idssss',$user_id,$amount,$wow_order_id,$kind,$currency,$notes_json);
if(!$stmt->execute()){
    $err=$stmt->error;$stmt->close();pgb_stream_log('Transaction insert failed',['error'=>$err]);
    pgb_stream_json(500,['status'=>'error','message'=>'Unable to record payment transaction.']);
}
$stmt->close();

$verify=$db->prepare("SELECT order_id FROM Wo_Payment_Transactions WHERE order_id=? LIMIT 1");
$verify->bind_param('s',$wow_order_id);$verify->execute();$row=$verify->get_result()->fetch_assoc();$verify->close();
if(empty($row)) pgb_stream_json(500,['status'=>'error','message'=>'Transaction verification failed.']);

$secret=getenv('BZJ_PGB_HANDOFF_SECRET');
if(!$secret && function_exists('bzj_get_sso_secret')) $secret=bzj_get_sso_secret();
if(strlen((string)$secret)<32) pgb_stream_json(500,['status'=>'error','message'=>'Payment gateway security secret is not configured.']);

$ts=time();$nonce=bin2hex(random_bytes(12));
$payload=$wow_order_id.'|'.$user_id.'|'.$ts.'|'.$nonce;
$sig=hash_hmac('sha256',$payload,$secret);
$store=rtrim((string)($wo['config']['wow_store_url']??getenv('BZJ_STORE_URL')??''),'/');
if(!$store) pgb_stream_json(500,['status'=>'error','message'=>'WooCommerce store URL is not configured.']);

$checkout=$store.'/pgb-checkout/';
$url=$checkout.'?wow_order_id='.rawurlencode($wow_order_id).'&wow_user_id='.$user_id.'&ts='.$ts.'&nonce='.rawurlencode($nonce).'&sig='.rawurlencode($sig);
pgb_stream_log('Checkout handoff created',['wow_order_id'=>$wow_order_id,'wow_user_id'=>$user_id,'kind'=>$kind]);
pgb_stream_json(200,['status'=>200,'url'=>$url,'wow_order_id'=>$wow_order_id]);
