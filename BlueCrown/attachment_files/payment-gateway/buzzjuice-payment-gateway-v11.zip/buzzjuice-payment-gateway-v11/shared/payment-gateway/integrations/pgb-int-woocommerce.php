<?php
if (!defined('ABSPATH')) { exit; }
/* WooCommerce lifecycle integration is registered by the MU bootstrap. */
