<?php
if (!defined('ABSPATH')) { exit; }
/**
 * Integration boundary only. Existing Jewel business rules should be placed here.
 * No rebate percentage is invented by this bridge.
 */
add_action('pgb_payment_confirmed', function($order_id,$tx,$order){
    do_action('pgb_jewel_payment_complete',$order_id,$tx,$order);
},90,3);
