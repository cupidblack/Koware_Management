# Buzzjuice Payment Gateway Bridge v11

## Architecture

WoWonder/Streams -> durable `Wo_Payment_Transactions` record -> signed browser handoff -> WordPress MU plugin -> native `wc_create_order()` -> WooCommerce native `order-pay` URL -> payment -> `woocommerce_payment_complete` -> PGB addons/integrations -> WoWonder fulfillment.

The Streams server never calls `https://buzzjuice.net/wp-json/wc/v3/...` for order creation.

## Required environment variables

- `BZJ_PGB_HANDOFF_SECRET` — at least 32 random characters; shared by Streams and WordPress.
- `BZJ_STREAMS_URL`
- `BZJ_STORE_URL`
- `WOWONDER_DB_HOST`
- `WOWONDER_DB_USER`
- `WOWONDER_DB_PASS`
- `WOWONDER_DB_NAME`
- optional: `BZJ_PGB_LOGGING`, `BZJ_PGB_LOG_LEVEL`, `BZJ_PGB_LOG_RETENTION_DAYS`, `BZJ_PGB_HANDOFF_TTL`

Generate a secret with:

`openssl rand -base64 48`

Do not put WooCommerce consumer keys/secrets in Streams. They are no longer needed by the bridge.

## Deployment layout

Only this file is directly inside `wp-content/mu-plugins/`:

`wp-content/mu-plugins/bzj-payment-gateway.php`

Everything else is under:

`shared/payment-gateway/`

## WooCommerce mappings

Configure the product/variation IDs under:

WordPress Admin -> Buzzjuice -> Payment Gateways

PRO 1-4 should point to the actual subscription product/variation IDs used by WooCommerce Subscriptions.

## Migration

1. Back up database and files.
2. Deploy `shared/payment-gateway`.
3. Deploy the single MU plugin.
4. Configure the server environment variables.
5. Configure product IDs under Buzzjuice -> Payment Gateways.
6. Replace `streams/assets/wow-pgb/wow-pgb_init.php` with the compatibility wrapper supplied here.
7. Stop loading the old `wow-pgb_sync.php` and `buzzjuice-affwp-order-complete.php`.
8. Disable the old WooCommerce webhook endpoint after successful staging tests.
9. Do not delete the old files until the migration has passed all tests.
10. Test PRO, wallet, crowdfund and market/product payments, failed payment, duplicate refresh, subscription creation, AffiliateWP referral creation and post-payment redirect.

## Important

The previous webhook contained a hard-coded WooCommerce webhook secret. Rotate that secret before production and do not retain it in source control.

The previous system also created some WoWonder purchase records before payment. v11 moves those fulfillment actions to the payment-complete lifecycle so an unpaid checkout does not become a completed purchase.
