<?php
/**
 * LEGACY DISABLED.
 *
 * v11 no longer depends on a WooCommerce webhook for payment completion.
 * WordPress executes the bridge on woocommerce_payment_complete and updates
 * WoWonder directly. Keep this file during migration only; do not configure
 * WooCommerce to call it after v11 is verified.
 */
http_response_code(410);
header('Content-Type: text/plain; charset=utf-8');
exit('Buzzjuice Payment Gateway webhook retired in v11.');
