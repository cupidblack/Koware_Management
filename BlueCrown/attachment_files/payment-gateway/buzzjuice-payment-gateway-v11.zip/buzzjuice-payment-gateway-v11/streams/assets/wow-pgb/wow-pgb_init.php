<?php
/**
 * Compatibility entry point.
 * The legacy Streams → WooCommerce REST/cURL implementation has been retired.
 */
require_once dirname(__DIR__, 2) . '/config.php';
require_once dirname(__DIR__, 2) . '/init.php';
require_once dirname(__DIR__, 3) . '/shared/payment-gateway/pgb-client-streams.php';
