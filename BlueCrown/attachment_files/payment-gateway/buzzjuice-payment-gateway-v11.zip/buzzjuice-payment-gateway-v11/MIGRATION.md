# v11 migration plan

## Remove/disable

After staging validation, stop loading:

- `wp-content/mu-plugins/buzzjuice-affwp-order-complete.php`
- `wp-content/plugins/blue-crown-wp/wow-pgb_sync/wow-pgb_sync.php`
- the old WooCommerce webhook pointing to `streams/wow-pgb_webhook.php`

The supplied `streams/wow-pgb_webhook.php` is replaced by a 410 retirement stub.

Do not delete the legacy PHP files until the production cut-over is verified.

## Modify

### `streams/assets/wow-pgb/wow-pgb_init.php`
Replace the old 752-line REST/cURL implementation with the compatibility wrapper supplied in this package.

### `streams/admin-panel/pages/payment-settings/content.phtml`
Keep:
- `wow_payment`
- `wow_store_url`
- `wow_market_id`
- `wow_pro_package_id`
- `wow_pro_package_id_2`
- `wow_pro_package_id_3`
- `wow_pro_package_id_4`
- `wow_wallet_topup_id`
- `wow_crowdfund_id`

Remove from the Buzzjuice/WooCommerce bridge section:
- `wow_api_url`
- `wow_api_key`
- `wow_api_secret`
- `wow_webhook_secret`

Those credentials are no longer part of the Streams → WordPress order path.

The existing form AJAX handler that saves the retained fields can remain unchanged.

### `streams/themes/sunshine/layout/extra_js/content.phtml`
No architectural change is required if the existing payment button continues to POST to `wow-pgb_init.php`. The endpoint contract remains JSON `{status:200,url:"..."}`.

If the current JS checks WooCommerce REST-specific response fields, change it to redirect to the returned `url`.

### `streams/themes/sunshine/layout/modals/pay-go-pro.phtml`
No architectural change is required if it already posts the PRO fields to `wow-pgb_init.php`.

## WordPress

Install exactly one file directly in `wp-content/mu-plugins/`:

`bzj-payment-gateway.php`

All other PGB files belong under `shared/payment-gateway/`.

## Security

The legacy `streams/wow-pgb_webhook.php` contains a hard-coded webhook secret in the current repository. Rotate that WooCommerce webhook secret before production and remove the old webhook after v11 is verified.

Create the new handoff secret with:

`openssl rand -base64 48`

Expose it to both PHP environments as `BZJ_PGB_HANDOFF_SECRET`.

## DNS/cURL issue

The cPanel `curl: (6) Could not resolve host: buzzjuice.net` result is sufficient reason to remove the Streams→same-host REST dependency. It does not prove that every PHP process on the server can never resolve the domain, but the native WordPress approach removes that dependency entirely.
