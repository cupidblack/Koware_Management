<?php
defined('ABSPATH') || exit;
final class BZJ_PGB_Jewel {
    public static function boot(){}
    public static function process($order){
        if($order->get_meta('_bzj_pgb_jewel_done'))return;
        $wp_user_id=(int)$order->get_user_id(); if(!$wp_user_id)return;
        $roles=(array)(new WP_User($wp_user_id))->roles;
        if(!in_array('jewel_affiliate',$roles,true))return;
        $amount=(float)$order->get_total(); if($amount<=0)return;
        # Keep Jewel calculation isolated: the existing webhook/integration can consume this deterministic event.
        $order->update_meta_data('_bzj_pgb_jewel_base_amount',(string)$amount);
        $order->update_meta_data('_bzj_pgb_jewel_done',gmdate('c')); $order->save();
        do_action('bzj_pgb_jewel_affiliate_rebate',$order,$amount);
        BZJ_PGB_Log::write('pgb-int-jewel-affiliate','rebate_event',array('order_id'=>$order->get_id(),'user_id'=>$wp_user_id,'base_amount'=>$amount));
    }
}