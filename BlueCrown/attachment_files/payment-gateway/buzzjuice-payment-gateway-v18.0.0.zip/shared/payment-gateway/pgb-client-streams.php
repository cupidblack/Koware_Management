<?php
/* Buzzjuice Streams payment client: no WordPress functions and no cURL. */
if (empty($wo['loggedin'])) { http_response_code(401); exit(json_encode(array('status'=>'error','message'=>'Login required.'))); }
header('Content-Type: application/json');

function bzj_pgb_secret_streams(){
    $s=getenv('BZJ_PGB_SECRET');
    if($s)return $s;
    if(function_exists('bzj_get_sso_secret'))return bzj_get_sso_secret().'|payment-gateway';
    return hash('sha256',__FILE__);
}
function bzj_pgb_table_streams(){return '`Wo_BZJ_PGB_Transactions`';}
function bzj_pgb_db_streams(){
    global $sqlConnect;
    if($sqlConnect)return $sqlConnect;
    return function_exists('get_wowonder_db')?get_wowonder_db():false;
}
function bzj_pgb_ensure_streams_table(){
    $db=bzj_pgb_db_streams(); if(!$db)throw new Exception('WoWonder database connection unavailable.');
    $sql="CREATE TABLE IF NOT EXISTS ".bzj_pgb_table_streams()." (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, token_hash CHAR(64) NOT NULL, signature_hash CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'pending', wow_order_id VARCHAR(80) NOT NULL, wow_user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
    wp_user_id BIGINT UNSIGNED NOT NULL DEFAULT 0, transaction_kind VARCHAR(40) NOT NULL, product_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
    variation_id BIGINT UNSIGNED NOT NULL DEFAULT 0, product_name VARCHAR(255) NOT NULL DEFAULT '', quantity INT UNSIGNED NOT NULL DEFAULT 1,
    amount DECIMAL(20,8) NOT NULL DEFAULT 0, source_currency VARCHAR(12) NOT NULL DEFAULT '', requested_currency VARCHAR(12) NOT NULL DEFAULT '',
    billing_email VARCHAR(320) NOT NULL DEFAULT '', payload LONGTEXT NULL, woo_order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
    claimed_at DATETIME NULL, paid_at DATETIME NULL, fulfilled_at DATETIME NULL, attempts INT UNSIGNED NOT NULL DEFAULT 0,
    last_error TEXT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
    PRIMARY KEY(id), UNIQUE KEY uq_token(token_hash), UNIQUE KEY uq_wow(wow_order_id), KEY idx_status(status), KEY idx_woo(woo_order_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    if(!$db->query($sql))throw new Exception($db->error);
}
try{
    bzj_pgb_ensure_streams_table();
    $uid=(int)$wo['user']['user_id'];
    $wpid=0;
    $q=$sqlConnect->query("SELECT wp_user_id FROM ".T_USERS." WHERE user_id=".$uid." LIMIT 1");
    if($q&&$r=$q->fetch_assoc())$wpid=(int)($r['wp_user_id']??0);
    if(!$wpid)throw new Exception('WordPress user mapping is missing.');
    $kind=strtoupper(preg_replace('/[^A-Z0-9_-]/','',$_POST['transaction_kind']??''));
    $allowed=array('PRO','WALLET','DONATE','PRODUCT','SALE','PURCHASE');
    if(!in_array($kind,$allowed,true))throw new Exception('Invalid transaction kind.');
    $amount=(float)($_POST['amount']??0); if($amount<=0)throw new Exception('Invalid amount.');
    $name=trim((string)($_POST['product_name']??'Buzzjuice purchase'));
    $wow_post_id=(int)($_POST['wow_post_id']??0);
    $variation_id=(int)($_POST['variation_id']??0);
    $product_id=(int)($_POST['product_id']??0);
    $qty=max(1,(int)($_POST['product_units']??1));
    $currency=strtoupper(preg_replace('/[^A-Z]/','',$_POST['wow_currency_code']??''));
    $token=bin2hex(random_bytes(32)); $sig=hash_hmac('sha256',$token,bzj_pgb_secret_streams());
    $wow_order_id='wow_'.bin2hex(random_bytes(12)); $now=gmdate('Y-m-d H:i:s');
    $db=bzj_pgb_db_streams();
    $payload=json_encode(array('post'=>$_POST,'wp_user_id'=>$wpid),JSON_UNESCAPED_SLASHES);
    $st=$db->prepare("INSERT INTO ".bzj_pgb_table_streams()." (token_hash,signature_hash,status,wow_order_id,wow_user_id,wp_user_id,transaction_kind,product_id,variation_id,product_name,quantity,amount,source_currency,requested_currency,billing_email,payload,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    if(!$st)throw new Exception($db->error);
    # bind_param arguments must be variables.
    $th=hash('sha256',$token);$sh=hash('sha256',$sig);$status='pending';$email=(string)$wo['user']['email'];
    $st=$db->prepare("INSERT INTO ".bzj_pgb_table_streams()." (token_hash,signature_hash,status,wow_order_id,wow_user_id,wp_user_id,transaction_kind,product_id,variation_id,product_name,quantity,amount,source_currency,requested_currency,billing_email,payload,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    $st->bind_param('ssssiiisiiidssssss',$th,$sh,$status,$wow_order_id,$uid,$wpid,$kind,$product_id,$variation_id,$name,$qty,$amount,$currency,$currency,$email,$payload,$now,$now);
    if(!$st->execute())throw new Exception($st->error);
    $base=rtrim($wo['config']['site_url'],'/');
    $url=$base.'/?bzj_pgb=checkout&token='.rawurlencode($token).'&sig='.rawurlencode($sig);
    echo json_encode(array('status'=>200,'url'=>$url,'wow_order_id'=>$wow_order_id));
}catch(Throwable $e){http_response_code(500);echo json_encode(array('status'=>'error','message'=>$e->getMessage()));}
