<?php
defined('ABSPATH') || exit;
final class BZJ_PGB_Log {
    public static function write($file,$event,$ctx=array(),$level='info'){
        if(!get_option('bzj_pgb_debug',0)) return;
        $dir=BZJ_PGB_LOG_DIR; if(!is_dir($dir)) wp_mkdir_p($dir);
        if(!is_dir($dir)||!is_writable($dir))return;
        $entry=array('time'=>gmdate('c'),'level'=>$level,'event'=>$event,'context'=>self::redact($ctx));
        file_put_contents($dir.'/'.preg_replace('/[^A-Za-z0-9._-]/','_',basename($file,'.log')).'.log',wp_json_encode($entry,JSON_UNESCAPED_SLASHES).PHP_EOL,FILE_APPEND|LOCK_EX);
    }
    private static function redact($v){
        if(is_array($v)){ $o=array(); foreach($v as $k=>$x){$o[$k]=preg_match('/secret|token|cookie|authorization|password|signature/i',(string)$k)?'[redacted]':self::redact($x);} return $o;}
        return is_object($v)?self::redact((array)$v):$v;
    }
}