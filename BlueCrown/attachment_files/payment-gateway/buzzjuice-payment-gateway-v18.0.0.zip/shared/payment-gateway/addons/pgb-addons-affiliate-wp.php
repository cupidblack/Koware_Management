<?php
defined('ABSPATH') || exit;
final class BZJ_PGB_AffiliateWP {
    public static function boot(){ }
    public static function process($order){
        if(!function_exists('affiliate_wp'))return;
        if($order->get_meta('_bzj_pgb_affwp_done'))return;
        $affiliate_id=0;
        if(function_exists('affwp_get_affiliate_id')) $affiliate_id=(int)affwp_get_affiliate_id($order->get_user_id());
        if(!$affiliate_id){
            $customer_id=function_exists('affwp_get_customer_id')?(int)affwp_get_customer_id(array('user_id'=>$order->get_user_id(),'email'=>$order->get_billing_email())):0;
            if($customer_id && function_exists('affwp_get_customer_meta')) $affiliate_id=(int)affwp_get_customer_meta($customer_id,'referring_affiliate_id',true);
        }
        if(!$affiliate_id){
            $email=$order->get_billing_email();
            if($email && function_exists('affwp_get_affiliate_id')) $affiliate_id=(int)affwp_get_affiliate_id($email);
        }
        if(!$affiliate_id){BZJ_PGB_Log::write('pgb-addons-affiliate-wp','no_affiliate',array('order_id'=>$order->get_id()));return;}
        $amount=(float)$order->get_subtotal();
        if($amount<=0)return;
        $settings=get_option('affwp_settings',array());
        $rate=(float)($settings['referral_rate']??0);
        $type=$settings['referral_rate_type']??'percentage';
        $commission=$type==='flat_rate'?$rate:$amount*($rate/100);
        if($commission<=0)return;
        global $wpdb;
        $exists=$wpdb->get_var($wpdb->prepare("SELECT referral_id FROM {$wpdb->prefix}affiliate_wp_referrals WHERE reference=%s AND context='woocommerce' AND affiliate_id=%d LIMIT 1",$order->get_id(),$affiliate_id));
        if($exists){$order->update_meta_data('_bzj_pgb_affwp_done',gmdate('c'));$order->save();return;}
        $customer_id=function_exists('affwp_get_customer_id')?(int)affwp_get_customer_id(array('user_id'=>$order->get_user_id(),'email'=>$order->get_billing_email())):0;
        if(function_exists('affwp_insert_referral')){
            $ref=affwp_insert_referral(array(
                'affiliate_id'=>$affiliate_id,'amount'=>$commission,'description'=>'Buzzjuice order #'.$order->get_order_number(),
                'reference'=>(string)$order->get_id(),'context'=>'woocommerce','status'=>'unpaid',
                'currency'=>$order->get_currency(),'custom'=>$customer_id?'customer_id='.$customer_id:''
            ));
            if($ref){$order->update_meta_data('_bzj_pgb_affwp_referral_id',(int)$ref);$order->update_meta_data('_bzj_pgb_affwp_done',gmdate('c'));$order->save();}
        }
    }
}