<?php
defined('ABSPATH') || exit;
final class BZJ_PGB_Client {
    const TABLE='Wo_BZJ_PGB_Transactions';

    public static function boot(){
        self::ensure_table();
        add_action('woocommerce_payment_complete',array(__CLASS__,'payment_complete'),999,2);
        add_action('woocommerce_order_status_processing',array(__CLASS__,'order_lifecycle'),999,1);
        add_action('woocommerce_order_status_completed',array(__CLASS__,'order_lifecycle'),999,1);
        add_action('woocommerce_subscription_status_active',array(__CLASS__,'subscription_active'),999,1);
    }

    private static function db(){
        if(!function_exists('get_wowonder_db')) require_once ABSPATH.'shared/db_helpers.php';
        return function_exists('get_wowonder_db')?get_wowonder_db():false;
    }
    public static function ensure_table(){
        $db=self::db(); if(!$db)return false;
        $sql="CREATE TABLE IF NOT EXISTS `".self::TABLE."` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `token_hash` CHAR(64) NOT NULL, `signature_hash` CHAR(64) NOT NULL,
        `status` VARCHAR(30) NOT NULL DEFAULT 'pending', `wow_order_id` VARCHAR(80) NOT NULL,
        `wow_user_id` BIGINT UNSIGNED NOT NULL DEFAULT 0, `wp_user_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
        `transaction_kind` VARCHAR(40) NOT NULL, `product_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
        `variation_id` BIGINT UNSIGNED NOT NULL DEFAULT 0, `product_name` VARCHAR(255) NOT NULL DEFAULT '',
        `quantity` INT UNSIGNED NOT NULL DEFAULT 1, `amount` DECIMAL(20,8) NOT NULL DEFAULT 0,
        `source_currency` VARCHAR(12) NOT NULL DEFAULT '', `requested_currency` VARCHAR(12) NOT NULL DEFAULT '',
        `billing_email` VARCHAR(320) NOT NULL DEFAULT '', `payload` LONGTEXT NULL,
        `woo_order_id` BIGINT UNSIGNED NOT NULL DEFAULT 0, `claimed_at` DATETIME NULL,
        `paid_at` DATETIME NULL, `fulfilled_at` DATETIME NULL, `attempts` INT UNSIGNED NOT NULL DEFAULT 0,
        `last_error` TEXT NULL, `created_at` DATETIME NOT NULL, `updated_at` DATETIME NOT NULL,
        PRIMARY KEY(`id`), UNIQUE KEY `uq_token`(`token_hash`), UNIQUE KEY `uq_wow`(`wow_order_id`),
        KEY `idx_status`(`status`), KEY `idx_woo`(`woo_order_id`), KEY `idx_wp`(`wp_user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        return (bool)$db->query($sql);
    }
    private static function secret(){
        $s=get_option('bzj_pgb_secret','');
        if($s!=='')return $s;
        if(!function_exists('bzj_get_sso_secret')) require_once ABSPATH.'shared/db_helpers.php';
        return function_exists('bzj_get_sso_secret')?bzj_get_sso_secret().'|payment-gateway':wp_salt('auth').'|payment-gateway';
    }
    private static function hash_token($t){return hash('sha256',$t);}
    private static function sign($token){return hash_hmac('sha256',$token,self::secret());}
    private static function row($hash){
        $db=self::db(); if(!$db)return null;
        $st=$db->prepare("SELECT * FROM `".self::TABLE."` WHERE token_hash=? LIMIT 1");
        $st->bind_param('s',$hash); $st->execute(); $r=$st->get_result();
        return $r?$r->fetch_assoc():null;
    }
    private static function update($id,$fields){
        $db=self::db(); if(!$db)return false; $sets=array();$vals=array();$types='';
        foreach($fields as $k=>$v){$sets[]="`".$k."`=?";$vals[]=$v;$types.=is_int($v)?'i':'s';}
        $vals[]=(int)$id;$types.='i';
        $st=$db->prepare("UPDATE `".self::TABLE."` SET ".implode(',',$sets)." WHERE id=?");
        if(!$st)return false; $st->bind_param($types,...$vals); return $st->execute();
    }

    public static function checkout_route(){
        if(!function_exists('wc_create_order')) return;
        $token=sanitize_text_field(wp_unslash($_GET['token']??''));
        $sig=sanitize_text_field(wp_unslash($_GET['sig']??''));
        if($token===''||$sig===''||!hash_equals(self::sign($token),$sig)){wp_die('Invalid payment request.',403);}
        $row=self::row(self::hash_token($token));
        if(!$row){wp_die('Payment request not found.',404);}
        if(!in_array($row['status'],array('pending','claimed','checkout'),true) && empty($row['woo_order_id'])) wp_die('Payment request is no longer valid.',409);

        $order=$row['woo_order_id']?wc_get_order((int)$row['woo_order_id']):false;
        if(!$order){
            $order=wc_create_order(array('customer_id'=>(int)$row['wp_user_id']));
            if(is_wp_error($order)) wp_die('Unable to create WooCommerce order.',500);
            $order->set_created_via('buzzjuice-pgb');
            $order->set_currency(self::resolve_currency($row['requested_currency']));
            $user=get_user_by('id',(int)$row['wp_user_id']);
            if($user){
                $order->set_billing_email($user->user_email);
                $order->set_billing_first_name(get_user_meta($user->ID,'billing_first_name',true)?:$user->first_name);
                $order->set_billing_last_name(get_user_meta($user->ID,'billing_last_name',true)?:$user->last_name);
            } elseif($row['billing_email']) $order->set_billing_email($row['billing_email']);
            $product=self::resolve_product($row);
            if(!$product) wp_die('Mapped WooCommerce product was not found.',500);
            $qty=max(1,(int)$row['quantity']);
            $item_id=$order->add_product($product,$qty);
            if(!$item_id) wp_die('Unable to add product to order.',500);
            $order->update_meta_data('wow_order_id',$row['wow_order_id']);
            $order->update_meta_data('wow_user_id',(int)$row['wow_user_id']);
            $order->update_meta_data('userid',(int)$row['wow_user_id']);
            $order->update_meta_data('wow_post_id',(int)$row['product_id']);
            $order->update_meta_data('_buzzjuice_origin','streams');
            $order->update_meta_data('_bzj_pgb_transaction_id',(int)$row['id']);
            $order->update_meta_data('_bzj_pgb_transaction_kind',$row['transaction_kind']);
            $order->update_meta_data('_bzj_pgb_source_currency',$row['source_currency']);
            $order->update_meta_data('_bzj_pgb_requested_currency',$row['requested_currency']);
            $order->update_meta_data('_bzj_pgb_original_amount',(string)$row['amount']);
            self::apply_price($order,$row,$product,$qty);
            $order->calculate_totals(false);
            $order->save();
            self::update($row['id'],array('status'=>'checkout','woo_order_id'=>(int)$order->get_id(),'claimed_at'=>gmdate('Y-m-d H:i:s'),'updated_at'=>gmdate('Y-m-d H:i:s')));
        }
        $url=$order->get_checkout_payment_url(false);
        BZJ_PGB_Log::write('class-pgb-client','checkout_redirect',array('transaction_id'=>$row['id'],'woo_order_id'=>$order->get_id(),'status'=>$order->get_status()));
        wp_safe_redirect($url); exit;
    }

    private static function resolve_currency($requested){
        $c=strtoupper(preg_replace('/[^A-Z]/','',$requested));
        return $c?:get_woocommerce_currency();
    }
    private static function resolve_product($row){
        $id=(int)$row['variation_id']; if($id){$p=wc_get_product($id);if($p)return $p;}
        $id=(int)$row['product_id']; if($id){$p=wc_get_product($id);if($p)return $p;}
        if($row['transaction_kind']==='PRO'){
            $map=array(1=>'wow-pgb_pro_1',2=>'wow-pgb_pro_2',3=>'wow-pgb_pro_3',4=>'wow-pgb_pro_4');
            $sku=$map[(int)$row['product_id']]??'';
            if($sku){$id=wc_get_product_id_by_sku($sku);if($id)return wc_get_product($id);}
        }
        return false;
    }
    private static function apply_price($order,$row,$product,$qty){
        $target=$order->get_currency(); $source=strtoupper($row['source_currency']); $amount=(float)$row['amount'];
        $converted=$amount;
        if($source && $target && $source!==$target) $converted=self::convert_woocs($amount,$source,$target);
        $unit=$qty>0?$converted/$qty:$converted;
        foreach($order->get_items() as $item){
            $item->set_subtotal($unit*$item->get_quantity());
            $item->set_total($unit*$item->get_quantity());
            $item->save();
        }
        $order->update_meta_data('_bzj_pgb_converted_amount',(string)$converted);
    }
    private static function convert_woocs($amount,$from,$to){
        if(function_exists('woocs_convert_price')) {
            $v=woocs_convert_price($amount,$from,$to); if(is_numeric($v))return (float)$v;
        }
        if(function_exists('woocs_get_currency_rate')){
            $fr=woocs_get_currency_rate($from);$tr=woocs_get_currency_rate($to);
            if(is_numeric($fr)&&is_numeric($tr)&&$fr!=0)return $amount*((float)$tr/(float)$fr);
        }
        return $amount;
    }

    public static function payment_complete($order_id,$transaction_id=''){
        self::fulfill((int)$order_id,'payment_complete');
    }
    public static function order_lifecycle($order_id){ self::fulfill((int)$order_id,'status'); }

    private static function fulfill($order_id,$reason){
        $order=wc_get_order($order_id); if(!$order)return;
        if(!$order->get_meta('_buzzjuice_origin') && !$order->get_meta('_bzj_pgb_transaction_id'))return;
        $txid=(int)$order->get_meta('_bzj_pgb_transaction_id');
        $db=self::db(); if(!$db)return;
        $row=null;
        if($txid){
            $st=$db->prepare("SELECT * FROM `".self::TABLE."` WHERE id=? LIMIT 1");$st->bind_param('i',$txid);$st->execute();$r=$st->get_result();$row=$r?$r->fetch_assoc():null;
        }
        if(!$row)return;
        self::update($row['id'],array('status'=>'paid','paid_at'=>gmdate('Y-m-d H:i:s'),'attempts'=>(int)$row['attempts']+1,'updated_at'=>gmdate('Y-m-d H:i:s')));
        self::ensure_subscription($order);
        BZJ_PGB_AffiliateWP::process($order);
        BZJ_PGB_Jewel::process($order);
        self::sync_streams($order,$row);
    }
    private static function ensure_subscription($order){
        if(!function_exists('wcs_create_subscription') || !function_exists('wcs_get_subscriptions_for_order') || !class_exists('WC_Subscriptions_Product')) return;
        $existing=wcs_get_subscriptions_for_order($order->get_id(),array('order_type'=>'parent'));
        if($existing) return;

        $kind=(string)$order->get_meta('_bzj_pgb_transaction_kind');
        if($kind!=='PRO') return;

        foreach($order->get_items() as $item){
            $p=$item->get_product(); if(!$p) continue;
            $period='month'; $interval=1; $length=0;
            if(WC_Subscriptions_Product::is_subscription($p)){
                $period=WC_Subscriptions_Product::get_period($p);
                $interval=(int)WC_Subscriptions_Product::get_interval($p);
                $length=(int)WC_Subscriptions_Product::get_length($p);
            }else{
                $post_id=(int)$order->get_meta('wow_post_id');
                $map=array(
                    1=>array('month',1,0),
                    2=>array('month',3,0),
                    3=>array('month',6,0),
                    4=>array('year',1,0)
                );
                if(isset($map[$post_id])) list($period,$interval,$length)=$map[$post_id];
                $period=(string)$item->get_meta('_subscription_period',true) ?: $period;
                $interval=(int)($item->get_meta('_subscription_interval',true) ?: $interval);
            }

            try{
                $sub=wcs_create_subscription(array(
                    'order_id'=>$order->get_id(),
                    'customer_id'=>$order->get_user_id(),
                    'status'=>'pending',
                    'created_via'=>'buzzjuice-pgb',
                    'start_date'=>gmdate('Y-m-d H:i:s'),
                    'billing_period'=>$period,
                    'billing_interval'=>max(1,$interval),
                ));
                if(is_wp_error($sub)){
                    BZJ_PGB_Log::write('class-pgb-client','subscription_create_failed',array('order_id'=>$order->get_id(),'error'=>$sub->get_error_message()),'error');
                    continue;
                }

                $sub->add_product($p,$item->get_quantity());
                $start=gmdate('Y-m-d H:i:s');
                $dates=array(
                    'next_payment'=>wcs_add_time(max(1,$interval),$period,wcs_date_to_time($start)),
                );
                if($length>0) $dates['end']=wcs_add_time($length,$period,wcs_date_to_time($start));
                if(method_exists('WC_Subscriptions_Product','get_trial_expiration_date')) {
                    $trial=WC_Subscriptions_Product::get_trial_expiration_date($p,$start);
                    if($trial>0)$dates['trial_end']=$trial;
                }
                $sub->update_dates($dates);
                $sub->set_payment_method($order->get_payment_method());
                $sub->calculate_totals();
                $sub->save();

                $order->update_meta_data('_bzj_pgb_subscription_id',$sub->get_id());
                $order->save();
                BZJ_PGB_Log::write('class-pgb-client','subscription_created',array('order_id'=>$order->get_id(),'subscription_id'=>$sub->get_id(),'period'=>$period,'interval'=>$interval));
            }catch(Throwable $e){
                BZJ_PGB_Log::write('class-pgb-client','subscription_exception',array('order_id'=>$order->get_id(),'error'=>$e->getMessage()),'error');
            }
            break;
        }
    }
    public static function subscription_active($subscription_id){
        $sub=wcs_get_subscription($subscription_id); if(!$sub)return;
        $order_id=$sub->get_parent_id(); if(!$order_id)return;
        self::sync_streams(wc_get_order($order_id),null);
    }
    private static function sync_streams($order,$row){
        $wow_user_id=(int)$order->get_meta('wow_user_id'); if(!$wow_user_id)return;
        $kind=(string)$order->get_meta('_bzj_pgb_transaction_kind');
        if($kind!=='PRO')return;
        $post_id=(int)$order->get_meta('wow_post_id');
        $role_map=array(1=>'classic_lifestyle',2=>'silver_lifestyle',3=>'rockstar_lifestyle',4=>'premium_lifestyle');
        $wp_user_id=(int)$order->get_user_id();
        if($wp_user_id && isset($role_map[$post_id])){
            $u=new WP_User($wp_user_id); $u->add_role($role_map[$post_id]);
        }
        if($row)self::update($row['id'],array('status'=>'fulfilled','fulfilled_at'=>gmdate('Y-m-d H:i:s'),'updated_at'=>gmdate('Y-m-d H:i:s')));
    }
}