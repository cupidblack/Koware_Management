<?php
/* WoWonder entry point retained for requests.php compatibility. */
require_once dirname(__DIR__,2).'/config.php';
require_once dirname(__DIR__).'/init.php';
require_once dirname(__DIR__,3).'/shared/db_helpers.php';
require_once dirname(__DIR__,3).'/shared/payment-gateway/pgb-client-streams.php';
