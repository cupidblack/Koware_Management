# Buzzjuice Payment Gateway Bridge v6.0

This package is a migration foundation, not a blind drop-in replacement for the existing fulfillment code.

## Critical changes
- Only `wp-content/mu-plugins/bzj-payment-gateway.php` is in MU plugins.
- All engine code lives under `shared/payment-gateway/`.
- Streams sends an authenticated payment intent to WordPress.
- WooCommerce creates/owns the payment order.
- A durable WordPress ledger is used for idempotency.
- Ledger creation uses direct `CREATE TABLE IF NOT EXISTS`, avoiding the malformed `dbDelta()` schema seen in v5.1.
- `BZJ_PGB_SECRET` is server environment configuration.
- AffiliateWP is triggered only after payment confirmation.
- Browser return/thank-you pages are not payment authority.
- WooCommerce Subscriptions should create/activate subscriptions natively from subscription products.

## Before production
1. Preserve the current production files.
2. Add `BZJ_PGB_SECRET` and `BZJ_PGB_DEBUG=1` temporarily.
3. Install the MU file and shared directory.
4. Confirm `wp_bzj_pgb_transactions` exists.
5. Confirm REST order creation works.
6. Confirm one successful payment reaches `woocommerce_payment_complete`.
7. Confirm ledger transitions to paid.
8. Move the proven AffiliateWP resolver into `addons/pgb-addon-affiliate-wp.php`.
9. Move proven Streams fulfillment from `wow-pgb_sync.php` into `integrations/pgb-int-streams.php`.
10. Only after successful end-to-end tests disable the old `wow-pgb_sync.php` payment hooks and old webhook.

## Important implementation status
The package is intentionally a **migration baseline**. It is not safe to switch production fulfillment to it until the proven Streams fulfillment routines from `wow-pgb_init.php`/`wow-pgb_sync.php` are moved into the isolated integration and verified against the live WoWonder schema. In particular, do not enable `pgb_streams_fulfillment_ready` as a substitute for the existing fulfillment logic. This prevents a partially migrated engine from silently losing paid fulfillment.
