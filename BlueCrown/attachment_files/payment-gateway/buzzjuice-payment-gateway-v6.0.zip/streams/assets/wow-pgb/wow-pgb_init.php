<?php
require_once dirname(__DIR__,3) . '/shared/payment-gateway/pgb-client-streams.php';
pgb_streams_init_payment();
