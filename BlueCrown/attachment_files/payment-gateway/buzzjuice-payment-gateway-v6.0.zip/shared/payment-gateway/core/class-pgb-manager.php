<?php
if (!defined('ABSPATH')) exit;

final class PGB_Manager {
    private $logger;
    public function __construct(PGB_Logger $logger){$this->logger=$logger;}

    public function create_order(array $d) {
        global $wpdb;
        $t=$wpdb->prefix.'bzj_pgb_transactions';
        $request_id=$d['request_id'];
        $wow_order_id=$d['wow_order_id'];

        $existing=PGB_Idempotency::get_by_request_id($request_id);
        if(!$existing) $existing=PGB_Idempotency::get_by_wow_order_id($wow_order_id);
        if($existing && !empty($existing['woo_order_id'])){
            $order=wc_get_order((int)$existing['woo_order_id']);
            if($order){
                return ['success'=>true,'duplicate'=>true,'order_id'=>$order->get_id(),'payment_url'=>$order->get_checkout_payment_url()];
            }
        }

        $user_id=absint($d['wp_user_id']);
        if(!$user_id || !get_user_by('id',$user_id)){
            return ['success'=>false,'error'=>'WordPress customer could not be resolved.'];
        }
        $amount=wc_format_decimal($d['amount'],8);
        $currency=strtoupper($d['currency']);
        $kind=strtoupper($d['transaction_kind']);

        $order=wc_create_order(['customer_id'=>$user_id]);
        if(is_wp_error($order)) return ['success'=>false,'error'=>$order->get_error_message()];

        $order->set_currency($currency);
        $order->set_customer_id($user_id);
        $product_id=absint($d['product_id']??0);
        $variation_id=absint($d['variation_id']??0);
        $qty=max(1,absint($d['product_units']??1));

        $product=$variation_id?wc_get_product($variation_id):wc_get_product($product_id);
        if(!$product){
            $order->delete(true);
            return ['success'=>false,'error'=>'Configured WooCommerce product/variation could not be loaded.'];
        }

        $item_id=$order->add_product($product,$qty,['subtotal'=>wc_format_decimal($amount/$qty,8),'total'=>wc_format_decimal($amount,8)]);
        if(!$item_id){
            $order->delete(true);
            return ['success'=>false,'error'=>'Could not add payment product to WooCommerce order.'];
        }

        $meta=[
            '_buzzjuice_pgb'=>'1',
            '_buzzjuice_origin'=>'streams',
            '_wow_user_id'=>(string)$d['wow_user_id'],
            '_wp_user_id'=>(string)$user_id,
            'wow_order_id'=>$wow_order_id,
            'wow_post_id'=>(string)($d['wow_post_id']??0),
            'transaction_kind'=>$kind,
            'product_units'=>(string)$qty,
            'product_owner_id'=>(string)($d['product_owner_id']??0),
            'pgb_request_id'=>$request_id,
        ];
        foreach($meta as $k=>$v) $order->update_meta_data($k,$v);
        if(!empty($d['product_name'])) $order->update_meta_data('_pgb_product_name',sanitize_text_field($d['product_name']));
        if(!empty($d['subscription_period'])) $order->update_meta_data('_subscription_period',sanitize_text_field($d['subscription_period']));
        if(!empty($d['subscription_interval'])) $order->update_meta_data('_subscription_interval',absint($d['subscription_interval']));
        if(isset($d['subscription_length'])) $order->update_meta_data('_subscription_length',absint($d['subscription_length']));
        $order->calculate_totals(false);
        $order->save();

        $now=current_time('mysql',true);
        $insert=[
            'request_id'=>$request_id,'wow_order_id'=>$wow_order_id,'woo_order_id'=>$order->get_id(),
            'wp_user_id'=>$user_id,'wow_user_id'=>absint($d['wow_user_id']),'transaction_kind'=>$kind,
            'status'=>'order_created','amount'=>$amount,'currency'=>$currency,'payload'=>wp_json_encode($d),
            'created_at'=>$now,'updated_at'=>$now
        ];
        $ok=$wpdb->insert($t,$insert,['%s','%s','%d','%d','%d','%s','%s','%s','%s','%s','%s']);
        if($ok===false){
            $order->delete(true);
            $this->logger->log('Ledger insert failed after order creation',PGB_Logger::CRITICAL,['db_error'=>$wpdb->last_error,'order_id'=>$order->get_id()],__FILE__);
            return ['success'=>false,'error'=>'Could not persist payment transaction.'];
        }
        $this->logger->log('WooCommerce order created',PGB_Logger::INFO,['order_id'=>$order->get_id(),'kind'=>$kind],__FILE__);
        return ['success'=>true,'duplicate'=>false,'order_id'=>$order->get_id(),'payment_url'=>$order->get_checkout_payment_url()];
    }

    public function process_payment_complete($order_id){
        $order=wc_get_order($order_id); if(!$order) return false;
        if($order->get_meta('_buzzjuice_pgb')!=='1') return false;
        if(!in_array($order->get_status(),['processing','completed'],true) && !$order->is_paid()) return false;
        global $wpdb; $t=$wpdb->prefix.'bzj_pgb_transactions';
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE woo_order_id=%d LIMIT 1",$order_id),ARRAY_A);
        if(!$row){$this->logger->log('Paid PGB order has no ledger row',PGB_Logger::CRITICAL,['order_id'=>$order_id],__FILE__);return false;}
        if($row['status']==='fulfilled') return true;
        $wpdb->update($t,['status'=>'paid','paid_at'=>current_time('mysql',true),'updated_at'=>current_time('mysql',true)],['id'=>$row['id']],['%s','%s','%s'],['%d']);
        do_action('pgb_payment_confirmed',$order_id,$row,$order);
        return true;
    }

    public function mark_fulfilled($row_id){
        global $wpdb; $t=$wpdb->prefix.'bzj_pgb_transactions';
        return $wpdb->update($t,['status'=>'fulfilled','fulfilled_at'=>current_time('mysql',true),'updated_at'=>current_time('mysql',true),'last_error'=>null],['id'=>$row_id],['%s','%s','%s','%s'],['%d']);
    }
    public function mark_failed($row_id,$error){
        global $wpdb; $t=$wpdb->prefix.'bzj_pgb_transactions';
        return $wpdb->update($t,['status'=>'fulfillment_failed','last_error'=>substr((string)$error,0,65000),'updated_at'=>current_time('mysql',true)],['id'=>$row_id]);
    }
}
