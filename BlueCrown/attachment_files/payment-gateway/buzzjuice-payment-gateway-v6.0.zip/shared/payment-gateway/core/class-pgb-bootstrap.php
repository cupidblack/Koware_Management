<?php
if (!defined('ABSPATH')) exit;

final class PGB_Bootstrap {
    private static $instance;
    private $logger,$manager;
    public static function instance(){return self::$instance?:self::$instance=new self();}
    public function boot(){
        if($this->logger) return;
        $cfg=require BZJ_PGB_DIR.'/config/pgb-config.php';
        $this->logger=new PGB_Logger($cfg);
        PGB_Schema::ensure($this->logger);
        $this->manager=new PGB_Manager($this->logger);
        require_once BZJ_PGB_DIR.'/addons/pgb-addon-affiliate-wp.php';
        require_once BZJ_PGB_DIR.'/addons/pgb-addon-subscriptions.php';
        require_once BZJ_PGB_DIR.'/integrations/pgb-int-streams.php';
        require_once BZJ_PGB_DIR.'/integrations/pgb-int-jewel-affiliate.php';
        $this->register_rest();
        $this->register_wc_hooks();
        do_action('pgb_booted',$this);
        $this->logger->log('PGB booted',PGB_Logger::INFO,['version'=>BZJ_PGB_VERSION],__FILE__);
    }
    public function logger(){return $this->logger;}
    public function manager(){return $this->manager;}
    private function register_wc_hooks(){
        add_action('woocommerce_payment_complete',[$this,'wc_payment_complete'],20,1);
        add_action('woocommerce_order_status_processing',[$this,'wc_status'],20,1);
        add_action('woocommerce_order_status_completed',[$this,'wc_status'],20,1);
    }
    public function wc_payment_complete($id){$this->manager->process_payment_complete($id);}
    public function wc_status($id){
        $o=wc_get_order($id); if($o && $o->is_paid()) $this->manager->process_payment_complete($id);
    }
    private function register_rest(){
        add_action('rest_api_init',function(){
            register_rest_route('bzj-pgb/v1','/order',[
                'methods'=>'POST','permission_callback'=>'__return_true',
                'callback'=>[$this,'rest_create_order']
            ]);
        });
    }
    public function rest_create_order(WP_REST_Request $request){
        $raw=$request->get_body();
        $ts=(string)$request->get_header('x-bzj-pgb-timestamp');
        $rid=(string)$request->get_header('x-bzj-pgb-request-id');
        $sig=(string)$request->get_header('x-bzj-pgb-signature');
        $secret=getenv('BZJ_PGB_SECRET');
        if(!$secret) return new WP_Error('pgb_not_configured','Payment bridge secret is not configured',['status'=>503]);
        if(!$ts||!$rid||!$sig||abs(time()-(int)$ts)>300) return new WP_Error('pgb_auth','Invalid or stale request',['status'=>401]);
        $expected=hash_hmac('sha256',$ts."\n".$rid."\n".$raw,$secret);
        if(!hash_equals($expected,$sig)) return new WP_Error('pgb_auth','Signature mismatch',['status'=>401]);
        $data=json_decode($raw,true);
        if(!is_array($data)) return new WP_Error('pgb_json','Invalid JSON',['status'=>400]);
        $data['request_id']=$rid;
        $required=['wow_user_id','wp_user_id','wow_email','transaction_kind','amount','currency','wow_order_id'];
        foreach($required as $k) if(!isset($data[$k])||$data[$k]==='') return new WP_Error('pgb_missing','Missing '.$k,['status'=>400]);
        $data['transaction_kind']=strtoupper(sanitize_key($data['transaction_kind']));
        if(!in_array($data['transaction_kind'],['PRO','PRODUCT','PURCHASE','WALLET','DONATE'],true)) return new WP_Error('pgb_kind','Unsupported transaction kind',['status'=>400]);
        if(!is_email($data['wow_email']) || (float)$data['amount']<=0 || absint($data['wow_user_id'])<=0 || absint($data['wp_user_id'])<=0) return new WP_Error('pgb_validation','Invalid order data',['status'=>400]);
        $result=$this->manager->create_order($data);
        if(!$result['success']) return new WP_Error('pgb_order',$result['error'],['status'=>500]);
        return new WP_REST_Response(['status'=>200,'url'=>$result['payment_url'],'order_id'=>$result['order_id'],'duplicate'=>!empty($result['duplicate'])],200);
    }
}
