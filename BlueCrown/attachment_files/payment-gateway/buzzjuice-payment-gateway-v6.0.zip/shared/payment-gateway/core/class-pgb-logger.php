<?php
if (!defined('ABSPATH')) exit;

final class PGB_Logger {
    const DEBUG='debug', INFO='info', WARNING='warning', ERROR='error', CRITICAL='critical';
    private $enabled=true, $level=self::INFO, $max_bytes=10485760;

    public function __construct(array $config=[]) {
        $this->enabled = !empty($config['logging_enabled']);
        $this->level = $config['log_level'] ?? self::INFO;
        if (!is_dir(BZJ_PGB_LOG_DIR)) @wp_mkdir_p(BZJ_PGB_LOG_DIR);
    }
    public function enabled(){ return $this->enabled; }
    private function rank($level){ return [self::DEBUG=>10,self::INFO=>20,self::WARNING=>30,self::ERROR=>40,self::CRITICAL=>50][$level] ?? 20; }
    public function log($message,$level=self::INFO,array $context=[], $source=null) {
        if (!$this->enabled || $this->rank($level)<$this->rank($this->level)) return;
        $source=$source ?: __FILE__;
        $name=preg_replace('/[^A-Za-z0-9._-]/','_',pathinfo($source,PATHINFO_FILENAME));
        $file=trailingslashit(BZJ_PGB_LOG_DIR).$name.'.log';
        $context=$this->redact($context);
        $line=wp_json_encode(['time'=>gmdate('c'),'level'=>$level,'message'=>(string)$message,'context'=>$context], JSON_UNESCAPED_SLASHES).PHP_EOL;
        if (file_exists($file) && filesize($file)>$this->max_bytes) @rename($file,$file.'.'.gmdate('YmdHis'));
        @file_put_contents($file,$line,FILE_APPEND|LOCK_EX);
        if(in_array($level,[self::ERROR,self::CRITICAL],true)) error_log('[BZJ-PGB]['.strtoupper($level).'] '.$message);
    }
    private function redact($v) {
        if(is_array($v)){ $o=[]; foreach($v as $k=>$x){ $lk=strtolower((string)$k); $o[$k]=preg_match('/secret|token|password|cookie|authorization|signature|api_key|api_secret/i',$lk)?'[REDACTED]':$this->redact($x); } return $o; }
        if(is_object($v)) return $this->redact((array)$v);
        return is_string($v) && strlen($v)>1000 ? substr($v,0,997).'...' : $v;
    }
}
