<?php
if (!defined('ABSPATH')) exit;

final class PGB_Idempotency {
    public static function get_by_request_id($request_id){
        global $wpdb; $t=$wpdb->prefix.'bzj_pgb_transactions';
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE request_id=%s LIMIT 1",$request_id),ARRAY_A);
    }
    public static function get_by_wow_order_id($wow_order_id){
        global $wpdb; $t=$wpdb->prefix.'bzj_pgb_transactions';
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE wow_order_id=%s LIMIT 1",$wow_order_id),ARRAY_A);
    }
}
