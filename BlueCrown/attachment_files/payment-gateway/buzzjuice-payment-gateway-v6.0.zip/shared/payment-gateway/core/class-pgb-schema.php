<?php
if (!defined('ABSPATH')) exit;

final class PGB_Schema {
    const VERSION='2';
    public static function install(PGB_Logger $logger) {
        global $wpdb;
        $table=$wpdb->prefix.'bzj_pgb_transactions';
        $charset=$wpdb->get_charset_collate();
        $sql="CREATE TABLE IF NOT EXISTS {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            request_id varchar(64) NOT NULL,
            wow_order_id varchar(100) NOT NULL,
            woo_order_id bigint(20) unsigned NULL,
            wp_user_id bigint(20) unsigned NULL,
            wow_user_id bigint(20) unsigned NULL,
            transaction_kind varchar(32) NOT NULL,
            status varchar(32) NOT NULL DEFAULT 'initiated',
            amount decimal(20,8) NOT NULL DEFAULT 0.00000000,
            currency varchar(10) NOT NULL DEFAULT '',
            payload longtext NULL,
            last_error text NULL,
            attempts int(10) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            paid_at datetime NULL,
            fulfilled_at datetime NULL,
            PRIMARY KEY (id),
            UNIQUE KEY request_id (request_id),
            UNIQUE KEY wow_order_id (wow_order_id),
            KEY woo_order_id (woo_order_id),
            KEY status (status),
            KEY wow_user_id (wow_user_id)
        ) {$charset}";
        $ok=$wpdb->query($sql);
        if($ok===false){
            $logger->log('Ledger table creation failed',PGB_Logger::CRITICAL,['db_error'=>$wpdb->last_error],__FILE__);
            return false;
        }
        update_option('bzj_pgb_schema_version',self::VERSION,false);
        return true;
    }
    public static function ensure(PGB_Logger $logger){
        global $wpdb;
        $table=$wpdb->prefix.'bzj_pgb_transactions';
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table))!==$table) return self::install($logger);
        return true;
    }
}
