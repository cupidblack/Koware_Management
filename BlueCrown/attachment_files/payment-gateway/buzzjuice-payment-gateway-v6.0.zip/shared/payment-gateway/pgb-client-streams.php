<?php
/**
 * WoWonder-side PGB client. Streams never receives WooCommerce credentials.
 */
if (!function_exists('pgb_streams_init_payment')) {
function pgb_streams_init_payment(){
    global $wo,$sqlConnect;
    $log=trailingslashit(dirname(__FILE__)).'log/pgb-client-streams.log';
    $write=function($msg,$ctx=[])use($log){
        if(getenv('BZJ_PGB_DEBUG')!=='1')return;
        @file_put_contents($log,json_encode(['time'=>gmdate('c'),'message'=>$msg,'context'=>$ctx],JSON_UNESCAPED_SLASHES).PHP_EOL,FILE_APPEND|LOCK_EX);
    };
    if(empty($wo['loggedin'])||empty($wo['user']['user_id'])){http_response_code(401);echo json_encode(['status'=>'error','message'=>'Not authenticated']);return;}
    $wow_user_id=absint($wo['user']['user_id']);
    $email=filter_var($wo['user']['email']??'',FILTER_VALIDATE_EMAIL);
    if(!$email){http_response_code(400);echo json_encode(['status'=>'error','message'=>'Invalid account email']);return;}

    $wp_user_id=0;
    if($sqlConnect){
        $q=mysqli_query($sqlConnect,"SELECT wp_user_id FROM ".T_USERS." WHERE user_id=".$wow_user_id." LIMIT 1");
        if($q && ($r=mysqli_fetch_assoc($q))) $wp_user_id=absint($r['wp_user_id']??0);
    }
    if(!$wp_user_id){http_response_code(400);echo json_encode(['status'=>'error','message'=>'WordPress account link is missing']);return;}

    $kind=strtoupper(preg_replace('/[^A-Z_]/','',(string)($_POST['transaction_kind']??'')));
    if($kind==='PRODUCT')$kind='PURCHASE';
    if(!in_array($kind,['PRO','PURCHASE','WALLET','DONATE'],true)){http_response_code(400);echo json_encode(['status'=>'error','message'=>'Unsupported transaction type']);return;}

    $amount=(float)($_POST['amount']??0);
    if($amount<=0){http_response_code(400);echo json_encode(['status'=>'error','message'=>'Invalid amount']);return;}

    $wow_order_id='wow_'.bin2hex(random_bytes(12));
    $request_id='pgb_'.bin2hex(random_bytes(16));
    $payload=[
        'wow_user_id'=>$wow_user_id,'wp_user_id'=>$wp_user_id,'wow_email'=>$email,
        'wow_username'=>preg_replace('/[^A-Za-z0-9._@+\- ]/','',(string)($wo['user']['username']??'')),
        'transaction_kind'=>$kind,'amount'=>round($amount,8),
        'currency'=>strtoupper(preg_replace('/[^A-Za-z]/','',(string)($_POST['wow_currency_code']??$wo['config']['currency']??'GHS'))),
        'wow_order_id'=>$wow_order_id,'product_id'=>absint($_POST['product_id']??0),
        'variation_id'=>absint($_POST['variation_id']??0),'product_name'=>trim((string)($_POST['product_name']??'Product')),
        'product_price'=>(float)($_POST['product_price']??$amount),'product_units'=>max(1,absint($_POST['product_units']??1)),
        'product_owner_id'=>absint($_POST['product_owner_id']??0),'wow_post_id'=>absint($_POST['wow_post_id']??0),
        'subscription_period'=>preg_replace('/[^A-Za-z]/','',(string)($_POST['subscription_period']??'')),'subscription_interval'=>absint($_POST['subscription_interval']??0),
        'subscription_length'=>absint($_POST['subscription_length']??0)
    ];

    $endpoint=rtrim((string)($wo['config']['wow_store_url']??''),'/').'/wp-json/bzj-pgb/v1/order';
    $secret=getenv('BZJ_PGB_SECRET');
    if(!$secret || !filter_var($endpoint,FILTER_VALIDATE_URL)){http_response_code(500);echo json_encode(['status'=>'error','message'=>'Payment bridge is not configured']);return;}

    $body=json_encode($payload,JSON_UNESCAPED_SLASHES);
    $ts=(string)time();
    $sig=hash_hmac('sha256',$ts."\n".$request_id."\n".$body,$secret);
    $response=wp_remote_post($endpoint,['timeout'=>20,'headers'=>[
        'Content-Type'=>'application/json','X-BZJ-PGB-Timestamp'=>$ts,'X-BZJ-PGB-Request-ID'=>$request_id,'X-BZJ-PGB-Signature'=>$sig
    ],'body'=>$body]);
    if(is_wp_error($response)){ $write('REST transport error',['error'=>$response->get_error_message()]);http_response_code(502);echo json_encode(['status'=>'error','message'=>'Unable to start payment']);return;}
    $code=wp_remote_retrieve_response_code($response);$data=json_decode(wp_remote_retrieve_body($response),true);
    $write('REST response',['http_code'=>$code,'order_id'=>$data['order_id']??0]);
    if($code!==200 || empty($data['url'])){http_response_code(502);echo json_encode(['status'=>'error','message'=>$data['message']??'Unable to create payment order']);return;}
    echo json_encode(['status'=>200,'url'=>$data['url'],'order_id'=>$data['order_id']??0]);exit;
}}
