<?php
if (!defined('ABSPATH')) exit;

/* Reserved integration hook for the existing Jewel Affiliate webhook/service. */
add_action('pgb_payment_confirmed',function($order_id,$transaction,$order){
    do_action('pgb_jewel_affiliate_payment_confirmed',$order_id,$transaction,$order);
},50,3);
