<?php
if (!defined('ABSPATH')) exit;

/*
 * Streams fulfillment is intentionally isolated. The implementation uses the
 * existing server-to-server bridge pattern and must be adapted to the exact
 * WoWonder tables/columns before enabling production fulfillment.
 */
add_action('pgb_payment_confirmed',function($order_id,$transaction,$order){
    $logger=PGB_Bootstrap::instance()->logger();
    $wow_user_id=absint($transaction['wow_user_id']);
    $kind=strtoupper($transaction['transaction_kind']);
    $logger->log('Streams fulfillment requested',PGB_Logger::INFO,['order_id'=>$order_id,'wow_user_id'=>$wow_user_id,'kind'=>$kind],__FILE__);

    $secret=getenv('BZJ_PGB_SECRET');
    if(!$secret){$logger->log('Missing BZJ_PGB_SECRET; Streams fulfillment stopped',PGB_Logger::ERROR,[],__FILE__);return;}

    /*
     * IMPORTANT: Do not perform arbitrary SQL here. The final implementation
     * must use a single transaction-specific fulfillment endpoint or a
     * tightly scoped DB service with an idempotency marker.
     */
    do_action('pgb_streams_fulfillment_ready',$order_id,$transaction,$order);
},40,3);
