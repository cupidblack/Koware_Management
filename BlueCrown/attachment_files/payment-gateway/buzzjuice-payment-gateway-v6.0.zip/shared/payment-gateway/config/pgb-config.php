<?php
return [
    'logging_enabled' => (getenv('BZJ_PGB_DEBUG') === '1'),
    'log_level' => getenv('BZJ_PGB_LOG_LEVEL') ?: 'info',
];
