<?php
if (!defined('ABSPATH')) exit;

/*
 * AffiliateWP addon. The proven resolver/commission logic remains in the
 * existing wow-pgb_sync.php during migration; this addon calls it only once.
 * After validation, move its helper functions here and remove the old file.
 */
add_action('pgb_payment_confirmed',function($order_id,$transaction,$order){
    $logger=PGB_Bootstrap::instance()->logger();
    if(!class_exists('Affiliate_WP') && !function_exists('affiliate_wp')) return;
    $legacy=ABSPATH.'wp-content/plugins/blue-crown-wp/wow-pgb_sync/wow-pgb_sync.php';
    if(function_exists('bluecrown_affiliatewp_post_checkout_verification')){
        bluecrown_affiliatewp_post_checkout_verification($order_id);
        $logger->log('AffiliateWP processed',PGB_Logger::INFO,['order_id'=>$order_id],__FILE__);
        return;
    }
    $logger->log('AffiliateWP addon loaded but legacy resolver is unavailable; no referral created',PGB_Logger::WARNING,['order_id'=>$order_id],__FILE__);
},30,3);
