<?php
if (!defined('ABSPATH')) exit;

/*
 * Initial PRO orders should preferably use a WooCommerce subscription product
 * and let Subscriptions create/activate the subscription during normal checkout.
 * This addon deliberately does not manufacture a subscription through the REST API.
 */
add_action('pgb_payment_confirmed',function($order_id,$transaction,$order){
    if(strtoupper($transaction['transaction_kind'])!=='PRO') return;
    if(!class_exists('WC_Subscriptions')) return;
    if(function_exists('wcs_get_subscriptions_for_order')){
        $subs=wcs_get_subscriptions_for_order($order_id,['order_type'=>'parent']);
        if(!empty($subs)) return;
    }
    $order->add_order_note('Buzzjuice PGB: payment confirmed. No subscription object is linked; verify that the configured WooCommerce product is a subscription product.');
    PGB_Bootstrap::instance()->logger()->log('PRO paid but no linked subscription found',PGB_Logger::WARNING,['order_id'=>$order_id],__FILE__);
},20,3);
