# Buzzjuice Streams Payment Gateway Bridge 4.0

## Target lifecycle

Streams browser -> Streams authenticated PHP client -> WordPress MU plugin -> native WooCommerce order -> gateway -> WooCommerce payment hooks -> PGB fulfilment -> Streams DB / AffiliateWP / Jewel.

The browser is never trusted for fixed-price financial values. PRO prices come from the mapped WooCommerce product/variation. Wallet and donation amounts are accepted only within the WordPress-configured dynamic limits.

## Environment

Add the same strong random secret to the server environment used by both WordPress and Streams:

BZJ_PGB_SECRET=CHANGE_THIS_TO_A_LONG_RANDOM_SECRET
BZJ_PGB_WP_URL=https://buzzjuice.net

Do not put this secret into Streams admin, JavaScript, WooCommerce order metadata, or logs.

## Migration

1. Back up the WordPress DB, Streams DB and all current PGB files.
2. Create `shared/payment-gateway/` and copy this package into the repository.
3. Install exactly one MU file: `wp-content/mu-plugins/bzj-payment-gateway.php`.
4. Ensure the WordPress process and Streams PHP process can read the same `BZJ_PGB_SECRET`.
5. Confirm the existing Streams payment settings contain valid handler product IDs.
6. Confirm the WooCommerce products/variations referenced by those IDs exist and have the intended prices.
7. Do not delete the old `wow-pgb_sync` plugin until the test matrix below has passed.
8. Replace `streams/assets/wow-pgb/wow-pgb_init.php` with the client version in this package.
9. Disable the old `wow-pgb_sync` plugin/old fulfilment hooks before live traffic is switched to v4. Never run both fulfilment engines for the same order.
10. Keep `streams/wow-pgb_webhook.php` only during migration; it now returns HTTP 410 and performs no payment operation.
11. Test: PRO, wallet, donation, market, duplicate click, browser close after order creation, payment gateway success without return page, payment retry, failed Streams DB operation, failed AffiliateWP operation, and Jewel Affiliate.
12. After verification, remove the old `wp-content/plugins/blue-crown-wp/wow-pgb_sync/` implementation and obsolete WooCommerce API credentials from Streams settings.

## Important implementation note

`shared/db_helpers.php` is loaded by the MU plugin only when it needs the WoWonder DB connection. WordPress does not rely on Streams `$wo` globals.

The WordPress bridge reads the existing WoWonder `Wo_Config` values for the handler product IDs so the Streams admin remains the operational configuration surface.

## Known legacy fields preserved

WooCommerce order metadata includes:
- `wow_order_id`
- `wow_post_id`
- `userid`
- `bz_wow_user_id`
- `_buzzjuice_origin`
- `_bzj_pgb_transaction_id`
- `_bzj_wow_user_id`
- `_bzj_wow_order_id`
- `_bzj_transaction_kind`

## Logs

All bridge logs are written to:
`shared/payment-gateway/log/`

No passwords, tokens, API credentials, HMAC signatures or authorization headers are written.

## Security corrections

- TLS verification is mandatory.
- No hard-coded webhook secret.
- No WooCommerce consumer credentials in Streams.
- HMAC protects Streams -> WordPress initiation.
- Fixed-price amounts are server authoritative.
- Idempotency is enforced by a unique PGB transaction key.
- Fulfilment is triggered by WooCommerce server-side lifecycle events, not the thank-you page.
