<?php
if (!defined('ABSPATH')) exit;

class BZJ_PGB_Client {
    public static function secret() {
        $env=getenv('BZJ_PGB_SECRET');
        if (!$env && defined('BZJ_PGB_SECRET')) $env=BZJ_PGB_SECRET;
        return (string)$env;
    }
    public static function authenticate($request,$body,$settings,$logger) {
        $ts=(string)$request->get_header('x-bzj-pgb-timestamp');
        $sig=(string)$request->get_header('x-bzj-pgb-signature');
        $reqid=(string)$request->get_header('x-bzj-pgb-request-id');
        if ($ts==='' || $sig==='' || $reqid==='') return new WP_Error('auth_missing','Missing PGB authentication headers',array('status'=>401));
        if (!ctype_digit($ts) || abs(time()-(int)$ts)>(int)$settings['request_ttl']) return new WP_Error('auth_expired','Expired PGB request',array('status'=>401));
        $secret=self::secret();
        if ($secret==='') { $logger->error('class-pgb-client.log','PGB secret is not configured'); return new WP_Error('auth_config','PGB authentication is not configured',array('status'=>500)); }
        $expected=hash_hmac('sha256',$ts."\n".$body,$secret);
        if (!hash_equals($expected,$sig)) return new WP_Error('auth_invalid','Invalid PGB signature',array('status'=>401));
        return true;
    }
    public static function sign($url,$body,$secret=null) {
        $secret=$secret!==null?$secret:self::secret();
        $ts=(string)time();
        return array('X-BZJ-PGB-Timestamp'=>$ts,'X-BZJ-PGB-Request-ID'=>wp_generate_uuid4(),
            'X-BZJ-PGB-Signature'=>hash_hmac('sha256',$ts."\n".$body,$secret),'Content-Type'=>'application/json');
    }
}
