<?php
if (!defined('ABSPATH')) exit;

class BZJ_PGB_Fulfillment {
    public static function process($order_id,$bridge) {
        global $wpdb;
        $order=wc_get_order($order_id);
        if (!$order) return false;
        $txid=(int)$order->get_meta('_bzj_pgb_transaction_id',true);
        if (!$txid) return false;
        $table=$wpdb->prefix.'bzj_pgb_transactions';
        $tx=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d",$txid),ARRAY_A);
        if (!$tx) return false;
        if (!in_array($order->get_status(),array('processing','completed'),true) && !$order->is_paid()) return false;

        $wpdb->update($table,array('payment_status'=>$order->get_status(),'final_amount'=>(float)$order->get_total(),
            'updated_at'=>current_time('mysql',true),'paid_at'=>$tx['paid_at']?:current_time('mysql',true)),array('id'=>$txid));

        if ($tx['fulfilment_status']==='completed') return true;
        $claim=$wpdb->query($wpdb->prepare("UPDATE {$table} SET fulfilment_status='processing',updated_at=%s
            WHERE id=%d AND fulfilment_status IN('pending','failed','processing') AND retry_count < %d",
            current_time('mysql',true),$txid,(int)$bridge->settings['retry_limit']));
        if ($claim===false) return false;

        try {
            require_once BZJ_PGB_DIR.'integrations/pgb-int-streams.php';
            require_once BZJ_PGB_DIR.'integrations/pgb-int-jewel-affiliate.php';
            if (class_exists('BZJ_PGB_Streams_Integration')) BZJ_PGB_Streams_Integration::fulfill($tx,$order,$bridge);
            do_action('bzj_pgb_before_addons',$tx,$order,$bridge);
            $affiliate_ok=true;
            if (class_exists('BZJ_PGB_Affiliate_WP')) $affiliate_ok=BZJ_PGB_Affiliate_WP::process($tx,$order,$bridge);
            $jewel_ok=true;
            if (class_exists('BZJ_PGB_Jewel_Affiliate')) $jewel_ok=BZJ_PGB_Jewel_Affiliate::process($tx,$order,$bridge);
            do_action('bzj_pgb_after_addons',$tx,$order,$bridge);
            if (!$affiliate_ok || !$jewel_ok) throw new Exception('One or more payment addons require retry');
            $wpdb->update($table,array('fulfilment_status'=>'completed','affiliate_status'=>$affiliate_ok?'completed':'failed',
                'retry_count'=>(int)$tx['retry_count'],'last_error'=>null,'fulfilled_at'=>current_time('mysql',true),
                'updated_at'=>current_time('mysql',true)),array('id'=>$txid));
            $bridge->logger->info('class-pgb-fulfillment.log','Fulfilment completed',array('transaction_id'=>$txid,'woo_order_id'=>$order_id));
            return true;
        } catch(Throwable $e) {
            $retry=(int)$tx['retry_count']+1;
            $delay=min(86400,max(60,60*(2**min($retry,8))));
            $next=gmdate('Y-m-d H:i:s',time()+$delay);
            $status=$retry >= (int)$bridge->settings['retry_limit'] ? 'failed' : 'processing';
            $wpdb->update($table,array('fulfilment_status'=>$status,'retry_count'=>$retry,'next_retry_at'=>$next,
                'last_error'=>$e->getMessage(),'updated_at'=>current_time('mysql',true)),array('id'=>$txid));
            $bridge->logger->error('class-pgb-fulfillment.log','Fulfilment failed; retry scheduled',array('transaction_id'=>$txid,'retry'=>$retry,'error'=>$e->getMessage()));
            return false;
        }
    }
}
