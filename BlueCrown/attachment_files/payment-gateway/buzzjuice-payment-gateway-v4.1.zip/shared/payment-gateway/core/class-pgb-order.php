<?php
if (!defined('ABSPATH')) exit;

class BZJ_PGB_Order {
    public static function initiate($data,$bridge) {
        global $wpdb;
        $log=$bridge->logger;
        $required=array('request_id','idempotency_key','wow_order_id','wow_user_id','wp_user_id','transaction_kind','wow_post_id');
        foreach($required as $k) if (!isset($data[$k]) || (string)$data[$k]==='') return new WP_Error('missing_'.$k,'Missing required field: '.$k,array('status'=>400));
        $request_id=sanitize_text_field($data['request_id']);
        $idem=sanitize_text_field($data['idempotency_key']);
        $wow_order=sanitize_text_field($data['wow_order_id']);
        $wow_user=absint($data['wow_user_id']); $wp_user=absint($data['wp_user_id']);
        $kind=strtoupper(preg_replace('/[^A-Z0-9_-]/','',(string)$data['transaction_kind']));
        $post_id=absint($data['wow_post_id']); $owner=absint($data['product_owner_id']??0);
        $currency=strtoupper(preg_replace('/[^A-Z]/','',(string)($data['currency']??get_woocommerce_currency())));
        if (!$currency) $currency=get_woocommerce_currency();
        $requested=(float)($data['amount']??0); $units=max(1,absint($data['units']??1));
        $return=esc_url_raw($data['return_url']??'');
        $table=$wpdb->prefix.'bzj_pgb_transactions';

        $existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE idempotency_key=%s LIMIT 1",$idem),ARRAY_A);
        if ($existing) return self::existing_response($existing);

        if ($wp_user<=0 || !get_user_by('ID',$wp_user)) return new WP_Error('user_invalid','WordPress user is invalid',array('status'=>400));
        if (!in_array($kind,array('PRO','WALLET','DONATE','PRODUCT'),true)) return new WP_Error('kind_invalid','Unsupported transaction kind',array('status'=>400));

        $map=self::streams_config();
        $expected_user=self::streams_user_link($wow_user);
        if ($expected_user && (int)$expected_user !== $wp_user) return new WP_Error('user_link_mismatch','Streams/WordPress user link mismatch',array('status'=>403));

        $product_id=self::resolve_product_id($kind,$post_id,$map);
        if ($product_id<=0) return new WP_Error('product_invalid','No configured WooCommerce product is mapped to this transaction',array('status'=>400));

        $product=wc_get_product($product_id);
        if (!$product) return new WP_Error('product_missing','WooCommerce product is unavailable',array('status'=>500));

        $dynamic=in_array($kind,array('WALLET','DONATE'),true);
        $price=(float)$product->get_price();
        if ($dynamic) {
            if ($requested < (float)$bridge->settings['dynamic_min'] || $requested > (float)$bridge->settings['dynamic_max']) return new WP_Error('amount_invalid','Dynamic payment amount is outside the configured limits',array('status'=>400));
            $unit=$requested/$units; $total=$requested;
        } else {
            $quantity=$units;
            if ($product->is_type('variation')) $price=(float)$product->get_price();
            if ($price<=0) return new WP_Error('price_invalid','Configured WooCommerce product has no valid price',array('status'=>400));
            $unit=$price; $total=round($price*$quantity, wc_get_price_decimals());
            if ($requested>0 && abs($requested-$total)>0.01) $log->warning('class-pgb-order.log','Browser amount ignored for fixed-price transaction',array('wow_order_id'=>$wow_order));
        }

        $wpdb->insert($table,array(
            'idempotency_key'=>$idem,'request_id'=>$request_id,'wow_order_id'=>$wow_order,'wow_user_id'=>$wow_user,'wp_user_id'=>$wp_user,
            'transaction_kind'=>$kind,'wow_post_id'=>$post_id,'product_id'=>$product_id,'currency'=>$currency,'requested_amount'=>$requested,
            'final_amount'=>$total,'payment_status'=>'pending','fulfilment_status'=>'pending','affiliate_status'=>'pending',
            'request_payload'=>wp_json_encode(self::redact_payload($data)),'created_at'=>current_time('mysql',true),'updated_at'=>current_time('mysql',true)
        ));
        $tx=(int)$wpdb->insert_id;
        if (!$tx) return new WP_Error('transaction_create','Could not create persistent payment transaction',array('status'=>500));

        try {
            $order=wc_create_order(array('customer_id'=>$wp_user));
            if (is_wp_error($order)) throw new Exception($order->get_error_message());
            $order->set_currency($currency);
            $order->set_created_via('bzj-pgb');
            $order->set_customer_id($wp_user);
            $order->add_product($product,$units,array(
                'subtotal'=>(string)$total,'total'=>(string)$total,
                'name'=>$product->get_name()
            ));
            $meta=array(
                '_bzj_pgb_transaction_id'=>$tx,'_bzj_pgb_request_id'=>$request_id,'_bzj_pgb_idempotency_key'=>$idem,
                '_bzj_wow_order_id'=>$wow_order,'_bzj_wow_user_id'=>$wow_user,'_bzj_wp_user_id'=>$wp_user,
                '_bzj_wow_post_id'=>$post_id,'_bzj_transaction_kind'=>$kind,'_bzj_product_owner_id'=>$owner,
                '_bzj_pgb_origin'=>'streams','_bzj_pgb_return_url'=>$return,
                'wow_order_id'=>$wow_order,'wow_post_id'=>$post_id,'userid'=>$wow_user,'bz_wow_user_id'=>$wow_user,
                '_buzzjuice_origin'=>'streams'
            );
            foreach($meta as $k=>$v) $order->update_meta_data($k,$v);
            $user=get_user_by('ID',$wp_user);
            if ($user) {
                $order->set_billing_first_name(get_user_meta($wp_user,'first_name',true) ?: $user->display_name);
                $order->set_billing_last_name(get_user_meta($wp_user,'last_name',true) ?: '');
                $order->set_billing_email($user->user_email);
                $order->set_shipping_first_name($order->get_billing_first_name());
                $order->set_shipping_last_name($order->get_billing_last_name());
            }
            $order->calculate_totals(false);
            $order->save();
            $pay_url=$order->get_checkout_payment_url();
            $wpdb->update($table,array('woo_order_id'=>$order->get_id(),'updated_at'=>current_time('mysql',true)),array('id'=>$tx));
            $log->info('class-pgb-order.log','WooCommerce order created',array('transaction_id'=>$tx,'woo_order_id'=>$order->get_id(),'wow_order_id'=>$wow_order));
            return array('success'=>true,'transaction_id'=>$tx,'woo_order_id'=>$order->get_id(),'url'=>$pay_url,'idempotent'=>false);
        } catch(Throwable $e) {
            $wpdb->update($table,array('fulfilment_status'=>'failed','last_error'=>$e->getMessage(),'updated_at'=>current_time('mysql',true)),array('id'=>$tx));
            $log->error('class-pgb-order.log','Order creation failed',array('transaction_id'=>$tx,'error'=>$e->getMessage()));
            return new WP_Error('order_create_failed','Unable to create the WooCommerce order',array('status'=>500,'transaction_id'=>$tx));
        }
    }

    private static function existing_response($row) {
        if (!empty($row['woo_order_id'])) {
            $order=wc_get_order((int)$row['woo_order_id']);
            if ($order) return array('success'=>true,'transaction_id'=>(int)$row['id'],'woo_order_id'=>(int)$row['woo_order_id'],'url'=>$order->get_checkout_payment_url(),'idempotent'=>true);
        }
        return new WP_Error('transaction_incomplete','An existing transaction is being recovered; retry shortly',array('status'=>409,'transaction_id'=>(int)$row['id']));
    }
    private static function resolve_product_id($kind,$post,$map) {
        if ($kind==='PRO') return absint($map['wow_pro_package_id_'.$post]??0);
        if ($kind==='WALLET') return absint($map['wow_wallet_topup_id']??0);
        if ($kind==='DONATE') return absint($map['wow_crowdfund_id']??0);
        return absint($map['wow_market_id']??0);
    }
    private static function streams_config() {
        $db=function_exists('get_wowonder_db')?get_wowonder_db():false;
        if (!$db) return array();
        $names=array('wow_market_id','wow_pro_package_id','wow_pro_package_id_2','wow_pro_package_id_3','wow_pro_package_id_4','wow_wallet_topup_id','wow_crowdfund_id','wow_payment','wow_store_url');
        $in="'".implode("','",array_map(array($db,'real_escape_string'),$names))."'";
        $out=array(); $q=$db->query("SELECT name,value FROM Wo_Config WHERE name IN ({$in})");
        if ($q) while($r=$q->fetch_assoc()) $out[$r['name']]=$r['value'];
        return $out;
    }
    private static function streams_user_link($wow_user_id) {
        $db=function_exists('get_wowonder_db')?get_wowonder_db():false; if(!$db) return 0;
        $st=$db->prepare("SELECT wp_user_id FROM Wo_Users WHERE user_id=? LIMIT 1"); if(!$st) return 0;
        $st->bind_param('i',$wow_user_id); $st->execute(); $st->bind_result($id); $id=$st->fetch()?(int)$id:0; $st->close(); return $id;
    }
    private static function redact_payload($d) {
        foreach(array('password','secret','api_key','api_secret','token','signature') as $k) if(isset($d[$k])) $d[$k]='[REDACTED]';
        return $d;
    }
}
