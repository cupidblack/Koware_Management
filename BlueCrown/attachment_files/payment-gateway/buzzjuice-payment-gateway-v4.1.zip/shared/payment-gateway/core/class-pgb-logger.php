<?php
if (!defined('ABSPATH')) exit;

class BZJ_PGB_Logger {
    private $dir;
    private $enabled;
    private $level;
    private $levels = array('DEBUG'=>10,'INFO'=>20,'WARNING'=>30,'ERROR'=>40);

    public function __construct($dir, $enabled=true, $level='INFO') {
        $this->dir = trailingslashit($dir);
        $this->enabled = (bool)$enabled;
        $this->level = strtoupper((string)$level);
        if (!isset($this->levels[$this->level])) $this->level='INFO';
        if (!is_dir($this->dir)) wp_mkdir_p($this->dir);
    }
    public function enabled(){ return $this->enabled; }
    public function log($file,$level,$message,$context=array()) {
        $level=strtoupper((string)$level);
        if (!isset($this->levels[$level])) $level='INFO';
        if (!$this->enabled && $level !== 'ERROR') return;
        if ($this->levels[$level] < $this->levels[$this->level]) return;
        $safe=$this->redact($context);
        $line=array('time'=>gmdate('c'),'level'=>$level,'message'=>(string)$message);
        if ($safe) $line['context']=$safe;
        $target=preg_replace('/[^A-Za-z0-9_.-]/','-',basename((string)$file));
        if ($target==='') $target='pgb-general.log';
        @file_put_contents($this->dir.$target, wp_json_encode($line, JSON_UNESCAPED_SLASHES).PHP_EOL, FILE_APPEND|LOCK_EX);
    }
    public function debug($f,$m,$c=array()){ $this->log($f,'DEBUG',$m,$c); }
    public function info($f,$m,$c=array()){ $this->log($f,'INFO',$m,$c); }
    public function warning($f,$m,$c=array()){ $this->log($f,'WARNING',$m,$c); }
    public function error($f,$m,$c=array()){ $this->log($f,'ERROR',$m,$c); }
    private function redact($v) {
        $keys=array('password','secret','api_secret','api_key','consumer_key','consumer_secret','token','access_token','refresh_token','authorization','signature','webhook_secret');
        if (is_array($v)) {
            $out=array();
            foreach($v as $k=>$x) {
                if (in_array(strtolower((string)$k),$keys,true)) $out[$k]='[REDACTED]';
                else $out[$k]=$this->redact($x);
            }
            return $out;
        }
        if (is_object($v)) return $this->redact((array)$v);
        if (is_string($v) && strlen($v)>2000) return substr($v,0,2000).'…';
        return $v;
    }
}
