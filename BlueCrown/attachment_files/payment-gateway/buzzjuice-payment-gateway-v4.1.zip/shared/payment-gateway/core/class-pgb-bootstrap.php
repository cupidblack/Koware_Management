<?php
if (!defined('ABSPATH')) exit;

$bzj_db_helpers = ABSPATH . 'shared/db_helpers.php';
if (is_readable($bzj_db_helpers)) require_once $bzj_db_helpers;
require_once BZJ_PGB_DIR.'core/class-pgb-logger.php';
require_once BZJ_PGB_DIR.'core/class-pgb-client.php';
require_once BZJ_PGB_DIR.'core/class-pgb-order.php';
require_once BZJ_PGB_DIR.'core/class-pgb-fulfillment.php';

class BZJ_PGB_Bootstrap {
    private static $instance;
    public $logger;
    public $settings;

    public static function instance(){ return self::$instance ?: (self::$instance=new self()); }
    private function __construct(){}

    public function boot() {
        $this->settings=$this->settings();
        $this->logger=new BZJ_PGB_Logger(BZJ_PGB_LOG_DIR,$this->settings['logging_enabled'],$this->settings['log_level']);
        add_action('init',array($this,'ensure_table'),1);
        add_action('rest_api_init',array($this,'register_routes'));
        add_action('admin_menu',array($this,'admin_menu'));
        add_action('admin_init',array($this,'admin_init'));
        add_action('woocommerce_payment_complete',array($this,'payment_event'),20);
        add_action('woocommerce_order_status_processing',array($this,'payment_event'),20);
        add_action('woocommerce_order_status_completed',array($this,'payment_event'),20);
        add_action('bzj_pgb_retry_due',array($this,'retry_due'));
        add_action('init',array($this,'schedule_retry'),20);
        if (class_exists('WooCommerce')) {
            add_filter('woocommerce_get_return_url',array($this,'return_url'),10,2);
        }
        $this->load_extensions();
    }

    public function settings() {
        $defaults=array(
            'enabled'=>true,'logging_enabled'=>true,'log_level'=>'INFO','request_ttl'=>300,
            'retry_limit'=>6,'dynamic_min'=>1,'dynamic_max'=>100000,
            'streams_url'=>'','secret_env'=>'BZJ_PGB_SECRET',
        );
        $saved=get_option(BZJ_PGB_OPTION,array());
        return wp_parse_args(is_array($saved)?$saved:array(),$defaults);
    }

    public function ensure_table() {
        global $wpdb;
        $table=$wpdb->prefix.'bzj_pgb_transactions';
        $charset=$wpdb->get_charset_collate();
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $sql="CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            idempotency_key varchar(191) NOT NULL,
            request_id varchar(191) NOT NULL,
            wow_order_id varchar(191) NOT NULL,
            wow_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            wp_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            woo_order_id bigint(20) unsigned NOT NULL DEFAULT 0,
            transaction_kind varchar(32) NOT NULL,
            wow_post_id bigint(20) unsigned NOT NULL DEFAULT 0,
            product_id bigint(20) unsigned NOT NULL DEFAULT 0,
            currency varchar(12) NOT NULL DEFAULT '',
            requested_amount decimal(20,6) NOT NULL DEFAULT 0,
            final_amount decimal(20,6) NOT NULL DEFAULT 0,
            payment_status varchar(32) NOT NULL DEFAULT 'pending',
            fulfilment_status varchar(32) NOT NULL DEFAULT 'pending',
            affiliate_status varchar(32) NOT NULL DEFAULT 'pending',
            retry_count int(11) NOT NULL DEFAULT 0,
            next_retry_at datetime NULL,
            last_error text NULL,
            request_payload longtext NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            paid_at datetime NULL,
            fulfilled_at datetime NULL,
            PRIMARY KEY(id),
            UNIQUE KEY idempotency_key(idempotency_key),
            UNIQUE KEY request_id(request_id),
            UNIQUE KEY wow_order_id(wow_order_id),
            KEY woo_order_id(woo_order_id),
            KEY status_retry(payment_status,fulfilment_status,next_retry_at)
        ) {$charset};";
        dbDelta($sql);
    }

    public function register_routes() {
        register_rest_route('bzj-pgb/v1','/init',array(
            'methods'=>'POST','callback'=>array($this,'api_init'),'permission_callback'=>'__return_true'
        ));
        register_rest_route('bzj-pgb/v1','/status/(?P<id>[0-9]+)',array(
            'methods'=>'GET','callback'=>array($this,'api_status'),'permission_callback'=>'__return_true'
        ));
    }

    public function api_init(WP_REST_Request $r) {
        if (!$this->settings['enabled']) return new WP_Error('pgb_disabled','Payment Gateway Bridge is disabled',array('status'=>503));
        $body=$r->get_body();
        $auth=BZJ_PGB_Client::authenticate($r,$body,$this->settings,$this->logger);
        if (is_wp_error($auth)) return $auth;
        $data=json_decode($body,true);
        if (!is_array($data)) return new WP_Error('bad_json','Invalid JSON',array('status'=>400));
        $result=BZJ_PGB_Order::initiate($data,$this);
        if (is_wp_error($result)) return $result;
        return new WP_REST_Response($result,200);
    }

    public function api_status(WP_REST_Request $r) {
        global $wpdb;
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}bzj_pgb_transactions WHERE id=%d",(int)$r['id']),ARRAY_A);
        if (!$row) return new WP_Error('not_found','Transaction not found',array('status'=>404));
        return array('success'=>true,'transaction_id'=>(int)$row['id'],'payment_status'=>$row['payment_status'],
            'fulfilment_status'=>$row['fulfilment_status'],'woo_order_id'=>(int)$row['woo_order_id']);
    }

    public function payment_event($order_id) {
        if (!$this->settings['enabled']) return;
        BZJ_PGB_Fulfillment::process((int)$order_id,$this);
    }

    public function retry_due() {
        global $wpdb;
        $now=current_time('mysql',true);
        $rows=$wpdb->get_col($wpdb->prepare("SELECT woo_order_id FROM {$wpdb->prefix}bzj_pgb_transactions
            WHERE payment_status='paid' AND fulfilment_status IN('pending','processing','failed')
            AND retry_count < %d AND (next_retry_at IS NULL OR next_retry_at<=%s) LIMIT 20",
            (int)$this->settings['retry_limit'],$now));
        foreach((array)$rows as $order_id) BZJ_PGB_Fulfillment::process((int)$order_id,$this);
    }

    public function schedule_retry() {
        if (!wp_next_scheduled('bzj_pgb_retry_due')) wp_schedule_event(time()+120,'minute','bzj_pgb_retry_due');
    }

    public function load_extensions() {
        foreach(array('addons','integrations') as $dir) {
            $files=glob(BZJ_PGB_DIR.$dir.'/pgb-*.php');
            foreach((array)$files as $file) {
                if (basename($file)==='pgb-bootstrap.php') continue;
                require_once $file;
            }
        }
    }

    public function admin_menu() {
        $parent='blue-crown';
        if (!isset($GLOBALS['menu'])) return;
        $found=false;
        foreach((array)$GLOBALS['menu'] as $m) if(isset($m[2]) && $m[2]===$parent) $found=true;
        if ($found) add_submenu_page($parent,'Payment Gateway','Payment Gateway','manage_options','bzj-payment-gateway',array($this,'admin_page'));
        else add_menu_page('Blue Crown Payment Gateway','Payment Gateway','manage_options','bzj-payment-gateway',array($this,'admin_page'),'dashicons-cart',58.5);
    }
    public function admin_init() {
        if (!isset($_POST['bzj_pgb_save'])) return;
        if (!current_user_can('manage_options') || !check_admin_referer('bzj_pgb_settings')) return;
        $s=$this->settings;
        foreach(array('enabled','logging_enabled') as $k) $s[$k]=!empty($_POST[$k]);
        $s['log_level']=in_array($_POST['log_level']??'INFO',array('DEBUG','INFO','WARNING','ERROR'),true)?$_POST['log_level']:'INFO';
        $s['request_ttl']=max(30,min(3600,(int)($_POST['request_ttl']??300)));
        $s['retry_limit']=max(1,min(20,(int)($_POST['retry_limit']??6)));
        $s['dynamic_min']=max(0,(float)($_POST['dynamic_min']??1));
        $s['dynamic_max']=max($s['dynamic_min'],(float)($_POST['dynamic_max']??100000));
        $s['streams_url']=esc_url_raw($_POST['streams_url']??'');
        update_option(BZJ_PGB_OPTION,$s);
        $this->settings=$s;
        $this->logger->info('class-pgb-bootstrap.log','Settings updated');
    }
    public function admin_page() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        global $wpdb;
        $t=$wpdb->prefix.'bzj_pgb_transactions';
        $stats=$wpdb->get_row("SELECT COUNT(*) total,
            SUM(payment_status='paid') paid,SUM(fulfilment_status='completed') completed,
            SUM(fulfilment_status='failed') failed FROM {$t}",ARRAY_A);
        $s=$this->settings;
        ?>
        <div class="wrap"><h1>Blue Crown → Payment Gateway</h1>
        <form method="post"><?php wp_nonce_field('bzj_pgb_settings'); ?>
        <table class="form-table">
        <tr><th>Bridge enabled</th><td><input type="checkbox" name="enabled" value="1" <?php checked($s['enabled']); ?>></td></tr>
        <tr><th>Logging enabled</th><td><input type="checkbox" name="logging_enabled" value="1" <?php checked($s['logging_enabled']); ?>></td></tr>
        <tr><th>Log level</th><td><select name="log_level"><?php foreach(array('DEBUG','INFO','WARNING','ERROR') as $l) echo '<option '.selected($s['log_level'],$l,false).'>'.$l.'</option>'; ?></select></td></tr>
        <tr><th>Request TTL</th><td><input type="number" name="request_ttl" value="<?php echo esc_attr($s['request_ttl']); ?>"> seconds</td></tr>
        <tr><th>Retry limit</th><td><input type="number" name="retry_limit" value="<?php echo esc_attr($s['retry_limit']); ?>"></td></tr>
        <tr><th>Dynamic minimum</th><td><input type="number" step="0.01" name="dynamic_min" value="<?php echo esc_attr($s['dynamic_min']); ?>"></td></tr>
        <tr><th>Dynamic maximum</th><td><input type="number" step="0.01" name="dynamic_max" value="<?php echo esc_attr($s['dynamic_max']); ?>"></td></tr>
        <tr><th>Streams URL</th><td><input class="regular-text" name="streams_url" value="<?php echo esc_attr($s['streams_url']); ?>"></td></tr>
        </table><p><strong>HMAC secret:</strong> supplied only through <code>BZJ_PGB_SECRET</code> in the server environment. It is never stored in WordPress options.</p>
        <p><strong>Transactions:</strong> <?php echo esc_html((int)($stats['total']??0)); ?> &nbsp; Paid: <?php echo esc_html((int)($stats['paid']??0)); ?> &nbsp; Fulfilled: <?php echo esc_html((int)($stats['completed']??0)); ?> &nbsp; Failed: <?php echo esc_html((int)($stats['failed']??0)); ?></p>
        <p><button class="button button-primary" name="bzj_pgb_save" value="1">Save Changes</button></p></form></div>
        <?php
    }

    public function return_url($url,$order) {
        $tid=$order->get_meta('_bzj_pgb_transaction_id',true);
        if (!$tid) return $url;
        $return=$order->get_meta('_bzj_pgb_return_url',true);
        return $return ? add_query_arg(array('pgb_transaction'=>(int)$tid,'pgb_status'=>'paid'),$return) : $url;
    }
}
