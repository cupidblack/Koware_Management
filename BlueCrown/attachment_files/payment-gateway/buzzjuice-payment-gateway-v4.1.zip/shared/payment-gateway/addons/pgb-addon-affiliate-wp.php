<?php
if (!defined('ABSPATH')) exit;

class BZJ_PGB_Affiliate_WP {
    public static function process($tx,$order,$bridge) {
        if ($order->get_meta('_bzj_pgb_affiliate_processed',true)) return true;
        if (!function_exists('affwp_add_referral')) return true;
        global $wpdb;
        $log=$bridge->logger;
        $email=$order->get_billing_email();
        if(!$email) return false;
        $customer_id=self::customer($order);
        if(!$customer_id) return true;
        $resolved=self::affiliate($order,$customer_id);
        if(!$resolved) return true;
        $affiliate_id=(int)$resolved['affiliate_id'];
        $commission=self::commission($order);
        if($commission<=0){$order->update_meta_data('_bzj_pgb_affiliate_processed',gmdate('c'));$order->save();return true;}
        $existing=(int)$wpdb->get_var($wpdb->prepare("SELECT referral_id FROM {$wpdb->prefix}affiliate_wp_referrals WHERE reference=%s AND context=%s LIMIT 1",(string)$order->get_id(),'woocommerce'));
        if($existing){$order->update_meta_data('_bzj_pgb_affiliate_processed',gmdate('c'));$order->update_meta_data('_affwp_bridge_referral_id',$existing);$order->save();return true;}
        $products=array();
        foreach($order->get_items() as $item)$products[]=array('product_id'=>$item->get_product_id(),'variation_id'=>$item->get_variation_id(),'name'=>$item->get_name(),'item_total'=>(float)$item->get_total());
        $data=array('affiliate_id'=>$affiliate_id,'customer_id'=>$customer_id,'description'=>'Buzzjuice Streams order #'.$order->get_id(),
            'status'=>'unpaid','amount'=>round($commission,4),'currency'=>$order->get_currency(),'context'=>'woocommerce',
            'reference'=>(string)$order->get_id(),'products'=>maybe_serialize($products),'date'=>current_time('mysql'),
            'custom'=>maybe_serialize(array('origin'=>'streams','resolution_source'=>$resolved['source'],'pgb_transaction_id'=>(int)$tx['id'])));
        $ref=affwp_add_referral($data);
        if(!$ref) throw new Exception('AffiliateWP referral creation failed');
        $verify=$wpdb->get_row($wpdb->prepare("SELECT referral_id,affiliate_id,customer_id,amount,reference,status FROM {$wpdb->prefix}affiliate_wp_referrals WHERE referral_id=%d",(int)$ref));
        if(!$verify || (int)$verify->affiliate_id!==$affiliate_id || abs((float)$verify->amount-$commission)>0.0001 || (string)$verify->reference!==(string)$order->get_id()) throw new Exception('AffiliateWP referral verification failed');
        if(function_exists('affiliate_wp_lifetime_commissions')){
            $exists=(int)$wpdb->get_var($wpdb->prepare("SELECT lifetime_customer_id FROM {$wpdb->prefix}affiliate_wp_lifetime_customers WHERE affwp_customer_id=%d AND affiliate_id=%d LIMIT 1",$customer_id,$affiliate_id));
            if(!$exists) @affiliate_wp_lifetime_commissions()->lifetime_customers->add(array('affwp_customer_id'=>$customer_id,'affiliate_id'=>$affiliate_id,'date_created'=>current_time('mysql')));
        }
        $order->update_meta_data('_bzj_pgb_affiliate_processed',gmdate('c'));
        $order->update_meta_data('_affwp_bridge_processed',current_time('mysql'));
        $order->update_meta_data('_affwp_bridge_referral_id',(int)$ref);
        $order->save();
        $log->info('pgb-addon-affiliate-wp.log','AffiliateWP referral created',array('transaction_id'=>$tx['id'],'order_id'=>$order->get_id(),'affiliate_id'=>$affiliate_id,'referral_id'=>(int)$ref,'commission'=>$commission));
        return true;
    }
    private static function customer($order) {
        $email=$order->get_billing_email(); $uid=(int)$order->get_customer_id();
        if(function_exists('affwp_get_customer_by_email')){ $c=affwp_get_customer_by_email($email); if($c && !empty($c->customer_id)) return (int)$c->customer_id; }
        global $wpdb;
        $id=(int)$wpdb->get_var($wpdb->prepare("SELECT customer_id FROM {$wpdb->prefix}affiliate_wp_customers WHERE email=%s LIMIT 1",$email));
        if($id)return $id;
        if(function_exists('affwp_add_customer')){
            $id=affwp_add_customer(array('user_id'=>$uid,'email'=>$email)); if($id && !is_wp_error($id))return (int)$id;
        }
        return 0;
    }
    private static function affiliate($order,$customer_id) {
        global $wpdb; $snap=json_decode((string)$order->get_meta('_buzzjuice_affwp_context_snapshot',true),true)?:array();
        $id=(int)$wpdb->get_var($wpdb->prepare("SELECT affiliate_id FROM {$wpdb->prefix}affiliate_wp_lifetime_customers WHERE affwp_customer_id=%d ORDER BY lifetime_customer_id DESC LIMIT 1",$customer_id));
        if($id)return array('affiliate_id'=>$id,'source'=>'LifetimeCustomers');
        $visit=(int)($snap['affwp_visit_id']??0);
        if($visit)$id=(int)$wpdb->get_var($wpdb->prepare("SELECT affiliate_id FROM {$wpdb->prefix}affiliate_wp_visits WHERE visit_id=%d",$visit));
        if($id)return array('affiliate_id'=>$id,'source'=>'Snapshot:visit_id');
        $id=(int)$wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->prefix}affiliate_wp_customermeta WHERE affwp_customer_id=%d AND meta_key=%s LIMIT 1",$customer_id,'referring_affiliate_id'));
        if($id)return array('affiliate_id'=>$id,'source'=>'CustomerMeta');
        $id=(int)($snap['affwp_affiliate_id']??0);
        if($id)return array('affiliate_id'=>$id,'source'=>'Snapshot:affiliate_id');
        if(function_exists('affwp_get_affiliate_id')){ $id=(int)affwp_get_affiliate_id(); if($id)return array('affiliate_id'=>$id,'source'=>'AffiliateWP current context');}
        return false;
    }
    private static function commission($order) {
        $settings=get_option('affwp_settings',array()); $default=(float)($settings['referral_rate']??0); $type=$settings['referral_rate_type']??'percentage'; $total=0;
        foreach($order->get_items() as $item){
            $target=$item->get_variation_id()?:$item->get_product_id(); $raw=get_post_meta($target,'_affwp_woocommerce_product_rate',true); $rt=get_post_meta($target,'_affwp_woocommerce_product_rate_type',true);
            $base=(float)$item->get_total();
            if($raw!=='' && is_numeric($raw) && in_array($rt,array('percentage','flat'),true)) $total += $rt==='percentage' ? $base*((float)$raw/100) : (float)$raw;
            elseif($default>0) $total += $type==='percentage' ? $base*($default/100) : $default;
        }
        return round($total,4);
    }
}
