<?php
/**
 * Generic client helpers. Streams should use pgb-client-streams.php.
 */
if (!defined('ABSPATH') && !defined('WO_PGB_CLIENT')) { /* allowed when included by Streams */ }
if (!function_exists('bzj_pgb_json')) {
function bzj_pgb_json($data){ return json_encode($data,JSON_UNESCAPED_SLASHES); }
}
