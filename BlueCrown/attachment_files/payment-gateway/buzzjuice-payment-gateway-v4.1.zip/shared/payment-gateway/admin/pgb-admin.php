<?php
// Admin UI is intentionally bootstrapped by class-pgb-bootstrap.php so the MU plugin remains one file.
