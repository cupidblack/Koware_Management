<?php
if (!defined('ABSPATH')) exit;

class BZJ_PGB_Jewel_Affiliate {
    public static function process($tx,$order,$bridge) {
        $variation=0;
        foreach($order->get_items() as $item){$variation=(int)$item->get_variation_id();if($variation)break;}
        if(!$variation) $variation=(int)reset($order->get_items())->get_product_id();
        $name=strtolower((string)$order->get_meta('_bzj_product_name',true));
        $is_jewel=(bool)$order->get_meta('_jewel_affiliate',true) || strpos($name,'jewel')!==false;
        if(!$is_jewel) return true;
        if($order->get_meta('_bzj_pgb_jewel_processed',true)) return true;
        $db=function_exists('get_wowonder_db')?get_wowonder_db():false;
        if(!$db) throw new Exception('WoWonder DB unavailable for Jewel integration');
        $uid=(int)$tx['wow_user_id']; $type=(int)$tx['wow_post_id']; $now=time();
        $st=$db->prepare("UPDATE Wo_Users SET pro_time=?, is_pro=1, pro_type=? WHERE user_id=?");
        if(!$st) throw new Exception('Jewel user update prepare failed');
        $st->bind_param('iii',$now,$type,$uid);
        if(!$st->execute()) throw new Exception('Jewel user update failed');
        $order->update_meta_data('_bzj_pgb_jewel_processed',gmdate('c'));$order->save();
        $bridge->logger->info('pgb-int-jewel-affiliate.log','Jewel Affiliate integration completed',array('transaction_id'=>$tx['id'],'wow_user_id'=>$uid,'variation_id'=>$variation));
        return true;
    }
}
