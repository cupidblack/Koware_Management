<?php
if (!defined('ABSPATH')) exit;

class BZJ_PGB_Streams_Integration {
    public static function db() {
        if (function_exists('get_wowonder_db')) return get_wowonder_db();
        return false;
    }
    public static function fulfill($tx,$order,$bridge) {
        $db=self::db(); if(!$db) throw new Exception('WoWonder database unavailable');
        $wow_order=(string)$tx['wow_order_id']; $wow_user=(int)$tx['wow_user_id'];
        $amount=(float)$order->get_total(); $status=$order->get_status();
        $method=$order->get_payment_method_title();
        $st=$db->prepare("UPDATE Wo_Payment_Transactions SET payment_status=?, payment_method=?, woo_order_id=?, amount=?, transaction_dt=NOW() WHERE order_id=?");
        if(!$st) throw new Exception('Wo_Payment_Transactions prepare failed: '.$db->error);
        $wid=(int)$order->get_id();
        $st->bind_param('ssids',$status,$method,$wid,$amount,$wow_order);
        if(!$st->execute()) throw new Exception('Wo_Payment_Transactions update failed: '.$st->error);
        $kind=strtoupper($tx['transaction_kind']);
        if($kind==='WALLET') self::wallet($db,$tx,$order);
        elseif($kind==='DONATE') self::donation($db,$tx,$order);
        elseif($kind==='PRODUCT') self::product($db,$tx,$order);
        elseif($kind==='PRO') self::pro($db,$tx,$order);
        $bridge->logger->info('pgb-int-streams.log','Streams fulfilment applied',array('transaction_id'=>$tx['id'],'kind'=>$kind,'wow_order_id'=>$wow_order));
    }
    private static function marker($order,$name){ return (string)$order->get_meta('_bzj_pgb_'.$name.'_applied',true)!==''; }
    private static function mark($order,$name){ $order->update_meta_data('_bzj_pgb_'.$name.'_applied',gmdate('c')); $order->save(); }
    private static function wallet($db,$tx,$order) {
        if(self::marker($order,'wallet')) return;
        $uid=(int)$tx['wow_user_id']; $amount=(float)$order->get_total();
        $st=$db->prepare("UPDATE Wo_Users SET wallet=wallet+? WHERE user_id=?");
        if(!$st) throw new Exception('Wallet update prepare failed: '.$db->error);
        $st->bind_param('di',$amount,$uid);
        if(!$st->execute()) throw new Exception('Wallet update failed: '.$st->error);
        self::mark($order,'wallet');
    }
    private static function donation($db,$tx,$order) {
        if(self::marker($order,'donation')) return;
        $fund=(int)$tx['wow_post_id']; $uid=(int)$tx['wow_user_id']; $amount=(float)$order->get_total(); $time=time();
        $st=$db->prepare("INSERT INTO Wo_Funding_Raise (funding_id,user_id,amount,time) VALUES (?,?,?,?)");
        if(!$st) throw new Exception('Funding prepare failed: '.$db->error);
        $st->bind_param('iidi',$fund,$uid,$amount,$time);
        if(!$st->execute()) throw new Exception('Funding insert failed: '.$st->error);
        self::mark($order,'donation');
    }
    private static function product($db,$tx,$order) {
        if(self::marker($order,'product')) return;
        $uid=(int)$tx['wow_user_id']; $owner=(int)$order->get_meta('_bzj_product_owner_id',true); $amount=(float)$order->get_total(); $time=time();
        $hash=(string)$tx['wow_order_id']; $name=$order->get_items()?reset($order->get_items())->get_name():'Product'; $pid=(int)$tx['wow_post_id'];
        $data=wp_json_encode(array('name'=>$name,'product_id'=>$pid,'units'=>1,'currency'=>$order->get_currency(),'timestamp'=>$time));
        $st=$db->prepare("INSERT INTO Wo_Purchases (user_id,order_hash_id,owner_id,data,final_price,commission,price,timestamp,time) VALUES (?,?,?,?,?,?,?,?,?)");
        if($st){$zero=0.0;$price=$amount;$st->bind_param('isssddddd',$uid,$hash,$owner,$data,$amount,$zero,$price,$time,$time);if(!$st->execute())throw new Exception('Purchase insert failed: '.$st->error);}
        $st=$db->prepare("UPDATE Wo_UserOrders SET status='delivered' WHERE hash_id=?");
        if($st){$st->bind_param('s',$hash);$st->execute();}
        self::mark($order,'product');
    }
    private static function pro($db,$tx,$order) {
        if(self::marker($order,'pro')) return;
        $uid=(int)$tx['wow_user_id']; $type=(int)$tx['wow_post_id'];
        if(!in_array($type,array(1,2,3,4),true)) throw new Exception('Invalid PRO type');
        $now=time();
        $st=$db->prepare("UPDATE Wo_Users SET pro_time=?, is_pro=1, pro_type=? WHERE user_id=?");
        if(!$st) throw new Exception('PRO update prepare failed: '.$db->error);
        $st->bind_param('iii',$now,$type,$uid);
        if(!$st->execute()) throw new Exception('PRO update failed: '.$st->error);
        self::mark($order,'pro');
    }
}
