(function(window,$){
'use strict';
window.BZJ_PGB={
  busy:false,
  pay:function(button){
    if(this.busy)return false;
    this.busy=true;
    var el=$(button), data=el.data('pgbPayload');
    if(typeof data==='string'){try{data=JSON.parse(data);}catch(e){data={};}}
    el.prop('disabled',true).addClass('disabled');
    $.ajax({
      url:el.data('pgbEndpoint')||window.location.origin+'/requests.php?f=payment',
      method:'POST',data:data,dataType:'json'
    }).done(function(r){
      if(r&&r.success&&r.url){window.location.href=r.url;return;}
      var msg=(r&&r.message)||'Payment initialization failed.';
      if(window.Wo_ShowAlert) Wo_ShowAlert(msg); else alert(msg);
    }).fail(function(xhr){
      var msg='Payment service is temporarily unavailable. Please try again.';
      if(xhr.responseJSON&&xhr.responseJSON.message)msg=xhr.responseJSON.message;
      if(window.Wo_ShowAlert)Wo_ShowAlert(msg);else alert(msg);
    }).always(function(){BZJ_PGB.busy=false;el.prop('disabled',false).removeClass('disabled');});
    return false;
  }
};
})(window,window.jQuery);
