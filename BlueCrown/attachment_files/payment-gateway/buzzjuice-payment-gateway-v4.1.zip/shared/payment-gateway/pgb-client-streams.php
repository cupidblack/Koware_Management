<?php
/**
 * Buzzjuice Streams PGB client.
 * This file intentionally contains no WooCommerce credentials.
 */
if (is_readable(dirname(__DIR__,2).'/db_helpers.php')) require_once dirname(__DIR__,2).'/db_helpers.php';
if (!function_exists('bzj_pgb_streams_uuid')) { function bzj_pgb_streams_uuid(){ try{return bin2hex(random_bytes(16));}catch(Throwable $e){return uniqid('pgb_',true);} } }
if (!function_exists('bzj_pgb_streams_log')) {
    function bzj_pgb_streams_log($message,$context=array()) {
        $enabled=true;
        if (defined('BZJ_PGB_STREAMS_LOGGING')) $enabled=(bool)BZJ_PGB_STREAMS_LOGGING;
        if (!$enabled) return;
        $dir=dirname(__DIR__).'/payment-gateway/log';
        if(!is_dir($dir)) @mkdir($dir,0755,true);
        $safe=array();
        foreach((array)$context as $k=>$v) if(!in_array(strtolower($k),array('secret','signature','token','password'),true)) $safe[$k]=$v;
        @file_put_contents($dir.'/pgb-client-streams.log',json_encode(array('time'=>gmdate('c'),'message'=>$message,'context'=>$safe),JSON_UNESCAPED_SLASHES).PHP_EOL,FILE_APPEND|LOCK_EX);
    }
}
class BZJ_PGB_Client_Streams {
    private $endpoint;
    private $secret;
    public function __construct($endpoint=null,$secret=null) {
        $this->endpoint=$endpoint ?: rtrim(getenv('BZJ_PGB_WP_URL') ?: 'https://buzzjuice.net','/').'/wp-json/bzj-pgb/v1/init';
        $this->secret=$secret!==null?$secret:(getenv('BZJ_PGB_SECRET')?:'');
    }
    public function init_payment(array $data) {
        if($this->secret==='') return array('success'=>false,'message'=>'Payment bridge is not configured.');
        $body=json_encode($data,JSON_UNESCAPED_SLASHES);
        $ts=(string)time(); $request_id=bzj_pgb_streams_uuid();
        $headers=array('Content-Type: application/json','X-BZJ-PGB-Timestamp: '.$ts,'X-BZJ-PGB-Request-ID: '.$request_id,
            'X-BZJ-PGB-Signature: '.hash_hmac('sha256',$ts."\n".$body,$this->secret));
        $ch=curl_init($this->endpoint);
        curl_setopt_array($ch,array(CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_HTTPHEADER=>$headers,
            CURLOPT_TIMEOUT=>30,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_SSL_VERIFYPEER=>true));
        $raw=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
        if($err){bzj_pgb_streams_log('HTTP error',array('request_id'=>$request_id,'error'=>$err));return array('success'=>false,'message'=>'Payment service temporarily unavailable.');}
        $out=json_decode((string)$raw,true);
        if($http<200||$http>=300||!is_array($out)){bzj_pgb_streams_log('Bridge rejected request',array('request_id'=>$request_id,'http_code'=>$http));return array('success'=>false,'message'=>$out['message']??'Payment initialization failed.');}
        return $out;
    }
}
