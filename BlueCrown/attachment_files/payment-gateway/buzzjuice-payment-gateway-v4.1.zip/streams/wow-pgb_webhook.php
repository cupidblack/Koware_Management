<?php
/**
 * Legacy WooCommerce webhook endpoint.
 * Payment fulfilment is now owned by the WordPress MU-plugin and WooCommerce hooks.
 * This endpoint is intentionally non-operative during migration.
 */
http_response_code(410);
header('Content-Type: application/json');
echo json_encode(array(
    'success'=>false,
    'status'=>'retired',
    'message'=>'Buzzjuice Payment Gateway Bridge v4 uses server-side WooCommerce lifecycle hooks. This webhook endpoint is retired.'
));
exit;
