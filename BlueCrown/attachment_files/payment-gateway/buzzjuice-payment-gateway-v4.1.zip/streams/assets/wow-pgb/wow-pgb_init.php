<?php
require_once dirname(__DIR__,2).'/config.php';
require_once dirname(__DIR__,2).'/init.php';
header('Content-Type: application/json');

if (empty($wo['loggedin']) || !$wo['loggedin']) {
    http_response_code(401);
    echo json_encode(array('success'=>false,'message'=>'Please login to continue.'));
    exit;
}
require_once dirname(__DIR__,3).'/shared/payment-gateway/pgb-client-streams.php';

$wow_user_id=(int)($wo['user']['user_id']??0);
$wp_user_id=0;
if($wow_user_id){
    $q=mysqli_query($sqlConnect,"SELECT wp_user_id FROM ".T_USERS." WHERE user_id=".$wow_user_id." LIMIT 1");
    if($q&&($r=mysqli_fetch_assoc($q)))$wp_user_id=(int)($r['wp_user_id']??0);
}
if(!$wp_user_id){http_response_code(400);echo json_encode(array('success'=>false,'message'=>'Your Buzzjuice account is not linked correctly.'));exit;}

$kind=strtoupper(preg_replace('/[^A-Z0-9_-]/','',(string)($_POST['transaction_kind']??'')));
$post_id=(int)($_POST['wow_post_id']??0);
$uuid=function_exists('random_bytes')?bin2hex(random_bytes(16)):uniqid('',true);
$wow_order_id='wow_'.$uuid;
$payload=array(
 'request_id'=>(function_exists('random_bytes')?bin2hex(random_bytes(16)):uniqid('req_',true)),'idempotency_key'=>hash('sha256',$wow_order_id.'|'.$wow_user_id.'|'.$kind.'|'.$post_id.'|'.(string)($_POST['payment_attempt']??'')),
 'wow_order_id'=>$wow_order_id,'wow_user_id'=>$wow_user_id,'wp_user_id'=>$wp_user_id,'transaction_kind'=>$kind,
 'wow_post_id'=>$post_id,'product_owner_id'=>(int)($_POST['product_owner_id']??0),'amount'=>(float)($_POST['amount']??0),
 'units'=>max(1,(int)($_POST['product_units']??1)),'currency'=>strtoupper((string)($_POST['wow_currency_code']??($wo['config']['currency']??'GHS'))),
 'return_url'=>filter_var($_POST['return_url']??'',FILTER_VALIDATE_URL)?$_POST['return_url']:''
);
$client=new BZJ_PGB_Client_Streams();
$result=$client->init_payment($payload);
echo json_encode($result);
exit;
