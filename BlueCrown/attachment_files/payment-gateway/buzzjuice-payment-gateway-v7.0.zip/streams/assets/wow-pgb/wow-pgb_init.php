<?php
require_once dirname(__DIR__, 2) . '/config.php';
require_once dirname(__DIR__, 2) . '/init.php';

header('Content-Type: application/json; charset=UTF-8');

if (empty($wo['loggedin'])) {
    http_response_code(401);
    echo json_encode(array('status' => 'error', 'message' => 'Please login to continue.'));
    exit;
}

$log_dir = dirname(__DIR__, 3) . '/shared/payment-gateway/log/';

if (!function_exists('wow_pgb_init_log')) {
    function wow_pgb_init_log($message, array $context = array()) {
        global $log_dir;

        $enabled = getenv('BZJ_PGB_DEBUG');
        if (!in_array(strtolower((string) $enabled), array('1','true','yes','on'), true)) {
            return;
        }

        if (!is_dir($log_dir)) {
            @mkdir($log_dir, 0755, true);
        }

        @file_put_contents(
            $log_dir . 'wow-pgb_init.log',
            json_encode(array(
                'time' => gmdate('c'),
                'level' => 'INFO',
                'message' => $message,
                'context' => $context,
            ), JSON_UNESCAPED_SLASHES) . PHP_EOL,
            FILE_APPEND | LOCK_EX
        );
    }
}

$required = array(
    'amount',
    'product_name',
    'product_price',
    'product_units',
    'product_owner_id',
    'transaction_kind',
    'wow_currency_code',
);

foreach ($required as $field) {
    if (!isset($_POST[$field]) || $_POST[$field] === '') {
        http_response_code(400);
        echo json_encode(array(
            'status' => 'error',
            'message' => 'Missing required parameter: ' . $field,
        ));
        exit;
    }
}

$wow_user_id = (int) ($wo['user']['user_id'] ?? 0);
$wow_username = (string) ($wo['user']['username'] ?? '');
$email = filter_var((string) ($wo['user']['email'] ?? ''), FILTER_VALIDATE_EMAIL);

if ($wow_user_id <= 0 || $wow_username === '' || !$email) {
    http_response_code(400);
    echo json_encode(array('status' => 'error', 'message' => 'Unable to resolve the current Streams user.'));
    exit;
}

$transaction_kind = strtoupper(preg_replace('/[^A-Z0-9_-]/', '', (string) $_POST['transaction_kind']));
$amount = (float) $_POST['amount'];
$product_name = trim((string) $_POST['product_name']);
$product_price = (float) $_POST['product_price'];
$product_units = max(1, (int) $_POST['product_units']);
$product_owner_id = (int) $_POST['product_owner_id'];
$wow_currency_code = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string) $_POST['wow_currency_code']));
$wow_post_id = (int) ($_POST['wow_post_id'] ?? 0);
$address_id = (int) ($_POST['address_id'] ?? 0);

if ($amount < 0 || $product_price < 0 || $wow_currency_code === '') {
    http_response_code(400);
    echo json_encode(array('status' => 'error', 'message' => 'Invalid payment amount or currency.'));
    exit;
}

if (!in_array($transaction_kind, array('PRO', 'WALLET', 'DONATE', 'PRODUCT', 'PURCHASE', 'MARKET', 'FUND'), true)) {
    http_response_code(400);
    echo json_encode(array('status' => 'error', 'message' => 'Unsupported transaction kind.'));
    exit;
}

/*
 * WordPress is authoritative for the customer relationship. We only resolve
 * the already-linked WP user ID from the Streams user record.
 */
$wp_user_id = 0;
$stmt = $sqlConnect->prepare("SELECT wp_user_id FROM " . T_USERS . " WHERE user_id = ? LIMIT 1");

if ($stmt) {
    $stmt->bind_param('i', $wow_user_id);
    if ($stmt->execute()) {
        $stmt->bind_result($wp_user_id);
        $stmt->fetch();
    }
    $stmt->close();
}

if ($wp_user_id <= 0) {
    http_response_code(409);
    echo json_encode(array(
        'status' => 'error',
        'message' => 'Your Buzzjuice account is not linked to WordPress. Please contact support.',
    ));
    exit;
}

/*
 * Existing WoWonder product settings remain the source of the WooCommerce
 * handler product/variation IDs.
 */
$variation_id = 0;
$product_id = 0;

switch ($transaction_kind) {
    case 'PRO':
        $map = array(
            1 => (int) ($wo['config']['wow_pro_package_id'] ?? 0),
            2 => (int) ($wo['config']['wow_pro_package_id_2'] ?? 0),
            3 => (int) ($wo['config']['wow_pro_package_id_3'] ?? 0),
            4 => (int) ($wo['config']['wow_pro_package_id_4'] ?? 0),
        );

        if (!isset($map[$wow_post_id]) || $map[$wow_post_id] <= 0) {
            http_response_code(400);
            echo json_encode(array('status' => 'error', 'message' => 'Invalid PRO package configuration.'));
            exit;
        }

        $variation_id = $map[$wow_post_id];
        $product_id = $variation_id;
        break;

    case 'WALLET':
        $product_id = (int) ($wo['config']['wow_wallet_topup_id'] ?? 0);
        break;

    case 'DONATE':
    case 'FUND':
        $product_id = (int) ($wo['config']['wow_crowdfund_id'] ?? 0);
        break;

    case 'MARKET':
    case 'PRODUCT':
    case 'PURCHASE':
        $product_id = (int) ($wo['config']['wow_market_id'] ?? 0);
        break;
}

if ($product_id <= 0) {
    http_response_code(500);
    echo json_encode(array('status' => 'error', 'message' => 'WooCommerce handler product is not configured.'));
    exit;
}

$subscription_period = 'month';
$subscription_interval = 1;
$subscription_length = 0;

if ($transaction_kind === 'PRO' && !empty($wo['pro_packages'][$wow_post_id])) {
    $package = $wo['pro_packages'][$wow_post_id];

    $subscription_period = preg_replace('/[^a-z]/i', '', (string) ($package['time'] ?? 'month')) ?: 'month';
    $subscription_interval = max(1, (int) ($package['count'] ?? 1));
    $subscription_length = max(0, (int) ($package['time_count'] ?? 0));
}

$first_name = (string) ($wo['user']['first_name'] ?? '');
$last_name = (string) ($wo['user']['last_name'] ?? '');

$bridge_url = (string) ($wo['config']['wow_bridge_url'] ?? '');
if ($bridge_url === '') {
    $bridge_url = (string) ($wo['config']['wow_store_url'] ?? '');
}
if ($bridge_url === '') {
    $bridge_url = 'https://buzzjuice.net';
}

$client = dirname(__DIR__, 3) . '/shared/payment-gateway/pgb-client-streams.php';

if (!is_readable($client)) {
    http_response_code(500);
    echo json_encode(array('status' => 'error', 'message' => 'Payment Gateway client is unavailable.'));
    exit;
}

require_once $client;

try {
    $result = wow_pgb_create_request(array(
        'wow_user_id' => $wow_user_id,
        'wp_user_id' => $wp_user_id,
        'email' => $email,
        'first_name' => $first_name,
        'last_name' => $last_name,
        'transaction_kind' => $transaction_kind,
        'amount' => $amount,
        'currency' => $wow_currency_code,
        'product_id' => $product_id,
        'variation_id' => $variation_id,
        'quantity' => $product_units,
        'product_name' => $product_name,
        'product_price' => $product_price,
        'product_owner_id' => $product_owner_id,
        'wow_post_id' => $wow_post_id,
        'address_id' => $address_id,
        'subscription_period' => $subscription_period,
        'subscription_interval' => $subscription_interval,
        'subscription_length' => $subscription_length,
        'bridge_url' => $bridge_url,
    ));

    echo json_encode($result);
} catch (Throwable $e) {
    wow_pgb_init_log('Payment intent creation failed', array(
        'wow_user_id' => $wow_user_id,
        'transaction_kind' => $transaction_kind,
        'error' => $e->getMessage(),
    ));

    http_response_code(500);
    echo json_encode(array(
        'status' => 'error',
        'message' => 'Unable to start the payment. Please try again.',
    ));
}
exit;
