<?php
namespace BZJ\PGB\Core;

if (!defined('ABSPATH')) {
    exit;
}

require_once BZJ_PGB_DIR . 'core/class-pgb-logger.php';
require_once BZJ_PGB_DIR . 'core/class-pgb-security.php';
require_once BZJ_PGB_DIR . 'core/class-pgb-schema.php';
require_once BZJ_PGB_DIR . 'core/class-pgb-manager.php';

final class Bootstrap {
    private static $instance;
    private $logger;
    private $schema;
    private $manager;

    public static function instance() {
        if (!self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->logger = new Logger();
        $this->schema = new Schema($this->logger);
        $this->manager = new Manager($this->logger, $this->schema);
    }

    public function boot() {
        if (!class_exists('WooCommerce')) {
            $this->logger->log('WooCommerce is not loaded; PGB not started', Logger::ERROR, array(), __FILE__);
            return;
        }

        $this->schema->install();

        $this->load_addons();
        $this->load_integrations();

        add_action('template_redirect', array($this, 'handle_browser_handoff'), 1);
        add_action('woocommerce_payment_complete', array($this->manager, 'process_payment_complete'), 999, 1);
        add_action('woocommerce_order_status_completed', array($this->manager, 'process_payment_complete'), 1000, 1);

        add_action('admin_menu', array($this, 'register_admin_page'), 30);

        $this->logger->log('Payment Gateway Bridge booted', Logger::INFO, array(
            'version' => BZJ_PGB_VERSION,
            'debug' => getenv('BZJ_PGB_DEBUG') ?: '0',
        ), __FILE__);
    }

    public function handle_browser_handoff() {
        if (empty($_GET['bzj_pgb']) || $_GET['bzj_pgb'] !== 'checkout') {
            return;
        }

        $request_id = isset($_GET['request_id']) ? sanitize_text_field(wp_unslash($_GET['request_id'])) : '';
        $expires = isset($_GET['expires']) ? sanitize_text_field(wp_unslash($_GET['expires'])) : '';
        $signature = isset($_GET['sig']) ? sanitize_text_field(wp_unslash($_GET['sig'])) : '';

        if (!Security::verify($request_id, $expires, $signature)) {
            $this->logger->log('Invalid payment handoff signature', Logger::WARNING, array(
                'request_id' => $request_id,
            ), __FILE__);
            wp_die('Invalid or expired payment request.', 'Buzzjuice Payment Gateway', array('response' => 403));
        }

        $result = $this->manager->create_order_from_request($request_id);

        if (is_wp_error($result)) {
            $this->logger->log('Payment handoff failed', Logger::ERROR, array(
                'request_id' => $request_id,
                'code' => $result->get_error_code(),
                'message' => $result->get_error_message(),
            ), __FILE__);
            wp_die(esc_html($result->get_error_message()), 'Buzzjuice Payment Gateway', array('response' => 500));
        }

        wp_safe_redirect($result['payment_url']);
        exit;
    }

    public function register_admin_page() {
        add_menu_page(
            'Buzzjuice Payment Gateways',
            'Buzzjuice',
            'manage_options',
            'buzzjuice',
            array($this, 'render_admin_page'),
            'dashicons-cart',
            58
        );

        add_submenu_page(
            'buzzjuice',
            'Payment Gateways',
            'Payment Gateways',
            'manage_options',
            'buzzjuice-payment-gateways',
            array($this, 'render_admin_page')
        );
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        global $wpdb;
        $table = $this->schema->table();
        $counts = $wpdb->get_results("SELECT status, COUNT(*) total FROM `{$table}` GROUP BY status", ARRAY_A);
        ?>
        <div class="wrap">
            <h1>Buzzjuice → Payment Gateways</h1>
            <p>The payment bridge uses a durable transaction ledger and native WooCommerce order APIs. WooCommerce remains the payment authority.</p>
            <table class="widefat striped" style="max-width:800px">
                <thead><tr><th>Status</th><th>Transactions</th></tr></thead>
                <tbody>
                <?php foreach ((array) $counts as $count) : ?>
                    <tr>
                        <td><?php echo esc_html($count['status']); ?></td>
                        <td><?php echo esc_html($count['total']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <h2>Environment</h2>
            <p><code>BZJ_PGB_DEBUG</code>: <?php echo esc_html(getenv('BZJ_PGB_DEBUG') ?: '0'); ?></p>
            <p><code>BZJ_PGB_LOG_LEVEL</code>: <?php echo esc_html(getenv('BZJ_PGB_LOG_LEVEL') ?: 'info'); ?></p>
            <p><code>BZJ_PGB_SECRET</code>: <?php echo getenv('BZJ_PGB_SECRET') ? 'Configured' : 'MISSING'; ?></p>
        </div>
        <?php
    }

    private function load_addons() {
        $files = glob(BZJ_PGB_DIR . 'addons/pgb-addon-*.php');
        foreach ((array) $files as $file) {
            require_once $file;
        }
    }

    private function load_integrations() {
        $files = glob(BZJ_PGB_DIR . 'integrations/pgb-int-*.php');
        foreach ((array) $files as $file) {
            require_once $file;
        }
    }

    public function get_logger() {
        return $this->logger;
    }

    public function get_manager() {
        return $this->manager;
    }
}
