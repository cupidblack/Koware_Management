<?php
namespace BZJ\PGB\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Manager {
    private $logger;
    private $schema;

    public function __construct(Logger $logger, Schema $schema) {
        $this->logger = $logger;
        $this->schema = $schema;
    }

    public function create_order_from_request($request_id) {
        global $wpdb;

        $table = $this->schema->table();
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM `{$table}` WHERE request_id = %s LIMIT 1",
            $request_id
        ), ARRAY_A);

        if (!$row) {
            return new \WP_Error('pgb_not_found', 'Payment request was not found.', array('status' => 404));
        }

        if (!in_array($row['status'], array('initiated', 'order_creation_failed'), true)) {
            if (!empty($row['woo_order_id'])) {
                $order = wc_get_order((int) $row['woo_order_id']);
                if ($order) {
                    return array(
                        'order_id' => $order->get_id(),
                        'payment_url' => $order->get_checkout_payment_url(true),
                        'status' => $row['status'],
                    );
                }
            }
            return new \WP_Error('pgb_invalid_state', 'Payment request is no longer available for checkout.', array('status' => 409));
        }

        $product_id = (int) $row['product_id'];
        $variation_id = (int) $row['variation_id'];
        $product = $variation_id > 0 ? wc_get_product($variation_id) : wc_get_product($product_id);

        if (!$product) {
            $this->fail($row, 'WooCommerce product/variation not found.');
            return new \WP_Error('pgb_product_missing', 'The configured WooCommerce product could not be found.', array('status' => 500));
        }

        if ((float) $row['amount'] < 0 || (int) $row['quantity'] < 1) {
            $this->fail($row, 'Invalid amount or quantity.');
            return new \WP_Error('pgb_invalid_amount', 'Invalid payment amount.', array('status' => 400));
        }

        $existing = wc_get_orders(array(
            'limit' => 1,
            'meta_key' => '_bzj_pgb_request_id',
            'meta_value' => $request_id,
            'return' => 'objects',
        ));

        if (!empty($existing)) {
            $order = $existing[0];
            $this->attach_order($row, $order);
            return array(
                'order_id' => $order->get_id(),
                'payment_url' => $order->get_checkout_payment_url(true),
                'status' => 'order_created',
            );
        }

        $order = wc_create_order(array(
            'customer_id' => (int) $row['wp_user_id'],
            'created_via' => 'buzzjuice_pgb',
        ));

        if (is_wp_error($order)) {
            $this->fail($row, $order->get_error_message());
            return $order;
        }

        try {
            $order->set_currency($row['currency'] ?: get_woocommerce_currency());

            $item = new \WC_Order_Item_Product();
            $item->set_product($product);
            $item->set_quantity(max(1, (int) $row['quantity']));

            $unit = (float) $row['product_price'];
            $total = (float) $row['amount'];
            $subtotal = $unit * max(1, (int) $row['quantity']);

            $item->set_subtotal($subtotal);
            $item->set_total($total);
            $item->set_subtotal_tax(0);
            $item->set_total_tax(0);
            $item->add_meta_data('wow_order_id', $row['wow_order_id'], true);
            $item->add_meta_data('wow_user_id', (int) $row['wow_user_id'], true);
            $item->add_meta_data('wow_post_id', (int) $row['wow_post_id'], true);
            $item->add_meta_data('transaction_kind', $row['transaction_kind'], true);
            $order->add_item($item);

            $this->set_billing($order, $row);

            $order->update_meta_data('_bzj_pgb_request_id', $row['request_id']);
            $order->update_meta_data('_bzj_pgb_origin', 'streams');
            $order->update_meta_data('_buzzjuice_origin', 'streams');
            $order->update_meta_data('wow_order_id', $row['wow_order_id']);
            $order->update_meta_data('wow_user_id', (int) $row['wow_user_id']);
            $order->update_meta_data('wp_user_id', (int) $row['wp_user_id']);
            $order->update_meta_data('transaction_kind', $row['transaction_kind']);
            $order->update_meta_data('wow_post_id', (int) $row['wow_post_id']);
            $order->update_meta_data('bz_wow_user_id', (int) $row['wow_user_id']);
            $order->update_meta_data('bz_product_owner_id', (int) $row['product_owner_id']);
            $order->update_meta_data('_subscription_period', $row['subscription_period']);
            $order->update_meta_data('_subscription_interval', (int) $row['subscription_interval']);
            $order->update_meta_data('_subscription_length', (int) $row['subscription_length']);

            if (!empty($row['payload_json'])) {
                $order->update_meta_data('_bzj_pgb_payload', $row['payload_json']);
            }

            $order->calculate_totals(false);
            $order->set_status('pending');
            $order->save();

            $payment_url = $order->get_checkout_payment_url(true);

            $wpdb->update(
                $table,
                array(
                    'status' => 'order_created',
                    'woo_order_id' => $order->get_id(),
                    'payment_url' => $payment_url,
                    'updated_at' => current_time('mysql', true),
                    'fulfillment_error' => '',
                ),
                array('id' => (int) $row['id']),
                array('%s','%d','%s','%s','%s'),
                array('%d')
            );

            $this->logger->log('WooCommerce order created', Logger::INFO, array(
                'request_id' => $request_id,
                'woo_order_id' => $order->get_id(),
                'transaction_kind' => $row['transaction_kind'],
            ), __FILE__);

            return array(
                'order_id' => $order->get_id(),
                'payment_url' => $payment_url,
                'status' => 'order_created',
            );
        } catch (\Throwable $e) {
            if ($order && $order->get_id()) {
                $order->update_status('failed', 'Buzzjuice PGB order creation failed: ' . $e->getMessage());
            }
            $this->fail($row, $e->getMessage());
            return new \WP_Error('pgb_order_exception', 'Unable to create the payment order.', array('status' => 500));
        }
    }

    public function process_payment_complete($order_id) {
        global $wpdb;

        $order = wc_get_order($order_id);
        if (!$order) {
            return false;
        }

        $request_id = (string) $order->get_meta('_bzj_pgb_request_id', true);
        if ($request_id === '') {
            return false;
        }

        $table = $this->schema->table();
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM `{$table}` WHERE request_id = %s LIMIT 1",
            $request_id
        ), ARRAY_A);

        if (!$row) {
            $this->logger->log('Completion ledger row missing', Logger::ERROR, array(
                'woo_order_id' => $order_id,
                'request_id' => $request_id,
            ), __FILE__);
            return false;
        }

        if ($row['status'] === 'fulfilled') {
            return true;
        }

        $wpdb->query($wpdb->prepare(
            "UPDATE `{$table}`
             SET fulfillment_attempts = fulfillment_attempts + 1,
                 locked_at = %s,
                 updated_at = %s
             WHERE id = %d",
            current_time('mysql', true),
            current_time('mysql', true),
            (int) $row['id']
        ));

        $this->logger->log('Payment completion processing started', Logger::INFO, array(
            'woo_order_id' => $order_id,
            'request_id' => $request_id,
            'transaction_kind' => $row['transaction_kind'],
        ), __FILE__);

        $this->set_status($row['id'], 'fulfilling', '');

        $errors = array();

        try {
            do_action('bzj_pgb_payment_fulfillment', $order, $row, $this);
        } catch (\Throwable $e) {
            $errors[] = 'addon exception: ' . $e->getMessage();
            $this->logger->log('Fulfillment addon exception', Logger::ERROR, array(
                'woo_order_id' => $order_id,
                'request_id' => $request_id,
                'error' => $e->getMessage(),
            ), __FILE__);
        }

        if (empty($errors)) {
            $this->set_status($row['id'], 'fulfilled', '');
            $order->update_meta_data('_bzj_pgb_fulfilled', 'yes');
            $order->save();

            $this->logger->log('Payment fulfillment completed', Logger::INFO, array(
                'woo_order_id' => $order_id,
                'request_id' => $request_id,
            ), __FILE__);
            return true;
        }

        $message = implode('; ', $errors);
        $this->set_status($row['id'], 'fulfillment_failed', $message);
        return false;
    }

    public function set_status($id, $status, $error = '') {
        global $wpdb;
        $wpdb->update(
            $this->schema->table(),
            array(
                'status' => $status,
                'fulfillment_error' => $error,
                'updated_at' => current_time('mysql', true),
            ),
            array('id' => (int) $id),
            array('%s','%s','%s'),
            array('%d')
        );
    }

    private function attach_order(array $row, $order) {
        global $wpdb;
        $wpdb->update(
            $this->schema->table(),
            array(
                'status' => 'order_created',
                'woo_order_id' => $order->get_id(),
                'payment_url' => $order->get_checkout_payment_url(true),
                'updated_at' => current_time('mysql', true),
            ),
            array('id' => (int) $row['id']),
            array('%s','%d','%s','%s'),
            array('%d')
        );
    }

    private function set_billing($order, array $row) {
        $email = sanitize_email($row['email']);
        $first = '';
        $last = '';

        $payload = json_decode($row['payload_json'], true);
        if (is_array($payload)) {
            $first = sanitize_text_field($payload['first_name'] ?? '');
            $last = sanitize_text_field($payload['last_name'] ?? '');
        }

        $order->set_billing_first_name($first ?: 'Buzzjuice');
        $order->set_billing_last_name($last ?: 'Member');
        $order->set_billing_email($email);
    }

    private function fail(array $row, $message) {
        $this->set_status((int) $row['id'], 'order_creation_failed', (string) $message);
        $this->logger->log('Order creation failed', Logger::ERROR, array(
            'request_id' => $row['request_id'],
            'error' => $message,
        ), __FILE__);
    }
}
