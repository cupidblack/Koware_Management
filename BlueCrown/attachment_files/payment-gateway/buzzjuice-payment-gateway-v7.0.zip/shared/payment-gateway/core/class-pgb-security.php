<?php
namespace BZJ\PGB\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Security {
    public static function secret() {
        $secret = getenv('BZJ_PGB_SECRET');
        return is_string($secret) ? trim($secret) : '';
    }

    public static function sign($request_id, $expires) {
        $secret = self::secret();
        if ($secret === '') {
            return '';
        }
        return hash_hmac('sha256', $request_id . "\n" . (string) $expires, $secret);
    }

    public static function verify($request_id, $expires, $signature) {
        if ($request_id === '' || $signature === '' || !ctype_digit((string) $expires)) {
            return false;
        }

        if ((int) $expires < time() - 60 || (int) $expires > time() + 900) {
            return false;
        }

        $expected = self::sign($request_id, $expires);
        return $expected !== '' && hash_equals($expected, (string) $signature);
    }

    public static function generate_request_id() {
        return 'pgb_' . gmdate('YmdHis') . '_' . bin2hex(random_bytes(16));
    }
}
