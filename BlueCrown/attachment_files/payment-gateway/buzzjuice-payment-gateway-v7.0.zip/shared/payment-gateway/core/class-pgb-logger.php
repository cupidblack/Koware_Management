<?php
namespace BZJ\PGB\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Logger {
    const DEBUG = 10;
    const INFO = 20;
    const WARNING = 30;
    const ERROR = 40;

    private $enabled;
    private $level;

    public function __construct() {
        $this->enabled = $this->env_bool('BZJ_PGB_DEBUG', false);
        $level = strtolower((string) getenv('BZJ_PGB_LOG_LEVEL'));
        $this->level = array(
            'debug' => self::DEBUG,
            'info' => self::INFO,
            'warning' => self::WARNING,
            'error' => self::ERROR,
        )[$level] ?? self::INFO;
    }

    public function log($message, $level = self::INFO, array $context = array(), $source_file = '') {
        if (!$this->enabled || $level < $this->level) {
            return;
        }

        $source = $source_file ? basename($source_file, '.php') : 'class-pgb-bootstrap';
        $path = BZJ_PGB_LOG_DIR . $source . '.log';

        if (!is_dir(BZJ_PGB_LOG_DIR)) {
            wp_mkdir_p(BZJ_PGB_LOG_DIR);
        }

        if (!is_dir(BZJ_PGB_LOG_DIR) || !is_writable(BZJ_PGB_LOG_DIR)) {
            return;
        }

        $entry = array(
            'time' => gmdate('c'),
            'level' => $this->level_name($level),
            'message' => (string) $message,
            'context' => $this->redact($context),
        );

        @file_put_contents(
            $path,
            wp_json_encode($entry, JSON_UNESCAPED_SLASHES) . PHP_EOL,
            FILE_APPEND | LOCK_EX
        );
    }

    private function level_name($level) {
        switch ($level) {
            case self::DEBUG: return 'DEBUG';
            case self::WARNING: return 'WARNING';
            case self::ERROR: return 'ERROR';
            default: return 'INFO';
        }
    }

    private function env_bool($key, $default) {
        $value = getenv($key);
        if ($value === false || $value === '') {
            return $default;
        }
        return in_array(strtolower((string) $value), array('1','true','yes','on'), true);
    }

    private function redact($value) {
        if (is_array($value)) {
            $out = array();
            foreach ($value as $k => $v) {
                $key = strtolower((string) $k);
                if (preg_match('/(password|secret|token|cookie|authorization|signature|api[_-]?key|api[_-]?secret)/i', $key)) {
                    $out[$k] = '[REDACTED]';
                } else {
                    $out[$k] = $this->redact($v);
                }
            }
            return $out;
        }

        if (is_object($value)) {
            return '[OBJECT]';
        }

        if (is_string($value) && strlen($value) > 1000) {
            return substr($value, 0, 997) . '...';
        }

        return $value;
    }
}
