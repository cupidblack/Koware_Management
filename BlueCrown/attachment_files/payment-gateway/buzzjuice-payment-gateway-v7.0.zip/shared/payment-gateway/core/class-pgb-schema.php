<?php
namespace BZJ\PGB\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Schema {
    const VERSION = 1;

    private $logger;

    public function __construct(Logger $logger) {
        $this->logger = $logger;
    }

    public function install() {
        global $wpdb;

        $table = $wpdb->prefix . 'bzj_pgb_transactions';
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS `{$table}` (
            `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `request_id` varchar(80) NOT NULL,
            `wow_order_id` varchar(100) NOT NULL,
            `wow_user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
            `wp_user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
            `email` varchar(190) NOT NULL DEFAULT '',
            `transaction_kind` varchar(40) NOT NULL DEFAULT '',
            `currency` varchar(12) NOT NULL DEFAULT '',
            `amount` decimal(20,6) NOT NULL DEFAULT 0.000000,
            `product_id` bigint(20) unsigned NOT NULL DEFAULT 0,
            `variation_id` bigint(20) unsigned NOT NULL DEFAULT 0,
            `quantity` int(10) unsigned NOT NULL DEFAULT 1,
            `product_name` text NULL,
            `product_price` decimal(20,6) NOT NULL DEFAULT 0.000000,
            `product_owner_id` bigint(20) unsigned NOT NULL DEFAULT 0,
            `wow_post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
            `address_id` bigint(20) unsigned NOT NULL DEFAULT 0,
            `subscription_period` varchar(20) NOT NULL DEFAULT '',
            `subscription_interval` int(10) unsigned NOT NULL DEFAULT 1,
            `subscription_length` int(10) unsigned NOT NULL DEFAULT 0,
            `payload_json` longtext NULL,
            `status` varchar(40) NOT NULL DEFAULT 'initiated',
            `woo_order_id` bigint(20) unsigned NOT NULL DEFAULT 0,
            `payment_url` text NULL,
            `fulfillment_attempts` int(10) unsigned NOT NULL DEFAULT 0,
            `fulfillment_error` text NULL,
            `locked_at` datetime NULL,
            `created_at` datetime NOT NULL,
            `updated_at` datetime NOT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `request_id` (`request_id`),
            UNIQUE KEY `wow_order_id` (`wow_order_id`),
            KEY `status` (`status`),
            KEY `woo_order_id` (`woo_order_id`),
            KEY `wow_user_id` (`wow_user_id`),
            KEY `created_at` (`created_at`)
        ) {$charset};";

        $ok = $wpdb->query($sql);
        if ($ok === false) {
            $this->logger->log('Ledger table creation failed', Logger::ERROR, array(
                'table' => $table,
                'db_error' => $wpdb->last_error,
            ), __FILE__);
            return false;
        }

        update_option('bzj_pgb_schema_version', self::VERSION, false);
        $this->logger->log('Ledger schema verified', Logger::INFO, array(
            'table' => $table,
            'version' => self::VERSION,
        ), __FILE__);

        return true;
    }

    public function table() {
        global $wpdb;
        return $wpdb->prefix . 'bzj_pgb_transactions';
    }
}
