<?php
namespace BZJ\PGB\Integrations;

use BZJ\PGB\Core\Logger;

if (!defined('ABSPATH')) {
    exit;
}

add_action('bzj_pgb_payment_fulfillment', function ($order, $ledger, $manager) {
    $kind = strtoupper((string) $ledger['transaction_kind']);
    $wow_user_id = (int) $ledger['wow_user_id'];

    $helpers = dirname(BZJ_PGB_DIR) . '/db_helpers.php';
    if (!is_readable($helpers)) {
        throw new \RuntimeException('shared/db_helpers.php could not be loaded.');
    }

    require_once $helpers;

    if (!function_exists('get_wowonder_db')) {
        throw new \RuntimeException('WoWonder DB helper is unavailable.');
    }

    $db = get_wowonder_db();
    if (!$db) {
        throw new \RuntimeException('WoWonder database connection failed.');
    }

    switch ($kind) {
        case 'PRO':
            $pro_type = (int) $ledger['wow_post_id'];
            if ($pro_type <= 0) {
                throw new \RuntimeException('PRO transaction has no WoWonder pro type.');
            }

            $now = time();
            $stmt = $db->prepare("UPDATE Wo_Users SET is_pro = '1', pro_type = ?, pro_time = ? WHERE user_id = ? LIMIT 1");
            if (!$stmt) {
                throw new \RuntimeException('WoWonder PRO update prepare failed: ' . $db->error);
            }
            $stmt->bind_param('iii', $pro_type, $now, $wow_user_id);
            if (!$stmt->execute()) {
                throw new \RuntimeException('WoWonder PRO update failed: ' . $stmt->error);
            }
            $stmt->close();
            break;

        case 'WALLET':
            $amount = (float) $ledger['amount'];
            $stmt = $db->prepare("UPDATE Wo_Users SET wallet = wallet + ? WHERE user_id = ? LIMIT 1");
            if (!$stmt) {
                throw new \RuntimeException('WoWonder wallet prepare failed: ' . $db->error);
            }
            $stmt->bind_param('di', $amount, $wow_user_id);
            if (!$stmt->execute()) {
                throw new \RuntimeException('WoWonder wallet update failed: ' . $stmt->error);
            }
            $stmt->close();
            break;

        case 'PRODUCT':
        case 'PURCHASE':
        case 'MARKET':
            /*
             * Marketplace fulfillment remains deliberately isolated. The PGB
             * order is paid here; a later integration can update Wo_Purchases/
             * Wo_UserOrders once the exact current schema/business rules are
             * confirmed. We do not create a second "paid" record here that
             * could double-credit the marketplace.
             */
            break;

        case 'DONATE':
        case 'FUND':
            break;

        default:
            break;
    }
}, 10, 3);
