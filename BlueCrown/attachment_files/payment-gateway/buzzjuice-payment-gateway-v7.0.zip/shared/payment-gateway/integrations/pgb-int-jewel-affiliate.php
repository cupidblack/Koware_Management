<?php
namespace BZJ\PGB\Integrations;

if (!defined('ABSPATH')) {
    exit;
}

add_action('bzj_pgb_payment_fulfillment', function ($order, $ledger, $manager) {
    $wow_user_id = (int) $ledger['wow_user_id'];
    if ($wow_user_id <= 0) {
        return;
    }

    $helpers = dirname(BZJ_PGB_DIR) . '/db_helpers.php';
    if (!is_readable($helpers)) {
        return;
    }

    require_once $helpers;

    if (!function_exists('get_wowonder_db')) {
        return;
    }

    $db = get_wowonder_db();
    if (!$db) {
        return;
    }

    /*
     * Jewel mapping is stored in WordPress options and can be resolved here
     * without the old public webhook. Only mapped variations are processed.
     */
    $mapping_json = get_option('bz_rebate_mapping_json', '');
    $mapping = json_decode((string) $mapping_json, true);

    if (!is_array($mapping)) {
        return;
    }

    foreach ($order->get_items('line_item') as $item) {
        $variation_id = (int) $item->get_variation_id();
        if (!$variation_id) {
            $variation_id = (int) $item->get_product_id();
        }

        $map = null;
        foreach ($mapping as $candidate) {
            if ((int) ($candidate['variation_id'] ?? 0) === $variation_id) {
                $map = $candidate;
                break;
            }
        }

        if (!is_array($map)) {
            continue;
        }

        $pro_type = (int) ($map['wow_pro_type'] ?? 0);
        if ($pro_type <= 0) {
            continue;
        }

        $now = time();
        $stmt = $db->prepare("UPDATE Wo_Users SET is_pro = '1', pro_type = ?, pro_time = ? WHERE user_id = ? LIMIT 1");
        if (!$stmt) {
            throw new \RuntimeException('Jewel WoWonder update prepare failed: ' . $db->error);
        }

        $stmt->bind_param('iii', $pro_type, $now, $wow_user_id);
        if (!$stmt->execute()) {
            throw new \RuntimeException('Jewel WoWonder update failed: ' . $stmt->error);
        }
        $stmt->close();
    }
}, 40, 3);
