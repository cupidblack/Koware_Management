<?php
namespace BZJ\PGB\Addons;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Buzzjuice AffiliateWP addon.
 *
 * The previous bridge already had working lifetime-customer and product-rate
 * logic. This addon keeps those rules WordPress-side and deliberately does
 * not depend on AffiliateWP cookies captured inside Streams.
 */
add_action('bzj_pgb_payment_fulfillment', function ($order, $ledger, $manager) {
    if ($order->get_meta('_bzj_pgb_affwp_done', true)) {
        return;
    }

    if (!function_exists('affwp_add_referral')) {
        throw new \RuntimeException('AffiliateWP public referral API is unavailable.');
    }

    global $wpdb;

    $wp_user_id = (int) $order->get_customer_id();
    if ($wp_user_id <= 0) {
        throw new \RuntimeException('WooCommerce order has no WordPress customer.');
    }

    $email = sanitize_email($order->get_billing_email());
    $customer_id = 0;

    if (function_exists('affwp_get_customer')) {
        $customer = affwp_get_customer(array('user_id' => $wp_user_id));
        if (is_object($customer)) {
            $customer_id = (int) ($customer->customer_id ?? 0);
        }
    }

    if ($customer_id <= 0) {
        $customer_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT customer_id FROM {$wpdb->prefix}affiliate_wp_customers WHERE user_id = %d LIMIT 1",
            $wp_user_id
        ));
    }

    if ($customer_id <= 0 && $email !== '') {
        $customer_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT customer_id FROM {$wpdb->prefix}affiliate_wp_customers WHERE email = %s LIMIT 1",
            $email
        ));
    }

    if ($customer_id <= 0 && function_exists('affwp_add_customer')) {
        $customer_id = (int) affwp_add_customer(array(
            'user_id' => $wp_user_id,
            'email' => $email,
        ));
    }

    if ($customer_id <= 0) {
        $order->update_meta_data('_bzj_pgb_affwp_done', 'no_customer');
        $order->save();
        return;
    }

    $affiliate_id = 0;
    $resolution_source = '';

    /*
     * 1. AffiliateWP Lifetime Commissions / Lifetime Customers.
     */
    $lifetime_table = $wpdb->prefix . 'affiliate_wp_lifetime_customers';
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $lifetime_table)) === $lifetime_table) {
        $affiliate_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT affiliate_id
             FROM {$lifetime_table}
             WHERE affwp_customer_id = %d
             ORDER BY lifetime_customer_id DESC
             LIMIT 1",
            $customer_id
        ));
        if ($affiliate_id > 0) {
            $resolution_source = 'lifetime_customer';
        }
    }

    /*
     * 2. WordPress/AffiliateWP runtime attribution.
     * The browser is already on WordPress when the order is created, so this
     * is the correct place to resolve current AffiliateWP context.
     */
    if ($affiliate_id <= 0 && function_exists('affwp_get_affiliate_id')) {
        $runtime_affiliate = (int) affwp_get_affiliate_id();
        if ($runtime_affiliate > 0) {
            $affiliate_id = $runtime_affiliate;
            $resolution_source = 'runtime';
        }
    }

    /*
     * 3. AffiliateWP customer metadata.
     */
    if ($affiliate_id <= 0) {
        $customer_meta_table = $wpdb->prefix . 'affiliate_wp_customermeta';
        $affiliate_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value
             FROM {$customer_meta_table}
             WHERE affwp_customer_id = %d
               AND meta_key = %s
             LIMIT 1",
            $customer_id,
            'affiliate_id'
        ));
        if ($affiliate_id > 0) {
            $resolution_source = 'customer_meta_affiliate_id';
        }
    }

    if ($affiliate_id <= 0) {
        $customer_meta_table = $wpdb->prefix . 'affiliate_wp_customermeta';
        $affiliate_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value
             FROM {$customer_meta_table}
             WHERE affwp_customer_id = %d
               AND meta_key = %s
             LIMIT 1",
            $customer_id,
            'referring_affiliate_id'
        ));
        if ($affiliate_id > 0) {
            $resolution_source = 'customer_meta_referring_affiliate_id';
        }
    }

    /*
     * If no affiliate is attached, this is a valid non-affiliate order.
     */
    if ($affiliate_id <= 0) {
        $order->update_meta_data('_bzj_pgb_affwp_done', 'no_affiliate');
        $order->save();
        return;
    }

    /*
     * Hard duplicate guard. AffiliateWP reference is the WooCommerce order ID.
     */
    $existing_referral = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT referral_id
         FROM {$wpdb->prefix}affiliate_wp_referrals
         WHERE reference = %s
         LIMIT 1",
        (string) $order->get_id()
    ));

    if ($existing_referral > 0) {
        $order->update_meta_data('_bzj_pgb_affwp_done', 'existing');
        $order->update_meta_data('_affwp_bridge_processed', '1');
        $order->update_meta_data('_bzj_pgb_affwp_referral_id', $existing_referral);
        $order->save();
        return;
    }

    /*
     * Preserve the existing Buzzjuice commission model:
     * - product/variation override
     * - otherwise AffiliateWP default rate
     * - percentage or flat
     */
    $settings = get_option('affwp_settings', array());
    $default_rate_type = $settings['referral_rate_type'] ?? 'percentage';
    $default_rate = (float) ($settings['referral_rate'] ?? 0);

    $commission = 0.0;
    $products_meta = array();

    foreach ($order->get_items('line_item') as $item) {
        $product_id = (int) $item->get_product_id();
        $variation_id = (int) $item->get_variation_id();
        $target = $variation_id > 0 ? $variation_id : $product_id;

        $raw_rate = get_post_meta($target, '_affwp_woocommerce_product_rate', true);
        $raw_type = trim((string) get_post_meta($target, '_affwp_woocommerce_product_rate_type', true));

        $item_total = (float) $item->get_total();
        $item_commission = 0.0;

        if ($raw_rate !== '' && is_numeric($raw_rate) && in_array($raw_type, array('percentage', 'flat'), true)) {
            $rate = (float) $raw_rate;
            $item_commission = $raw_type === 'percentage'
                ? round($item_total * ($rate / 100), 4)
                : round($rate, 4);
        } elseif ($default_rate > 0) {
            $item_commission = $default_rate_type === 'percentage'
                ? round($item_total * ($default_rate / 100), 4)
                : round($default_rate, 4);
        }

        $commission += $item_commission;

        $products_meta[] = array(
            'product_id' => $product_id,
            'variation_id' => $variation_id,
            'name' => $item->get_name(),
            'quantity' => (int) $item->get_quantity(),
            'item_total' => $item_total,
            'commission' => $item_commission,
        );
    }

    if ($commission <= 0) {
        $order->update_meta_data('_bzj_pgb_affwp_done', 'zero_commission');
        $order->save();
        return;
    }

    $description = array();
    foreach ($order->get_items('line_item') as $item) {
        $description[] = $item->get_name() . ' (var:' . (int) $item->get_variation_id() . ')';
    }

    $referral = affwp_add_referral(array(
        'affiliate_id' => $affiliate_id,
        'customer_id' => $customer_id,
        'parent_id' => (int) $order->get_parent_id(),
        'description' => implode('; ', $description),
        'status' => 'unpaid',
        'amount' => round($commission, 4),
        'currency' => $order->get_currency(),
        'context' => 'woocommerce',
        'campaign' => '',
        'reference' => (string) $order->get_id(),
        'products' => maybe_serialize($products_meta),
        'date' => current_time('mysql'),
        'custom' => maybe_serialize(array(
            'origin' => 'streams',
            'wow_order_id' => (string) $ledger['wow_order_id'],
            'wow_user_id' => (int) $ledger['wow_user_id'],
            'resolution_source' => $resolution_source,
            'commission_amount' => $commission,
            'default_rate' => $default_rate,
            'default_rate_type' => $default_rate_type,
            'calculation_source' => 'buzzjuice_pgb_v7',
        )),
    ));

    if (!$referral || is_wp_error($referral)) {
        $message = is_wp_error($referral)
            ? $referral->get_error_message()
            : 'AffiliateWP referral insertion failed.';
        throw new \RuntimeException($message);
    }

    $order->update_meta_data('_bzj_pgb_affwp_done', 'yes');
    $order->update_meta_data('_affwp_bridge_processed', '1');
    $order->update_meta_data('_bzj_pgb_affwp_referral_id', (int) $referral);
    $order->update_meta_data('_bzj_pgb_affiliate_id', $affiliate_id);
    $order->save();
}, 20, 3);
