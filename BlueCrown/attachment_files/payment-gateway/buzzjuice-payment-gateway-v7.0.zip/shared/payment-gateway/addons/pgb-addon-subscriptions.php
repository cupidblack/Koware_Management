<?php
namespace BZJ\PGB\Addons;

if (!defined('ABSPATH')) {
    exit;
}

add_action('bzj_pgb_payment_fulfillment', function ($order, $ledger, $manager) {
    if (strtoupper((string) $ledger['transaction_kind']) !== 'PRO') {
        return;
    }

    if (!function_exists('wcs_create_subscription')) {
        throw new \RuntimeException('WooCommerce Subscriptions is not active.');
    }

    if (function_exists('wcs_get_subscriptions_for_order')) {
        $existing = wcs_get_subscriptions_for_order($order->get_id(), array('order_type' => 'parent'));
        if (!empty($existing)) {
            return;
        }
    }

    $variation_id = (int) $ledger['variation_id'];
    $product = $variation_id > 0 ? wc_get_product($variation_id) : null;

    if (!$product) {
        throw new \RuntimeException('Subscription variation could not be resolved.');
    }

    $period = sanitize_key($ledger['subscription_period']) ?: 'month';
    $interval = max(1, (int) $ledger['subscription_interval']);

    $subscription = wcs_create_subscription(array(
        'order_id' => $order->get_id(),
        'customer_id' => $order->get_customer_id(),
        'billing_period' => $period,
        'billing_interval' => $interval,
        'start_date' => gmdate('Y-m-d H:i:s'),
        'status' => 'active',
    ));

    if (is_wp_error($subscription)) {
        throw new \RuntimeException($subscription->get_error_message());
    }

    $subscription_item_id = $subscription->add_product($product, max(1, (int) $ledger['quantity']));
    if ($subscription_item_id) {
        $subscription_item = $subscription->get_item($subscription_item_id);
        if ($subscription_item) {
            $parent_total = (float) $order->get_total();
            $parent_quantity = max(1, (int) $ledger['quantity']);
            $subscription_item->set_subtotal($parent_total);
            $subscription_item->set_total($parent_total);
            $subscription_item->set_subtotal_tax(0);
            $subscription_item->set_total_tax(0);
            $subscription_item->save();
        }
    }

    $subscription->set_currency($order->get_currency());
    $subscription->set_address($order->get_address('billing'), 'billing');
    $subscription->set_address($order->get_address('shipping'), 'shipping');
    $subscription->set_payment_method($order->get_payment_method(), $order->get_payment_method_title());

    $length = max(0, (int) $ledger['subscription_length']);
    if ($length > 0 && function_exists('wcs_add_time')) {
        $end = wcs_add_time($length, $period, gmdate('Y-m-d H:i:s'));
        if ($end) {
            $subscription->update_dates(array('end' => $end));
        }
    }

    $next_payment = null;
    if (function_exists('wcs_add_time')) {
        $next_payment = wcs_add_time($interval, $period, gmdate('Y-m-d H:i:s'));
        if ($next_payment) {
            $subscription->update_dates(array('next_payment' => $next_payment));
        }
    }

    $subscription->calculate_totals(false);
    $subscription->save();
    $order->update_meta_data('_bzj_pgb_subscription_id', $subscription->get_id());
    $order->save();
}, 30, 3);

add_action('woocommerce_subscription_status_active', function ($subscription) {
    if (!$subscription || !$subscription->get_parent_id()) {
        return;
    }

    $parent = wc_get_order($subscription->get_parent_id());
    if ($parent) {
        $parent->update_meta_data('_bzj_pgb_subscription_active', 'yes');
        $parent->save();
    }
}, 20, 1);
