Buzzjuice Payment Gateway Bridge v7.0
======================================

Architecture
------------
Streams creates a payment intent in the WordPress database using the existing
shared/db_helpers.php connection. No Streams->WordPress HTTP request is made.

The browser is then redirected to:
    https://buzzjuice.net/?bzj_pgb=checkout&request_id=...&expires=...&sig=...

The WordPress MU plugin verifies the signed handoff, creates a native
WooCommerce order, and redirects the browser to the order payment URL.

WooCommerce remains the payment authority.

Environment
-----------
Add these variables to the root .env:

BZJ_PGB_SECRET=<long-random-secret>
BZJ_PGB_DEBUG=0
BZJ_PGB_LOG_LEVEL=info

Use the same BZJ_PGB_SECRET for the Streams and WordPress PHP processes.

Database
--------
The MU plugin creates:
    wp_bzj_pgb_transactions

The schema is intentionally installed with CREATE TABLE IF NOT EXISTS rather
than dbDelta().

Legacy components to retire
----------------------------
1. wp-content/mu-plugins/buzzjuice-affwp-order-complete.php
2. wp-content/plugins/blue-crown-wp/wow-pgb_sync/wow-pgb_sync.php
3. streams/wow-pgb_webhook.php

Do not leave the old completion engine enabled while v7 is processing orders.

Logging
-------
When BZJ_PGB_DEBUG=1, logs are written under:
    shared/payment-gateway/log/

Each PHP source file writes to a same-named .log file.

Security
--------
Do not put BZJ_PGB_SECRET, WooCommerce consumer keys/secrets, webhook secrets,
or payment gateway credentials into Streams payment settings.

The browser URL contains only request_id, expiry and a one-time signed
handoff. It contains no payment credentials.

Deployment
----------
1. Back up the current bridge files and databases.
2. Add BZJ_PGB_SECRET.
3. Install the MU plugin and shared/payment-gateway files.
4. Visit WordPress once to allow schema creation.
5. Confirm wp_bzj_pgb_transactions exists.
6. Update Streams payment settings.
7. Replace wow-pgb_init.php.
8. Remove/disable the old webhook and old sync engine.
9. Test PRO, wallet, market/product and donation flows separately.
10. Test duplicate browser refresh and duplicate WooCommerce completion hooks.
