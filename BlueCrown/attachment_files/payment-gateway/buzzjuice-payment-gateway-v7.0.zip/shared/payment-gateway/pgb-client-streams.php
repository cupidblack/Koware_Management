<?php
/**
 * Buzzjuice Streams Payment Gateway client.
 *
 * Streams does not load WordPress. This client only uses native PHP,
 * mysqli and shared/db_helpers.php.
 */

if (!defined('WOW_PGB_CLIENT_LOADED')) {
    define('WOW_PGB_CLIENT_LOADED', true);
}

if (!function_exists('wow_pgb_streams_log')) {
    function wow_pgb_streams_log($message, array $context = array()) {
        $enabled = getenv('BZJ_PGB_DEBUG');
        if (!in_array(strtolower((string) $enabled), array('1','true','yes','on'), true)) {
            return;
        }

        $dir = dirname(__DIR__) . '/payment-gateway/log/';
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        $entry = array(
            'time' => gmdate('c'),
            'level' => 'INFO',
            'message' => (string) $message,
            'context' => wow_pgb_redact($context),
        );

        @file_put_contents(
            $dir . 'pgb-client-streams.log',
            json_encode($entry, JSON_UNESCAPED_SLASHES) . PHP_EOL,
            FILE_APPEND | LOCK_EX
        );
    }
}

if (!function_exists('wow_pgb_redact')) {
    function wow_pgb_redact($value) {
        if (!is_array($value)) return $value;
        $out = array();
        foreach ($value as $key => $val) {
            if (preg_match('/secret|token|cookie|password|signature|api[_-]?key/i', (string) $key)) {
                $out[$key] = '[REDACTED]';
            } else {
                $out[$key] = is_array($val) ? wow_pgb_redact($val) : $val;
            }
        }
        return $out;
    }
}

if (!function_exists('wow_pgb_env_secret')) {
    function wow_pgb_env_secret() {
        $secret = getenv('BZJ_PGB_SECRET');
        if (!$secret) {
            throw new RuntimeException('BZJ_PGB_SECRET is not configured.');
        }
        return $secret;
    }
}

if (!function_exists('wow_pgb_sign')) {
    function wow_pgb_sign($request_id, $expires) {
        return hash_hmac('sha256', $request_id . "\n" . $expires, wow_pgb_env_secret());
    }
}

if (!function_exists('wow_pgb_create_request')) {
    function wow_pgb_create_request(array $params) {
        if (!function_exists('get_wp_db_conn')) {
            $helpers = dirname(__DIR__, 2) . '/db_helpers.php';
            if (!is_readable($helpers)) {
                throw new RuntimeException('shared/db_helpers.php is unavailable.');
            }
            require_once $helpers;
        }

        $db = get_wp_db_conn();
        if (!$db) {
            throw new RuntimeException('WordPress database connection failed.');
        }

        $request_id = 'pgb_' . gmdate('YmdHis') . '_' . bin2hex(random_bytes(16));
        $expires = time() + 600;
        $wow_order_id = (string) ($params['wow_order_id'] ?? ('wow_' . bin2hex(random_bytes(10))));

        $payload = array(
            'first_name' => (string) ($params['first_name'] ?? ''),
            'last_name' => (string) ($params['last_name'] ?? ''),
            'email' => (string) ($params['email'] ?? ''),
        );

        $table = (defined('WP_TABLE_PREFIX') ? WP_TABLE_PREFIX : 'wp_') . 'bzj_pgb_transactions';

        $sql = "INSERT INTO `{$table}`
            (request_id, wow_order_id, wow_user_id, wp_user_id, email, transaction_kind,
             currency, amount, product_id, variation_id, quantity, product_name,
             product_price, product_owner_id, wow_post_id, address_id,
             subscription_period, subscription_interval, subscription_length,
             payload_json, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'initiated', UTC_TIMESTAMP(), UTC_TIMESTAMP())";

        $stmt = $db->prepare($sql);
        if (!$stmt) {
            throw new RuntimeException('PGB ledger prepare failed: ' . $db->error);
        }

        $wow_user_id = (int) ($params['wow_user_id'] ?? 0);
        $wp_user_id = (int) ($params['wp_user_id'] ?? 0);
        $email = (string) ($params['email'] ?? '');
        $kind = strtoupper((string) ($params['transaction_kind'] ?? ''));
        $currency = strtoupper((string) ($params['currency'] ?? 'GHS'));
        $amount = (float) ($params['amount'] ?? 0);
        $product_id = (int) ($params['product_id'] ?? 0);
        $variation_id = (int) ($params['variation_id'] ?? 0);
        $quantity = max(1, (int) ($params['quantity'] ?? 1));
        $product_name = (string) ($params['product_name'] ?? 'Buzzjuice Payment');
        $product_price = (float) ($params['product_price'] ?? $amount);
        $owner_id = (int) ($params['product_owner_id'] ?? 0);
        $wow_post_id = (int) ($params['wow_post_id'] ?? 0);
        $address_id = (int) ($params['address_id'] ?? 0);
        $period = (string) ($params['subscription_period'] ?? '');
        $interval = max(1, (int) ($params['subscription_interval'] ?? 1));
        $length = max(0, (int) ($params['subscription_length'] ?? 0));
        $json = json_encode($payload, JSON_UNESCAPED_SLASHES);

        $stmt->bind_param(
            'ssiisssdiiisdiiisiis',
            $request_id,
            $wow_order_id,
            $wow_user_id,
            $wp_user_id,
            $email,
            $kind,
            $currency,
            $amount,
            $product_id,
            $variation_id,
            $quantity,
            $product_name,
            $product_price,
            $owner_id,
            $wow_post_id,
            $address_id,
            $period,
            $interval,
            $length,
            $json
        );

        if (!$stmt->execute()) {
            throw new RuntimeException('PGB ledger insert failed: ' . $stmt->error);
        }

        $stmt->close();

        $bridge_url = rtrim((string) ($params['bridge_url'] ?? ''), '/');
        if ($bridge_url === '') {
            throw new RuntimeException('WordPress Payment Bridge URL is not configured.');
        }

        $signature = wow_pgb_sign($request_id, $expires);
        $url = $bridge_url . '/?bzj_pgb=checkout'
             . '&request_id=' . rawurlencode($request_id)
             . '&expires=' . rawurlencode((string) $expires)
             . '&sig=' . rawurlencode($signature);

        wow_pgb_streams_log('Payment intent stored', array(
            'request_id' => $request_id,
            'wow_order_id' => $wow_order_id,
            'wow_user_id' => $wow_user_id,
            'transaction_kind' => $kind,
            'amount' => $amount,
            'currency' => $currency,
        ));

        return array(
            'status' => 200,
            'request_id' => $request_id,
            'wow_order_id' => $wow_order_id,
            'url' => $url,
        );
    }
}
