<?php
/**
 * Generic PGB client loader.
 * The Streams-specific implementation lives in pgb-client-streams.php.
 */
require_once __DIR__ . '/pgb-client-streams.php';
