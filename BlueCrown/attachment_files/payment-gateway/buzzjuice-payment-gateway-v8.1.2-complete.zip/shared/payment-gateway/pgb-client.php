<?php
/**
 * Buzzjuice Payment Gateway client bootstrap.
 * This file is intentionally WordPress-safe and is not a WooCommerce REST client.
 */
if (!function_exists('pgb_client_version')) {
    function pgb_client_version() { return '8.1.2'; }
}
