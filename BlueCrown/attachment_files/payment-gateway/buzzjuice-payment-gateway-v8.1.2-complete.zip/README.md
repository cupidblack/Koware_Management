# Buzzjuice Payment Gateway Bridge v8.1.2

This package corrects the v8.1 deployment failure and contains the complete core tree required by `bzj-pgb-engine.php`.

## Critical installation rule

Extract the archive **from its root** so that these two paths exist on the server:

- `shared/payment-gateway/core/class-pgb-manager.php`
- `wp-content/mu-plugins/bzj-pgb-engine.php`

The MU engine now resolves the bridge root from several common WordPress layouts and reports the resolved path in **Buzzjuice → Payment Gateways**.

## Checkout behavior

`/wp-json/bzj-pgb/v1/checkout` validates the HMAC handoff, creates/reuses the WooCommerce order, then sends a browser HTTP 302 redirect to WooCommerce's payment URL. It no longer leaves the browser on a JSON REST endpoint.

## Important

Wallet, funding and market addons are intentionally diagnostic-only until the existing proven Streams fulfillment rules have been migrated into them. They do not silently create duplicate business records.
