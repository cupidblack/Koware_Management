<?php
require_once('assets/init.php');
decryptConfigData();
$f = isset($_GET['f']) ? Wo_Secure($_GET['f'], 0) : '';
$s = isset($_GET['s']) ? Wo_Secure($_GET['s'], 0) : '';
$hash_id = '';
$hash_candidates = [$_POST['hash_id'] ?? '', $_GET['hash_id'] ?? '', $_GET['hash'] ?? '', $_POST['hash'] ?? ''];
foreach ($hash_candidates as $candidate) { if (is_string($candidate) && trim($candidate)!=='') { $hash_id=trim($candidate); break; } }

$allow_array = ['bank_transfer','confirm_order','wow_payment','upgrade','paystack','cashfree','payment','pay_with_bitcoin','coinpayments_callback','paypro_with_bitcoin','upload-blog-image','wallet','download_user_info','movies','funding','stripe','coinbase','load_more_products','yoomoney','iyzipay','fluttewave','fortumo','aamarpay','pay_with_bitcoin'];
if ($f==='certification' && !empty($_GET['id']) && is_numeric($_GET['id']) && $_GET['id']>0) $allow_array[]='certification';
$non_login_array=['bank_transfer','confirm_order','session_status','open_lightbox','get_welcome_users','load_posts','save_user_location','load-more-groups','load-more-pages','load-more-users','load_profile_posts','confirm_user_unusal_login','confirm_user','confirm_sms_user','resned_code','resned_code_ac','resned_ac_email','contact_us','google_login','login','register','recover','recoversms','reset_password','search','get_search_filter','update_announcement_views','get_more_hashtag_posts','open_album_lightbox','get_next_album_image','get_previous_album_image','get_next_product_image','get_previous_product_image','open_multilightbox','get_next_image','get_previous_image','get_next_video','get_previous_video','load-blogs','load-recent-blogs','get_no_posts_name','search-blog-read','search-blog','coinbase','load_more_products','yoomoney','iyzipay','fluttewave','fortumo','aamarpay','pay_with_bitcoin','resend_two_factor','cashfree'];
if (($wo['config']['membership_system']??0)==1) $non_login_array=array_merge($non_login_array,['pro_register','get_payment_method','cashfree','paystack','pay_using_wallet','get_paypal_url','stripe_payment','paypro_with_bitcoin','2checkout_pro','bank_transfer','stripe']);
if (!in_array($f,$allow_array,true)) { if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH'])==='xmlhttprequest') {} else exit('Restricted Area'); }
if (!in_array($f,$non_login_array,true) && empty($wo['loggedin'])) exit('Please login or signup to continue.');
if (!empty($wo['loggedin']) && !empty($wo['user']['banned']) && $wo['user']['banned']==1 && !in_array($f,$non_login_array,true)) exit();

if ($f==='update_payment_settings' && Wo_CheckMainSession($hash_id)===true) {
    $fields=['wow_payment','wow_store_url','wow_market_id','wow_pro_package_id','wow_pro_package_id_2','wow_pro_package_id_3','wow_pro_package_id_4','wow_wallet_topup_id','wow_crowdfund_id','wow_api_url','wow_api_key','wow_api_secret','wow_webhook_secret','wow_pgb_shared_secret'];
    foreach($fields as $field) if(isset($_POST[$field])) Wo_UpdateConfig($field, Wo_Secure($_POST[$field]));
}
$files=scandir('xhr'); unset($files[0],$files[1]);
if ($f!=='admin_setting' && $f!=='admincp' && !empty($wo['loggedin']) && !empty($wo['user']) && !empty($wo['user']['is_pro']) && !empty($wo['pro_packages'][$wo['user']['pro_type']]['max_upload'])) $wo['config']['maxUpload']=$wo['pro_packages'][$wo['user']['pro_type']]['max_upload'];
if (file_exists('xhr/'.$f.'.php') && in_array($f.'.php',$files,true)) include 'xhr/'.$f.'.php';
elseif (!empty($_GET['mode_type']) && in_array($_GET['mode_type'],['linkedin','instagram'],true)) include 'xhr/modes/'.Wo_Secure($_GET['mode_type']).'.php';

if ($f==='payment' && ($_POST['payment_type']??'')==='wow_payment') require 'assets/wow-pgb/wow-pgb_init.php';
mysqli_close($sqlConnect); unset($wo); exit();
