<?php
/**
 * RETIRED COMPATIBILITY STUB.
 * Payment completion is now driven by the Buzzjuice MU plugin and WooCommerce
 * payment hooks. Do not add payment logic here.
 */
if (!defined('WOOWONDER') && !defined('ABSPATH')) { exit; }
return;
