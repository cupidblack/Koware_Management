<?php
/**
 * Compatibility entry point.
 * requests.php remains responsible for authentication; all payment orchestration
 * now lives in the WordPress MU bridge.
 */
require_once __DIR__.'/pgb-client-streams.php';
header('Content-Type: application/json');

if (empty($wo['loggedin']) || empty($wo['user']['user_id'])) {
    http_response_code(401); echo json_encode(['status'=>'error','message'=>'Please login to continue.']); exit;
}
$params=$_POST;
$params['return_url']=$params['return_url'] ?? ($wo['config']['site_url'].'/');
$result=bzj_pgb_streams_create_intent($params,$wo,$sqlConnect);
http_response_code(($result['status']??'error')===200?200:400);
echo json_encode($result);
exit;
