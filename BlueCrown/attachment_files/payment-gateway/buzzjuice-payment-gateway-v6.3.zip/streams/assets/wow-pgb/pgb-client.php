<?php
/**
 * Buzzjuice Streams Payment Gateway Client.
 * WordPress-independent. It creates a signed payment intent at the WP PGB API.
 */
if (!defined('WOOWONDER')) { /* harmless marker */ }

function bzj_pgb_client_log($message,$context=[]) {
    $enabled=getenv('BZJ_PGB_STREAMS_DEBUG');
    if ($enabled===false || !in_array(strtolower((string)$enabled),['1','true','yes','on'],true)) return;
    $dir=dirname(__DIR__,3).'/../shared/payment-gateway/log/';
    if(!is_dir($dir))@mkdir($dir,0755,true);
    $entry=['time'=>gmdate('c'),'level'=>'INFO','message'=>(string)$message,'context'=>$context];
    @file_put_contents($dir.'pgb-client.log',json_encode($entry,JSON_UNESCAPED_SLASHES).PHP_EOL,FILE_APPEND|LOCK_EX);
}
function bzj_pgb_sign($timestamp,$body,$secret){return hash_hmac('sha256',$timestamp.'.'.$body,$secret);}
function bzj_pgb_http_post($url,$body,$secret,$timeout=30) {
    $timestamp=(string)time();
    $signature=bzj_pgb_sign($timestamp,$body,$secret);
    $ch=curl_init($url);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,
        CURLOPT_HTTPHEADER=>['Content-Type: application/json','X-Bzj-Pgb-Timestamp: '.$timestamp,'X-Bzj-Pgb-Signature: '.$signature],
        CURLOPT_TIMEOUT=>$timeout,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
    $response=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$error=curl_error($ch);curl_close($ch);
    return ['code'=>$code,'body'=>$response,'error'=>$error];
}
