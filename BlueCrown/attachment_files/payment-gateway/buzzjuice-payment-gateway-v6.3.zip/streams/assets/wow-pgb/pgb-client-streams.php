<?php
require_once __DIR__.'/pgb-client.php';

function bzj_pgb_streams_create_intent($params,$wo,$sqlConnect) {
    if (empty($wo['user']['user_id'])) return ['status'=>'error','message'=>'Login required.'];
    $userid=(int)$wo['user']['user_id'];
    $email=filter_var($wo['user']['email']??'',FILTER_VALIDATE_EMAIL);
    if(!$email)return ['status'=>'error','message'=>'A valid account email is required.'];

    $wp_user_id=0;
    $q=mysqli_query($sqlConnect,"SELECT wp_user_id FROM ".T_USERS." WHERE user_id=".$userid." LIMIT 1");
    if($q && ($r=mysqli_fetch_assoc($q))) $wp_user_id=(int)($r['wp_user_id']??0);
    if(!$wp_user_id)return ['status'=>'error','message'=>'Your account is not linked to WordPress.'];

    $kind=strtoupper(preg_replace('/[^A-Z0-9_-]/','',(string)($params['transaction_kind']??'')));
    if($kind==='PRODUCT')$kind='PURCHASE';
    $amount=(float)($params['amount']??0);$unit=(float)($params['product_price']??0);$qty=max(1,(int)($params['product_units']??1));
    if($amount<=0 || $unit<0)return ['status'=>'error','message'=>'Invalid payment amount.'];

    $intent=bin2hex(random_bytes(16));$wow_order_id='wow_'.$intent;
    $payload=[
        'intent_id'=>$intent,'wow_order_id'=>$wow_order_id,'wp_user_id'=>$wp_user_id,'wow_user_id'=>$userid,
        'transaction_kind'=>$kind,'amount'=>round($amount,6),'currency'=>strtoupper((string)($params['wow_currency_code']??'GHS')),
        'product_id'=>(int)($params['product_id']??$params['wow_product_kind']??0),
        'variation_id'=>(int)($params['variation_id']??0),'quantity'=>$qty,'product_name'=>(string)($params['product_name']??'Buzzjuice Payment'),
        'wow_post_id'=>(int)($params['wow_post_id']??0),'qdw_order_id'=>(string)($params['qdw_order_id']??''),
        'qdw_membershipType'=>(string)($params['qdw_membershipType']??''),'qdw_transaction_kind'=>(string)($params['qdw_transaction_kind']??''),
        'subscription_period'=>(string)($params['subscription_period']??''),'subscription_interval'=>(int)($params['subscription_interval']??0),
        'subscription_length'=>(int)($params['subscription_length']??0),'email'=>$email,
        'billing'=>[
            'first_name'=>(string)($wo['user']['first_name']??$wo['user']['username']??''),
            'last_name'=>(string)($wo['user']['last_name']??''),
            'phone'=>(string)($wo['user']['phone_number']??''),'address_1'=>(string)($wo['user']['address']??''),
            'city'=>(string)($wo['user']['city']??''),'state'=>(string)($wo['user']['state']??''),
            'postcode'=>(string)($wo['user']['zip']??''),'country'=>strtoupper((string)($wo['user']['country_id']??'GH'))
        ],
        'return_url'=>(string)($params['return_url']??$wo['config']['site_url'].'/'),
        'idempotency_key'=>'streams:'.$userid.':'.$intent
    ];

    $wp_api=rtrim((string)($wo['config']['wow_api_url']??''),'/');
    $shared_secret=(string)($wo['config']['wow_pgb_shared_secret']??getenv('BZJ_PGB_SHARED_SECRET'));
    if($wp_api==='' || $shared_secret==='')return ['status'=>'error','message'=>'Payment gateway is not configured.'];

    $body=json_encode($payload,JSON_UNESCAPED_SLASHES);
    $response=bzj_pgb_http_post($wp_api.'/wp-json/bzj-pgb/v1/intents',$body,$shared_secret,30);
    bzj_pgb_client_log('Intent response',['http_code'=>$response['code'],'intent_id'=>$intent,'error'=>$response['error']]);
    if($response['code']<200 || $response['code']>=300){
        return ['status'=>'error','message'=>'Unable to create payment order.','debug'=>getenv('BZJ_PGB_STREAMS_DEBUG')?'HTTP '.$response['code']:null];
    }
    $data=json_decode($response['body'],true);
    if(!is_array($data) || empty($data['url']))return ['status'=>'error','message'=>'WooCommerce did not return a payment URL.'];
    return ['status'=>200,'url'=>$data['url'],'intent_id'=>$intent,'wow_order_id'=>$wow_order_id,'woo_order_id'=>(int)($data['woo_order_id']??0)];
}
