<?php
if (!defined('ABSPATH')) exit;

/**
 * Jewel Affiliate integration hook.
 * The existing Streams jewel logic should be migrated here incrementally.
 * The MU bridge triggers this only after payment confirmation.
 */
function pgb_int_jewel_affiliate($order,$ledger) {
    $has=false;
    foreach($order->get_items('line_item') as $item) {
        $sku=$item->get_product() ? $item->get_product()->get_sku() : '';
        if ($sku && stripos($sku,'jewel')!==false) {$has=true;break;}
    }
    if (!$has || $order->get_meta('_bzj_pgb_jewel_processed',true)) return;

    $endpoint=getenv('BUZZJUICE_JEWEL_WEBHOOK_URL');
    if (!$endpoint) return;
    $payload=[
        'woo_order_id'=>$order->get_id(),
        'wow_user_id'=>(int)$order->get_meta('wow_user_id',true),
        'wow_order_id'=>(string)$order->get_meta('wow_order_id',true),
        'status'=>$order->get_status(),
        'currency'=>$order->get_currency(),
        'total'=>(float)$order->get_total()
    ];
    $secret=(string)getenv('BUZZJUICE_JEWEL_WEBHOOK_SECRET');
    $body=wp_json_encode($payload);
    $headers=['Content-Type'=>'application/json'];
    if($secret!=='')$headers['X-Buzzjuice-Signature']=hash_hmac('sha256',$body,$secret);
    $response=wp_remote_post($endpoint,['timeout'=>20,'headers'=>$headers,'body'=>$body]);
    if(!is_wp_error($response) && wp_remote_retrieve_response_code($response)>=200 && wp_remote_retrieve_response_code($response)<300){
        $order->update_meta_data('_bzj_pgb_jewel_processed',gmdate('c'));$order->save();
    }
}
