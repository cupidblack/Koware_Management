<?php
if (!defined('ABSPATH')) exit;

/**
 * Fulfil the WoWonder side only after WooCommerce payment is authoritative.
 * Uses the configured WoWonder API rather than wp-load in Streams.
 */
function pgb_int_streams($order,$ledger) {
    $kind=strtoupper((string)$order->get_meta('_bzj_pgb_transaction_kind',true));
    if (!$kind) return;
    $api=rtrim((string)getenv('WOWONDER_API_URL'),'/');
    $server=(string)getenv('WOWONDER_SERVER_KEY');
    $admin_user=(string)getenv('WOWONDER_ADMIN_USERNAME');
    $admin_pass=(string)getenv('WOWONDER_ADMIN_PASSWORD');
    if ($api==='' || $server==='' || $admin_user==='' || $admin_pass==='') {
        pgb_streams_log('WoWonder credentials not configured',PGB_Logger::ERROR,['kind'=>$kind],__FILE__);
        return;
    }

    $wow_user=(int)$order->get_meta('wow_user_id',true);
    $post=(int)$order->get_meta('wow_post_id',true);
    $email=$order->get_billing_email();

    switch($kind) {
        case 'PRO':
            pgb_streams_update_pro($api,$server,$admin_user,$admin_pass,$wow_user,$post,$order);
            break;
        case 'WALLET':
            pgb_streams_wallet($api,$server,$admin_user,$admin_pass,$wow_user,(float)$order->get_total(),$order);
            break;
        case 'DONATE':
        case 'FUND':
            pgb_streams_mark_transaction($wow_user,(string)$order->get_meta('wow_order_id',true),'paid',$order);
            break;
        case 'PRODUCT':
        case 'PURCHASE':
        case 'SALE':
        case 'MARKET':
            pgb_streams_mark_transaction($wow_user,(string)$order->get_meta('wow_order_id',true),'paid',$order);
            break;
    }
    $order->update_meta_data('_bzj_pgb_streams_fulfilled',gmdate('c')); $order->save();
}
function pgb_streams_log($m,$l,$c=[],$s=null){ global $pgb_logger; if($pgb_logger instanceof PGB_Logger)$pgb_logger->log($m,$l,$c,$s); }
function pgb_streams_api($url,$fields,$timeout=30) {
    $ch=curl_init($url);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query($fields),CURLOPT_TIMEOUT=>$timeout,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
    $body=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
    return ['code'=>$code,'body'=>$body,'error'=>$err];
}
function pgb_streams_auth($api,$server,$user,$pass) {
    $r=pgb_streams_api($api.'/auth',['server_key'=>$server,'username'=>$user,'password'=>$pass]);
    if($r['code']!==200)return '';
    $j=json_decode($r['body'],true);return (string)($j['access_token']??'');
}
function pgb_streams_update_pro($api,$server,$user,$pass,$wow_user,$post,$order) {
    $token=pgb_streams_auth($api,$server,$user,$pass); if(!$token)return;
    $r=pgb_streams_api($api.'/update-user-pro?access_token='.rawurlencode($token),[
        'server_key'=>$server,'user_id'=>$wow_user,'pro_type'=>$post,'is_pro'=>1
    ]);
    pgb_streams_log('WoWonder PRO fulfillment attempted',PGB_Logger::INFO,['http_code'=>$r['code'],'wow_user_id'=>$wow_user,'pro_type'=>$post],__FILE__);
}
function pgb_streams_wallet($api,$server,$user,$pass,$wow_user,$amount,$order) {
    $token=pgb_streams_auth($api,$server,$user,$pass); if(!$token)return;
    /* Wallet endpoint varies by WoWonder version. The transaction is still marked
       only through the dedicated SQL helper below; do not invent an API contract. */
    pgb_streams_log('Wallet fulfillment requires site-specific wallet endpoint',PGB_Logger::WARNING,['wow_user_id'=>$wow_user,'amount'=>$amount],__FILE__);
    pgb_streams_mark_transaction($wow_user,(string)$order->get_meta('wow_order_id',true),'paid',$order);
}
function pgb_streams_mark_transaction($wow_user,$wow_order_id,$status,$order) {
    if(!$wow_user || !$wow_order_id)return;
    $path=ABSPATH.'../shared/db_helpers.php';
    /* Streams DB is intentionally not opened through wp-load. The implementation
       below is delegated to the existing shared bridge helper when available. */
    do_action('bzj_pgb_streams_transaction_status',$wow_user,$wow_order_id,$status,$order);
}
