<?php
if (!defined('ABSPATH')) exit;

class PGB_Schema {
    private $logger;
    public function __construct($logger) { $this->logger=$logger; }

    public function install() {
        global $wpdb;
        $table = $wpdb->prefix . 'bzj_pgb_transactions';
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            intent_id varchar(64) NOT NULL,
            wow_order_id varchar(64) NOT NULL,
            woo_order_id bigint(20) unsigned DEFAULT NULL,
            wp_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            wow_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            transaction_kind varchar(32) NOT NULL,
            product_id bigint(20) unsigned NOT NULL DEFAULT 0,
            variation_id bigint(20) unsigned NOT NULL DEFAULT 0,
            amount decimal(20,6) NOT NULL DEFAULT 0,
            currency varchar(12) NOT NULL DEFAULT '',
            status varchar(24) NOT NULL DEFAULT 'intent',
            fulfillment_status varchar(24) NOT NULL DEFAULT 'pending',
            idempotency_key varchar(128) NOT NULL,
            return_url text NULL,
            payload longtext NULL,
            last_error text NULL,
            attempts int unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            paid_at datetime NULL,
            fulfilled_at datetime NULL,
            PRIMARY KEY (id),
            UNIQUE KEY intent_id (intent_id),
            UNIQUE KEY wow_order_id (wow_order_id),
            UNIQUE KEY idempotency_key (idempotency_key),
            KEY woo_order_id (woo_order_id),
            KEY status (status),
            KEY wp_user_id (wp_user_id)
        ) {$charset};";
        $ok = $wpdb->query($sql);
        if ($ok === false) $this->logger->log('Schema creation failed', PGB_Logger::ERROR, ['error'=>$wpdb->last_error], __FILE__);
        else $this->logger->log('Schema ready', PGB_Logger::INFO, ['table'=>$table], __FILE__);
        return $ok !== false;
    }
    public function table() { global $wpdb; return $wpdb->prefix . 'bzj_pgb_transactions'; }
}
