<?php
if (!defined('ABSPATH')) exit;

class PGB_Logger {
    const DEBUG='debug', INFO='info', WARNING='warning', ERROR='error', CRITICAL='critical';

    private $enabled;
    private $min_level;
    private $dir;
    private $priority = ['debug'=>0,'info'=>1,'warning'=>2,'error'=>3,'critical'=>4];

    public function __construct() {
        $env = getenv('BZJ_PGB_DEBUG');
        $this->enabled = ($env !== false) ? in_array(strtolower((string)$env), ['1','true','yes','on'], true) : false;
        $option = get_option('bzj_pgb_debug', null);
        if ($option !== null) $this->enabled = (bool)$option;
        $level = getenv('BZJ_PGB_LOG_LEVEL');
        $option_level = get_option('bzj_pgb_log_level', null);
        $this->min_level = strtolower((string)($option_level ?: ($level ?: self::INFO)));
        if (!isset($this->priority[$this->min_level])) $this->min_level = self::INFO;
        $this->dir = BZJ_PGB_LOG_DIR;
        if (!is_dir($this->dir)) wp_mkdir_p($this->dir);
    }

    public function enabled() { return $this->enabled; }

    public function log($message, $level=self::INFO, $context=[], $source=null) {
        if (!$this->enabled && $level === self::DEBUG) return;
        if (($this->priority[$level] ?? 1) < ($this->priority[$this->min_level] ?? 1)) return;
        $file = $this->source_file($source);
        $path = $this->dir . $file . '.log';
        if (!is_dir($this->dir)) wp_mkdir_p($this->dir);
        if (!is_writable($this->dir)) return;
        $entry = [
            'time'=>gmdate('c'), 'level'=>strtoupper($level),
            'message'=>(string)$message, 'context'=>$this->redact($context)
        ];
        @file_put_contents($path, wp_json_encode($entry, JSON_UNESCAPED_SLASHES) . PHP_EOL, FILE_APPEND | LOCK_EX);
        $this->rotate($path);
    }

    private function source_file($source) {
        if (!$source) return 'pgb-client';
        $name = basename((string)$source);
        return preg_replace('/\.php$/i','',$name) ?: 'pgb';
    }
    private function redact($value, $key='') {
        $sensitive = ['password','secret','token','cookie','authorization','signature','api_key','api_secret','consumer_key','consumer_secret'];
        if (is_array($value)) {
            $out=[];
            foreach ($value as $k=>$v) $out[$k] = in_array(strtolower((string)$k), $sensitive, true) ? '[REDACTED]' : $this->redact($v, (string)$k);
            return $out;
        }
        if (is_object($value)) return $this->redact((array)$value, $key);
        return is_string($value) && in_array(strtolower($key), $sensitive, true) ? '[REDACTED]' : $value;
    }
    private function rotate($path) {
        if (is_file($path) && filesize($path) > 10 * 1024 * 1024) {
            @rename($path, $path . '.' . gmdate('YmdHis') . '.1');
        }
    }
}
