<?php
if (!defined('ABSPATH')) exit;

class PGB_Idempotency {
    private $logger;
    public function __construct($logger) { $this->logger=$logger; }
    public function find($key) {
        global $wpdb;
        $table = $wpdb->prefix . 'bzj_pgb_transactions';
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE idempotency_key=%s LIMIT 1", $key), ARRAY_A);
    }
    public function reserve($data) {
        global $wpdb;
        $table = $wpdb->prefix . 'bzj_pgb_transactions';
        $now = current_time('mysql', true);
        $row = [
            'intent_id'=>$data['intent_id'], 'wow_order_id'=>$data['wow_order_id'],
            'wp_user_id'=>(int)$data['wp_user_id'], 'wow_user_id'=>(int)$data['wow_user_id'],
            'transaction_kind'=>$data['transaction_kind'], 'product_id'=>(int)$data['product_id'],
            'variation_id'=>(int)$data['variation_id'], 'amount'=>(float)$data['amount'],
            'currency'=>$data['currency'], 'status'=>'intent', 'fulfillment_status'=>'pending',
            'idempotency_key'=>$data['idempotency_key'], 'return_url'=>$data['return_url'],
            'payload'=>wp_json_encode($data['payload']), 'created_at'=>$now, 'updated_at'=>$now
        ];
        $formats=['%s','%s','%d','%d','%s','%d','%d','%f','%s','%s','%s','%s','%s','%s','%s'];
        $ok=$wpdb->insert($table,$row,$formats);
        if ($ok===false) {
            $existing=$this->find($data['idempotency_key']);
            if ($existing) return $existing;
            $this->logger->log('Ledger reservation failed', PGB_Logger::ERROR, ['error'=>$wpdb->last_error], __FILE__);
            return false;
        }
        return $this->find($data['idempotency_key']);
    }
}
