<?php
if (!defined('ABSPATH')) exit;

class PGB_Manager {
    private $logger; private $validator; private $idem;
    public function __construct($logger,$validator,$idem) { $this->logger=$logger; $this->validator=$validator; $this->idem=$idem; }

    public function create_intent($data) {
        $valid=$this->validator->intent($data); if (is_wp_error($valid)) return $valid;
        $existing=$this->idem->find($data['idempotency_key']);
        if ($existing) {
            if (!empty($existing['woo_order_id'])) {
                $order=wc_get_order((int)$existing['woo_order_id']);
                if ($order) return $this->response_for_order($order,$existing);
            }
            return ['status'=>200,'intent_id'=>$existing['intent_id'],'wow_order_id'=>$existing['wow_order_id'],'state'=>$existing['status']];
        }

        $ledger=$this->idem->reserve(['intent_id'=>$data['intent_id'],'wow_order_id'=>$data['wow_order_id'],
            'wp_user_id'=>$data['wp_user_id'],'wow_user_id'=>$data['wow_user_id'],'transaction_kind'=>$data['transaction_kind'],
            'product_id'=>$data['product_id'],'variation_id'=>$data['variation_id'],'amount'=>$data['amount'],
            'currency'=>$data['currency'],'idempotency_key'=>$data['idempotency_key'],'return_url'=>$data['return_url'],'payload'=>$data]);
        if (!$ledger) return new WP_Error('pgb_ledger_error','Unable to reserve payment intent.',['status'=>500]);

        $order=$this->create_order($data);
        if (is_wp_error($order)) {
            $this->fail_ledger($data['intent_id'],$order->get_error_message());
            return $order;
        }

        global $wpdb; $table=$wpdb->prefix.'bzj_pgb_transactions';
        $wpdb->update($table, ['woo_order_id'=>$order->get_id(),'status'=>'pending','updated_at'=>current_time('mysql',true)], ['intent_id'=>$data['intent_id']], ['%d','%s','%s'], ['%s']);
        $this->logger->log('Payment order created',PGB_Logger::INFO,['intent_id'=>$data['intent_id'],'woo_order_id'=>$order->get_id()],__FILE__);
        return $this->response_for_order($order,$ledger);
    }

    private function create_order($data) {
        try {
            $order=wc_create_order(['customer_id'=>(int)$data['wp_user_id']]);
            if (is_wp_error($order)) return $order;
            $product=wc_get_product((int)$data['product_id']);
            if (!$product) return new WP_Error('pgb_product_missing','Configured WooCommerce handler product was not found.',['status'=>500]);

            $qty=max(1,(int)($data['quantity'] ?? 1));
            $variation_id=(int)($data['variation_id'] ?? 0);
            $line_product=$variation_id ? wc_get_product($variation_id) : $product;
            if (!$line_product) $line_product=$product;
            $line=$order->add_product($line_product,$qty);
            if (!$line) return new WP_Error('pgb_line_item','Unable to add payment product.',['status'=>500]);
            $line->set_subtotal((float)$data['amount']);
            $line->set_total((float)$data['amount']);
            $line->save();

            $meta=[
                'wow_order_id'=>$data['wow_order_id'],'wow_user_id'=>(int)$data['wow_user_id'],
                'userid'=>(int)$data['wow_user_id'],'wp_user_id'=>(int)$data['wp_user_id'],
                'wow_post_id'=>(int)($data['wow_post_id'] ?? 0),'qdw_order_id'=>(string)($data['qdw_order_id'] ?? ''),
                'qdw_membershipType'=>(string)($data['qdw_membershipType'] ?? ''),
                'qdw_transaction_kind'=>(string)($data['qdw_transaction_kind'] ?? ''),
                '_buzzjuice_origin'=>'streams','_bzj_pgb_intent_id'=>$data['intent_id'],
                '_bzj_pgb_transaction_kind'=>$data['transaction_kind'],
            ];
            if (!empty($data['subscription_period'])) $meta['_subscription_period']=$data['subscription_period'];
            if (!empty($data['subscription_interval'])) $meta['_subscription_interval']=(int)$data['subscription_interval'];
            if (isset($data['subscription_length'])) $meta['_subscription_length']=(int)$data['subscription_length'];
            foreach($meta as $k=>$v) $order->update_meta_data($k,$v);

            $order->set_currency(strtoupper($data['currency']));
            $order->set_billing_first_name($data['billing']['first_name'] ?? '');
            $order->set_billing_last_name($data['billing']['last_name'] ?? '');
            $order->set_billing_email($data['email']);
            $order->set_billing_phone($data['billing']['phone'] ?? '');
            $order->set_billing_address_1($data['billing']['address_1'] ?? '');
            $order->set_billing_city($data['billing']['city'] ?? '');
            $order->set_billing_state($data['billing']['state'] ?? '');
            $order->set_billing_postcode($data['billing']['postcode'] ?? '');
            $order->set_billing_country($data['billing']['country'] ?? '');
            $order->set_customer_note('Buzzjuice Streams payment intent '.$data['intent_id']);
            $order->calculate_totals(false);
            $order->save();
            return $order;
        } catch (Throwable $e) {
            $this->logger->log('Order creation exception',PGB_Logger::ERROR,['error'=>$e->getMessage(),'line'=>$e->getLine()],__FILE__);
            return new WP_Error('pgb_exception','Unable to create WooCommerce order.',['status'=>500]);
        }
    }

    public function process_paid_order($order_id,$source='hook') {
        $order=wc_get_order($order_id); if (!$order) return false;
        if ($order->get_meta('_buzzjuice_origin',true)!=='streams') return false;
        $intent=$order->get_meta('_bzj_pgb_intent_id',true); if (!$intent) return false;
        $paid=in_array($order->get_status(),['processing','completed'],true) || $order->is_paid();
        if (!$paid) return false;

        global $wpdb; $table=$wpdb->prefix.'bzj_pgb_transactions';
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE intent_id=%s LIMIT 1",$intent),ARRAY_A);
        if (!$row) { $this->logger->log('Paid order has no ledger row',PGB_Logger::ERROR,['order_id'=>$order_id,'intent_id'=>$intent],__FILE__); return false; }
        if ($row['fulfillment_status']==='complete') return true;

        $wpdb->update($table,['status'=>'paid','paid_at'=>($row['paid_at']?:current_time('mysql',true)),'updated_at'=>current_time('mysql',true),'attempts'=>(int)$row['attempts']+1],['intent_id'=>$intent],['%s','%s','%s','%d'],['%s']);

        do_action('pgb_payment_confirmed',$order,$row);
        $this->logger->log('Payment confirmed',PGB_Logger::INFO,['order_id'=>$order_id,'intent_id'=>$intent,'source'=>$source],__FILE__);
        return true;
    }

    public function mark_fulfilled($intent_id,$ok,$error='') {
        global $wpdb; $table=$wpdb->prefix.'bzj_pgb_transactions';
        $data=['fulfillment_status'=>$ok?'complete':'failed','updated_at'=>current_time('mysql',true)];
        if ($ok) $data['fulfilled_at']=current_time('mysql',true); else $data['last_error']=substr((string)$error,0,2000);
        $wpdb->update($table,$data,['intent_id'=>$intent_id],null,['%s']);
    }
    private function fail_ledger($intent,$error) {
        global $wpdb; $wpdb->update($wpdb->prefix.'bzj_pgb_transactions',['status'=>'failed','last_error'=>substr((string)$error,0,2000),'updated_at'=>current_time('mysql',true)],['intent_id'=>$intent],['%s','%s','%s'],['%s']);
    }
    private function response_for_order($order,$row) {
        return ['status'=>200,'intent_id'=>$row['intent_id'],'wow_order_id'=>$row['wow_order_id'],'woo_order_id'=>$order->get_id(),
            'state'=>$order->get_status(),'url'=>$order->get_checkout_payment_url()];
    }
}
