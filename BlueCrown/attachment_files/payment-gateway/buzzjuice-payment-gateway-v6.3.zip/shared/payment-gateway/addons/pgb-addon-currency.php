<?php
if (!defined('ABSPATH')) exit;

/**
 * Currency integration point. WOOCS/WooCommerce Currency Switcher is authoritative
 * for conversion when the plugin exposes its public conversion API.
 */
function pgb_currency_amount($amount,$from,$to) {
    $from=strtoupper((string)$from); $to=strtoupper((string)$to);
    if ($from===$to) return (float)$amount;
    if (function_exists('woocs_exchange_value')) {
        try { return (float)woocs_exchange_value((float)$amount,$from,$to); } catch(Throwable $e) {}
    }
    return (float)$amount;
}
