<?php
if (!defined('ABSPATH')) exit;

/**
 * AffiliateWP completion addon.
 * Reuses the proven bridge function when available; otherwise resolves affiliate
 * through AffiliateWP's public APIs and creates one referral per Woo order.
 */
function pgb_addon_affiliate_wp($order,$ledger) {
    if (!function_exists('affwp_add_referral') && !function_exists('bluecrown_affiliatewp_post_checkout_verification')) return;
    if ($order->get_meta('_affwp_bridge_processed',true)) return;
    if ($order->get_meta('_bzj_pgb_affwp_processed',true)) return;

    try {
        if (function_exists('bluecrown_affiliatewp_post_checkout_verification')) {
            bluecrown_affiliatewp_post_checkout_verification($order->get_id());
            if ($order->get_meta('_affwp_bridge_processed',true)) {
                $order->update_meta_data('_bzj_pgb_affwp_processed',gmdate('c')); $order->save(); return;
            }
        }

        $customer_id=0;
        if (function_exists('affwp_get_customer_by')) {
            $customer=affwp_get_customer_by('user_id',(int)$order->get_customer_id());
            if (!$customer && $order->get_billing_email()) $customer=affwp_get_customer_by('email',$order->get_billing_email());
            if ($customer) $customer_id=(int)$customer->customer_id;
        }
        if (!$customer_id && function_exists('affwp_add_customer')) {
            $customer_id=(int)affwp_add_customer(['user_id'=>(int)$order->get_customer_id(),'email'=>$order->get_billing_email()]);
        }
        if (!$customer_id) return;

        global $wpdb;
        $affiliate_id=(int)$wpdb->get_var($wpdb->prepare(
            "SELECT affiliate_id FROM {$wpdb->prefix}affiliate_wp_lifetime_customers WHERE affwp_customer_id=%d ORDER BY lifetime_customer_id DESC LIMIT 1",$customer_id
        ));
        if (!$affiliate_id) return;

        $existing=(int)$wpdb->get_var($wpdb->prepare(
            "SELECT referral_id FROM {$wpdb->prefix}affiliate_wp_referrals WHERE reference=%s AND context=%s AND affiliate_id=%d LIMIT 1",
            (string)$order->get_id(),'woocommerce',$affiliate_id
        ));
        if ($existing) {
            $order->update_meta_data('_bzj_pgb_affwp_processed',gmdate('c')); $order->save(); return;
        }

        $commission=0.0;$products=[];
        foreach($order->get_items('line_item') as $item) {
            $product_id=(int)$item->get_product_id(); $variation_id=(int)$item->get_variation_id();
            $target=$variation_id?:$product_id;
            $rate_raw=get_post_meta($target,'_affwp_woocommerce_product_rate',true);
            $type=(string)get_post_meta($target,'_affwp_woocommerce_product_rate_type',true);
            if ($rate_raw==='' || !is_numeric($rate_raw)) {
                $rate=(float)get_option('affwp_rate',0); $type=(string)get_option('affwp_rate_type','percentage');
            } else $rate=(float)$rate_raw;
            $item_total=(float)$item->get_total();
            $item_comm=$type==='flat' ? $rate : ($item_total*($rate/100));
            $commission+=max(0,$item_comm);
            $products[]=['product_id'=>$product_id,'variation_id'=>$variation_id,'name'=>$item->get_name(),'item_total'=>$item_total,'commission'=>$item_comm];
        }
        if ($commission<=0) return;

        $ref=affwp_add_referral([
            'affiliate_id'=>$affiliate_id,'customer_id'=>$customer_id,'parent_id'=>(int)$order->get_parent_id(),
            'description'=>'Buzzjuice Streams order '.$order->get_id(),'status'=>'unpaid','amount'=>round($commission,4),
            'currency'=>$order->get_currency(),'context'=>'woocommerce','campaign'=>'','reference'=>(string)$order->get_id(),
            'products'=>maybe_serialize($products),'date'=>current_time('mysql'),'custom'=>maybe_serialize(['origin'=>'streams','calculation_source'=>'pgb_addon'])
        ]);
        if ($ref) {
            $order->update_meta_data('_bzj_pgb_affwp_processed',gmdate('c'));
            $order->update_meta_data('_bzj_pgb_affwp_referral_id',(int)$ref);
            $order->save();
        }
    } catch(Throwable $e) {
        if (function_exists('pgb_log')) pgb_log('AffiliateWP addon failed',PGB_Logger::ERROR,['error'=>$e->getMessage()],__FILE__);
    }
}
if (!function_exists('pgb_log')) {
    function pgb_log($m,$l,$c=[],$s=null){ global $pgb_logger; if($pgb_logger instanceof PGB_Logger)$pgb_logger->log($m,$l,$c,$s); }
}
