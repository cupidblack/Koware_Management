<?php
if (!defined('ABSPATH')) exit;

/**
 * WooCommerce Subscriptions integration.
 * The bridge does not manufacture a subscription through REST. Subscription
 * products are allowed to create native WC_Subscription objects at checkout.
 */
function pgb_addon_subscriptions($order,$ledger) {
    if (!function_exists('wcs_get_subscriptions_for_order')) return;
    $subs=wcs_get_subscriptions_for_order($order,['order_type'=>'parent']);
    if (!empty($subs)) {
        foreach($subs as $subscription) {
            if ($subscription->get_status() !== 'active' && $order->is_paid()) {
                try { $subscription->update_status('active'); } catch(Throwable $e) {}
            }
            $order->update_meta_data('_bzj_pgb_subscription_id',$subscription->get_id());
        }
        $order->save();
    }
}
add_action('woocommerce_subscription_payment_complete',function($subscription){
    if (!$subscription instanceof WC_Subscription) return;
    $order_id=$subscription->get_parent_id();
    if (!$order_id) return;
    do_action('bzj_pgb_subscription_payment_complete',$subscription,wc_get_order($order_id));
},20,1);
add_action('woocommerce_subscription_renewal_payment_complete',function($subscription,$renewal_order){
    do_action('bzj_pgb_subscription_renewal_payment_complete',$subscription,$renewal_order);
},20,2);
add_action('woocommerce_subscription_status_active',function($subscription){
    do_action('bzj_pgb_subscription_activated',$subscription);
},20,1);
