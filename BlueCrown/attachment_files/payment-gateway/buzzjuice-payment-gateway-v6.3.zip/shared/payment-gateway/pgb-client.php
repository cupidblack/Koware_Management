<?php
if (!defined('ABSPATH')) exit;

/**
 * Shared WordPress-side request signature verification.
 * Secret is stored in the WP environment as BZJ_PGB_SHARED_SECRET.
 */
function pgb_client_shared_secret() {
    $secret=getenv('BZJ_PGB_SHARED_SECRET');
    if ($secret!==false && $secret!=='') return (string)$secret;
    if (defined('BZJ_PGB_SHARED_SECRET')) return (string)BZJ_PGB_SHARED_SECRET;
    return '';
}
function pgb_client_verify_request($headers,$body) {
    $secret=pgb_client_shared_secret(); if ($secret==='') return false;
    $timestamp=(string)($headers['x-bzj-pgb-timestamp'][0] ?? $headers['X-Bzj-Pgb-Timestamp'][0] ?? '');
    $signature=(string)($headers['x-bzj-pgb-signature'][0] ?? $headers['X-Bzj-Pgb-Signature'][0] ?? '');
    if ($timestamp==='' || $signature==='' || !ctype_digit($timestamp)) return false;
    if (abs(time()-(int)$timestamp)>300) return false;
    $expected=hash_hmac('sha256',$timestamp.'.'.$body,$secret);
    return hash_equals($expected,$signature);
}
