# Buzzjuice Payment Gateway Bridge 6.3 — Migration

## Target architecture
Streams -> `pgb-client-streams.php` -> signed WordPress REST intent -> `bzj-payment-gateway.php` -> WooCommerce native order/payment -> `woocommerce_payment_complete` / processing / completed -> PGB ledger -> addons/integrations.

WooCommerce is authoritative for payment state. The PGB ledger is authoritative only for bridge state/idempotency.

## Install
1. Create `shared/payment-gateway/` and copy this package preserving paths.
2. Ensure `wp-content/mu-plugins/bzj-payment-gateway.php` is the only PGB MU plugin.
3. Set `BZJ_PGB_SHARED_SECRET` in the WordPress environment. Use the same secret in Streams as `wow_pgb_shared_secret`.
4. For Streams-side logs set `BZJ_PGB_STREAMS_DEBUG=1`; for WP logs set `BZJ_PGB_DEBUG=1` and optionally `BZJ_PGB_LOG_LEVEL=debug`.
5. Configure `WOWONDER_API_URL`, `WOWONDER_SERVER_KEY`, `WOWONDER_ADMIN_USERNAME`, `WOWONDER_ADMIN_PASSWORD` for the Streams integration only.
6. Configure `BUZZJUICE_JEWEL_WEBHOOK_URL` and `BUZZJUICE_JEWEL_WEBHOOK_SECRET` if the Jewel integration is enabled.

## Existing files to retire/modify
- `streams/assets/wow-pgb/wow-pgb_init.php`: replace with compatibility wrapper in this package.
- `streams/requests.php`: retain route; update payment settings to save `wow_pgb_shared_secret`; keep `wow_payment` route.
- `wp-content/plugins/blue-crown-wp/wow-pgb_sync/wow-pgb_sync.php`: stop loading it as a payment engine. Keep the supplied stub temporarily, then remove after validation.
- `streams/wow-pgb_webhook.php`: DISABLE and archive. Do not run it beside the new engine.
- `wp-content/mu-plugins/buzzjuice-affwp-order-complete.php`: DISABLE/archive after the new AffiliateWP addon has passed production tests. Do not run two completion hooks.
- `streams/jewel-affiliate-webhook.php`: archive after Jewel processing is moved to `pgb-int-jewel-affiliate.php`.
- Existing `wow-pgb` browser modal/button code: no conceptual redesign is required; it continues posting to `requests.php?f=payment` with `payment_type=wow_payment`.

## Important product/subscription rule
The handler product/variation must be a real WooCommerce product. For subscriptions, use a native WooCommerce Subscriptions product/variation. Do not create a normal order and then manufacture a subscription by REST API.

## Legacy transaction rows
The new bridge intentionally does not insert WoWonder payment rows before payment. On successful payment, a Streams integration must update the existing WoWonder transaction/purchase tables using the exact schemas of this installation. Because WoWonder table schemas vary by release, this final fulfillment SQL should be migrated from the currently working completion code rather than guessed.

## Rollout
A. Deploy package with old completion engines disabled.
B. Create one test intent per transaction type: PRO, wallet, fund/donation, market/product.
C. Confirm one Woo order per intent and a stable payment URL.
D. Pay once and repeat the completion callback/status transition. Confirm no duplicate fulfillment/referral.
E. Test failed payment, abandoned checkout, duplicate browser click, webhook/status retry, and subscription renewal.
F. Only after all tests pass, delete archived engines.
