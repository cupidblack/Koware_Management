<?php
if (!defined('ABSPATH')) exit;

class PGB_Validator {
    private $logger;
    public function __construct($logger) { $this->logger=$logger; }

    public function intent($data) {
        $required=['intent_id','wow_order_id','wp_user_id','wow_user_id','transaction_kind','amount','currency','product_id','idempotency_key'];
        foreach($required as $key) {
            if (!isset($data[$key]) || $data[$key] === '' || ($key==='amount' && (float)$data[$key] <= 0) || ($key==='product_id' && (int)$data[$key] <= 0)) {
                $this->logger->log('Intent validation failed', PGB_Logger::WARNING, ['field'=>$key], __FILE__);
                return new WP_Error('pgb_invalid_intent', 'Invalid payment intent.', ['status'=>400]);
            }
        }
        if (!preg_match('/^[A-Za-z0-9_-]{8,64}$/', (string)$data['intent_id'])) return new WP_Error('pgb_invalid_intent_id','Invalid intent ID',['status'=>400]);
        if (!preg_match('/^[A-Za-z0-9._:-]{8,128}$/', (string)$data['idempotency_key'])) return new WP_Error('pgb_invalid_idempotency','Invalid idempotency key',['status'=>400]);
        if (!is_email($data['email'] ?? '')) return new WP_Error('pgb_invalid_email','Valid email required',['status'=>400]);
        return true;
    }
}
