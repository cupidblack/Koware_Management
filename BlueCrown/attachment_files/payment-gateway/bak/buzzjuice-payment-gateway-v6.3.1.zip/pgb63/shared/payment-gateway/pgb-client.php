<?php
if (!defined('ABSPATH')) exit;

/**
 * WordPress-side request signature verification for Streams -> PGB.
 */
function pgb_client_shared_secret() {
    $secret = getenv('BZJ_PGB_SHARED_SECRET');
    if ($secret !== false && $secret !== '') return (string)$secret;
    if (defined('BZJ_PGB_SHARED_SECRET')) return (string)BZJ_PGB_SHARED_SECRET;
    return '';
}

function pgb_client_header_value($headers, $name) {
    $wanted = strtolower($name);
    foreach ((array)$headers as $key => $value) {
        if (strtolower((string)$key) !== $wanted) continue;
        if (is_array($value)) return (string)reset($value);
        return (string)$value;
    }
    return '';
}

function pgb_client_verify_request($headers, $body) {
    $secret = pgb_client_shared_secret();
    if ($secret === '') return false;

    $timestamp = pgb_client_header_value($headers, 'X-Bzj-Pgb-Timestamp');
    $signature = pgb_client_header_value($headers, 'X-Bzj-Pgb-Signature');

    if ($timestamp === '' || $signature === '' || !ctype_digit($timestamp)) return false;
    if (abs(time() - (int)$timestamp) > 300) return false;

    $expected = hash_hmac('sha256', $timestamp . '.' . $body, $secret);
    return hash_equals($expected, $signature);
}
