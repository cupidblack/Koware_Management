<?php
if (!defined('ABSPATH')) exit;

class PGB_Bootstrap {
    private $logger; private $manager;
    public function boot() {
        $this->logger=new PGB_Logger();
        global $pgb_logger; $pgb_logger=$this->logger;
        $schema=new PGB_Schema($this->logger); $schema->install();
        $validator=new PGB_Validator($this->logger);
        $idem=new PGB_Idempotency($this->logger);
        $this->manager=new PGB_Manager($this->logger,$validator,$idem);

        require_once BZJ_PGB_DIR.'pgb-client.php';
        require_once BZJ_PGB_DIR.'addons/pgb-addon-affiliate-wp.php';
        require_once BZJ_PGB_DIR.'addons/pgb-addon-subscriptions.php';
        require_once BZJ_PGB_DIR.'addons/pgb-addon-currency.php';
        require_once BZJ_PGB_DIR.'integrations/pgb-int-streams.php';
        require_once BZJ_PGB_DIR.'integrations/pgb-int-jewel-affiliate.php';

        add_action('rest_api_init',[$this,'rest']);
        add_action('woocommerce_payment_complete',[$this,'paid'],20,1);
        add_action('woocommerce_order_status_processing',[$this,'paid'],20,1);
        add_action('woocommerce_order_status_completed',[$this,'paid'],20,1);
        add_action('pgb_payment_confirmed','pgb_addon_affiliate_wp',20,2);
        add_action('pgb_payment_confirmed','pgb_addon_subscriptions',30,2);
        add_action('pgb_payment_confirmed','pgb_int_streams',40,2);
        add_action('pgb_payment_confirmed','pgb_int_jewel_affiliate',50,2);

        $this->logger->log('Payment Gateway Bridge booted',PGB_Logger::INFO,['version'=>BZJ_PGB_VERSION],__FILE__);
    }
    public function rest() {
        register_rest_route('bzj-pgb/v1','/intents',[
            'methods'=>WP_REST_Server::CREATABLE,'permission_callback'=>'__return_true',
            'callback'=>[$this,'create_intent']
        ]);
        register_rest_route('bzj-pgb/v1','/health',[
            'methods'=>WP_REST_Server::READABLE,'permission_callback'=>function(){return current_user_can('manage_options');},
            'callback'=>function(){return ['status'=>'ok','version'=>BZJ_PGB_VERSION];}
        ]);
    }
    public function create_intent(WP_REST_Request $request) {
        $raw=$request->get_body();
        if (!pgb_client_verify_request($request->get_headers(),$raw)) return new WP_Error('pgb_signature','Invalid payment signature',['status'=>401]);
        $data=json_decode($raw,true); if (!is_array($data)) return new WP_Error('pgb_json','Invalid JSON',['status'=>400]);
        $result=$this->manager->create_intent($data);
        if ($result instanceof WP_Error) {
            $this->logger->log('Intent creation failed', PGB_Logger::ERROR, [
                'code' => $result->get_error_code(),
                'message' => $result->get_error_message(),
                'data' => $result->get_error_data(),
            ], __FILE__);
            return $result;
        }
        return new WP_REST_Response($result, 200);
    }
    public function paid($order_id) { $this->manager->process_paid_order($order_id,current_filter()); }
}
