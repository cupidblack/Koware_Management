<?php
/**
 * Buzzjuice Streams Payment Gateway client.
 *
 * WordPress-independent. Builds a signed payment intent for the WordPress
 * Payment Gateway Bridge. No WordPress functions are used here.
 */
require_once __DIR__ . '/pgb-client.php';

/**
 * Resolve the WooCommerce handler product/variation from the existing
 * WoWonder payment settings. The browser is intentionally NOT trusted to
 * supply the WooCommerce product ID for PRO/WALLET/DONATE transactions.
 */
function bzj_pgb_streams_resolve_handler($transaction_kind, $wow_post_id, $params, $wo) {
    $kind = strtoupper((string)$transaction_kind);
    $product_id = 0;
    $variation_id = 0;

    switch ($kind) {
        case 'PRO':
            $map = [
                1 => (int)($wo['config']['wow_pro_package_id'] ?? 0),
                2 => (int)($wo['config']['wow_pro_package_id_2'] ?? 0),
                3 => (int)($wo['config']['wow_pro_package_id_3'] ?? 0),
                4 => (int)($wo['config']['wow_pro_package_id_4'] ?? 0),
            ];

            $package_id = (int)$wow_post_id;
            if (!isset($map[$package_id]) || $map[$package_id] <= 0) {
                return [
                    'ok' => false,
                    'message' => 'The selected subscription package is not configured for WooCommerce.'
                ];
            }

            $product_id = $map[$package_id];
            // Existing Buzzjuice configuration maps PRO package handlers to
            // the WooCommerce subscription variation used for checkout.
            $variation_id = $product_id;
            break;

        case 'WALLET':
            $product_id = (int)($wo['config']['wow_wallet_topup_id'] ?? 0);
            break;

        case 'DONATE':
        case 'CROWDFUND':
            $product_id = (int)($wo['config']['wow_crowdfund_id'] ?? 0);
            break;

        case 'PURCHASE':
        case 'PRODUCT':
        case 'SALE':
            // For product/market purchases, allow the existing integration to
            // supply a real WooCommerce handler product. If absent, fall back
            // to the legacy POST value. Never silently send product ID 0.
            $product_id = (int)($params['product_id'] ?? $params['wow_product_kind'] ?? 0);
            $variation_id = (int)($params['variation_id'] ?? 0);
            break;

        default:
            return [
                'ok' => false,
                'message' => 'Invalid payment transaction type.'
            ];
    }

    if ($product_id <= 0) {
        return [
            'ok' => false,
            'message' => 'The WooCommerce payment product is not configured.'
        ];
    }

    return [
        'ok' => true,
        'product_id' => $product_id,
        'variation_id' => $variation_id,
    ];
}

/**
 * Resolve subscription metadata from the native WoWonder PRO package.
 * This is retained as metadata only; WooCommerce Subscriptions remains the
 * authority for subscription creation and lifecycle.
 */
function bzj_pgb_streams_subscription_meta($transaction_kind, $wow_post_id, $wo) {
    if (strtoupper((string)$transaction_kind) !== 'PRO') {
        return [
            'subscription_period' => '',
            'subscription_interval' => 0,
            'subscription_length' => 0,
        ];
    }

    $period = 'month';
    $interval = 1;
    $length = 0;

    if (!empty($wo['pro_packages']) && is_array($wo['pro_packages'])) {
        foreach ($wo['pro_packages'] as $package) {
            if ((int)($package['id'] ?? 0) !== (int)$wow_post_id) {
                continue;
            }

            $period = (string)($package['time'] ?? 'month');
            $interval = max(1, (int)($package['count'] ?? 1));
            $length = max(0, (int)($package['time_count'] ?? 0));
            break;
        }
    }

    return [
        'subscription_period' => $period,
        'subscription_interval' => $interval,
        'subscription_length' => $length,
    ];
}

/**
 * Build the WordPress PGB REST endpoint while remaining compatible with the
 * existing wow_api_url setting. Historically this value represented either
 * the site root or a REST base, so avoid producing /wp-json/wp-json.
 */
function bzj_pgb_streams_endpoint($wo) {
    $configured = trim((string)($wo['config']['wow_api_url'] ?? ''));
    if ($configured === '') {
        $configured = trim((string)($wo['config']['wow_store_url'] ?? ''));
    }

    if ($configured === '' || !filter_var($configured, FILTER_VALIDATE_URL)) {
        return '';
    }

    $base = rtrim($configured, '/');

    // If the old setting was saved as /wc/v3, strip that API suffix.
    $base = preg_replace('#/wc/v[0-9]+$#i', '', $base);

    if (preg_match('#/wp-json$#i', $base)) {
        return $base . '/bzj-pgb/v1/intents';
    }

    return $base . '/wp-json/bzj-pgb/v1/intents';
}

function bzj_pgb_streams_create_intent($params, $wo, $sqlConnect) {
    if (empty($wo['user']['user_id'])) {
        return ['status' => 'error', 'message' => 'Login required.'];
    }

    $userid = (int)$wo['user']['user_id'];
    $email = filter_var($wo['user']['email'] ?? '', FILTER_VALIDATE_EMAIL);
    if (!$email) {
        return ['status' => 'error', 'message' => 'A valid account email is required.'];
    }

    $wp_user_id = 0;
    $q = mysqli_query(
        $sqlConnect,
        "SELECT wp_user_id FROM " . T_USERS . " WHERE user_id=" . $userid . " LIMIT 1"
    );
    if ($q && ($r = mysqli_fetch_assoc($q))) {
        $wp_user_id = (int)($r['wp_user_id'] ?? 0);
    }

    if (!$wp_user_id) {
        return ['status' => 'error', 'message' => 'Your account is not linked to WordPress.'];
    }

    $kind = strtoupper(preg_replace('/[^A-Z0-9_-]/', '', (string)($params['transaction_kind'] ?? '')));
    if ($kind === 'PRODUCT') {
        $kind = 'PURCHASE';
    }

    $amount = (float)($params['amount'] ?? 0);
    $unit = (float)($params['product_price'] ?? 0);
    $qty = max(1, (int)($params['product_units'] ?? 1));
    $wow_post_id = (int)($params['wow_post_id'] ?? 0);

    if ($amount <= 0 || $unit < 0) {
        return ['status' => 'error', 'message' => 'Invalid payment amount.'];
    }

    $handler = bzj_pgb_streams_resolve_handler($kind, $wow_post_id, $params, $wo);
    if (empty($handler['ok'])) {
        return ['status' => 'error', 'message' => $handler['message'] ?? 'Invalid payment product.'];
    }

    $subscription = bzj_pgb_streams_subscription_meta($kind, $wow_post_id, $wo);

    $intent = bin2hex(random_bytes(16));
    $wow_order_id = 'wow_' . $intent;

    $payload = [
        'intent_id' => $intent,
        'wow_order_id' => $wow_order_id,
        'wp_user_id' => $wp_user_id,
        'wow_user_id' => $userid,
        'transaction_kind' => $kind,
        'amount' => round($amount, 6),
        'currency' => strtoupper((string)($params['wow_currency_code'] ?? 'GHS')),
        'product_id' => (int)$handler['product_id'],
        'variation_id' => (int)$handler['variation_id'],
        'quantity' => $qty,
        'product_name' => (string)($params['product_name'] ?? 'Buzzjuice Payment'),
        'wow_post_id' => $wow_post_id,
        'qdw_order_id' => (string)($params['qdw_order_id'] ?? ''),
        'qdw_membershipType' => (string)($params['qdw_membershipType'] ?? ''),
        'qdw_transaction_kind' => (string)($params['qdw_transaction_kind'] ?? ''),
        'subscription_period' => $subscription['subscription_period'],
        'subscription_interval' => $subscription['subscription_interval'],
        'subscription_length' => $subscription['subscription_length'],
        'email' => $email,
        'billing' => [
            'first_name' => (string)($wo['user']['first_name'] ?? $wo['user']['username'] ?? ''),
            'last_name' => (string)($wo['user']['last_name'] ?? ''),
            'phone' => (string)($wo['user']['phone_number'] ?? ''),
            'address_1' => (string)($wo['user']['address'] ?? ''),
            'city' => (string)($wo['user']['city'] ?? ''),
            'state' => (string)($wo['user']['state'] ?? ''),
            'postcode' => (string)($wo['user']['zip'] ?? ''),
            'country' => strtoupper((string)($wo['user']['country_id'] ?? 'GH')),
        ],
        'return_url' => (string)($params['return_url'] ?? $wo['config']['site_url'] . '/'),
        'idempotency_key' => 'streams:' . $userid . ':' . $intent,
    ];

    $endpoint = bzj_pgb_streams_endpoint($wo);
    $shared_secret = (string)($wo['config']['wow_pgb_shared_secret'] ?? getenv('BZJ_PGB_SHARED_SECRET'));

    if ($endpoint === '' || $shared_secret === '') {
        return ['status' => 'error', 'message' => 'Payment gateway is not configured.'];
    }

    bzj_pgb_client_log('Creating payment intent', [
        'transaction_kind' => $kind,
        'wow_post_id' => $wow_post_id,
        'product_id' => (int)$handler['product_id'],
        'variation_id' => (int)$handler['variation_id'],
        'wp_user_id' => $wp_user_id,
    ]);

    $body = json_encode($payload, JSON_UNESCAPED_SLASHES);
    if ($body === false) {
        return ['status' => 'error', 'message' => 'Unable to prepare payment request.'];
    }

    $response = bzj_pgb_http_post($endpoint, $body, $shared_secret, 30);

    $response_body = is_string($response['body'] ?? null) ? $response['body'] : '';
    $decoded = json_decode($response_body, true);

    bzj_pgb_client_log('Intent response', [
        'http_code' => (int)($response['code'] ?? 0),
        'intent_id' => $intent,
        'error' => (string)($response['error'] ?? ''),
        'response' => $decoded ?: substr($response_body, 0, 2000),
    ]);

    if ((int)$response['code'] < 200 || (int)$response['code'] >= 300) {
        $message = is_array($decoded) ? ($decoded['message'] ?? $decoded['code'] ?? '') : '';
        $debug = getenv('BZJ_PGB_STREAMS_DEBUG');

        return [
            'status' => 'error',
            'message' => $message !== '' ? (string)$message : 'Unable to create payment order.',
            'debug' => $debug ? ('HTTP ' . (int)$response['code'] . ($response['error'] ? ' ' . $response['error'] : '')) : null,
        ];
    }

    if (!is_array($decoded) || empty($decoded['url'])) {
        return ['status' => 'error', 'message' => 'WooCommerce did not return a payment URL.'];
    }

    return [
        'status' => 200,
        'url' => $decoded['url'],
        'intent_id' => $intent,
        'wow_order_id' => $wow_order_id,
        'woo_order_id' => (int)($decoded['woo_order_id'] ?? 0),
    ];
}
