<?php
/**
 * Buzzjuice PGB 5.3 Streams fulfillment endpoint.
 * This is the only server-to-server payment completion entry point in Streams.
 *
 * The existing wow-pgb_webhook.php fulfillment SQL/business logic should be
 * moved into pgb_streams_apply_fulfillment() below during migration.
 */
require_once dirname(__DIR__) . '/shared/db_helpers.php';
header('Content-Type: application/json');

$raw=file_get_contents('php://input');
$ts=(string)($_SERVER['HTTP_X_BZJ_PGB_TIMESTAMP']??'');
$rid=(string)($_SERVER['HTTP_X_BZJ_PGB_REQUEST_ID']??'');
$sig=(string)($_SERVER['HTTP_X_BZJ_PGB_SIGNATURE']??'');
$secret=getenv('BZJ_PGB_SECRET') ?: '';
$ok=$secret!=='' && ctype_digit($ts) && $rid!=='' && $sig!=='' && abs(time()-(int)$ts)<=300;
if($ok){
    $expected=base64_encode(hash_hmac('sha256',$ts."\n".$rid."\n".$raw,$secret,true));
    $ok=hash_equals($expected,$sig);
}
if(!$ok){http_response_code(401);echo json_encode(['status'=>'error','message'=>'Invalid signature']);exit;}

$data=json_decode($raw,true);
if(!is_array($data)||empty($data['woo_order_id'])||empty($data['wow_order_id'])||empty($data['wow_user_id'])){
    http_response_code(400);echo json_encode(['status'=>'error','message'=>'Invalid fulfillment payload']);exit;
}

try{
    pgb_streams_apply_fulfillment($data);
    echo json_encode(['status'=>'success','order_id'=>(int)$data['woo_order_id']]);
}catch(Throwable $e){
    error_log('[BZJ-PGB Streams] fulfillment failed: '.$e->getMessage());
    http_response_code(500);
    echo json_encode(['status'=>'error','message'=>'Fulfillment failed']);
}

function pgb_streams_apply_fulfillment(array $data): void {
    /*
     * Migration rule:
     * Move the exact successful DB/business operations from the former
     * wow-pgb_webhook.php here. They must be idempotent and keyed by
     * wow_order_id / woo_order_id. Do not execute the old webhook in parallel.
     *
     * This function intentionally refuses to invent WoWonder schema mutations.
     */
    throw new RuntimeException('WoWonder fulfillment handler has not yet been ported from the legacy webhook');
}
