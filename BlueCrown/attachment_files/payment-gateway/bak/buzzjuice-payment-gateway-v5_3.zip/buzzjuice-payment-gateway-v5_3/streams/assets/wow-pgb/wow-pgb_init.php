<?php
/**
 * Streams compatibility entry point.
 * Streams itself remains responsible for authentication and its own config.
 * The client is the only payment code in this file.
 */
require_once dirname(__DIR__,3) . '/shared/payment-gateway/pgb-client-streams.php';
pgb_streams_init_payment();
