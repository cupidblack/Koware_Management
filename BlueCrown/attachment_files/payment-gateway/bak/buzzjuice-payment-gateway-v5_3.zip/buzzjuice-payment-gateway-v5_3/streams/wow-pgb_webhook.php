<?php
/**
 * RETIRED. Do not route WooCommerce webhooks here.
 * Keep this file temporarily as a hard stop so the old fulfillment engine
 * cannot run alongside PGB 5.3.
 */
http_response_code(410);
header('Content-Type: application/json');
echo json_encode(['status'=>'retired','message'=>'Legacy Buzzjuice payment webhook retired; use /wp-json/bzj-pgb/v1/order and WooCommerce payment hooks.']);
exit;
