<?php
defined('ABSPATH') || exit;

class PGB_Manager {
    private PGB_Logger $logger; private PGB_Schema $schema; private array $config;
    public function __construct(PGB_Logger $l,PGB_Schema $s,array $c){$this->logger=$l;$this->schema=$s;$this->config=$c;}

    public function create_order(array $d): array {
        try {
            $v=$this->validate($d); if($v) return ['success'=>false,'message'=>implode('; ',$v)];
            $rid=(string)$d['request_id'];
            $existing=$this->schema->by_request($rid);
            if($existing && !empty($existing['woo_order_id'])){
                $o=wc_get_order((int)$existing['woo_order_id']);
                return $o?['success'=>true,'order_id'=>$o->get_id(),'payment_url'=>$o->get_checkout_payment_url(),'replayed'=>true]:['success'=>false,'message'=>'Existing transaction order is unavailable'];
            }
            $wow_user=(int)$d['wow_user_id']; $email=sanitize_email($d['wow_email']);
            $wp_user=$this->map_user($wow_user,$email);
            if(!$wp_user) return ['success'=>false,'message'=>'WordPress customer mapping failed'];
            $kind=strtoupper((string)$d['transaction_kind']);
            $amount=round((float)$d['amount'],6);
            $currency=strtoupper(preg_replace('/[^A-Z0-9]/','',(string)($d['currency']??get_woocommerce_currency())));
            if($currency==='') $currency=get_woocommerce_currency();

            $this->schema->create([
                'request_id'=>$rid,'wow_order_id'=>sanitize_text_field($d['wow_order_id']??''),
                'wow_user_id'=>$wow_user,'wp_user_id'=>$wp_user,'transaction_kind'=>$kind,
                'amount'=>$amount,'currency'=>$currency,'payload'=>wp_json_encode($d)
            ]);

            $order=wc_create_order(['customer_id'=>$wp_user]);
            if(is_wp_error($order)) throw new Exception($order->get_error_message());
            $product_id=(int)($d['product_id']??0);
            $variation_id=(int)($d['variation_id']??0);
            $product=$variation_id?wc_get_product($variation_id):wc_get_product($product_id);
            if(!$product) throw new Exception('Configured WooCommerce product/variation not found');

            $qty=max(1,(int)($d['product_units']??1));
            $item_id=$order->add_product($product,$qty,['subtotal'=>$amount,'total'=>$amount]);
            if(!$item_id) throw new Exception('Unable to add payment line item');

            $order->set_customer_id($wp_user);
            $order->set_currency($currency);
            $this->meta($order,$d,$rid,$wow_user,$kind);
            $order->calculate_totals(false);
            $order->set_status('pending');
            $order->save();

            $this->schema->update_by_request($rid,[
                'woo_order_id'=>$order->get_id(),'status'=>'order_created',
                'updated_at'=>gmdate('Y-m-d H:i:s')
            ]);
            do_action('pgb_order_created',$order,$d);
            return ['success'=>true,'order_id'=>$order->get_id(),'payment_url'=>$order->get_checkout_payment_url()];
        } catch(Throwable $e) {
            $this->logger->log('Order creation failed',PGB_Logger::CRITICAL,['error'=>$e->getMessage(),'trace'=>$e->getTraceAsString()],__FILE__);
            return ['success'=>false,'message'=>'Payment order creation failed'];
        }
    }

    public function complete(int $order_id): void {
        $order=wc_get_order($order_id); if(!$order) return;
        $tx=$this->schema->by_woo($order_id); if(!$tx) return;
        if($tx['status']==='fulfilled') return;
        $this->schema->update_by_woo($order_id,['status'=>'paid','paid_at'=>gmdate('Y-m-d H:i:s'),'fulfillment_status'=>'processing']);
        do_action('pgb_payment_confirmed',$order,$tx);
        $this->fulfill_streams($order,$tx);
    }

    private function fulfill_streams(WC_Order $order,array $tx): void {
        try {
            $result=apply_filters('pgb_streams_fulfillment',$this->default_streams_payload($order,$tx),$order,$tx);
            if(is_wp_error($result)) throw new Exception($result->get_error_message());
            $url=rtrim((string)$this->config['streams_fulfillment_url'],'/').'/';
            if($url==='/' || empty($url)) throw new Exception('Streams fulfillment URL is not configured');
            $secret=getenv($this->config['secret_env']) ?: '';
            $rid='fulfill_'.$order->get_id().'_'.wp_generate_uuid4();
            $body=wp_json_encode($result);
            $ts=(string)time();
            $sig=base64_encode(hash_hmac('sha256',$ts."\n".$rid."\n".$body,$secret,true));
            $resp=wp_remote_post($url.'?f=wow-pgb-fulfill',[
                'timeout'=>(int)$this->config['request_timeout'],
                'headers'=>['Content-Type'=>'application/json','X-BZJ-PGB-Timestamp'=>$ts,'X-BZJ-PGB-Request-ID'=>$rid,'X-BZJ-PGB-Signature'=>$sig],
                'body'=>$body
            ]);
            if(is_wp_error($resp)) throw new Exception($resp->get_error_message());
            $code=wp_remote_retrieve_response_code($resp);
            if($code<200||$code>=300) throw new Exception('Streams fulfillment HTTP '.$code);
            $this->schema->update_by_woo($order->get_id(),['status'=>'fulfilled','fulfillment_status'=>'fulfilled','fulfilled_at'=>gmdate('Y-m-d H:i:s')]);
            $order->update_meta_data('_bzj_pgb_fulfilled',gmdate('c')); $order->save();
        } catch(Throwable $e) {
            $this->schema->update_by_woo($order->get_id(),['status'=>'paid','fulfillment_status'=>'failed','last_error'=>$e->getMessage(),'attempts'=>(int)$tx['attempts']+1]);
            $this->logger->log('Streams fulfillment failed',PGB_Logger::ERROR,['order_id'=>$order->get_id(),'error'=>$e->getMessage()],__FILE__);
        }
    }

    private function default_streams_payload(WC_Order $o,array $tx): array {
        return ['order_id'=>$o->get_id(),'wow_order_id'=>$tx['wow_order_id'],'wow_user_id'=>(int)$tx['wow_user_id'],'transaction_kind'=>$tx['transaction_kind'],'amount'=>(float)$o->get_total(),'currency'=>$o->get_currency(),'reference'=>(string)$o->get_id()];
    }
    private function meta(WC_Order $o,array $d,string $rid,int $uid,string $kind): void {
        $map=['wow_user_id'=>$uid,'wow_order_id'=>$d['wow_order_id']??'','transaction_kind'=>$kind,'pgb_request_id'=>$rid,'wow_post_id'=>$d['wow_post_id']??0,'wow_username'=>$d['wow_username']??''];
        foreach($map as $k=>$v)$o->update_meta_data($k,$v);
        $o->update_meta_data('_buzzjuice_origin','streams');
        if(!empty($d['affwp_context_snapshot'])) $o->update_meta_data('_buzzjuice_affwp_context_snapshot',wp_json_encode($d['affwp_context_snapshot']));
    }
    private function map_user(int $wow_user,string $email): int {
        $users=get_users(['meta_key'=>'wow_user_id','meta_value'=>$wow_user,'number'=>1,'fields'=>'ID']);
        if($users) return (int)$users[0];
        $u=get_user_by('email',$email); if($u) return (int)$u->ID;
        return 0;
    }
    private function validate(array $d): array {
        $e=[];
        foreach(['request_id','wow_user_id','wow_email','transaction_kind','amount','wow_order_id'] as $k) if(!isset($d[$k])||$d[$k]==='')$e[]='Missing '.$k;
        if(isset($d['wow_email'])&&!is_email($d['wow_email']))$e[]='Invalid email';
        if(isset($d['amount'])&&(float)$d['amount']<=0)$e[]='Amount must be positive';
        if(isset($d['transaction_kind'])&&!in_array(strtoupper($d['transaction_kind']),['PRO','PRODUCT','PURCHASE','SALE','WALLET','DONATE'],true))$e[]='Invalid transaction kind';
        return $e;
    }
}
