<?php
defined('ABSPATH') || exit;

class PGB_Bootstrap {
    private static ?self $instance=null; private PGB_Logger $logger; private PGB_Schema $schema; private PGB_Manager $manager; private array $config;
    public static function instance(): self { return self::$instance ??= new self; }
    private function __construct(){ $this->config=bzj_pgb_config(); $this->logger=new PGB_Logger($this->config); }
    public function boot(): void {
        require_once BZJ_PGB_DIR.'/core/class-pgb-schema.php';
        require_once BZJ_PGB_DIR.'/core/class-pgb-manager.php';
        require_once BZJ_PGB_DIR.'/core/class-pgb-rest.php';
        $this->schema=new PGB_Schema($this->logger);
        if(!$this->schema->install()) return;
        $this->manager=new PGB_Manager($this->logger,$this->schema,$this->config);
        add_action('rest_api_init',function(){ (new PGB_REST($this->logger,$this->manager,$this->config))->register(); });
        add_action('woocommerce_payment_complete',[$this,'payment_complete'],20,1);
        add_action('woocommerce_order_status_completed',[$this,'payment_complete'],20,1);
        $this->load_dir('addons'); $this->load_dir('integrations');
        $this->admin();
        $this->logger->log('Bridge booted',PGB_Logger::INFO,['version'=>BZJ_PGB_VERSION],__FILE__);
    }
    public function payment_complete($order_id): void { $this->manager->complete((int)$order_id); }
    private function load_dir(string $dir): void {
        $path=BZJ_PGB_DIR.'/'.$dir; if(!is_dir($path))return;
        foreach(glob($path.'/*.php')?:[] as $f) require_once $f;
    }
    private function admin(): void {
        add_action('admin_menu',function(){
            add_menu_page('Payment Gateways','Buzzjuice','manage_options','buzzjuice-payment-gateways',[$this,'admin_page'],'dashicons-cart',56);
        });
        add_action('admin_init',function(){
            register_setting('bzj_pgb','bzj_pgb_logging_enabled',['type'=>'boolean','sanitize_callback'=>'rest_sanitize_boolean','default'=>false]);
            register_setting('bzj_pgb','bzj_pgb_log_level',['type'=>'string','sanitize_callback'=>'sanitize_key','default'=>'info']);
            register_setting('bzj_pgb','bzj_pgb_streams_url',['type'=>'string','sanitize_callback'=>'esc_url_raw','default'=>'']);
        });
    }
    public function admin_page(): void {
        if(!current_user_can('manage_options'))return;
        ?><div class="wrap"><h1>Buzzjuice → Payment Gateways</h1>
        <form method="post" action="options.php"><?php settings_fields('bzj_pgb'); ?>
        <table class="form-table">
        <tr><th>Logging</th><td><label><input type="checkbox" name="bzj_pgb_logging_enabled" value="1" <?php checked(get_option('bzj_pgb_logging_enabled',false),true); ?>> Enable bridge logs</label></td></tr>
        <tr><th>Log level</th><td><select name="bzj_pgb_log_level"><?php foreach(['debug','info','warning','error','critical'] as $v) printf('<option value="%s" %s>%s</option>',esc_attr($v),selected(get_option('bzj_pgb_log_level','info'),$v,false),esc_html(ucfirst($v))); ?></select></td></tr>
        <tr><th>Streams base URL</th><td><input class="regular-text" name="bzj_pgb_streams_url" value="<?php echo esc_attr(get_option('bzj_pgb_streams_url','')); ?>"><p class="description">Base URL of Streams, without a trailing slash.</p></td></tr>
        </table><?php submit_button(); ?></form>
        <p><strong>Secret:</strong> set <code>BZJ_PGB_SECRET</code> in the server environment; never store it in the WordPress option or Streams database.</p></div><?php
    }
}
