<?php
defined('ABSPATH') || exit;

/**
 * WooCommerce Subscriptions is authoritative. The bridge does not manually
 * manufacture subscription records; it lets the plugin create/activate them.
 * This addon only records the resulting subscription IDs for auditability.
 */
add_action('woocommerce_subscription_status_active','bzj_pgb_subscription_active',20,1);
add_action('woocommerce_subscription_status_cancelled','bzj_pgb_subscription_state',20,1);
add_action('woocommerce_subscription_status_expired','bzj_pgb_subscription_state',20,1);

function bzj_pgb_subscription_active($subscription): void {
    if(!is_object($subscription) || !method_exists($subscription,'get_parent_id'))return;
    $parent=(int)$subscription->get_parent_id(); if(!$parent)return;
    $order=wc_get_order($parent); if(!$order)return;
    $ids=$order->get_meta('_bzj_subscription_ids',true);
    $ids=is_array($ids)?$ids:[];
    $id=(int)$subscription->get_id();
    if(!in_array($id,$ids,true)){$ids[]=$id;$order->update_meta_data('_bzj_subscription_ids',$ids);$order->save();}
    do_action('pgb_subscription_activated',$subscription,$order);
}
function bzj_pgb_subscription_state($subscription): void {
    if(!is_object($subscription))return;
    do_action('pgb_subscription_state_changed',$subscription,$subscription->get_status());
}
