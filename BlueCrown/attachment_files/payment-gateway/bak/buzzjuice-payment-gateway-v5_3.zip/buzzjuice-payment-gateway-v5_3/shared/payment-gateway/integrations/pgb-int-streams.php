<?php
defined('ABSPATH') || exit;

/**
 * Streams fulfillment extension point.
 * Add site-specific database operations here; keep them idempotent.
 */
add_filter('pgb_streams_fulfillment',function(array $payload,WC_Order $order,array $tx){
    $payload['payment_status']='paid';
    $payload['woo_order_id']=$order->get_id();
    return $payload;
},10,3);
