<?php
defined('ABSPATH') || exit;

class PGB_Schema {
    private wpdb $db;
    private PGB_Logger $logger;
    public function __construct(PGB_Logger $logger){ global $wpdb; $this->db=$wpdb; $this->logger=$logger; }

    public function install(): bool {
        $table=$this->db->prefix.'bzj_pgb_transactions';
        $version=get_option('bzj_pgb_schema_version','');
        if ($version==='5.3.0' && $this->db->get_var($this->db->prepare("SHOW TABLES LIKE %s",$table)) === $table) return true;
        $sql="CREATE TABLE {$table} (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
request_id varchar(80) NOT NULL,
woo_order_id bigint(20) unsigned NOT NULL DEFAULT 0,
wow_order_id varchar(191) NOT NULL,
wow_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
wp_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
transaction_kind varchar(32) NOT NULL,
status varchar(32) NOT NULL DEFAULT 'initiated',
fulfillment_status varchar(32) NOT NULL DEFAULT 'pending',
amount decimal(20,6) NOT NULL DEFAULT 0,
currency varchar(10) NOT NULL DEFAULT '',
payload longtext NULL,
last_error text NULL,
attempts int(11) NOT NULL DEFAULT 0,
created_at datetime NOT NULL,
updated_at datetime NOT NULL,
paid_at datetime NULL,
fulfilled_at datetime NULL,
PRIMARY KEY  (id),
UNIQUE KEY request_id (request_id),
UNIQUE KEY wow_order_id (wow_order_id),
UNIQUE KEY woo_order_id (woo_order_id),
KEY wow_user_id (wow_user_id),
KEY wp_user_id (wp_user_id),
KEY status (status),
KEY fulfillment_status (fulfillment_status)
) ".$this->db->get_charset_collate().";";
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $result=dbDelta($sql);
        $ok=$this->db->get_var($this->db->prepare("SHOW TABLES LIKE %s",$table)) === $table;
        if($ok) update_option('bzj_pgb_schema_version','5.3.0',false);
        $this->logger->log($ok?'Transaction ledger ready':'Transaction ledger creation failed',
            $ok?PGB_Logger::INFO:PGB_Logger::CRITICAL,['table'=>$table,'db_error'=>$this->db->last_error],__FILE__);
        return $ok;
    }

    public function by_request(string $id){ return $this->db->get_row($this->db->prepare("SELECT * FROM {$this->table()} WHERE request_id=%s LIMIT 1",$id),ARRAY_A); }
    public function by_woo(int $id){ return $this->db->get_row($this->db->prepare("SELECT * FROM {$this->table()} WHERE woo_order_id=%d LIMIT 1",$id),ARRAY_A); }
    public function table(){ return $this->db->prefix.'bzj_pgb_transactions'; }

    public function create(array $d): bool {
        $now=gmdate('Y-m-d H:i:s');
        $d=array_merge(['request_id'=>'','woo_order_id'=>0,'wow_order_id'=>'','wow_user_id'=>0,'wp_user_id'=>0,'transaction_kind'=>'UNKNOWN','status'=>'initiated','fulfillment_status'=>'pending','amount'=>0,'currency'=>'','payload'=>'','last_error'=>null,'attempts'=>0,'created_at'=>$now,'updated_at'=>$now],$d);
        return false !== $this->db->insert($this->table(),$d);
    }

    public function update_by_woo(int $id,array $d): bool {
        $d['updated_at']=gmdate('Y-m-d H:i:s');
        return false !== $this->db->update($this->table(),$d,['woo_order_id'=>$id]);
    }
    public function update_by_request(string $rid,array $d): bool {
        $d['updated_at']=gmdate('Y-m-d H:i:s');
        return false !== $this->db->update($this->table(),$d,['request_id'=>$rid]);
    }
}
