<?php
defined('ABSPATH') || exit;

/**
 * AffiliateWP addon.
 * Uses the same core principle as the proven bridge: resolve the purchasing
 * WordPress customer at fulfillment time, then use AffiliateWP's public API.
 */
add_action('pgb_payment_confirmed','bzj_pgb_affwp_process',30,2);

function bzj_pgb_affwp_process(WC_Order $order,array $tx): void {
    if(!function_exists('affwp_get_affiliate_id') && !function_exists('affwp_get_affiliate')) return;
    if($order->get_meta('_bzj_affwp_processed',true)) return;

    $customer_id=(int)$order->get_customer_id();
    if(!$customer_id) return;
    $affiliate_id=function_exists('affwp_get_affiliate_id') ? (int)affwp_get_affiliate_id($customer_id) : 0;

    if(!$affiliate_id){
        global $wpdb;
        $cid=function_exists('affwp_get_customer') ? affwp_get_customer($customer_id) : false;
        $affwp_customer_id=is_object($cid)?(int)$cid->customer_id:0;
        if($affwp_customer_id){
            $affiliate_id=(int)$wpdb->get_var($wpdb->prepare(
                "SELECT affiliate_id FROM {$wpdb->prefix}affiliate_wp_lifetime_customers WHERE affwp_customer_id=%d ORDER BY lifetime_customer_id DESC LIMIT 1",$affwp_customer_id
            ));
            if(!$affiliate_id){
                $affiliate_id=(int)$wpdb->get_var($wpdb->prepare(
                    "SELECT affiliate_id FROM {$wpdb->prefix}affiliate_wp_customermeta WHERE affwp_customer_id=%d AND meta_key IN ('affiliate_id','referring_affiliate_id') ORDER BY meta_id DESC LIMIT 1",$affwp_customer_id
                ));
            }
        }
    }
    if(!$affiliate_id) return;

    global $wpdb;
    $reference=(string)$order->get_id();
    $exists=(int)$wpdb->get_var($wpdb->prepare(
        "SELECT referral_id FROM {$wpdb->prefix}affiliate_wp_referrals WHERE reference=%s AND context=%s LIMIT 1",$reference,'woocommerce'
    ));
    if($exists){$order->update_meta_data('_bzj_affwp_processed',$exists);$order->save();return;}

    $settings=get_option('affwp_settings',[]);
    $rate=(float)($settings['referral_rate']??0);
    $type=(string)($settings['referral_rate_type']??'percentage');
    $commission=0.0;
    foreach($order->get_items() as $item){
        $total=(float)$item->get_total();
        $pid=(int)($item->get_variation_id()?:$item->get_product_id());
        $override=get_post_meta($pid,'_affwp_woocommerce_product_rate',true);
        $override_type=get_post_meta($pid,'_affwp_woocommerce_product_rate_type',true);
        if($override!=='' && is_numeric($override) && in_array($override_type,['percentage','flat'],true)){
            $commission += $override_type==='percentage' ? $total*((float)$override/100) : (float)$override;
        } elseif($rate>0){
            $commission += $type==='percentage' ? $total*($rate/100) : $rate;
        }
    }
    $commission=round($commission,4);
    if($commission<=0)return;

    $customer_id_affwp=0;
    if(function_exists('affwp_get_customer')) {
        $c=affwp_get_customer($customer_id);
        if(is_object($c))$customer_id_affwp=(int)$c->customer_id;
    }
    if(!$customer_id_affwp)return;

    $data=[
        'affiliate_id'=>$affiliate_id,'customer_id'=>$customer_id_affwp,'parent_id'=>0,
        'description'=>'Buzzjuice Streams order #'.$order->get_id(),'status'=>'unpaid',
        'amount'=>$commission,'currency'=>$order->get_currency(),'context'=>'woocommerce',
        'reference'=>$reference,'date'=>current_time('mysql')
    ];
    $referral_id=function_exists('affwp_add_referral') ? affwp_add_referral($data) : 0;
    if($referral_id){
        $order->update_meta_data('_bzj_affwp_processed',(int)$referral_id);
        $order->save();
    }
}
