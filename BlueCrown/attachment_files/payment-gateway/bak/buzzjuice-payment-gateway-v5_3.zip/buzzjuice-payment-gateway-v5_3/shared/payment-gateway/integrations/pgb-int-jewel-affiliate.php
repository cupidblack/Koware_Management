<?php
defined('ABSPATH') || exit;

/**
 * Jewel Affiliate extension point.
 * The previous standalone webhook should not be called automatically until
 * its exact contract is configured. This hook exposes the paid order safely.
 */
add_action('pgb_payment_confirmed',function(WC_Order $order,array $tx){
    do_action('bzj_jewel_affiliate_order_paid',$order,$tx);
},40,2);
