<?php
/**
 * Buzzjuice Streams payment client.
 * IMPORTANT: this file is executed by Streams, not WordPress.
 */
global $wo, $sqlConnect;
if(!isset($wo['user']['user_id'])) { http_response_code(401); header('Content-Type: application/json'); echo json_encode(['status'=>'error','message'=>'Not authenticated']); return; }

function pgb_streams_secret(): string {
    $v=getenv('BZJ_PGB_SECRET');
    return is_string($v)?trim($v):'';
}
function pgb_streams_wp_url(): string {
    global $wo;
    return rtrim((string)($wo['config']['wow_store_url']??''),'/');
}
function pgb_streams_snapshot(): array {
    $keys=['affwp_ref','affwp_visit','affwp_visit_id','affwp_affiliate_id','affwp_campaign','affwp_coupon','affwp_referrer'];
    $s=[];
    foreach($keys as $k) if(!empty($_COOKIE[$k])) $s[$k]=(string)$_COOKIE[$k];
    $s['timestamp']=gmdate('c');
    return $s;
}
function pgb_streams_init_payment(): void {
    global $wo,$sqlConnect;
    header('Content-Type: application/json');
    $uid=(int)$wo['user']['user_id']; $email=filter_var($wo['user']['email']??'',FILTER_VALIDATE_EMAIL);
    if(!$uid||!$email){http_response_code(400);echo json_encode(['status'=>'error','message'=>'Invalid user']);return;}
    $kind=strtoupper(preg_replace('/[^A-Z0-9_-]/i','',(string)($_POST['transaction_kind']??'')));
    $amount=(float)($_POST['amount']??0);
    if($amount<=0||!in_array($kind,['PRO','PRODUCT','PURCHASE','SALE','WALLET','DONATE'],true)){http_response_code(400);echo json_encode(['status'=>'error','message'=>'Invalid payment data']);return;}

    $wow_order_id='wow_'.bin2hex(random_bytes(12));
    $request_id='pgb_'.bin2hex(random_bytes(16));
    $data=[
        'request_id'=>$request_id,'wow_order_id'=>$wow_order_id,'wow_user_id'=>$uid,
        'wow_email'=>$email,'wow_username'=>(string)($wo['user']['username']??''),
        'transaction_kind'=>$kind,'amount'=>round($amount,6),
        'currency'=>strtoupper((string)($_POST['wow_currency_code']??$wo['config']['currency']??'GHS')),
        'product_id'=>(int)($_POST['product_id']??$_POST['wow_post_id']??0),
        'variation_id'=>(int)($_POST['variation_id']??0),
        'product_units'=>max(1,(int)($_POST['product_units']??1)),
        'product_name'=>trim((string)($_POST['product_name']??'Buzzjuice payment')),
        'wow_post_id'=>(int)($_POST['wow_post_id']??0),
        'affwp_context_snapshot'=>pgb_streams_snapshot()
    ];
    $secret=pgb_streams_secret(); $wp=pgb_streams_wp_url();
    if($secret===''||$wp===''){http_response_code(500);echo json_encode(['status'=>'error','message'=>'Payment bridge server configuration is incomplete']);return;}
    $body=json_encode($data,JSON_UNESCAPED_SLASHES); $ts=(string)time();
    $sig=base64_encode(hash_hmac('sha256',$ts."\n".$request_id."\n".$body,$secret,true));
    $url=$wp.'/wp-json/bzj-pgb/v1/order';
    $ch=curl_init($url);
    curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>20,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_HTTPHEADER=>['Content-Type: application/json','X-BZJ-PGB-Timestamp: '.$ts,'X-BZJ-PGB-Request-ID: '.$request_id,'X-BZJ-PGB-Signature: '.$sig],CURLOPT_POSTFIELDS=>$body, CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_SSL_VERIFYHOST=>2]);
    $raw=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $err=curl_error($ch); curl_close($ch);
    if($err||$code<200||$code>=300){error_log('[BZJ-PGB Streams] order request failed: HTTP '.$code.' '.$err);http_response_code(502);echo json_encode(['status'=>'error','message'=>'Unable to start payment']);return;}
    $out=json_decode($raw,true);
    if(!is_array($out)){http_response_code(502);echo json_encode(['status'=>'error','message'=>'Invalid payment bridge response']);return;}
    echo json_encode(['status'=>$out['success']?'success':'error','url'=>$out['payment_url']??'','order_id'=>$out['order_id']??0,'message'=>$out['message']??'']);
}
