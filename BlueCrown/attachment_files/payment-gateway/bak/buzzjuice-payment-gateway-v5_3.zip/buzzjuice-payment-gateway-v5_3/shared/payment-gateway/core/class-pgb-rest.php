<?php
defined('ABSPATH') || exit;

class PGB_REST {
    private PGB_Logger $logger; private PGB_Manager $manager; private array $config;
    public function __construct(PGB_Logger $l,PGB_Manager $m,array $c){$this->logger=$l;$this->manager=$m;$this->config=$c;}
    public function register(): void {
        register_rest_route($this->config['rest_namespace'],'/order',[
            'methods'=>'POST','permission_callback'=>'__return_true','callback'=>[$this,'order']
        ]);
    }
    public function order(WP_REST_Request $request) {
        $raw=$request->get_body();
        if (strlen($raw) > (int)$this->config['max_body_bytes']) return new WP_Error('pgb_body_too_large','Request too large',['status'=>413]);
        $timestamp=(string)$request->get_header('x-bzj-pgb-timestamp');
        $rid=(string)$request->get_header('x-bzj-pgb-request-id');
        $sig=(string)$request->get_header('x-bzj-pgb-signature');
        if(!$this->verify($timestamp,$rid,$sig,$raw)) return new WP_Error('pgb_auth_failed','Invalid payment bridge signature',['status'=>401]);
        $data=json_decode($raw,true);
        if(!is_array($data)) return new WP_Error('pgb_bad_json','Invalid JSON',['status'=>400]);
        $data['request_id']=$rid;
        $result=$this->manager->create_order($data);
        return new WP_REST_Response($result,$result['success']?200:422);
    }
    private function verify(string $timestamp,string $rid,string $sig,string $body): bool {
        $secret=getenv($this->config['secret_env']) ?: (defined('BZJ_PGB_SECRET')?BZJ_PGB_SECRET:'');
        if($secret==='' || !ctype_digit($timestamp) || $rid==='' || $sig==='') return false;
        if(abs(time()-(int)$timestamp)>(int)$this->config['replay_window']) return false;
        $expected=base64_encode(hash_hmac('sha256',$timestamp."\n".$rid."\n".$body,$secret,true));
        return hash_equals($expected,$sig);
    }
}
