<?php
defined('ABSPATH') || exit;

function bzj_pgb_config() {
    return [
        'logging_enabled' => (bool) get_option('bzj_pgb_logging_enabled', defined('WP_DEBUG') && WP_DEBUG),
        'log_level' => (string) get_option('bzj_pgb_log_level', 'info'),
        'schema_version' => '5.3.0',
        'replay_window' => 300,
        'request_timeout' => 20,
        'max_body_bytes' => 262144,
        'rest_namespace' => 'bzj-pgb/v1',
        'secret_env' => 'BZJ_PGB_SECRET',
        'streams_fulfillment_url' => (string) get_option('bzj_pgb_streams_fulfillment_url', ''),
    ];
}
