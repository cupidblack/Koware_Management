<?php
defined('ABSPATH') || exit;

class PGB_Logger {
    const DEBUG='debug', INFO='info', WARNING='warning', ERROR='error', CRITICAL='critical';
    private array $config;
    private array $priority = ['debug'=>10,'info'=>20,'warning'=>30,'error'=>40,'critical'=>50];

    public function __construct(array $config) { $this->config=$config; }

    public function enabled(): bool { return !empty($this->config['logging_enabled']); }

    public function log(string $message, string $level=self::INFO, array $context=[], string $source=''): void {
        if (!$this->enabled()) return;
        $min=$this->priority[$this->config['log_level'] ?? 'info'] ?? 20;
        if (($this->priority[$level] ?? 20) < $min) return;
        $source=$source ?: 'pgb';
        $name=pathinfo($source, PATHINFO_FILENAME);
        if ($name === '') $name='pgb';
        $dir=defined('BZJ_PGB_LOG_DIR') ? BZJ_PGB_LOG_DIR : dirname(__DIR__).'/log';
        if (!is_dir($dir)) @wp_mkdir_p($dir);
        $safe=$this->redact($context);
        $line='['.gmdate('Y-m-d H:i:s').'] ['.strtoupper($level).'] ['.$name.'] '.$message;
        if ($safe) $line.=' | '.wp_json_encode($safe, JSON_UNESCAPED_SLASHES);
        $line.="\n";
        $file=trailingslashit($dir).$name.'.log';
        if (@filesize($file) > 10*1024*1024) @rename($file, $file.'.'.gmdate('YmdHis'));
        @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
        if (in_array($level,[self::ERROR,self::CRITICAL],true)) error_log('[BZJ-PGB] '.$message);
    }

    private function redact($v) {
        if (!is_array($v)) return $v;
        $keys=['secret','password','token','signature','consumer_secret','api_secret','private_key','authorization'];
        foreach ($v as $k=>&$x) {
            if (is_array($x)) $x=$this->redact($x);
            elseif (preg_match('/('.implode('|',$keys).')/i',(string)$k)) $x='[REDACTED]';
        }
        return $v;
    }
}
