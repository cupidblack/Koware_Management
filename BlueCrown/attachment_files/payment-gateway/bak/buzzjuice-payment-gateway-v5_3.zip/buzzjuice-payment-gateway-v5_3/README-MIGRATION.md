# Buzzjuice Payment Gateway Bridge 5.3

## Target architecture
Streams -> `pgb-client-streams.php` -> signed WP REST endpoint -> WooCommerce order -> WooCommerce payment hooks -> PGB manager -> addons/integrations -> signed Streams fulfillment.

## Critical deployment prerequisites
1. Set the same high-entropy `BZJ_PGB_SECRET` in the PHP environment used by both Streams and WordPress.
2. Set `bzj_pgb_streams_url` to the public base URL of Streams in WordPress: **no trailing slash**.
3. Keep TLS verification enabled.
4. Disable/remove the old `wow-pgb_sync` execution path and WooCommerce webhook before enabling the new bridge.
5. Do not put a second PHP file in `wp-content/mu-plugins`; `bzj-payment-gateway.php` is the only MU bootstrap.
6. Create the log directory writable by PHP.
7. The WooCommerce product/variation IDs sent by Streams must be real existing products/variations.

## Existing Streams files
- `streams/assets/wow-pgb/wow-pgb_init.php`: replace with compatibility wrapper.
- `streams/requests.php`: retain the existing `wow_payment` route; it can continue requiring the wrapper.
- `streams/wow-pgb_webhook.php`: retire; it now returns HTTP 410.
- `streams/admin-panel/pages/payment-settings/content.phtml`: retain existing product/config fields. Add only operational bridge fields if desired; the secret should NOT be stored here.
- `streams/themes/sunshine/...`: no payment engine code needs to remain in the modal; existing button can continue submitting `payment_type=wow_payment`.

## Existing WordPress file
- `wp-content/plugins/blue-crown-wp/wow-pgb_sync/wow-pgb_sync.php`: replace/disable. It must not remain an active fulfillment engine.

## Why v5.1 failed
The supplied log shows the Streams client required `/buzzjuice.net/db_helpers.php`, but the actual helper is `/buzzjuice.net/shared/db_helpers.php`. The log also shows repeated `dbDelta()` warnings for `index_type`, `index_name`, `index_columns`, and `column_name`. The replacement schema deliberately uses conventional `KEY name (column)` syntax and verifies the table after `dbDelta()`.

## Important functional boundary
AffiliateWP and WooCommerce Subscriptions run after WooCommerce payment confirmation. The browser returning to Streams is not the payment authority. The transaction ledger makes fulfillment retryable and idempotent.

## Testing
Test in this order:
1. PHP syntax on every PHP file.
2. WordPress admin loads with no PGB errors.
3. PGB ledger table exists.
4. REST signature rejects wrong/expired signatures.
5. Duplicate request ID returns the existing order.
6. Streams starts an order and receives a payment URL.
7. Successful payment fires fulfillment once.
8. Browser-close test: close the browser after payment; fulfillment must still occur.
9. AffiliateWP referral is created once.
10. Subscription is created/activated by WooCommerce Subscriptions.
11. Failed Streams fulfillment remains `paid` + `failed` and is retryable.

## One migration item that cannot be safely guessed
The repository's current `streams/wow-pgb_webhook.php` contains the site-specific WoWonder fulfillment SQL. The durable architecture requires moving that exact proven logic into `streams/wow-pgb_fulfill.php` and making it idempotent. I have intentionally not fabricated table/column updates that were not fully visible in the supplied source review. Until that port is completed, do not switch production fulfillment to 5.3.
