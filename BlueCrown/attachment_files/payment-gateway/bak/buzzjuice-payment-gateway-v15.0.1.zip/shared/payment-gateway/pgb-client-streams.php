<?php
/**
 * Buzzjuice Payment Gateway Bridge - Streams client.
 *
 * Streams-side only. No WordPress functions are required here.
 * The browser handoff replaces the old Streams -> WooCommerce REST/cURL call.
 */

if (!defined('PGB_STREAMS_CONTEXT')) {
    define('PGB_STREAMS_CONTEXT', true);
}

require_once dirname(__DIR__, 2) . '/shared/db_helpers.php';
require_once __DIR__ . '/pgb-client.php';

function bzj_pgb_streams_log($event, $context = []) {
    $enabled = getenv('BUZZ_PGB_LOGGING');
    if ($enabled === false) $enabled = '1';

    if (!in_array(strtolower((string)$enabled), ['1','true','yes','on'], true)) return;

    $dir = __DIR__ . '/log';
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    if (!is_dir($dir) || !is_writable($dir)) return;

    @file_put_contents(
        $dir . '/pgb-client-streams.log',
        json_encode([
            'time' => gmdate('c'),
            'event' => (string)$event,
            'context' => $context,
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . PHP_EOL,
        FILE_APPEND | LOCK_EX
    );
}

function bzj_pgb_streams_init($data) {
    global $wo, $sqlConnect;

    if (empty($wo['loggedin']) || empty($wo['user']['user_id'])) {
        throw new RuntimeException('Authentication required.');
    }

    if (!function_exists('get_wowonder_db')) {
        throw new RuntimeException('Shared database helper unavailable.');
    }

    $db = get_wowonder_db();
    if (!$db) {
        throw new RuntimeException('Streams database unavailable.');
    }

    $wow_user_id = (int)$wo['user']['user_id'];

    /* Resolve the authoritative WordPress user mapping. */
    $wp_user_id = 0;
    $stmt = $db->prepare("SELECT wp_user_id FROM Wo_Users WHERE user_id=? LIMIT 1");
    if (!$stmt) {
        throw new RuntimeException('Unable to prepare user lookup.');
    }
    $stmt->bind_param('i', $wow_user_id);
    if (!$stmt->execute()) {
        throw new RuntimeException('Unable to execute user lookup.');
    }
    $result = $stmt->get_result();
    $user_row = $result ? $result->fetch_assoc() : null;
    if ($user_row) $wp_user_id = (int)($user_row['wp_user_id'] ?? 0);

    if (!$wp_user_id) {
        throw new RuntimeException('WordPress user mapping is missing.');
    }

    $amount = (float)($data['amount'] ?? 0);
    $product_price = (float)($data['product_price'] ?? 0);
    $quantity = max(1, (int)($data['product_units'] ?? 1));
    $wow_post_id = (int)($data['wow_post_id'] ?? 0);
    $variation_id = (int)($data['variation_id'] ?? 0);
    $owner_id = (int)($data['product_owner_id'] ?? 0);
    $post_id = $wow_post_id;

    $kind = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string)($data['transaction_kind'] ?? '')));
    $currency = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)($data['wow_currency_code'] ?? 'GHS')));
    $product_name = trim((string)($data['product_name'] ?? 'Product'));

    /*
     * IMPORTANT:
     * The existing Streams JavaScript sends wow_post_id, not product_id.
     * For PRO, wow_post_id is the WoWonder package number (1..4), which the
     * old bridge maps to wow_pro_package_id[_2..4]. For other transaction
     * kinds, the existing admin mappings are authoritative.
     */
    $woo_product_id = 0;

    switch ($kind) {
        case 'PRODUCT':
            $woo_product_id = $wow_post_id;
            break;

        case 'PRO':
            $pro_map = [
                1 => (int)($wo['config']['wow_pro_package_id'] ?? 0),
                2 => (int)($wo['config']['wow_pro_package_id_2'] ?? 0),
                3 => (int)($wo['config']['wow_pro_package_id_3'] ?? 0),
                4 => (int)($wo['config']['wow_pro_package_id_4'] ?? 0),
            ];

            if (!isset($pro_map[$wow_post_id]) || $pro_map[$wow_post_id] <= 0) {
                throw new RuntimeException('Invalid PRO package mapping.');
            }

            $woo_product_id = $pro_map[$wow_post_id];
            $variation_id = $woo_product_id;
            break;

        case 'WALLET':
            $woo_product_id = (int)($wo['config']['wow_wallet_topup_id'] ?? 0);
            break;

        case 'DONATE':
            $woo_product_id = (int)($wo['config']['wow_crowdfund_id'] ?? 0);
            break;

        case 'PURCHASE':
        case 'SALE':
            $woo_product_id = $wow_post_id;
            break;

        default:
            throw new RuntimeException('Invalid transaction kind.');
    }

    if ($amount <= 0 || $woo_product_id <= 0 || !$kind || !$currency) {
        bzj_pgb_streams_log('invalid_payment_request', [
            'wow_user_id' => $wow_user_id,
            'wp_user_id' => $wp_user_id,
            'kind' => $kind,
            'wow_post_id' => $wow_post_id,
            'woo_product_id' => $woo_product_id,
            'amount' => $amount,
            'currency' => $currency,
        ]);
        throw new RuntimeException('Invalid payment request.');
    }

    /* Preserve the existing Streams payment ledger. */
    $wow_order_id = 'wow_' . bin2hex(random_bytes(16));
    $timestamp = time();

    $stmt = $db->prepare(
        "INSERT INTO Wo_Payment_Transactions
        (userid, amount, order_id, kind, currency_code)
        VALUES (?, ?, ?, ?, ?)"
    );

    if (!$stmt) {
        throw new RuntimeException('Unable to prepare Streams payment transaction.');
    }

    $ledger_kind = ($kind === 'PRODUCT') ? 'PURCHASE' : $kind;
    $stmt->bind_param('idsss', $wow_user_id, $amount, $wow_order_id, $ledger_kind, $currency);

    if (!$stmt->execute()) {
        throw new RuntimeException('Unable to record Streams payment transaction.');
    }

    $check = $db->prepare("SELECT order_id FROM Wo_Payment_Transactions WHERE order_id=? LIMIT 1");
    if (!$check) {
        throw new RuntimeException('Unable to verify Streams payment transaction.');
    }
    $check->bind_param('s', $wow_order_id);
    $check->execute();
    $check_result = $check->get_result();
    if (!$check_result || !$check_result->fetch_assoc()) {
        throw new RuntimeException('Streams payment transaction verification failed.');
    }

    /* Product transactions retain the existing product-owner SALE ledger. */
    if ($kind === 'PRODUCT' && $owner_id > 0) {
        $owner_kind = 'SALE';
        $owner_notes = 'Product Sale';
        $owner_stmt = $db->prepare(
            "INSERT INTO Wo_Payment_Transactions
            (userid, amount, order_id, kind, currency_code, notes)
            VALUES (?, ?, ?, ?, ?, ?)"
        );
        if (!$owner_stmt) {
            throw new RuntimeException('Unable to prepare product-owner transaction.');
        }
        $owner_stmt->bind_param('idssss', $owner_id, $amount, $wow_order_id, $owner_kind, $currency, $owner_notes);
        if (!$owner_stmt->execute()) {
            throw new RuntimeException('Unable to record product-owner transaction.');
        }
    }

    $token = bin2hex(random_bytes(32));
    $token_hash = hash('sha256', $token);

    $payload = [
        'wp_user_id' => $wp_user_id,
        'wow_user_id' => $wow_user_id,
        'product_id' => $woo_product_id,
        'variation_id' => $variation_id,
        'wow_post_id' => $wow_post_id,
        'product_owner_id' => $owner_id,
        'transaction_kind' => $kind,
        'currency' => $currency,
        'amount' => $amount,
        'product_price' => $product_price,
        'quantity' => $quantity,
        'product_name' => $product_name,
        'meta' => [
            'wow_post_id' => $wow_post_id,
            'transaction_kind' => $kind,
            'product_owner_id' => $owner_id,
            '_buzzjuice_origin' => 'streams',
            'wow_order_id' => $wow_order_id,
        ],
    ];

    /*
     * The bridge table is deliberately separate from Wo_Payment_Transactions:
     * it is an orchestration/handoff state machine, not the Streams ledger.
     */
    $schema = "CREATE TABLE IF NOT EXISTS `Wo_Payment_Gateway_Bridge` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `token_hash` CHAR(64) NOT NULL,
        `wow_order_id` VARCHAR(191) NOT NULL,
        `wow_user_id` BIGINT UNSIGNED NOT NULL,
        `wp_user_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
        `transaction_kind` VARCHAR(50) NOT NULL,
        `currency` VARCHAR(10) NOT NULL,
        `amount` DECIMAL(20,8) NOT NULL DEFAULT 0,
        `payload_json` LONGTEXT NOT NULL,
        `status` VARCHAR(30) NOT NULL DEFAULT 'ready',
        `woo_order_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
        `error_code` VARCHAR(100) NOT NULL DEFAULT '',
        `error_message` TEXT NULL,
        `created_at` DATETIME NOT NULL,
        `expires_at` DATETIME NOT NULL,
        `claimed_at` DATETIME NULL,
        `fulfilled_at` DATETIME NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uq_token_hash` (`token_hash`),
        UNIQUE KEY `uq_wow_order_id` (`wow_order_id`),
        KEY `idx_status_expires` (`status`,`expires_at`),
        KEY `idx_woo_order_id` (`woo_order_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

    if (!$db->query($schema)) {
        throw new RuntimeException('Unable to initialize payment bridge table.');
    }

    $secret = getenv('BUZZ_PGB_SECRET');
    if (!$secret && function_exists('bzj_get_sso_secret')) {
        $secret = hash('sha256', bzj_get_sso_secret() . '|payment-gateway');
    }
    if (!$secret) {
        throw new RuntimeException('Payment gateway secret is not configured.');
    }

    $ttl = max(60, (int)(getenv('BUZZ_PGB_HANDOFF_TTL') ?: 900));
    $created = gmdate('Y-m-d H:i:s');
    $expires = gmdate('Y-m-d H:i:s', time() + $ttl);
    $status = 'ready';
    $payload_json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

    $stmt = $db->prepare(
        "INSERT INTO `Wo_Payment_Gateway_Bridge`
        (token_hash,wow_order_id,wow_user_id,wp_user_id,transaction_kind,currency,amount,payload_json,status,created_at,expires_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)"
    );
    if (!$stmt) {
        throw new RuntimeException('Unable to prepare payment handoff.');
    }

    $stmt->bind_param(
        'ssiiisdssss',
        $token_hash,
        $wow_order_id,
        $wow_user_id,
        $wp_user_id,
        $kind,
        $currency,
        $amount,
        $payload_json,
        $status,
        $created,
        $expires
    );

    if (!$stmt->execute()) {
        throw new RuntimeException('Unable to store payment handoff.');
    }

    $base = defined('WP_BASE_SITE_URL') && WP_BASE_SITE_URL
        ? WP_BASE_SITE_URL
        : ($wo['config']['site_url'] ?? 'https://buzzjuice.net');
    $base = rtrim($base, '/');
    $signature = bzj_pgb_client_signature($token, $secret);
    $url = $base . '/pgb-checkout/?token=' . rawurlencode($token) . '&sig=' . rawurlencode($signature);

    bzj_pgb_streams_log('handoff_created', [
        'wow_order_id' => $wow_order_id,
        'wow_user_id' => $wow_user_id,
        'wp_user_id' => $wp_user_id,
        'kind' => $kind,
        'wow_post_id' => $wow_post_id,
        'woo_product_id' => $woo_product_id,
        'currency' => $currency,
        'amount' => $amount,
        'bridge_id' => $db->insert_id,
    ]);

    return [
        'status' => 200,
        'url' => $url,
        'wow_order_id' => $wow_order_id,
    ];
}
