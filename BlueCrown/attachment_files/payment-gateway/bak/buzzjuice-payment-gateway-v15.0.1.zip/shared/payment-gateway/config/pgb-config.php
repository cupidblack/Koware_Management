<?php
/**
 * Buzzjuice Payment Gateway configuration.
 *
 * No payment secrets are stored in this file.
 * Recommended .env variables:
 *
 * BUZZ_PGB_SECRET=<long-random-secret>
 * BUZZ_PGB_LOGGING=1
 * BUZZ_PGB_LOG_LEVEL=debug
 * BUZZ_PGB_HANDOFF_TTL=900
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('BZJ_PGB_VERSION')) {
    define('BZJ_PGB_VERSION', '15.0.1');
}

if (!defined('BZJ_PGB_ROOT')) {
    define('BZJ_PGB_ROOT', dirname(__DIR__));
}

if (!defined('BZJ_PGB_LOG_DIR')) {
    define('BZJ_PGB_LOG_DIR', BZJ_PGB_ROOT . '/log');
}

if (!defined('BZJ_PGB_HANDOFF_TTL')) {
    define('BZJ_PGB_HANDOFF_TTL', max(60, (int)(getenv('BUZZ_PGB_HANDOFF_TTL') ?: 900)));
}

if (!defined('BZJ_PGB_LOGGING')) {
    define('BZJ_PGB_LOGGING', in_array(strtolower((string)(getenv('BUZZ_PGB_LOGGING') ?: '1')), ['1','true','yes','on'], true));
}

if (!defined('BZJ_PGB_LOG_LEVEL')) {
    define('BZJ_PGB_LOG_LEVEL', strtolower((string)(getenv('BUZZ_PGB_LOG_LEVEL') ?: 'info')));
}

if (!defined('BZJ_PGB_SECRET')) {
    $secret = getenv('BUZZ_PGB_SECRET');
    if (!$secret && function_exists('bzj_get_sso_secret')) {
        $secret = hash('sha256', bzj_get_sso_secret() . '|payment-gateway');
    }
    define('BZJ_PGB_SECRET', (string)$secret);
}

if (!defined('BZJ_PGB_STREAMS_TABLE')) {
    define('BZJ_PGB_STREAMS_TABLE', 'Wo_Payment_Gateway_Bridge');
}

if (!defined('BZJ_PGB_ROUTE')) {
    define('BZJ_PGB_ROUTE', 'pgb-checkout');
}

if (!defined('BZJ_PGB_CLIENT_FILE')) {
    define('BZJ_PGB_CLIENT_FILE', BZJ_PGB_ROOT . '/pgb-client-streams.php');
}
