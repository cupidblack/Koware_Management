<?php
if (!defined('ABSPATH')) exit;

/**
 * Jewel Affiliate integration.
 *
 * Reuses the established Streams business-rule implementation instead of
 * duplicating the rebate formula. The existing function is:
 *   jewel_affiliate_process(array $data, mysqli $db)
 *
 * It performs its own rebate idempotency and WP-role synchronization.
 */
add_filter('bzj_pgb_fulfillment_callbacks', function($callbacks) {
    $callbacks['jewel-affiliate'] = function($order, $logger) {
        if ($order->get_meta('_bzj_jewel_processed', true)) {
            return;
        }

        $wow_user_id = absint($order->get_meta('wow_user_id', true));
        if (!$wow_user_id) {
            $logger->log(__FILE__, 'Jewel skipped: missing WoWonder user ID', [
                'order_id' => $order->get_id(),
            ], BZJ_PGB_Logger::WARNING);
            return;
        }

        $wow_db = function_exists('get_wowonder_db') ? get_wowonder_db() : false;
        if (!$wow_db) {
            $logger->log(__FILE__, 'Jewel skipped: WoWonder DB unavailable', [
                'order_id' => $order->get_id(),
            ], BZJ_PGB_Logger::ERROR);
            return;
        }

        $jewel_file = trailingslashit(ABSPATH) . 'streams/jewel-affiliate-webhook.php';

        if (!is_readable($jewel_file)) {
            $logger->log(__FILE__, 'Jewel implementation file unavailable', [
                'path' => $jewel_file,
                'order_id' => $order->get_id(),
            ], BZJ_PGB_Logger::ERROR);
            return;
        }

        require_once $jewel_file;

        if (!function_exists('jewel_affiliate_process')) {
            $logger->log(__FILE__, 'jewel_affiliate_process() unavailable', [
                'order_id' => $order->get_id(),
            ], BZJ_PGB_Logger::ERROR);
            return;
        }

        $billing = [
            'email' => $order->get_billing_email(),
            'first_name' => $order->get_billing_first_name(),
            'last_name' => $order->get_billing_last_name(),
        ];

        $items = [];
        foreach ($order->get_items('line_item') as $item) {
            $product = $item->get_product();
            $items[] = [
                'product_id' => $item->get_product_id(),
                'variation_id' => $item->get_variation_id(),
                'quantity' => $item->get_quantity(),
                'total' => $item->get_total(),
                'subtotal' => $item->get_subtotal(),
                'sku' => $product ? $product->get_sku() : '',
            ];
        }

        $payload = [
            'id' => $order->get_id(),
            'number' => $order->get_order_number(),
            'status' => $order->get_status(),
            'currency' => $order->get_currency(),
            'total' => $order->get_total(),
            'billing' => $billing,
            'line_items' => $items,
        ];

        /*
         * jewel_affiliate_process() explicitly requires status "completed".
         * The fulfillment engine also runs on processing, so the Jewel
         * adapter only dispatches when WooCommerce has reached completed.
         */
        if ($order->get_status() !== 'completed') {
            $logger->log(__FILE__, 'Jewel waiting for completed status', [
                'order_id' => $order->get_id(),
                'status' => $order->get_status(),
            ]);
            return;
        }

        jewel_affiliate_process($payload, $wow_db);

        $order->update_meta_data('_bzj_jewel_processed', gmdate('c'));
        $order->save();

        $logger->log(__FILE__, 'Jewel affiliate processing completed', [
            'order_id' => $order->get_id(),
            'wow_user_id' => $wow_user_id,
        ]);
    };

    return $callbacks;
});
