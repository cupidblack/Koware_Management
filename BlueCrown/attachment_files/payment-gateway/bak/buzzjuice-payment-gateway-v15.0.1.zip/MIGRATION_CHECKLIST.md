# Buzzjuice PGB v15 migration checklist

## Before deployment
- [ ] Database backup of Streams and WordPress.
- [ ] Backup `wow-pgb_init.php`, `wow-pgb_sync.php`, `buzzjuice-affwp-order-complete.php`.
- [ ] Confirm WooCommerce and WooCommerce Subscriptions are active.
- [ ] Confirm HPOS status and do not use direct WooCommerce order SQL.
- [ ] Confirm `.env` contains `BUZZ_PGB_SECRET`.
- [ ] Confirm WordPress can read `shared/payment-gateway`.
- [ ] Confirm Streams can read `shared/payment-gateway` and `shared/db_helpers.php`.

## First deployment
- [ ] Install only `bzj-payment-gateway.php` under `wp-content/mu-plugins`.
- [ ] Install the `shared/payment-gateway` tree.
- [ ] Replace Streams `wow-pgb_init.php`.
- [ ] Make `buzzjuice-affwp-order-complete.php` inert.
- [ ] Keep `wow-pgb_sync.php` available for AffiliateWP compatibility during phase 1.
- [ ] Keep `wow-pgb_webhook.php` but return HTTP 410.
- [ ] Test `/pgb-checkout/` through a browser.

## Transaction tests
- [ ] PRODUCT/PURCHASE
- [ ] PRO package 1
- [ ] PRO package 2
- [ ] PRO package 3
- [ ] PRO package 4
- [ ] WALLET
- [ ] DONATE/CROWDFUND
- [ ] Market purchase
- [ ] Currency equal to store currency
- [ ] Currency requiring WOOCS conversion
- [ ] Failed payment
- [ ] Refresh thank-you page
- [ ] Re-open order-pay URL
- [ ] Duplicate completion hook
- [ ] Expired handoff

## Post-payment verification
- [ ] WooCommerce status becomes processing/completed.
- [ ] Streams bridge row becomes fulfilled.
- [ ] Existing Wo_Payment_Transactions row remains intact.
- [ ] Subscription is active when appropriate.
- [ ] AffiliateWP referral is created once.
- [ ] Jewel rebate is created once.
- [ ] Streams user role/pro status is updated by the migrated fulfillment logic.
- [ ] WooCommerce thank-you page remains normal.

## v15.0.1 hotfix
Fix MU root path and restore Streams wow_post_id-to-WooCommerce product mapping.
