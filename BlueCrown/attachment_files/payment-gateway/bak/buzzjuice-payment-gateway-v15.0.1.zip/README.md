# Buzzjuice Payment Gateway Bridge v15.0.1

This patch release fixes two v15 initialization defects discovered during first production testing:

1. WordPress MU-plugin root resolution now uses `ABSPATH . 'shared/payment-gateway'` instead of `dirname(ABSPATH)`, matching the Buzzjuice project layout.
2. Streams preserves the existing WoWonder payment request contract: the browser sends `wow_post_id`; the client maps PRO package IDs, wallet and donation mappings to the configured WooCommerce product IDs. It no longer incorrectly requires a client-supplied `product_id`.
3. Streams again records and verifies the existing `Wo_Payment_Transactions` ledger entry before creating the bridge handoff.
4. The Jewel integration path now resolves from `ABSPATH` as well.

No WooCommerce REST/cURL request is used by the new handoff.

## Deployment

Replace the v15 files with this package, then clear PHP/opcache if enabled. Test one PRO payment first. Check:

- `streams/assets/wow-pgb/log/pgb-client-streams.log`
- `shared/payment-gateway/log/class-pgb-bootstrap.log`
- `shared/payment-gateway/log/class-pgb-hooks.log`
- WordPress `debug.log`

The expected first successful sequence is:

`Streams AJAX 200 -> /pgb-checkout/?token=...&sig=... -> WooCommerce order created -> /checkout/order-pay/...`
