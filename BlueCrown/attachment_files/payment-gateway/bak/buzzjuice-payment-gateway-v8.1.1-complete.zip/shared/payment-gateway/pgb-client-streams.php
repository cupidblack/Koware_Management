<?php
/** Buzzjuice Streams-side Payment Gateway Bridge client. */
if (!function_exists('pgb_streams_create_pending')) {
function pgb_streams_create_pending(array $input, array $wo, $sqlConnect) {
    if (empty($wo['loggedin']) || empty($wo['user']['user_id'])) return ['status'=>401,'message'=>'Authentication required.'];
    if (!$sqlConnect || !method_exists($sqlConnect,'prepare')) return ['status'=>500,'message'=>'Payment database unavailable.'];
    $userid=(int)$wo['user']['user_id'];
    $kind=strtoupper(preg_replace('/[^A-Z_]/','',(string)($input['transaction_kind']??'')));
    if ($kind==='PRODUCT') $kind='PURCHASE';
    $allowed=['PRO','WALLET','DONATE','PURCHASE']; if(!in_array($kind,$allowed,true))return ['status'=>400,'message'=>'Invalid transaction type.'];
    $price=(float)($input['product_price']??$input['amount']??0); $qty=max(1,(int)($input['product_units']??1)); $amount=round($price*$qty,2);
    if($price<=0 || $amount<=0)return ['status'=>400,'message'=>'Invalid amount.'];
    $currency=strtoupper(preg_replace('/[^A-Z]/','',(string)($input['wow_currency_code']??$wo['config']['currency']??'GHS'))); if(strlen($currency)!==3)return ['status'=>400,'message'=>'Invalid currency.'];
    $secret=getenv('BUZZ_PGB_SECRET'); if(!$secret && defined('BUZZ_PGB_SECRET'))$secret=BUZZ_PGB_SECRET; if(!$secret)return ['status'=>500,'message'=>'Payment bridge secret is not configured.'];
    $wow_order_id='wow_'.bin2hex(random_bytes(16));
    $notes=wp_json_encode(['version'=>'8.1.1','product_name'=>sanitize_text_field((string)($input['product_name']??'')),'product_price'=>$price,'product_units'=>$qty,'product_owner_id'=>(int)($input['product_owner_id']??0),'wow_post_id'=>(int)($input['wow_post_id']??0),'address_id'=>(int)($input['address_id']??0),'pro_type'=>(int)($input['pro_type']??$input['wow_post_id']??0)]);
    $stmt=$sqlConnect->prepare("INSERT INTO Wo_Payment_Transactions (userid,amount,order_id,kind,currency_code,payment_status,notes,transaction_dt) VALUES (?,?,?,?,?,?,?,NOW())");
    if(!$stmt)return ['status'=>500,'message'=>'Could not prepare payment transaction.'];
    $status='pending'; $stmt->bind_param('idsssss',$userid,$amount,$wow_order_id,$kind,$currency,$status,$notes);
    if(!$stmt->execute()){ $stmt->close();return ['status'=>500,'message'=>'Could not store payment transaction.']; } $stmt->close();
    $base=rtrim((string)(getenv('WP_BASE_SITE_URL')?:($wo['config']['wow_store_url']??'')),'/'); if(!$base)return ['status'=>500,'message'=>'WordPress store URL is not configured.'];
    $token=hash_hmac('sha256',$wow_order_id,$secret); $url=$base.'/wp-json/bzj-pgb/v1/checkout?order='.rawurlencode($wow_order_id).'&token='.rawurlencode($token);
    return ['status'=>200,'url'=>$url,'wow_order_id'=>$wow_order_id];
}}
