# v8.1.1 deployment

1. Back up the Streams and WordPress databases.
2. Extract this archive preserving its directory tree.
3. Confirm `shared/payment-gateway/core/class-pgb-manager.php` exists on disk.
4. Confirm `wp-content/mu-plugins/bzj-pgb-engine.php` exists.
5. Configure `BUZZ_PGB_SECRET` identically for Streams PHP and WordPress PHP.
6. Apply `docs/schema.sql`, skipping columns that already exist.
7. Set Woo product IDs in WordPress options: `bzj_pgb_product_wow_market_id`, `bzj_pgb_product_wow_pro_package_id_1` etc.
8. Update `streams/requests.php` using the supplied PGB replacement handler.
9. Test the checkout URL in a browser. It should immediately redirect from the REST endpoint to WooCommerce payment.
10. Check WordPress error log. There should be no `Missing core file` messages.
11. Enable detailed PGB logging only during controlled testing.
