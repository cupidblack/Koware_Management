<?php
/**
 * Buzzjuice Streams Payment Gateway Bridge v10 client.
 * No WordPress bootstrap is loaded.
 */
require_once dirname(__DIR__,2).'/config.php';
require_once dirname(__DIR__).'/init.php';
require_once dirname(__DIR__,3).'/shared/payment-gateway/pgb-client-streams.php';
