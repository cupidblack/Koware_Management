<?php
/**
 * DEPRECATED webhook endpoint.
 * v10 no longer requires Streams -> WooCommerce server-to-server webhook delivery.
 */
http_response_code(410);
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['status'=>'deprecated','message'=>'Use the Buzzjuice Payment Gateway Bridge v10 checkout flow.']);
exit;
