<?php
if (!defined('ABSPATH')) exit;

class PGB_Logger {
    const DEBUG='debug', INFO='info', WARNING='warning', ERROR='error', CRITICAL='critical';
    private $dir, $enabled, $min, $handles=[];
    private $rank=[self::DEBUG=>0,self::INFO=>1,self::WARNING=>2,self::ERROR=>3,self::CRITICAL=>4];

    public function __construct(array $config=[]) {
        $this->dir = dirname(__DIR__) . '/log/';
        $this->enabled = array_key_exists('logging_enabled',$config) ? (bool)$config['logging_enabled'] : true;
        $this->min = $config['log_level'] ?? self::INFO;
        if (!is_dir($this->dir)) @mkdir($this->dir,0750,true);
    }
    public function enabled(){ return $this->enabled; }
    public function log($message,$level=self::INFO,$context=[],$source_file=null) {
        if (!$this->enabled || ($this->rank[$level]??0) < ($this->rank[$this->min]??1)) return;
        $source = $source_file ? pathinfo(str_replace('\\','/',$source_file),PATHINFO_FILENAME) : 'unknown';
        $context=$this->redact($context);
        $line=sprintf("[%s] [%s] %s%s\n",gmdate('Y-m-d H:i:s'),strtoupper($level),$message,
            $context ? ' | '.wp_json_encode($context,JSON_UNESCAPED_SLASHES) : '');
        $path=$this->dir.$source.'.log';
        if (file_exists($path) && filesize($path)>10*1024*1024) @rename($path,$path.'.'.gmdate('YmdHis'));
        @file_put_contents($path,$line,FILE_APPEND|LOCK_EX);
        if (in_array($level,[self::ERROR,self::CRITICAL],true)) error_log('[PGB] '.$source.': '.$message);
    }
    private function redact($data) {
        if (!is_array($data)) return $data;
        foreach ($data as $k=>$v) {
            $lk=strtolower((string)$k);
            if (preg_match('/secret|password|token|authorization|consumer_key|consumer_secret|api_key|api_secret|card|cvv|private_key/i',$lk)) $data[$k]='[REDACTED]';
            elseif (is_array($v)) $data[$k]=$this->redact($v);
        }
        return $data;
    }
    public function cleanup($days=90) {
        foreach (glob($this->dir.'*.log.*') ?: [] as $file) if (filemtime($file)<time()-$days*86400) @unlink($file);
    }
}
