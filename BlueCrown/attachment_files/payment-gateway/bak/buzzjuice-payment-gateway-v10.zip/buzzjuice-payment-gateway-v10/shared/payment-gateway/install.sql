CREATE TABLE IF NOT EXISTS wp_pgb_transactions (...); -- install through PGB_Schema/dbDelta, not manually.
