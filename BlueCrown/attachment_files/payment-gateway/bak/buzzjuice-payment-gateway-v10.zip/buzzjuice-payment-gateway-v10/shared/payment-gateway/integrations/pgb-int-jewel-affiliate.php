<?php
if (!defined('ABSPATH')) exit;

/**
 * Safe Jewel integration adapter.
 * It does not invent a rebate rule. If the existing Jewel service exposes a
 * callable integration hook, this addon emits pgb_jewel_payment_complete for it.
 */
add_action('pgb_wc_payment_complete',function($order_id,$order,$tx,$bridge){
    $bridge->logger()->log('Jewel payment-complete integration event',PGB_Logger::DEBUG,['order_id'=>$order_id],__FILE__);
    do_action('pgb_jewel_payment_complete',$order_id,$order,$tx,$bridge);
},40,4);
