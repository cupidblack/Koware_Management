/* Optional client helper. Server response remains authoritative. */
(function(window){
  'use strict';
  window.BuzzjuicePGB = window.BuzzjuicePGB || {
    redirect: function(url){
      if(typeof url !== 'string' || !/^https?:\/\//i.test(url)) return false;
      window.location.assign(url);
      return true;
    }
  };
})(window);
