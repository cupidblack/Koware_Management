<?php
if (!defined('ABSPATH')) exit;

class PGB_Auth {
    const ALGO='sha256';
    private $logger;
    public function __construct($logger){$this->logger=$logger;}
    public function secret() {
        $s=getenv('BZJ_PGB_SECRET');
        if (!$s && defined('BZJ_PGB_SECRET')) $s=BZJ_PGB_SECRET;
        if (!$s) $this->logger->log('PGB shared secret is missing',PGB_Logger::CRITICAL,[],__FILE__);
        return $s ?: null;
    }
    public function sign($timestamp,$request_id,$body) {
        $s=$this->secret(); if(!$s) return null;
        return base64_encode(hash_hmac(self::ALGO,$timestamp."\n".$request_id."\n".$body,$s,true));
    }
    public function verify($timestamp,$request_id,$body,$signature,$tolerance=300) {
        if(!$this->secret() || !ctype_digit((string)$timestamp) || abs(time()-(int)$timestamp)>$tolerance || !$signature) return false;
        $expected=$this->sign($timestamp,$request_id,$body);
        return $expected && hash_equals($expected,$signature);
    }
}
