<?php
if (!defined('ABSPATH')) exit;

add_action('pgb_wc_payment_complete',function($order_id,$order,$tx,$bridge){
    if(!$order || !class_exists('WC_Subscriptions_Product') || !function_exists('wcs_create_subscription')) return;
    if($order->get_meta('_pgb_subscription_id',true)) return;
    $is_sub=false;
    foreach($order->get_items('line_item') as $item){
        $p=$item->get_product();
        if($p && WC_Subscriptions_Product::is_subscription($p->get_id())){$is_sub=true;break;}
    }
    if(!$is_sub) return;
    $log=$bridge->logger();
    try {
        $period=sanitize_key((string)$order->get_meta('_subscription_period',true));
        $interval=max(1,(int)$order->get_meta('_subscription_interval',true));
        if(!in_array($period,['day','week','month','year'],true)) $period='month';
        $sub=wcs_get_subscriptions_for_order($order_id,['order_type'=>'parent']);
        if($sub){$id=(int)array_key_first($sub);$order->update_meta_data('_pgb_subscription_id',$id);$order->save();return;}
        $subscription=wcs_create_subscription([
            'order_id'=>$order_id,'customer_id'=>$order->get_customer_id(),
            'start_date'=>current_time('mysql'),'billing_period'=>$period,'billing_interval'=>$interval,
            'status'=>'pending'
        ]);
        if(is_wp_error($subscription)) throw new Exception($subscription->get_error_message());
        foreach($order->get_items('line_item') as $item){
            $product=$item->get_product(); if(!$product)continue;
            $subscription->add_product($product,$item->get_quantity(),['subtotal'=>$item->get_subtotal(),'total'=>$item->get_total()]);
        }
        $subscription->calculate_totals(false);
        $subscription->update_meta_data('_buzzjuice_wow_user_id',(int)$order->get_meta('wow_user_id',true));
        $subscription->update_meta_data('_buzzjuice_parent_order_id',$order_id);
        $subscription->save();
        $subscription->update_status('active');
        $order->update_meta_data('_pgb_subscription_id',$subscription->get_id());$order->save();
        $bridge->manager()->mark_addon($order_id,'subscriptions','complete',['subscription_id'=>$subscription->get_id()]);
        $log->log('Subscription created and activated',PGB_Logger::INFO,['order_id'=>$order_id,'subscription_id'=>$subscription->get_id()],__FILE__);
        do_action('pgb_subscription_created',$subscription->get_id(),$order_id,$tx);
    } catch(Throwable $e){
        $bridge->manager()->mark_addon($order_id,'subscriptions','error',null,$e->getMessage());
        $log->log('Subscription processing failed',PGB_Logger::ERROR,['order_id'=>$order_id,'error'=>$e->getMessage()],__FILE__);
    }
},30,4);
