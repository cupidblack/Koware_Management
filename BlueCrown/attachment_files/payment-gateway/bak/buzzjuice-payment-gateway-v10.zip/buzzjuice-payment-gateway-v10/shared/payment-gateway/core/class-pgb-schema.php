<?php
if (!defined('ABSPATH')) exit;

class PGB_Schema {
    private $db,$prefix,$logger;
    public function __construct($logger){global $wpdb;$this->db=$wpdb;$this->prefix=$wpdb->prefix;$this->logger=$logger;}
    public function install(){
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $t=$this->prefix.'pgb_transactions';
        $f=$this->prefix.'pgb_fulfillment';
        $charset=$this->db->get_charset_collate();
        dbDelta("CREATE TABLE $t (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            request_id varchar(191) NOT NULL,
            wow_order_id varchar(191) NOT NULL,
            wow_user_id bigint(20) unsigned NOT NULL,
            woo_order_id bigint(20) unsigned NULL,
            wp_user_id bigint(20) unsigned NULL,
            transaction_kind varchar(50) NOT NULL,
            status varchar(40) NOT NULL DEFAULT 'initiated',
            fulfillment_status varchar(40) NOT NULL DEFAULT 'pending',
            amount decimal(20,6) NOT NULL DEFAULT 0,
            currency varchar(3) NOT NULL,
            payload longtext NULL,
            last_error text NULL,
            attempts int(11) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            paid_at datetime NULL,
            fulfilled_at datetime NULL,
            PRIMARY KEY(id),
            UNIQUE KEY request_id(request_id),
            UNIQUE KEY wow_order_id(wow_order_id),
            KEY woo_order_id(woo_order_id),
            KEY status(status),
            KEY wow_user_id(wow_user_id)
        ) $charset;");
        dbDelta("CREATE TABLE $f (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            woo_order_id bigint(20) unsigned NOT NULL,
            addon_name varchar(191) NOT NULL,
            addon_status varchar(40) NOT NULL DEFAULT 'pending',
            addon_response longtext NULL,
            error_message text NULL,
            retry_count int(11) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            completed_at datetime NULL,
            PRIMARY KEY(id),
            UNIQUE KEY order_addon(woo_order_id,addon_name),
            KEY addon_status(addon_status)
        ) $charset;");
    }
}
