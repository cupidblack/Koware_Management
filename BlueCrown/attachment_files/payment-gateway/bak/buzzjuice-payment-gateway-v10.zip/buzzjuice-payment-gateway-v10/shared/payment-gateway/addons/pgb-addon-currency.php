<?php
/**
 * Currency addon is intentionally non-mutating after order creation.
 * The Streams transaction currency is authoritative; WooCommerce order
 * currency is set from that value. This avoids changing a paid amount.
 */
if (!defined('ABSPATH')) exit;
add_action('pgb_payment_confirmed',function($order_id,$order,$tx,$bridge){
    $bridge->logger()->log('Currency recorded for paid order',PGB_Logger::DEBUG,[
        'order_id'=>$order_id,'currency'=>$order->get_currency(),'amount'=>$order->get_total()
    ],__FILE__);
},10,4);
