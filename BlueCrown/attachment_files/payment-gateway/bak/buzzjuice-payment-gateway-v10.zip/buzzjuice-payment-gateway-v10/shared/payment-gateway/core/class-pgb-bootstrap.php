<?php
if (!defined('ABSPATH')) exit;

class PGB_Bootstrap {
    private static $instance;
    private $config,$logger,$validator,$auth,$manager,$schema;
    public static function instance(){return self::$instance ?: self::$instance=new self();}
    private function __construct(){
        $this->config=get_pgb_config();
        $this->logger=new PGB_Logger($this->config);
        $this->validator=new PGB_Validator();
        $this->auth=new PGB_Auth($this->logger);
        $this->schema=new PGB_Schema($this->logger);
        $this->manager=new PGB_Manager($this->logger,$this->validator,$this->auth,$this->config);
        $this->load_modules();
        add_action('woocommerce_payment_complete',[$this,'payment_complete'],20,1);
        add_action('woocommerce_order_status_processing',[$this,'status_processing'],20,1);
        add_action('woocommerce_order_status_completed',[$this,'status_completed'],20,1);
    }
    public function install(){ $this->schema->install(); }
    private function load_modules(){
        $base=dirname(__DIR__);
        foreach(glob($base.'/addons/pgb-addon-*.php')?:[] as $f) require_once $f;
        foreach(glob($base.'/integrations/pgb-int-*.php')?:[] as $f) require_once $f;
    }
    public function payment_complete($order_id){$this->process_paid((int)$order_id,'payment_complete');}
    public function status_processing($order_id){$this->process_paid((int)$order_id,'processing');}
    public function status_completed($order_id){$this->process_paid((int)$order_id,'completed');}
    private function process_paid($order_id,$event){
        $order=wc_get_order($order_id); if(!$order)return;
        if($order->get_meta('_buzzjuice_origin',true)!=='streams')return;
        $wow_order_id=(string)$order->get_meta('wow_order_id',true);
        if(!$wow_order_id)return;
        $tx=$this->manager->transaction($wow_order_id);
        if(!$tx)return;
        $this->logger->log('Paid lifecycle event',PGB_Logger::INFO,['order_id'=>$order_id,'event'=>$event],__FILE__);
        $this->manager->update_status($wow_order_id,'paid',$order_id);
        do_action('pgb_payment_confirmed',$order_id,$order,$tx,$this);
        do_action('pgb_wc_payment_complete',$order_id,$order,$tx,$this);
        do_action('pgb_fulfill',$order_id,$order,$tx,$this);
    }
    public function logger(){return $this->logger;}
    public function manager(){return $this->manager;}
    public function auth(){return $this->auth;}
    public function validator(){return $this->validator;}
    public function config(){return $this->config;}
}
