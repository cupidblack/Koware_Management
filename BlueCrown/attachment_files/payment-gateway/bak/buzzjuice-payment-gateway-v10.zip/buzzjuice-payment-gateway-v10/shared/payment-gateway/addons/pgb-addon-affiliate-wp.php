<?php
if (!defined('ABSPATH')) exit;

add_action('pgb_wc_payment_complete',function($order_id,$order,$tx,$bridge){
    $log=$bridge->logger(); $name='affiliate-wp';
    if(!$order || $order->get_meta('_affwp_bridge_processed',true)) return;
    if(!function_exists('affwp_add_customer') || !function_exists('affwp_add_referral')) {
        $log->log('AffiliateWP public API unavailable',PGB_Logger::WARNING,[],__FILE__);
        return;
    }
    try {
        $wp_id=(int)$order->get_customer_id(); $email=$order->get_billing_email();
        if(!$wp_id || !$email) throw new Exception('Affiliate customer identity unavailable.');
        global $wpdb;
        $customer=(int)$wpdb->get_var($wpdb->prepare("SELECT customer_id FROM {$wpdb->prefix}affiliate_wp_customers WHERE user_id=%d",$wp_id));
        if(!$customer) $customer=(int)$wpdb->get_var($wpdb->prepare("SELECT customer_id FROM {$wpdb->prefix}affiliate_wp_customers WHERE email=%s",$email));
        if(!$customer){
            $customer=affwp_add_customer(['user_id'=>$wp_id,'email'=>$email]);
            if(is_wp_error($customer)) throw new Exception($customer->get_error_message());
            $customer=(int)$customer;
        }
        if(!$customer) throw new Exception('Unable to resolve AffiliateWP customer.');

        $affiliate=0;
        $lc=$wpdb->get_var($wpdb->prepare("SELECT affiliate_id FROM {$wpdb->prefix}affiliate_wp_lifetime_customers WHERE affwp_customer_id=%d ORDER BY lifetime_customer_id DESC LIMIT 1",$customer));
        if($lc)$affiliate=(int)$lc;
        if(!$affiliate){
            $snapshot=json_decode((string)$order->get_meta('_buzzjuice_affwp_context_snapshot',true),true)?:[];
            $visit=(int)($snapshot['affwp_visit_id']??0);
            if($visit)$affiliate=(int)$wpdb->get_var($wpdb->prepare("SELECT affiliate_id FROM {$wpdb->prefix}affiliate_wp_visits WHERE visit_id=%d",$visit));
        }
        if(!$affiliate){
            $affiliate=(int)$wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->prefix}affiliate_wp_customermeta WHERE affwp_customer_id=%d AND meta_key='affiliate_id' LIMIT 1",$customer));
        }
        if(!$affiliate) return;

        $reference=(string)$order_id;
        $exists=(int)$wpdb->get_var($wpdb->prepare("SELECT referral_id FROM {$wpdb->prefix}affiliate_wp_referrals WHERE reference=%s AND context='woocommerce' AND affiliate_id=%d LIMIT 1",$reference,$affiliate));
        if($exists){$order->update_meta_data('_affwp_bridge_processed',current_time('mysql'));$order->save();return;}

        $amount=(float)$order->get_total();
        $rate=function_exists('affwp_get_affiliate_rate')?(float)affwp_get_affiliate_rate($affiliate):0;
        $rate_type=function_exists('affwp_get_affiliate_rate_type')?affwp_get_affiliate_rate_type($affiliate):'percentage';
        $commission=$rate_type==='flat'?$rate:round($amount*($rate/100),4);
        if($commission<=0){$order->update_meta_data('_affwp_bridge_processed',current_time('mysql'));$order->save();return;}

        $ref=affwp_add_referral([
            'affiliate_id'=>$affiliate,'amount'=>$commission,'description'=>'Buzzjuice Streams order #'.$order_id,
            'reference'=>$reference,'context'=>'woocommerce','customer_id'=>$customer,
            'status'=>'unpaid','currency'=>$order->get_currency(),
            'products'=>wp_json_encode(array_map(function($i){return $i->get_name();},array_values($order->get_items())))
        ]);
        if(is_wp_error($ref) || !$ref) throw new Exception('AffiliateWP referral creation failed.');
        $order->update_meta_data('_affwp_bridge_processed',current_time('mysql'));
        $order->update_meta_data('_affwp_bridge_referral_id',(int)$ref);
        $order->save();
        $bridge->manager()->mark_addon($order_id,$name,'complete',['referral_id'=>(int)$ref,'affiliate_id'=>$affiliate,'commission'=>$commission]);
        $log->log('AffiliateWP referral created',PGB_Logger::INFO,['order_id'=>$order_id,'referral_id'=>(int)$ref,'commission'=>$commission],__FILE__);
    } catch(Throwable $e) {
        $bridge->manager()->mark_addon($order_id,$name,'error',null,$e->getMessage());
        $log->log('AffiliateWP processing failed',PGB_Logger::ERROR,['order_id'=>$order_id,'error'=>$e->getMessage()],__FILE__);
    }
},20,4);
