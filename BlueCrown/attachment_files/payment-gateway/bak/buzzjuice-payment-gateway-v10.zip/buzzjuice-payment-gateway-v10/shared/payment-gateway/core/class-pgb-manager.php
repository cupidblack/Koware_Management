<?php
if (!defined('ABSPATH')) exit;

class PGB_Manager {
    private $logger,$validator,$auth,$config,$db;
    public function __construct($logger,$validator,$auth,$config){
        global $wpdb;$this->logger=$logger;$this->validator=$validator;$this->auth=$auth;$this->config=$config;$this->db=$wpdb;
    }
    public function table(){return $this->db->prefix.$this->config['transaction_table'];}
    public function fulfillment_table(){return $this->db->prefix.$this->config['fulfillment_table'];}
    public function transaction($wow_order_id){
        return $this->db->get_row($this->db->prepare("SELECT * FROM {$this->table()} WHERE wow_order_id=%s",$wow_order_id),ARRAY_A);
    }
    public function upsert($data){
        $now=current_time('mysql',true);
        $existing=$this->transaction($data['wow_order_id']);
        $row=[
            'request_id'=>$data['request_id'],'wow_order_id'=>$data['wow_order_id'],
            'wow_user_id'=>(int)$data['wow_user_id'],'woo_order_id'=>!empty($data['woo_order_id'])?(int)$data['woo_order_id']:null,
            'wp_user_id'=>!empty($data['wp_user_id'])?(int)$data['wp_user_id']:null,
            'transaction_kind'=>$data['transaction_kind'],'status'=>$data['status']??'initiated',
            'fulfillment_status'=>$data['fulfillment_status']??'pending','amount'=>(float)$data['amount'],
            'currency'=>$data['currency'],'payload'=>isset($data['payload'])?wp_json_encode($data['payload']):null,
            'updated_at'=>$now
        ];
        if($existing) return $this->db->update($this->table(),$row,['id'=>$existing['id']])!==false;
        $row['created_at']=$now;
        return $this->db->insert($this->table(),$row)!==false;
    }
    public function update_status($wow_order_id,$status,$woo_order_id=null,$error=null){
        $row=['status'=>$status,'updated_at'=>current_time('mysql',true)];
        if($woo_order_id!==null)$row['woo_order_id']=(int)$woo_order_id;
        if($error!==null)$row['last_error']=$error;
        if($status==='paid')$row['paid_at']=current_time('mysql',true);
        if($status==='fulfilled'){$row['fulfilled_at']=current_time('mysql',true);$row['fulfillment_status']='complete';}
        return $this->db->update($this->table(),$row,['wow_order_id'=>$wow_order_id])!==false;
    }
    public function mark_addon($order_id,$name,$status,$response=null,$error=null){
        $now=current_time('mysql',true);
        $data=['woo_order_id'=>(int)$order_id,'addon_name'=>$name,'addon_status'=>$status,'addon_response'=>$response?wp_json_encode($response):null,'error_message'=>$error,'completed_at'=>in_array($status,['complete','success'],true)?$now:null,'created_at'=>$now];
        return $this->db->replace($this->fulfillment_table(),$data)!==false;
    }
    public function create_wc_order(array $tx){
        if(!function_exists('wc_create_order')) return new WP_Error('pgb_wc_missing','WooCommerce is not loaded.');
        $existing=!empty($tx['woo_order_id'])?wc_get_order((int)$tx['woo_order_id']):false;
        if($existing) return $existing;
        $payload=json_decode($tx['payload']??'[]',true) ?: [];
        $order=wc_create_order(['customer_id'=>(int)($tx['wp_user_id']??0)]);
        if(is_wp_error($order)) return $order;
        $order->set_currency($tx['currency']);
        $items=$payload['line_items']??[];
        foreach($items as $item){
            $product=wc_get_product((int)($item['product_id']??0));
            if(!$product) throw new Exception('Mapped WooCommerce product not found: '.(int)($item['product_id']??0));
            $qty=max(1,(int)($item['quantity']??1));
            $item_id=$order->add_product($product,$qty);
            if(!$item_id) throw new Exception('Unable to add WooCommerce product to order.');
            $line=$order->get_item($item_id);
            if(isset($item['price']) && function_exists('wc_format_decimal')){
                $line->set_subtotal(wc_format_decimal($item['price']*$qty,6));
                $line->set_total(wc_format_decimal($item['total']??($item['price']*$qty),6));
                $line->save();
            }
        }
        $meta=$payload['meta_data']??[];
        $meta[]=['key'=>'_buzzjuice_origin','value'=>'streams'];
        $meta[]=['key'=>'wow_user_id','value'=>(int)$tx['wow_user_id']];
        $meta[]=['key'=>'wow_order_id','value'=>$tx['wow_order_id']];
        $meta[]=['key'=>'_pgb_request_id','value'=>$tx['request_id']];
        foreach($meta as $m) if(isset($m['key'])) $order->update_meta_data(sanitize_key($m['key']),$m['value']??'');
        $order->calculate_totals(false);
        $order->set_status('pending');
        $order->save();
        $url=$order->get_checkout_payment_url(false);
        $order->update_meta_data('_pgb_payment_url',$url);$order->save();
        $this->update_status($tx['wow_order_id'],'checkout_ready',$order->get_id());
        return $order;
    }
}
