# Buzzjuice Payment Gateway Bridge v10

This package replaces server-side Streams → same-host WooCommerce REST/cURL order creation with a database-first handoff.

## Runtime architecture

Streams:
1. authenticate the WoWonder user;
2. validate the submitted payment request;
3. write a durable `Wo_Payment_Transactions` record;
4. sign a short-lived browser handoff URL;
5. redirect the browser to `/pgb-checkout/`.

WordPress/MU plugin:
1. validates the HMAC handoff;
2. reads the durable transaction;
3. creates the WooCommerce order natively with `wc_create_order()`;
4. obtains the official WooCommerce payment URL from `WC_Order::get_checkout_payment_url()`;
5. redirects the browser to WooCommerce;
6. waits for WooCommerce's payment lifecycle;
7. runs addons/integrations idempotently.

WooCommerce documents `wc_create_order()` as the native programmatic order creator and `WC_Order::get_checkout_payment_url()` as the method for generating the unpaid-order payment URL.

## Important

The Streams side does not load `wp-load.php` and contains no WordPress API calls.

The only file under `wp-content/mu-plugins/` is `pgb-mu-plugin.php`.

Secrets:
- set `BZJ_PGB_SECRET` in the PHP/server environment;
- do not store it in Streams settings, WordPress options, JS, or source control.

## Deployment

1. Back up the live site and database.
2. Deploy `shared/payment-gateway/`.
3. Deploy the single MU plugin.
4. Set `BZJ_PGB_SECRET` to the same value in the PHP runtime used by both Streams and WordPress.
5. Replace the Streams init client with the supplied client.
6. Disable the old WooCommerce REST/cURL order creation.
7. Do not activate the old redirect/fulfillment code simultaneously.
8. Test product, PRO/subscription, wallet, market, affiliate and payment failure paths.
9. Only after staging validation, archive the legacy webhook and sync code.

## Logging

Logs are component-specific:
`shared/payment-gateway/log/<source-file>.log`

The logger redacts common credential/token fields. Enable/disable and minimum level are controlled by WordPress filters/config; do not put secrets in logs.
