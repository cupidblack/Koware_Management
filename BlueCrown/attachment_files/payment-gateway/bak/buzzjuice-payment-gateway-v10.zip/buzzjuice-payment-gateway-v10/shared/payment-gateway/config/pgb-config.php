<?php
/**
 * Buzzjuice Payment Gateway Bridge configuration.
 * Secrets are read from the server environment only.
 */
if (!defined('ABSPATH')) { exit; }

function pgb_config() {
    return [
        'version' => '10.0.0',
        'logging_enabled' => (bool) apply_filters('pgb_logging_enabled', true),
        'log_level' => (string) apply_filters('pgb_log_level', 'info'),
        'timestamp_tolerance' => 300,
        'checkout_path' => '/pgb-checkout/',
        'secret_env' => 'BZJ_PGB_SECRET',
        'transaction_table' => 'pgb_transactions',
        'fulfillment_table' => 'pgb_fulfillment',
        'cleanup_days' => 90,
        'max_payload_bytes' => 262144,
    ];
}
function get_pgb_config() { return pgb_config(); }
