<?php
/**
 * Streams-side client. Requires WoWonder $wo/$sqlConnect context.
 * It does not load WordPress.
 */
if (!isset($wo) || !isset($sqlConnect)) { http_response_code(500); exit('Payment bridge context unavailable.'); }
require_once dirname(__DIR__,2).'/db_helpers.php';

header('Content-Type: application/json; charset=utf-8');
if (empty($wo['loggedin'])) { http_response_code(401); echo json_encode(['status'=>'error','message'=>'Login required.']); exit; }

$user_id=(int)($wo['user']['user_id']??0);
$email=filter_var($wo['user']['email']??'',FILTER_VALIDATE_EMAIL);
if(!$user_id || !$email){http_response_code(400);echo json_encode(['status'=>'error','message'=>'Invalid user.']);exit;}

$post=function($k,$default=null){return isset($_POST[$k])?$_POST[$k]:$default;};
$amount=(float)$post('amount',0);
$product_price=(float)$post('product_price',0);
$units=(int)$post('product_units',1);
$owner=(int)$post('product_owner_id',0);
$kind=strtoupper(preg_replace('/[^A-Z0-9_-]/i','',(string)$post('transaction_kind','PURCHASE')));
$currency=strtoupper(preg_replace('/[^A-Z]/','',(string)$post('wow_currency_code','GHS')));
$product_id=(int)$post('wow_product_kind',0);
$post_id=(int)$post('wow_post_id',0);
$address_id=(int)$post('address_id',0);
$product_name=trim((string)$post('product_name',''));
if($amount<=0||$units<=0||!preg_match('/^[A-Z]{3}$/',$currency)||$product_id<=0){http_response_code(400);echo json_encode(['status'=>'error','message'=>'Invalid payment data.']);exit;}

$wow_order_id='wow_'.bin2hex(random_bytes(16));
$request_id='pgb_'.bin2hex(random_bytes(16));
$payload=[
 'customer_id'=>$user_id,'currency'=>$currency,'line_items'=>[[
   'product_id'=>$product_id,'quantity'=>$units,'price'=>$product_price,'total'=>$amount,'name'=>$product_name
 ]],
 'meta_data'=>[
   ['key'=>'wow_order_id','value'=>$wow_order_id],
   ['key'=>'wow_post_id','value'=>$post_id],
   ['key'=>'userid','value'=>$user_id],
   ['key'=>'_transaction_kind','value'=>$kind],
   ['key'=>'_subscription_period','value'=>(string)$post('subscription_period','')],
   ['key'=>'_subscription_interval','value'=>(int)$post('subscription_interval',1)],
   ['key'=>'_subscription_length','value'=>(int)$post('subscription_length',0)],
   ['key'=>'_buzzjuice_origin','value'=>'streams'],
   ['key'=>'_buzzjuice_email','value'=>$email],
 ]
];
$aff=[];
foreach(['affwp_ref','affwp_visit','affwp_visit_id','affwp_affiliate_id','affwp_campaign','affwp_coupon','affwp_referrer'] as $k) if(!empty($_COOKIE[$k])) $aff[$k]=(string)$_COOKIE[$k];
$aff['timestamp']=gmdate('c');$aff['wp_user_id']=$user_id;$aff['customer_email']=$email;$aff['snapshot_version']='3';
$payload['meta_data'][]=['key'=>'_buzzjuice_affwp_context_snapshot','value'=>json_encode($aff)];

$sql="INSERT INTO Wo_Payment_Transactions (userid,amount,order_id,kind,currency_code,notes) VALUES (?,?,?,?,?,?)";
$stmt=$sqlConnect->prepare($sql);
if(!$stmt){http_response_code(500);echo json_encode(['status'=>'error','message'=>'Unable to create payment transaction.']);exit;}
$notes='PGB v10 '.$kind;
$stmt->bind_param('idssss',$user_id,$amount,$wow_order_id,$kind,$currency,$notes);
if(!$stmt->execute()){http_response_code(500);echo json_encode(['status'=>'error','message'=>'Unable to record payment transaction.']);exit;}
$stmt->close();

$store=rtrim((string)($wo['config']['wow_store_url']??$wo['config']['site_url']??''),'/');
if(!$store){http_response_code(500);echo json_encode(['status'=>'error','message'=>'Payment store is not configured.']);exit;}

$ts=time();
$secret=getenv('BZJ_PGB_SECRET');
if(!$secret && defined('BZJ_PGB_SECRET')) $secret=BZJ_PGB_SECRET;
if(!$secret){http_response_code(500);echo json_encode(['status'=>'error','message'=>'Payment bridge secret is not configured.']);exit;}
$body=json_encode(['wow_order_id'=>$wow_order_id],JSON_UNESCAPED_SLASHES);
$sig=base64_encode(hash_hmac('sha256',$ts."\n".$request_id."\n".$body,$secret,true));
$url=$store.'/pgb-checkout/?'.http_build_query(['wow_order_id'=>$wow_order_id,'request_id'=>$request_id,'ts'=>$ts,'sig'=>$sig]);

echo json_encode(['status'=>200,'url'=>$url,'wow_order_id'=>$wow_order_id,'request_id'=>$request_id]);
exit;
