<?php
/**
 * Compatibility wrapper for Streams.
 * The actual Streams implementation lives in pgb-client-streams.php.
 */
require_once __DIR__.'/pgb-client-streams.php';
