<?php
if (!defined('ABSPATH')) exit;

class PGB_Validator {
    public function positive_int($v){return filter_var($v,FILTER_VALIDATE_INT)!==false && (int)$v>0;}
    public function currency($v){return (bool)preg_match('/^[A-Z]{3}$/',(string)$v);}
    public function amount($v){return is_numeric($v) && (float)$v>0;}
    public function email($v){return (bool)filter_var($v,FILTER_VALIDATE_EMAIL);}
    public function transaction_kind($v){return in_array(strtoupper((string)$v),['PRODUCT','PURCHASE','PRO','WALLET','DONATE','SALE'],true);}
}
