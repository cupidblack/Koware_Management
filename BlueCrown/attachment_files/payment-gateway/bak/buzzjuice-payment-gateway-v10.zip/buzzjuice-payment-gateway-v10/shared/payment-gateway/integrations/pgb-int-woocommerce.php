<?php
if (!defined('ABSPATH')) exit;

add_action('pgb_fulfill',function($order_id,$order,$tx,$bridge){
    $bridge->manager()->update_status($tx['wow_order_id'],'fulfilled',$order_id);
    $bridge->logger()->log('WooCommerce fulfillment pipeline completed',PGB_Logger::INFO,['order_id'=>$order_id],__FILE__);
},90,4);
