<?php
http_response_code(410);
header('Content-Type: application/json');
echo json_encode(['status'=>'deprecated','message'=>'Payment fulfillment is now handled by the Buzzjuice WordPress Payment Gateway Bridge.']);
exit;
