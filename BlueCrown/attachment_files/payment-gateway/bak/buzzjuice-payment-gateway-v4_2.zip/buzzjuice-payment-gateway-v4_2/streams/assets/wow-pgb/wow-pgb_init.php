<?php
require_once dirname(__DIR__,2).'/config.php';
require_once dirname(__DIR__).'/init.php';
require_once dirname(__DIR__,2).'/../shared/payment-gateway/pgb-client-streams.php';

if(empty($wo['loggedin'])){http_response_code(401);header('Content-Type: application/json');echo json_encode(['status'=>'error','message'=>'Not authenticated']);exit;}
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);header('Content-Type: application/json');echo json_encode(['status'=>'error','message'=>'Method not allowed']);exit;}

header('Content-Type: application/json');
$wow_user_id=(int)($wo['user']['user_id']??0);
$wow_order_id=preg_replace('/[^A-Za-z0-9._:-]/','',trim((string)($_POST['wow_order_id']??'')));
if($wow_order_id==='')$wow_order_id='wow_'.gmdate('YmdHis').'_'.bin2hex(random_bytes(8));

$type=strtoupper(preg_replace('/[^A-Z_]/','',$_POST['transaction_kind']??''));
if($type==='PRODUCT')$type='PRODUCT';
$payload=[
 'wow_user_id'=>$wow_user_id,'wow_order_id'=>$wow_order_id,'transaction_type'=>$type,
 'amount'=>(float)($_POST['amount']??0),'currency'=>strtoupper(trim((string)($_POST['wow_currency_code']??''))),
 'wow_post_id'=>(int)($_POST['wow_post_id']??0),'product_units'=>max(1,(int)($_POST['product_units']??1)),
 'qdw_order_id'=>preg_replace('/[^A-Za-z0-9._:-]/','',(string)($_POST['qdw_order_id']??'')),'qdw_membershipType'=>(int)($_POST['qdw_membershipType']??0)
];

$wp_url=rtrim((string)($wo['config']['wow_store_url']??''),'/');
$secret=trim((string)(getenv('BZJ_PGB_SECRET')?:($_ENV['BZJ_PGB_SECRET']??'')));
if($wp_url===''||$secret===''){http_response_code(500);echo json_encode(['status'=>'error','message'=>'Payment bridge is not configured']);exit;}
$result=bzj_pgb_streams_request($wp_url,$payload,$secret,30);
if($result['http_code']<200||$result['http_code']>=300){http_response_code($result['http_code']?:502);echo json_encode(['status'=>'error','message'=>$result['body']['message']??'Payment request failed','request_id'=>$result['request_id']]);exit;}
echo json_encode(['status'=>'success','url'=>$result['body']['payment_url']??'','payment_url'=>$result['body']['payment_url']??'','woo_order_id'=>$result['body']['woo_order_id']??0,'pgb_transaction_id'=>$result['body']['pgb_transaction_id']??'']);
