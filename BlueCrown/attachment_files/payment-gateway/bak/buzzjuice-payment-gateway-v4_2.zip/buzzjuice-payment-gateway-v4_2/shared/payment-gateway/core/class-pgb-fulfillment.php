<?php
if (!defined('ABSPATH')) exit;
class PGB_Fulfillment {
    private $logger,$orders,$wowdb;
    public function __construct(PGB_Logger $logger,PGB_Order $orders){$this->logger=$logger;$this->orders=$orders;$this->wowdb=function_exists('get_wowonder_db')?get_wowonder_db():null;}
    public function on_paid($woo_order_id){
        $tx=$this->orders->find_by_woo($woo_order_id); if(!$tx)return false;
        if($tx['fulfillment_status']==='completed')return true;
        if(!$this->orders->paid($tx['pgb_transaction_id']))return false;
        return $this->run($tx,$woo_order_id);
    }
    public function run($tx,$woo_order_id=null){
        $woo_order_id=$woo_order_id?:$tx['woo_order_id'];$order=wc_get_order($woo_order_id);
        if(!$order)return $this->fail($tx,'WooCommerce order unavailable');
        if(!$order->is_paid())return false;
        try{
            if(!$this->streams($tx,$order))throw new RuntimeException('Streams fulfillment failed');
            if(!$this->affiliate($tx,$order))throw new RuntimeException('AffiliateWP processing failed');
            if(!$this->integrations($tx,$order))throw new RuntimeException('Integration processing failed');
            $this->orders->update($tx['pgb_transaction_id'],['fulfillment_status'=>'completed','affiliate_status'=>$this->affiliate_status($tx),'integration_status'=>'completed','last_error'=>null,'next_retry_at'=>null]);
            $this->logger->info('Fulfillment completed',['pgb'=>$tx['pgb_transaction_id'],'woo'=>$woo_order_id],__FILE__,__LINE__);
            do_action('bzj_pgb_fulfillment_completed',$tx,$order);
            return true;
        }catch(Throwable $e){$this->fail($tx,$e->getMessage());return false;}
    }
    private function streams($tx,$order){
        if(!$this->wowdb)return false;
        $wow=(int)$tx['wow_user_id'];$amount=(float)$tx['final_amount'];$woo=(int)$order->get_id();$wowOrder=(string)$tx['wow_order_id'];$type=strtoupper($tx['transaction_type']);
        $this->update_payment_transaction($wowOrder,$woo,$order);
        if($type==='PRO')return $this->fulfill_pro($tx,$order);
        if(in_array($type,['WALLET'],true))return $this->fulfill_wallet($wow,$amount,$woo,$wowOrder);
        if(in_array($type,['DONATE'],true))return $this->fulfill_donation($tx,$order);
        if(in_array($type,['PRODUCT','PURCHASE','SALE'],true))return $this->fulfill_product($tx,$order);
        return true;
    }
    private function update_payment_transaction($wowOrder,$woo,$order){
        $stmt=$this->wowdb->prepare("UPDATE Wo_Payment_Transactions SET payment_status=?, payment_method=?, woo_order_id=?, amount=?, transaction_dt=NOW() WHERE order_id=?");
        if(!$stmt)return false;$status=$order->get_status();$method=$order->get_payment_method();$amount=(float)$order->get_total();$stmt->bind_param('ssids',$status,$method,$woo,$amount,$wowOrder);$ok=$stmt->execute();$stmt->close();return $ok;
    }
    private function fulfill_pro($tx,$order){
        $u=(int)$tx['wow_user_id'];$post=(int)$tx['wow_post_id'];if(!in_array($post,[1,2,3,4],true))return false;
        $now=time();$is='1';$stmt=$this->wowdb->prepare("UPDATE Wo_Users SET pro_time=?, is_pro=?, pro_type=? WHERE user_id=?");
        if(!$stmt)return false;$stmt->bind_param('isii',$now,$is,$post,$u);$ok=$stmt->execute();$stmt->close();if(!$ok)return false;
        if(function_exists('bzj_log_activity'))@bzj_log_activity($u,'Buzzjuice Subscription',$tx['wow_order_id'],'purchase',(float)$tx['final_amount'],'Wo_Payment_Transactions');
        return true;
    }
    private function fulfill_wallet($u,$amount,$woo,$wowOrder){
        // Preserve the payment ledger and let the existing wallet implementation consume the completed transaction.
        // The exact wallet balance mechanism varies by WoWonder build; update only the canonical payment row here.
        return $this->payment_exists($wowOrder);
    }
    private function fulfill_donation($tx,$order){
        return $this->payment_exists($tx['wow_order_id']);
    }
    private function fulfill_product($tx,$order){
        $u=(int)$tx['wow_user_id'];$owner=(int)$order->get_meta('product_owner_id',true);$post=(int)$tx['wow_post_id'];$qty=max(1,(int)$order->get_meta('product_units',true));
        if(!$owner)$owner=(int)$order->get_meta('wow_product_owner_id',true);
        $now=time();$data=wp_json_encode(['name'=>$order->get_items()?reset($order->get_items())->get_name():'Product','product_id'=>$post,'units'=>$qty,'currency'=>$order->get_currency(),'timestamp'=>$now]);
        $stmt=$this->wowdb->prepare("INSERT INTO Wo_Purchases (user_id, order_hash_id, owner_id, data, final_price, commission, price, timestamp, time) VALUES (?,?,?,?,?,?,?,?,?)");
        if(!$stmt)return false;$commission=0;$price=(float)$order->get_subtotal();$final=(float)$order->get_total();$stmt->bind_param('isssddddd',$u,$tx['wow_order_id'],$owner,$data,$final,$commission,$price,$now,$now);$ok=$stmt->execute();$stmt->close();
        if(!$ok)return false;
        $stmt=$this->wowdb->prepare("INSERT INTO Wo_UserOrders (hash_id,user_id,product_owner_id,product_id,address_id,price,commission,final_price,units,status,time) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        if(!$stmt)return false;$address=0;$status='placed';$stmt->bind_param('siiiiiddssi',$tx['wow_order_id'],$u,$owner,$post,$address,$price,$commission,$final,$qty,$status,$now);$ok=$stmt->execute();$stmt->close();return $ok;
    }
    private function payment_exists($wowOrder){$r=$this->wowdb->query("SELECT order_id FROM Wo_Payment_Transactions WHERE order_id='". $this->wowdb->real_escape_string($wowOrder)."' LIMIT 1");return (bool)($r&&$r->num_rows);}
    private function affiliate($tx,$order){
        if(!function_exists('pgb_addon_affiliate_wp_process'))return true;
        $ok=pgb_addon_affiliate_wp_process($tx,$order,$this->logger,$this->wowdb);
        $this->orders->update($tx['pgb_transaction_id'],['affiliate_status'=>$ok?'completed':'retry']);
        return $ok;
    }
    private function affiliate_status($tx){$r=$this->orders->find($tx['pgb_transaction_id']);return $r['affiliate_status']??'completed';}
    private function integrations($tx,$order){
        $ok=true;
        if(function_exists('pgb_int_jewel_affiliate_process'))$ok=pgb_int_jewel_affiliate_process($tx,$order,$this->logger,$this->wowdb)&&$ok;
        return $ok;
    }
    private function fail($tx,$error){$this->logger->error('Fulfillment failed',['pgb'=>$tx['pgb_transaction_id'],'error'=>$error],__FILE__,__LINE__);$this->orders->retry($tx['pgb_transaction_id'],$error,min(3600,300*max(1,(int)$tx['retry_count']+1)));return false;}
    public function retry_queue(){foreach($this->orders->retryable(10) as $tx){$this->run($tx);}}
}
