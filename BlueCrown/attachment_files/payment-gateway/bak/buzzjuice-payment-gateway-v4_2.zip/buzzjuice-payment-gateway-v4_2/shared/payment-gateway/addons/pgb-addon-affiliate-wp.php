<?php
if (!defined('ABSPATH')) exit;
/**
 * AffiliateWP addon.
 *
 * Important: no browser/cookie context is authoritative here.
 * Affiliate ownership is resolved from the purchasing WordPress user and
 * AffiliateWP's durable customer/lifetime-customer records.
 */
function pgb_addon_affiliate_wp_process($tx,$order,PGB_Logger $logger,$wow_db=null){
    if(!function_exists('affwp_add_referral')){ $logger->warning('AffiliateWP public API unavailable',[],__FILE__,__LINE__); return true; }
    global $wpdb;
    $order_id=(int)$order->get_id();$wp_user=(int)$tx['wp_user_id'];
    if($order->get_meta('_affwp_bridge_processed',true))return true;
    $customer=(int)$wpdb->get_var($wpdb->prepare("SELECT customer_id FROM {$wpdb->prefix}affiliate_wp_customers WHERE user_id=%d ORDER BY customer_id DESC LIMIT 1",$wp_user));
    if(!$customer){
        $u=get_user_by('id',$wp_user);if(!$u)return true;
        $customer=affwp_add_customer(['user_id'=>$wp_user,'email'=>$u->user_email]);
        if(is_wp_error($customer)||!$customer)return false;
    }
    $affiliate=(int)$wpdb->get_var($wpdb->prepare("SELECT affiliate_id FROM {$wpdb->prefix}affiliate_wp_lifetime_customers WHERE affwp_customer_id=%d ORDER BY lifetime_customer_id DESC LIMIT 1",$customer));
    if(!$affiliate)$affiliate=(int)$wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->prefix}affiliate_wp_customermeta WHERE affwp_customer_id=%d AND meta_key IN ('affiliate_id','referring_affiliate_id') ORDER BY meta_id DESC LIMIT 1",$customer));
    if(!$affiliate){$logger->info('No durable AffiliateWP affiliate associated with customer',['woo_order_id'=>$order_id],__FILE__,__LINE__);$order->update_meta_data('_affwp_bridge_processed',gmdate('c'));$order->save();return true;}
    $existing=(int)$wpdb->get_var($wpdb->prepare("SELECT referral_id FROM {$wpdb->prefix}affiliate_wp_referrals WHERE reference=%s AND context=%s LIMIT 1",(string)$order_id,'woocommerce'));
    if($existing){$order->update_meta_data('_affwp_bridge_processed',gmdate('c'));$order->save();return true;}
    $commission=0.0;$products=[];
    $settings=get_option('affwp_settings',[]);$rate=(float)($settings['referral_rate']??0);$rate_type=$settings['referral_rate_type']??'percentage';
    foreach($order->get_items('line_item') as $item){
        $product=$item->get_product();if(!$product)continue;
        $target=$item->get_variation_id()?:$item->get_product_id();
        $raw=get_post_meta($target,'_affwp_woocommerce_product_rate',true);
        $type=(string)get_post_meta($target,'_affwp_woocommerce_product_rate_type',true);
        $base=(float)$item->get_total();$c=0;
        if($raw!==''&&is_numeric($raw)&&in_array($type,['percentage','flat'],true))$c=$type==='percentage'?$base*((float)$raw/100):(float)$raw;
        elseif($rate>0)$c=$rate_type==='percentage'?$base*($rate/100):$rate;
        $commission+=max(0,$c);
        $products[]=['product_id'=>$item->get_product_id(),'variation_id'=>$item->get_variation_id(),'name'=>$item->get_name(),'item_total'=>$base,'commission'=>$c];
    }
    if($commission<=0){$order->update_meta_data('_affwp_bridge_processed',gmdate('c'));$order->save();return true;}
    $data=['affiliate_id'=>$affiliate,'customer_id'=>$customer,'amount'=>round($commission,4),'currency'=>$order->get_currency(),'context'=>'woocommerce','reference'=>(string)$order_id,'description'=>'Buzzjuice Streams order #'.$order_id,'status'=>'unpaid','products'=>maybe_serialize($products),'date'=>current_time('mysql')];
    $ref=affwp_add_referral($data);
    if(is_wp_error($ref)||!$ref){$logger->error('AffiliateWP referral creation failed',['woo_order_id'=>$order_id],__FILE__,__LINE__);return false;}
    $order->update_meta_data('_affwp_bridge_processed',gmdate('c'));$order->update_meta_data('_affwp_referral_id',(int)$ref);$order->save();
    return true;
}
