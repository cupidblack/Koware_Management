<?php
if (!defined('ABSPATH')) exit;
class PGB_Auth {
    public static function secret(){return trim((string)getenv('BZJ_PGB_SECRET'));}
    public static function verify(WP_REST_Request $request,PGB_Logger $logger){
        $ts=$request->get_header('X-BZJ-PGB-Timestamp');
        $rid=$request->get_header('X-BZJ-PGB-Request-ID');
        $sig=$request->get_header('X-BZJ-PGB-Signature');
        if(!$ts||!$rid||!$sig)return new WP_Error('pgb_auth','Missing authentication headers',['status'=>401]);
        if(!ctype_digit((string)$ts)||abs(time()-(int)$ts)>max(30,(int)get_option('pgb_request_ttl',300)))return new WP_Error('pgb_auth','Expired request',['status'=>401]);
        $secret=self::secret();
        if($secret===''){ $logger->error('PGB secret is not configured',[],__FILE__,__LINE__);return new WP_Error('pgb_config','Server configuration error',['status'=>500]);}
        $body=$request->get_body();
        $expected=hash_hmac('sha256',$ts."\n".$rid."\n".$body,$secret);
        if(!hash_equals($expected,$sig)){ $logger->warning('HMAC verification failed',['request_id'=>$rid],__FILE__,__LINE__);return new WP_Error('pgb_auth','Invalid signature',['status'=>401]);}
        if(!preg_match('/^[A-Za-z0-9._:-]{8,64}$/',$rid))return new WP_Error('pgb_auth','Invalid request ID',['status'=>401]);
        return true;
    }
}
