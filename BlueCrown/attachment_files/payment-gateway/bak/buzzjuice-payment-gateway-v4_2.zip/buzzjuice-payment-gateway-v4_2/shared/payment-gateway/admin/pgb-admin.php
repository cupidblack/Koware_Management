<?php
if (!defined('ABSPATH')) exit;
class PGB_Admin {
    public function __construct(){
        add_action('admin_menu',[$this,'menu'],30);
        add_action('admin_init',[$this,'settings']);
    }
    public function menu(){
        add_submenu_page('blue-crown','Payment Gateway','Payment Gateway','manage_options','bzj-pgb',[$this,'page']);
    }
    public function settings(){
        register_setting('bzj_pgb','pgb_enabled',['type'=>'boolean','sanitize_callback'=>fn($v)=>(bool)$v,'default'=>true]);
        register_setting('bzj_pgb','pgb_logging_enabled',['type'=>'boolean','sanitize_callback'=>fn($v)=>(bool)$v,'default'=>false]);
        register_setting('bzj_pgb','pgb_log_level',['sanitize_callback'=>fn($v)=>in_array($v,['debug','info','warning','error'],true)?$v:'info']);
        register_setting('bzj_pgb','pgb_request_ttl',['sanitize_callback'=>fn($v)=>max(30,min(900,(int)$v))]);
        register_setting('bzj_pgb','pgb_retry_limit',['sanitize_callback'=>fn($v)=>max(1,min(20,(int)$v))]);
        register_setting('bzj_pgb','pgb_dynamic_minimum',['sanitize_callback'=>fn($v)=>max(0.01,(float)$v)]);
        register_setting('bzj_pgb','pgb_dynamic_maximum',['sanitize_callback'=>fn($v)=>max(0.01,(float)$v)]);
    }
    public function page(){
        if(!current_user_can('manage_options'))wp_die('Unauthorized');
        $stats=(new PGB_Order(new PGB_Logger()))->stats();?>
        <div class="wrap"><h1>Buzzjuice Payment Gateway</h1>
        <p>The Streams admin remains the source for WooCommerce product mappings. This page controls the WordPress engine only.</p>
        <form method="post" action="options.php"><?php settings_fields('bzj_pgb');?>
        <table class="form-table">
        <tr><th>Bridge enabled</th><td><input type="checkbox" name="pgb_enabled" value="1" <?php checked(get_option('pgb_enabled',true));?>></td></tr>
        <tr><th>Logging enabled</th><td><input type="checkbox" name="pgb_logging_enabled" value="1" <?php checked(get_option('pgb_logging_enabled',false));?>></td></tr>
        <tr><th>Log level</th><td><select name="pgb_log_level"><?php foreach(['debug','info','warning','error'] as $v)printf('<option value="%s"%s>%s</option>',esc_attr($v),selected(get_option('pgb_log_level','info'),$v,false),esc_html(ucfirst($v)));?></select></td></tr>
        <tr><th>Request TTL (seconds)</th><td><input type="number" name="pgb_request_ttl" value="<?php echo esc_attr(get_option('pgb_request_ttl',300));?>"></td></tr>
        <tr><th>Retry limit</th><td><input type="number" name="pgb_retry_limit" value="<?php echo esc_attr(get_option('pgb_retry_limit',8));?>"></td></tr>
        <tr><th>Dynamic minimum</th><td><input type="number" step="0.01" name="pgb_dynamic_minimum" value="<?php echo esc_attr(get_option('pgb_dynamic_minimum',1));?>"></td></tr>
        <tr><th>Dynamic maximum</th><td><input type="number" step="0.01" name="pgb_dynamic_maximum" value="<?php echo esc_attr(get_option('pgb_dynamic_maximum',50000));?>"></td></tr>
        </table><?php submit_button();?></form>
        <h2>Ledger</h2><ul><?php foreach($stats as $k=>$v)echo '<li><strong>'.esc_html(ucfirst($k)).':</strong> '.intval($v).'</li>';?></ul>
        </div><?php
    }
}
new PGB_Admin();
