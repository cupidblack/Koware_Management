(function(){
'use strict';
window.BZJ_PGB={
  init:function(){
    document.addEventListener('click',function(e){
      var b=e.target.closest ? e.target.closest('[data-bzj-pgb]') : null;
      if(!b)return;
      e.preventDefault();
      if(b.dataset.pgbBusy==='1')return;
      b.dataset.pgbBusy='1';b.disabled=true;
      var form=b.closest('form');if(!form){b.disabled=false;b.dataset.pgbBusy='0';return;}
      var fd=new FormData(form);fd.append('request_id',crypto.randomUUID?crypto.randomUUID():'pgb_'+Date.now()+'_'+Math.random().toString(16).slice(2));
      fetch(form.action,{method:'POST',body:fd,credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}})
      .then(function(r){return r.json();})
      .then(function(x){if(x.url)window.location.href=x.url;else if(x.payment_url)window.location.href=x.payment_url;else throw new Error(x.message||'Payment could not be started');})
      .catch(function(err){b.disabled=false;b.dataset.pgbBusy='0';window.alert(err.message||'Payment could not be started');});
    });
  }
};
document.readyState==='loading'?document.addEventListener('DOMContentLoaded',BZJ_PGB.init):BZJ_PGB.init();
})();