<?php
/**
 * Streams-side transport helper. This file is intended to be included by
 * streams/assets/wow-pgb/wow-pgb_init.php and does not load WordPress.
 */
function bzj_pgb_streams_request($wp_url,$payload,$secret,$timeout=30){
    $rid=$payload['request_id']??('pgb_'.bin2hex(random_bytes(12)));unset($payload['request_id']);
    $ts=time();$body=json_encode($payload,JSON_UNESCAPED_SLASHES);
    $sig=hash_hmac('sha256',$ts."\n".$rid."\n".$body,$secret);
    $ch=curl_init(rtrim($wp_url,'/').'/wp-json/bzj-pgb/v1/order');
    curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>$timeout,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_HTTPHEADER=>['Content-Type: application/json','X-BZJ-PGB-Timestamp: '.$ts,'X-BZJ-PGB-Request-ID: '.$rid,'X-BZJ-PGB-Signature: '.$sig],CURLOPT_POSTFIELDS=>$body]);
    $raw=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
    $json=json_decode((string)$raw,true);
    return ['http_code'=>$http,'body'=>is_array($json)?$json:[],'error'=>$err,'request_id'=>$rid];
}
