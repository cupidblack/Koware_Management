<?php
if (!defined('ABSPATH')) exit;
/**
 * Jewel Affiliate integration entry point.
 *
 * The integration is intentionally transaction-idempotent. Existing Jewel
 * business rules should be migrated here from streams/jewel-affiliate-webhook.php
 * before the legacy endpoint is disabled.
 */
function pgb_int_jewel_affiliate_process($tx,$order,PGB_Logger $logger,$wow_db=null){
    // Only act on an explicitly marked Jewel transaction.
    $is_jewel=(string)$order->get_meta('pgb_integration_jewel',true)==='1'
        || (string)$order->get_meta('qdw_membershipType',true)!=='' 
        || (string)$order->get_meta('transaction_kind',true)==='JEWEL_AFFILIATE';
    if(!$is_jewel)return true;
    if($order->get_meta('_pgb_jewel_processed',true))return true;
    /*
     * Durable hook for the migrated Jewel rules. The legacy endpoint should
     * call the same action during migration; no browser return is required.
     */
    do_action('bzj_pgb_jewel_paid',$tx,$order,$wow_db,$logger);
    $order->update_meta_data('_pgb_jewel_processed',gmdate('c'));$order->save();
    return true;
}
