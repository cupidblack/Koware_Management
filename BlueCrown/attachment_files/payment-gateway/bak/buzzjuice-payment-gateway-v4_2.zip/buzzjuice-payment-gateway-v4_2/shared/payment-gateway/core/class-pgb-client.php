<?php
if (!defined('ABSPATH')) exit;
class PGB_Client {
    private $logger,$orders,$wowdb;
    public function __construct(PGB_Logger $logger,PGB_Order $orders){$this->logger=$logger;$this->orders=$orders;$this->wowdb=function_exists('get_wowonder_db')?get_wowonder_db():null;}
    public function process($request_id,$data){
        if(!(bool)get_option('pgb_enabled',true))return new WP_Error('pgb_disabled','Payment Gateway Bridge is disabled',['status'=>503]);
        $v=$this->validate($data); if(is_wp_error($v))return $v;
        $key=PGB_Idempotency::key($data);
        $existing=$this->orders->find_by_idempotency($key);
        if($existing)return $this->response_existing($existing);
        if($this->orders->find_by_request($request_id))return new WP_Error('pgb_request_reused','Request ID already used',['status'=>409]);

        $wow_user=(int)$data['wow_user_id'];
        $wp_user=$this->resolve_wp_user($wow_user);
        if(!$wp_user)return new WP_Error('pgb_user','Unable to resolve WordPress user',['status'=>422]);

        $mapping=$this->resolve_product($data);
        if(!$mapping)return new WP_Error('pgb_product','Invalid WooCommerce product mapping',['status'=>422]);

        $amount=(float)$data['amount'];
        $currency=strtoupper($data['currency']);
        $final=$this->validate_amount($data['transaction_type'],$amount,$currency,$mapping);
        if(is_wp_error($final))return $final;

        $tx=wp_generate_uuid4();
        $ledger=$this->orders->create([
            'pgb_transaction_id'=>$tx,'idempotency_key'=>$key,'request_id'=>$request_id,
            'wow_order_id'=>sanitize_text_field($data['wow_order_id']),'wow_user_id'=>$wow_user,'wp_user_id'=>$wp_user,
            'transaction_type'=>strtoupper($data['transaction_type']),'wow_post_id'=>(int)($data['wow_post_id']??0),
            'woo_product_id'=>(int)$mapping['product_id'],'woo_variation_id'=>(int)($mapping['variation_id']??0),
            'currency'=>$currency,'requested_amount'=>$amount,'final_amount'=>$final,
            'payment_status'=>'pending','fulfillment_status'=>'pending','affiliate_status'=>'pending','integration_status'=>'pending',
            'payload'=>wp_json_encode($this->safe_payload($data))
        ]);
        if(!$ledger)return new WP_Error('pgb_ledger','Unable to create transaction ledger',['status'=>500]);

        $order_id=$this->create_order($wp_user,$mapping,$final,$currency,$data,$tx);
        if(!$order_id){
            $this->orders->update($tx,['last_error'=>'WooCommerce order creation failed']);
            return new WP_Error('pgb_order','Unable to create WooCommerce order',['status'=>500]);
        }
        $this->orders->update($tx,['woo_order_id'=>$order_id]);
        $order=wc_get_order($order_id);
        return ['status'=>'success','pgb_transaction_id'=>$tx,'woo_order_id'=>$order_id,'payment_url'=>$order?$order->get_checkout_payment_url():wc_get_checkout_url()];
    }
    private function validate($d){
        foreach(['wow_user_id','wow_order_id','transaction_type','amount','currency'] as $k)if(!isset($d[$k])||$d[$k]==='')return new WP_Error('pgb_validation','Missing '.$k,['status'=>400]);
        if((int)$d['wow_user_id']<1)return new WP_Error('pgb_validation','Invalid user',['status'=>400]);
        if(!preg_match('/^[A-Za-z0-9._:-]{3,100}$/',(string)$d['wow_order_id']))return new WP_Error('pgb_validation','Invalid order ID',['status'=>400]);
        if(!in_array(strtoupper($d['transaction_type']),['PRO','PRODUCT','PURCHASE','SALE','WALLET','DONATE'],true))return new WP_Error('pgb_validation','Invalid transaction type',['status'=>400]);
        if((float)$d['amount']<=0)return new WP_Error('pgb_validation','Amount must be greater than zero',['status'=>400]);
        if(!preg_match('/^[A-Z]{3}$/',strtoupper($d['currency'])))return new WP_Error('pgb_validation','Invalid currency',['status'=>400]);
        return true;
    }
    private function resolve_wp_user($wow){
        if(!$this->wowdb)return 0;
        $r=$this->wowdb->query("SELECT wp_user_id FROM Wo_Users WHERE user_id=".(int)$wow." LIMIT 1");
        if($r&&$row=$r->fetch_assoc())return (int)$row['wp_user_id'];
        return 0;
    }
    private function resolve_product($d){
        $type=strtoupper($d['transaction_type']);$post=(int)($d['wow_post_id']??0);
        $cfg=$this->streams_config();
        $id=0;
        if($type==='PRO'){$map=[1=>$cfg['wow_pro_package_id']??0,2=>$cfg['wow_pro_package_id_2']??0,3=>$cfg['wow_pro_package_id_3']??0,4=>$cfg['wow_pro_package_id_4']??0];$id=(int)($map[$post]??0);}
        elseif(in_array($type,['WALLET'],true))$id=(int)($cfg['wow_wallet_topup_id']??0);
        elseif(in_array($type,['DONATE'],true))$id=(int)($cfg['wow_crowdfund_id']??0);
        else $id=(int)($cfg['wow_market_id']??0);
        if($id<1)return false;
        $product=wc_get_product($id); if(!$product)return false;
        return ['product_id'=>$product->get_id(),'variation_id'=>$product->is_type('variation')?$product->get_id():0];
    }
    private function streams_config(){
        if(!$this->wowdb)return [];
        $r=$this->wowdb->query("SELECT data FROM Wo_Config LIMIT 1");
        if($r&&$row=$r->fetch_assoc()){ $j=json_decode($row['data']??'{}',true); return is_array($j)?$j:[]; }
        return [];
    }
    private function validate_amount($type,$amount,$currency,$mapping){
        $type=strtoupper($type);
        if($type==='PRO'){
            $product=wc_get_product($mapping['product_id']);$expected=$product?(float)$product->get_price():0;
            if($expected<=0)return new WP_Error('pgb_price','Mapped product has no valid price',['status'=>422]);
            if(abs($expected-$amount)>0.01)return new WP_Error('pgb_price','Payment amount does not match the configured product price',['status'=>422]);
            return round($expected,2);
        }
        $min=(float)get_option('pgb_dynamic_minimum',1);$max=(float)get_option('pgb_dynamic_maximum',50000);
        if($amount<$min||$amount>$max)return new WP_Error('pgb_amount','Amount is outside the permitted range',['status'=>422]);
        return round($amount,2);
    }
    private function create_order($wp_user,$mapping,$amount,$currency,$d,$tx){
        try{
            $order=wc_create_order(['customer_id'=>$wp_user,'created_via'=>'buzzjuice-pgb']);
            if(is_wp_error($order))return 0;
            $product=wc_get_product($mapping['product_id']);if(!$product){$order->delete(true);return 0;}
            $qty=max(1,(int)($d['product_units']??1));
            $item_id=$order->add_product($product,$qty,['subtotal'=>$amount,'total'=>$amount]);
            if(!$item_id){$order->delete(true);return 0;}
            $order->set_currency($currency);
            $meta=[
                '_buzzjuice_origin'=>'streams','_pgb_transaction_id'=>$tx,'wow_order_id'=>sanitize_text_field($d['wow_order_id']),
                'wow_user_id'=>(int)$d['wow_user_id'],'wow_post_id'=>(int)($d['wow_post_id']??0),
                'qdw_order_id'=>sanitize_text_field($d['qdw_order_id']??''),'qdw_membershipType'=>(int)($d['qdw_membershipType']??0),
                'transaction_kind'=>strtoupper($d['transaction_type'])
            ];
            foreach($meta as $k=>$v)$order->update_meta_data($k,$v);
            $order->set_status('pending');
            $order->calculate_totals(false);
            $order->save();
            return $order->get_id();
        }catch(Throwable $e){$this->logger->error('Woo order exception',['error'=>$e->getMessage()],__FILE__,__LINE__);return 0;}
    }
    private function safe_payload($d){$o=$d;unset($o['secret'],$o['token'],$o['password']);return $o;}
    private function response_existing($tx){
        if(!empty($tx['woo_order_id'])&&($o=wc_get_order($tx['woo_order_id'])))return ['status'=>'success','message'=>'Existing transaction','pgb_transaction_id'=>$tx['pgb_transaction_id'],'woo_order_id'=>$o->get_id(),'payment_url'=>$o->get_checkout_payment_url()];
        return ['status'=>'pending','message'=>'Existing transaction is being completed','pgb_transaction_id'=>$tx['pgb_transaction_id'],'woo_order_id'=>(int)$tx['woo_order_id']];
    }
}
