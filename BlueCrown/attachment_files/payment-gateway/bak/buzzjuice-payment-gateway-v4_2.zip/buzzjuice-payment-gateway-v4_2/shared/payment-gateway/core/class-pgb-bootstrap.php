<?php
if (!defined('ABSPATH')) exit;
class PGB_Bootstrap {
    private static $instance;
    public $logger,$orders,$client,$fulfillment;
    public static function instance(){return self::$instance?:self::$instance=new self();}
    private function __construct(){
        $this->logger=new PGB_Logger();
        $this->orders=new PGB_Order($this->logger);
        if(get_option('bzj_pgb_schema_version')!=='4.2.0')PGB_Schema::install();
        $this->client=new PGB_Client($this->logger,$this->orders);
        $this->fulfillment=new PGB_Fulfillment($this->logger,$this->orders);
        add_action('rest_api_init',[$this,'routes']);
        add_action('woocommerce_payment_complete',[$this,'paid'],20,1);
        add_action('woocommerce_order_status_processing',[$this,'paid'],20,1);
        add_action('woocommerce_order_status_completed',[$this,'paid'],20,1);
        add_action('bzj_pgb_retry_queue',[$this,'retry']);
        if(!wp_next_scheduled('bzj_pgb_retry_queue'))wp_schedule_event(time()+300,'hourly','bzj_pgb_retry_queue');
    }
    public function routes(){register_rest_route('bzj-pgb/v1','/order',['methods'=>'POST','permission_callback'=>function($r){return PGB_Auth::verify($r,$this->logger);},'callback'=>function(WP_REST_Request $r){
        $body=json_decode($r->get_body(),true);if(!is_array($body))return new WP_Error('pgb_json','Invalid JSON',['status'=>400]);
        $rid=$r->get_header('X-BZJ-PGB-Request-ID');$result=$this->client->process($rid,$body);
        if(is_wp_error($result))return $result;
        return new WP_REST_Response($result,200);
    }]);}
    public function paid($order_id){if($this->fulfillment)$this->fulfillment->on_paid((int)$order_id);}
    public function retry(){if($this->fulfillment)$this->fulfillment->retry_queue();}
}
