<?php
if (!defined('ABSPATH')) exit;
function pgb_client_request($payload){
    $url=rtrim((string)($payload['wp_url']??home_url()),'/').'/wp-json/bzj-pgb/v1/order';
    unset($payload['wp_url']);
    $rid=(string)($payload['request_id']??wp_generate_uuid4());unset($payload['request_id']);
    $ts=time();$secret=trim((string)getenv('BZJ_PGB_SECRET'));
    if($secret==='')return new WP_Error('pgb_secret','PGB secret is not configured');
    $body=wp_json_encode($payload);$sig=hash_hmac('sha256',$ts."\n".$rid."\n".$body,$secret);
    return wp_remote_post($url,['timeout'=>30,'headers'=>['Content-Type'=>'application/json','X-BZJ-PGB-Timestamp'=>$ts,'X-BZJ-PGB-Request-ID'=>$rid,'X-BZJ-PGB-Signature'=>$sig],'body'=>$body]);
}
