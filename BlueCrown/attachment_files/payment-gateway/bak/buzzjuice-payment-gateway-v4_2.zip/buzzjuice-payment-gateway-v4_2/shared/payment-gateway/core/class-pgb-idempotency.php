<?php
if (!defined('ABSPATH')) exit;
class PGB_Idempotency {
    public static function key($d){
        $parts=[
            (int)($d['wow_user_id']??0),
            (string)($d['wow_order_id']??''),
            strtoupper((string)($d['transaction_type']??'')),
            (string)($d['wow_post_id']??0),
            (string)($d['woo_product_id']??0),
            (string)($d['woo_variation_id']??0),
            number_format((float)($d['amount']??0),8,'.',''),
            strtoupper((string)($d['currency']??''))
        ];
        return hash('sha256',implode('|',$parts));
    }
}
