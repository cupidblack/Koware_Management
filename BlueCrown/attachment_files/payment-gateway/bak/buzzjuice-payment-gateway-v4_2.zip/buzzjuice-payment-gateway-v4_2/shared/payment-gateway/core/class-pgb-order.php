<?php
if (!defined('ABSPATH')) exit;
class PGB_Order {
    private $table; private $logger;
    public function __construct(PGB_Logger $logger){global $wpdb;$this->table=$wpdb->prefix.'bzj_pgb_transactions';$this->logger=$logger;}
    public function install(){PGB_Schema::install();}
    public function find_by_idempotency($key){global $wpdb;return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table} WHERE idempotency_key=%s",$key),ARRAY_A);}
    public function find_by_request($id){global $wpdb;return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table} WHERE request_id=%s",$id),ARRAY_A);}
    public function find_by_woo($id){global $wpdb;return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table} WHERE woo_order_id=%d",(int)$id),ARRAY_A);}
    public function find($id){global $wpdb;return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table} WHERE pgb_transaction_id=%s",$id),ARRAY_A);}
    public function create($data){
        global $wpdb;$now=current_time('mysql',true);
        $row=array_merge(['created_at'=>$now,'updated_at'=>$now],$data);
        $ok=$wpdb->insert($this->table,$row);
        if(!$ok){$this->logger->error('Ledger insert failed',['db_error'=>$wpdb->last_error],__FILE__,__LINE__);return false;}
        return $this->find($row['pgb_transaction_id']);
    }
    public function update($id,$fields){
        global $wpdb;$fields['updated_at']=current_time('mysql',true);
        $ok=$wpdb->update($this->table,$fields,['pgb_transaction_id'=>$id]);
        if($ok===false)$this->logger->error('Ledger update failed',['id'=>$id,'db_error'=>$wpdb->last_error],__FILE__,__LINE__);
        return $ok!==false;
    }
    public function paid($id){return $this->update($id,['payment_status'=>'paid','fulfillment_status'=>'processing']);}
    public function retry($id,$error,$seconds=300){
        $row=$this->find($id);$count=(int)($row['retry_count']??0)+1;
        $limit=max(1,(int)get_option('pgb_retry_limit',8));
        $status=$count >= $limit ? 'failed':'retry';
        return $this->update($id,['fulfillment_status'=>$status,'retry_count'=>$count,'next_retry_at'=>gmdate('Y-m-d H:i:s',time()+$seconds),'last_error'=>substr((string)$error,0,2000)]);
    }
    public function stats(){global $wpdb;$t=$this->table;return [
        'total'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t}"),
        'pending'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE payment_status='pending'"),
        'paid'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE payment_status='paid'"),
        'processing'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE fulfillment_status IN ('processing','retry')"),
        'completed'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE fulfillment_status='completed'"),
        'failed'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE fulfillment_status='failed'")
    ];}
    public function retryable($limit=10){global $wpdb;$limit=(int)$limit;return $wpdb->get_results("SELECT * FROM {$this->table} WHERE fulfillment_status='retry' AND next_retry_at<=UTC_TIMESTAMP() ORDER BY id ASC LIMIT {$limit}",ARRAY_A);}
}
