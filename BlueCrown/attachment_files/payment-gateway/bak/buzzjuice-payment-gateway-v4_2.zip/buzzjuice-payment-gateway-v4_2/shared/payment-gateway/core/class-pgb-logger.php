<?php
if (!defined('ABSPATH')) exit;
class PGB_Logger {
    const DEBUG=10, INFO=20, WARNING=30, ERROR=40;
    private $dir;
    private $enabled;
    private $level;
    private $secrets=[];

    public function __construct() {
        $this->dir = BZJ_PGB_LOG_DIR;
        if (!is_dir($this->dir)) wp_mkdir_p($this->dir);
        $this->enabled = (bool)get_option('pgb_logging_enabled', false);
        $this->level = $this->level(get_option('pgb_log_level','info'));
        $this->secrets = array_filter([
            getenv('BZJ_PGB_SECRET') ?: '',
            getenv('WOWONDER_SERVER_KEY') ?: '',
            getenv('WOWONDER_ADMIN_PASSWORD') ?: '',
            getenv('WC_CONSUMER_SECRET') ?: ''
        ]);
    }
    private function level($v) {
        $v=strtolower((string)$v);
        return ['debug'=>self::DEBUG,'info'=>self::INFO,'warning'=>self::WARNING,'error'=>self::ERROR][$v] ?? self::INFO;
    }
    public function log($level,$message,$context=[],$file=null,$line=null) {
        if (!$this->enabled || $level < $this->level) return;
        $component = $file ? basename($file,'.php') : 'pgb';
        $path=$this->dir.'/'.$component.'.log';
        $ctx=$this->redact($context);
        $entry=['time'=>gmdate('c'),'level'=>strtoupper($this->name($level)),'message'=>(string)$message,'context'=>$ctx];
        if ($line) $entry['line']=(int)$line;
        @file_put_contents($path, wp_json_encode($entry, JSON_UNESCAPED_SLASHES).PHP_EOL, FILE_APPEND|LOCK_EX);
    }
    private function name($l){return [10=>'debug',20=>'info',30=>'warning',40=>'error'][$l]??'info';}
    private function redact($v) {
        if (is_array($v)) { $o=[]; foreach($v as $k=>$x){$lk=strtolower((string)$k); if(preg_match('/secret|token|password|cookie|authorization|signature|api_key|consumer_secret/',$lk)) $o[$k]='[REDACTED]'; else $o[$k]=$this->redact($x);} return $o; }
        if (is_object($v)) return $this->redact((array)$v);
        $s=(string)$v; foreach($this->secrets as $secret) if($secret!=='') $s=str_replace($secret,'[REDACTED]',$s);
        return strlen($s)>500 ? substr($s,0,497).'...' : $s;
    }
    public function debug($m,$c=[],$f=null,$l=null){$this->log(self::DEBUG,$m,$c,$f,$l);}
    public function info($m,$c=[],$f=null,$l=null){$this->log(self::INFO,$m,$c,$f,$l);}
    public function warning($m,$c=[],$f=null,$l=null){$this->log(self::WARNING,$m,$c,$f,$l);}
    public function error($m,$c=[],$f=null,$l=null){$this->log(self::ERROR,$m,$c,$f,$l);}
}
