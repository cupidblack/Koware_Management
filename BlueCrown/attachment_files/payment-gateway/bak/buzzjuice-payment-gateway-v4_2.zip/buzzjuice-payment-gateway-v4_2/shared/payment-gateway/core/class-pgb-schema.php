<?php
if (!defined('ABSPATH')) exit;
class PGB_Schema {
    public static function install() {
        global $wpdb;
        $table=$wpdb->prefix.'bzj_pgb_transactions';
        $charset=$wpdb->get_charset_collate();
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $sql="CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            pgb_transaction_id CHAR(36) NOT NULL,
            idempotency_key CHAR(64) NOT NULL,
            request_id CHAR(64) NOT NULL,
            wow_order_id VARCHAR(100) NOT NULL,
            wow_user_id BIGINT UNSIGNED NOT NULL,
            wp_user_id BIGINT UNSIGNED NOT NULL,
            woo_order_id BIGINT UNSIGNED NULL,
            transaction_type VARCHAR(32) NOT NULL,
            wow_post_id BIGINT UNSIGNED NULL,
            woo_product_id BIGINT UNSIGNED NULL,
            woo_variation_id BIGINT UNSIGNED NULL,
            currency VARCHAR(10) NOT NULL,
            requested_amount DECIMAL(20,8) NOT NULL DEFAULT 0,
            final_amount DECIMAL(20,8) NOT NULL DEFAULT 0,
            payment_status VARCHAR(32) NOT NULL DEFAULT 'pending',
            fulfillment_status VARCHAR(32) NOT NULL DEFAULT 'pending',
            affiliate_status VARCHAR(32) NOT NULL DEFAULT 'pending',
            integration_status VARCHAR(32) NOT NULL DEFAULT 'pending',
            retry_count INT UNSIGNED NOT NULL DEFAULT 0,
            next_retry_at DATETIME NULL,
            last_error TEXT NULL,
            payload LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY(id),
            UNIQUE KEY pgb_transaction_id(pgb_transaction_id),
            UNIQUE KEY idempotency_key(idempotency_key),
            UNIQUE KEY request_id(request_id),
            KEY woo_order_id(woo_order_id),
            KEY wow_order_id(wow_order_id),
            KEY fulfillment_queue(fulfillment_status,next_retry_at)
        ) {$charset};";
        dbDelta($sql);
        update_option('bzj_pgb_schema_version','4.2.0',false);
    }
}
