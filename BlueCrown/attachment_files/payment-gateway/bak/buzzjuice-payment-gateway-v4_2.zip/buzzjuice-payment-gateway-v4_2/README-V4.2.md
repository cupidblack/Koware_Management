# Buzzjuice Payment Gateway Bridge 4.2

## Deployment model
- One MU plugin: `wp-content/mu-plugins/bzj-payment-gateway.php`
- Shared engine: `shared/payment-gateway/`
- Streams remains the operational source for product mappings.
- WordPress/WooCommerce is authoritative for payment completion.
- `BZJ_PGB_SECRET` must exist in both PHP environments and must never be stored in the Streams admin UI.
- Logs are component-specific under `shared/payment-gateway/log/` and are controlled by `pgb_logging_enabled`.

## Important migration rule
Do not delete the existing `wow-pgb_sync.php` or `jewel-affiliate-webhook.php` until the regression suite passes.

## Required Streams admin change
Keep:
- `wow_payment`
- `wow_store_url`
- `wow_market_id`
- `wow_pro_package_id`
- `wow_pro_package_id_2`
- `wow_pro_package_id_3`
- `wow_pro_package_id_4`
- `wow_wallet_topup_id`
- `wow_crowdfund_id`

Retire from the payment form after migration:
- `wow_api_key`
- `wow_api_secret`
- `wow_webhook_secret`

`wow_store_url` becomes the WordPress/WooCommerce site URL used by the Streams client.

## Security
The Streams request signs:
`timestamp + "\n" + request_id + "\n" + raw_json_body`
with HMAC-SHA256 using `BZJ_PGB_SECRET`.

## State model
`pending -> paid -> processing -> completed`
or
`processing -> retry -> completed`
or
`processing -> failed`

The browser is not a payment-completion authority.

## Subscriptions
The bridge must not manually fabricate a subscription merely because a product is a subscription variation. WooCommerce Subscriptions must be allowed to create/manage subscriptions through the normal paid-order lifecycle. Any existing custom subscription code should therefore be removed only after confirming the installed Subscriptions hooks create the intended subscription for the actual mapped product.

## AffiliateWP
The addon resolves durable AffiliateWP customer/affiliate state from the purchasing WordPress user. It does not rely on browser cookies captured in Streams.

## Jewel
The supplied integration entry point is idempotent, but the legacy Jewel business rules must be migrated function-for-function before the old webhook is disabled. Do not treat a compact replacement as equivalent to the existing production webhook.

## Cutover status
This package is the refactored core implementation and migration base, not a blind production cutover. The two areas that must be regression-migrated against the live installation are the exact Jewel Affiliate business rules and the installed WooCommerce Subscriptions lifecycle. The old engines therefore remain in place until those tests pass.
