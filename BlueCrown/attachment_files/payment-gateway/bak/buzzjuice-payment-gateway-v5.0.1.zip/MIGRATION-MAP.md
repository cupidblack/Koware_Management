# v5.0.1 migration map

## Remove after cutover
- `streams/wow-pgb_webhook.php`
- `wp-content/plugins/blue-crown-wp/wow-pgb_sync/wow-pgb_sync.php`
- the old WooCommerce webhook that points to `streams/wow-pgb_webhook.php`

## Replace
- `streams/assets/wow-pgb/wow-pgb_init.php` with the thin client version in this package.

## Modify
- `streams/admin-panel/pages/payment-settings/content.phtml`: retain payment enablement and product IDs; remove the WooCommerce API key, API secret and webhook-secret fields after migration.
- any payment button handler: continue POSTing to `streams/assets/wow-pgb/wow-pgb_init.php`; do not call WooCommerce directly.
- if `container.phtml` or `extra_js/content.phtml` hard-codes Paystack/WooCommerce bridge URLs, replace only the initiation endpoint with the existing Streams init endpoint. No secret belongs in JS.

## Preserve
- `shared/db_helpers.php`
- existing Streams payment transaction schema
- WooCommerce products and subscription products
- AffiliateWP and its lifetime/recurring extensions
- Jewel mapping option `bz_rebate_mapping_json`

## Important
The v5.0.1 package intentionally does not delete the legacy files automatically. First run the regression checklist in `README.md`, then archive/remove the legacy bridge.


## Currency and subscription rule
- The client sends the transaction currency/amount that the existing Streams pricing layer has calculated. Do not add a second conversion formula to the PGB core.
- If the installed WooCommerce Currency Switcher changes the checkout currency, migrate the exact existing `wow-pgb_sync.php` conversion hook/function into a dedicated `pgb-addon-currency.php` before cutover. The package deliberately avoids guessing at a site-specific WOOCS configuration.
- The subscription addon uses the installed WooCommerce Subscriptions public API (`wcs_create_subscription`) and does not call the WooCommerce REST API. Verify the installed product type/schedule before enabling production cutover.
