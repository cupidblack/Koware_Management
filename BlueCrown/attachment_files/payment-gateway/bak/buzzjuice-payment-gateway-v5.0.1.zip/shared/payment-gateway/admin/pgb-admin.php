<?php
defined('ABSPATH') || exit;

/**
 * Locate the existing Blue Crown admin menu without assuming a hard-coded slug.
 * This keeps Payment Gateways inside the existing Blue Crown admin group.
 */
function bzj_pgb_find_blue_crown_parent_slug() {
    global $menu;

    if (!is_array($menu)) {
        return false;
    }

    foreach ($menu as $item) {
        if (!is_array($item) || empty($item[0]) || empty($item[2])) {
            continue;
        }

        $label = wp_strip_all_tags((string) $item[0]);

        if (strcasecmp(trim($label), 'Blue Crown') === 0) {
            return (string) $item[2];
        }
    }

    return false;
}

add_action('admin_menu', function () {
    $parent_slug = bzj_pgb_find_blue_crown_parent_slug();

    if (!$parent_slug) {
        // Do not create a competing top-level menu. The project requirement is
        // that this page lives in the existing Blue Crown administration group.
        error_log('[BZJ-PGB][admin] Existing Blue Crown admin menu was not found; Payment Gateways submenu was not registered.');
        return;
    }

    add_submenu_page(
        $parent_slug,
        'Payment Gateways',
        'Payment Gateways',
        'manage_options',
        'bzj-payment-gateways',
        'bzj_pgb_admin_page'
    );
}, 99);

add_action('admin_init', function () {
    register_setting('bzj_pgb', 'bzj_pgb_logging', [
        'type' => 'boolean',
        'default' => true,
        'sanitize_callback' => static function ($value) {
            return !empty($value);
        },
    ]);

    register_setting('bzj_pgb', 'bzj_pgb_log_level', [
        'type' => 'string',
        'default' => 'debug',
        'sanitize_callback' => static function ($value) {
            $value = strtolower(sanitize_key($value));
            return in_array($value, ['debug', 'info', 'warning', 'error', 'critical'], true) ? $value : 'debug';
        },
    ]);

    register_setting('bzj_pgb', 'bzj_pgb_streams_url', [
        'type' => 'string',
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ]);

    register_setting('bzj_pgb', 'bzj_pgb_streams_product_map', [
        'type' => 'array',
        'default' => [],
        'sanitize_callback' => static function ($value) {
            $value = is_array($value) ? $value : [];
            $allowed = [
                'wow_market_id',
                'wow_pro_package_id',
                'wow_pro_package_id_2',
                'wow_pro_package_id_3',
                'wow_pro_package_id_4',
                'wow_wallet_topup_id',
                'wow_crowdfund_id',
            ];

            $clean = [];
            foreach ($allowed as $key) {
                $clean[$key] = isset($value[$key]) ? absint($value[$key]) : 0;
            }

            return $clean;
        },
    ]);
});

function bzj_pgb_admin_page() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('You do not have permission to access this page.', 'buzzjuice'));
    }

    $map = (array) get_option('bzj_pgb_streams_product_map', []);
    ?>
    <div class="wrap">
        <h1>Buzzjuice Payment Gateways</h1>

        <form method="post" action="options.php">
            <?php settings_fields('bzj_pgb'); ?>

            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">Logging</th>
                    <td>
                        <label>
                            <input type="checkbox" name="bzj_pgb_logging" value="1" <?php checked((bool) get_option('bzj_pgb_logging', true), true); ?>>
                            Enabled
                        </label>
                        <p class="description">Disable routine PGB file logging after testing. Critical/error events still reach the server PHP error log.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="bzj_pgb_log_level">Log level</label></th>
                    <td>
                        <select id="bzj_pgb_log_level" name="bzj_pgb_log_level">
                            <?php foreach (['debug', 'info', 'warning', 'error', 'critical'] as $level) : ?>
                                <option value="<?php echo esc_attr($level); ?>" <?php selected(get_option('bzj_pgb_log_level', 'debug'), $level); ?>>
                                    <?php echo esc_html(ucfirst($level)); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="bzj_pgb_streams_url">Streams URL</label></th>
                    <td>
                        <input id="bzj_pgb_streams_url" class="regular-text" type="url" name="bzj_pgb_streams_url" value="<?php echo esc_attr(get_option('bzj_pgb_streams_url', '')); ?>">
                    </td>
                </tr>

                <?php
                $fields = [
                    'wow_market_id' => 'Marketplace product ID',
                    'wow_pro_package_id' => 'PRO package 1 product ID',
                    'wow_pro_package_id_2' => 'PRO package 2 product ID',
                    'wow_pro_package_id_3' => 'PRO package 3 product ID',
                    'wow_pro_package_id_4' => 'PRO package 4 product ID',
                    'wow_wallet_topup_id' => 'Wallet top-up product ID',
                    'wow_crowdfund_id' => 'Crowdfund product ID',
                ];

                foreach ($fields as $key => $label) :
                    ?>
                    <tr>
                        <th scope="row"><label for="bzj-pgb-<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></label></th>
                        <td>
                            <input id="bzj-pgb-<?php echo esc_attr($key); ?>" class="small-text" type="number" min="0" step="1" name="bzj_pgb_streams_product_map[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr(isset($map[$key]) ? $map[$key] : 0); ?>">
                        </td>
                    </tr>
                    <?php
                endforeach;
                ?>
            </table>

            <?php submit_button('Save Payment Gateway Settings'); ?>
        </form>

        <h2>Server secret</h2>
        <p>
            Set <code>BZJ_PGB_SECRET</code> in the server environment. It is deliberately not stored in WordPress options, Streams settings, JavaScript, WooCommerce metadata, or logs.
        </p>

        <h2>Diagnostics</h2>
        <p>
            Logs are stored in <code>shared/payment-gateway/log/</code>. The bootstrap log is <code>class-pgb-bootstrap.log</code>.
        </p>
    </div>
    <?php
}
