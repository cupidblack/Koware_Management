<?php
defined('ABSPATH') || exit;

if (!function_exists('bzj_pgb_config')) {
    function bzj_pgb_config() {
        $level = defined('BZJ_PGB_LOG_LEVEL')
            ? strtolower((string) BZJ_PGB_LOG_LEVEL)
            : strtolower((string) get_option('bzj_pgb_log_level', 'debug'));

        $enabled = defined('BZJ_PGB_LOGGING')
            ? (bool) BZJ_PGB_LOGGING
            : (bool) get_option('bzj_pgb_logging', true);

        return [
            'logging_enabled' => $enabled,
            'log_level' => in_array($level, ['debug', 'info', 'warning', 'error', 'critical'], true) ? $level : 'debug',
            'secret' => defined('BZJ_PGB_SECRET') ? (string) BZJ_PGB_SECRET : (string) getenv('BZJ_PGB_SECRET'),
            'timestamp_tolerance' => 300,
            'http_timeout' => 20,
            'lock_timeout' => 10,
            'streams_url' => untrailingslashit((string) get_option('bzj_pgb_streams_url', get_option('wowonder_url', ''))),
            'social_url' => untrailingslashit((string) get_option('buzzsocial_url', '')),
        ];
    }
}
