<?php
defined('ABSPATH') || exit;

require_once BZJ_PGB_ROOT . 'config/pgb-config.php';
require_once BZJ_PGB_ROOT . 'core/class-pgb-logger.php';
require_once BZJ_PGB_ROOT . 'core/class-pgb-auth.php';
require_once BZJ_PGB_ROOT . 'core/class-pgb-validator.php';
require_once BZJ_PGB_ROOT . 'core/class-pgb-schema.php';
require_once BZJ_PGB_ROOT . 'core/class-pgb-idempotency.php';
require_once BZJ_PGB_ROOT . 'core/class-pgb-order.php';
require_once BZJ_PGB_ROOT . 'core/class-pgb-fulfillment.php';
require_once BZJ_PGB_ROOT . 'core/class-pgb-manager.php';

class PGB_Bootstrap {
    private static $instance = null;

    /** @var PGB_Logger */
    public $log;

    /** @var PGB_Manager|null */
    public $manager = null;

    private $components_loaded = false;
    private $admin_loaded = false;
    private $hooks_registered = false;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct() {
        // The logger must be created before any WooCommerce dependency check so
        // bootstrap failures can be diagnosed independently of WooCommerce.
        $this->log = new PGB_Logger('class-pgb-bootstrap');

        $this->log->info('PGB bootstrap reached plugins_loaded', [
            'version' => defined('BZJ_PGB_VERSION') ? BZJ_PGB_VERSION : 'unknown',
            'woocommerce_loaded' => class_exists('WooCommerce'),
            'root' => BZJ_PGB_ROOT,
        ]);

        // Schema and admin settings are WordPress concerns and must not depend
        // on WooCommerce being active for the current request.
        try {
            PGB_Schema::install();
            $this->log->info('PGB database schema check completed');
        } catch (Throwable $e) {
            $this->log->critical('PGB schema installation failed', [
                'error' => $e->getMessage(),
            ]);
        }

        $this->load_components();
        $this->ensure_options();
        $this->register_wordpress_hooks();

        if (!class_exists('WooCommerce')) {
            $this->log->warning('WooCommerce is not loaded at plugins_loaded; payment hooks are deferred.');
            add_action('woocommerce_init', [$this, 'on_woocommerce_ready'], 1);
            return;
        }

        $this->on_woocommerce_ready();
    }

    private function register_wordpress_hooks() {
        if ($this->hooks_registered) {
            return;
        }

        $this->hooks_registered = true;

        add_action('rest_api_init', [$this, 'register_rest']);
    }

    public function on_woocommerce_ready() {
        if (!$this->manager) {
            $this->manager = new PGB_Manager(
                $this->log,
                new PGB_Idempotency($this->log),
                new PGB_Order($this->log),
                new PGB_Fulfillment($this->log)
            );
        }

        if (!class_exists('WooCommerce')) {
            $this->log->warning('WooCommerce readiness callback fired but WooCommerce class is unavailable.');
            return;
        }

        if (!has_action('woocommerce_payment_complete', [$this, 'paid'])) {
            add_action('woocommerce_payment_complete', [$this, 'paid'], 20, 1);
        }

        if (!has_action('woocommerce_order_status_processing', [$this, 'status_paid'])) {
            add_action('woocommerce_order_status_processing', [$this, 'status_paid'], 20, 1);
        }

        if (!has_action('woocommerce_order_status_completed', [$this, 'status_paid'])) {
            add_action('woocommerce_order_status_completed', [$this, 'status_paid'], 20, 1);
        }

        $this->log->info('WooCommerce payment lifecycle hooks registered');
    }

    private function load_components() {
        if ($this->components_loaded) {
            return;
        }

        $this->components_loaded = true;

        $addons = glob(BZJ_PGB_ROOT . 'addons/pgb-addon-*.php');
        $integrations = glob(BZJ_PGB_ROOT . 'integrations/pgb-int-*.php');

        foreach (array_merge($addons ?: [], $integrations ?: []) as $file) {
            if (!is_readable($file)) {
                $this->log->warning('PGB component is not readable', ['file' => $file]);
                continue;
            }

            try {
                require_once $file;
                $this->log->debug('PGB component loaded', ['file' => basename($file)]);
            } catch (Throwable $e) {
                $this->log->critical('PGB component failed to load', [
                    'file' => basename($file),
                    'error' => $e->getMessage(),
                ]);
            }
        }

        $admin = BZJ_PGB_ROOT . 'admin/pgb-admin.php';
        if (is_readable($admin)) {
            try {
                require_once $admin;
                $this->admin_loaded = true;
                $this->log->debug('PGB admin component loaded');
            } catch (Throwable $e) {
                $this->log->critical('PGB admin component failed to load', [
                    'error' => $e->getMessage(),
                ]);
            }
        } else {
            $this->log->warning('PGB admin component is missing or unreadable', ['file' => $admin]);
        }
    }

    public function register_rest() {
        register_rest_route('bzj-pgb/v1', '/order', [
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => '__return_true',
            'callback' => [$this, 'rest_order'],
        ]);
    }

    public function rest_order(WP_REST_Request $request) {
        $raw = $request->get_body();
        $auth = PGB_Auth::verify($request, $raw, $this->log);

        if (is_wp_error($auth)) {
            return $auth;
        }

        $json = json_decode($raw, true);
        if (!is_array($json)) {
            return new WP_Error('pgb_json', 'Invalid JSON.', ['status' => 400]);
        }

        $data = PGB_Validator::request($json);
        if (is_wp_error($data)) {
            return $data;
        }

        if (!$this->manager) {
            $this->log->error('Payment initiation requested before WooCommerce manager was ready', [
                'wow_order_id' => $data['wow_order_id'] ?? '',
            ]);

            return new WP_Error(
                'pgb_woocommerce_unavailable',
                'WooCommerce payment services are not currently available.',
                ['status' => 503]
            );
        }

        try {
            $order = $this->manager->create_order($data);

            $this->log->info('Payment initiation accepted', [
                'woo_order_id' => $order->get_id(),
                'wow_order_id' => $data['wow_order_id'],
            ]);

            return new WP_REST_Response([
                'status' => 200,
                'woo_order_id' => $order->get_id(),
                'wow_order_id' => $data['wow_order_id'],
                'payment_url' => $order->get_checkout_payment_url(),
                'order_key' => $order->get_order_key(),
            ], 200);
        } catch (Throwable $e) {
            $this->log->error('Payment initiation failed', [
                'error' => $e->getMessage(),
                'wow_order_id' => $data['wow_order_id'],
            ]);

            return new WP_Error(
                'pgb_order_create',
                'Unable to create payment order.',
                ['status' => 500]
            );
        }
    }

    public function paid($id) {
        if ($this->manager) {
            $this->manager->handle_paid($id, 'woocommerce_payment_complete');
        }
    }

    public function status_paid($id) {
        if ($this->manager) {
            $this->manager->handle_paid($id, 'woocommerce_status_transition');
        }
    }

    private function ensure_options() {
        // Logging defaults to enabled on first installation so a fresh
        // deployment is diagnosable. Once the admin saves the setting, false
        // remains a valid explicit choice.
        if (get_option('bzj_pgb_logging', null) === null) {
            add_option('bzj_pgb_logging', true, '', false);
        }

        if (get_option('bzj_pgb_log_level', null) === null) {
            add_option('bzj_pgb_log_level', 'debug', '', false);
        }

        if (get_option('bzj_pgb_streams_product_map', null) === null) {
            add_option('bzj_pgb_streams_product_map', [
                'wow_market_id' => (int) get_option('wow_market_id', 0),
                'wow_pro_package_id' => (int) get_option('wow_pro_package_id', 0),
                'wow_pro_package_id_2' => (int) get_option('wow_pro_package_id_2', 0),
                'wow_pro_package_id_3' => (int) get_option('wow_pro_package_id_3', 0),
                'wow_pro_package_id_4' => (int) get_option('wow_pro_package_id_4', 0),
                'wow_wallet_topup_id' => (int) get_option('wow_wallet_topup_id', 0),
                'wow_crowdfund_id' => (int) get_option('wow_crowdfund_id', 0),
            ], '', false);
        }
    }
}
