<?php
defined('ABSPATH') || exit;

class PGB_Logger {
    private $component;
    private $file;
    private $enabled;
    private $min_level;
    private static $levels = [
        'debug' => 0,
        'info' => 1,
        'warning' => 2,
        'error' => 3,
        'critical' => 4,
    ];

    public function __construct($component) {
        $this->component = preg_replace('/[^A-Za-z0-9_.-]/', '-', (string) $component);

        $cfg = function_exists('bzj_pgb_config') ? bzj_pgb_config() : [
            'logging_enabled' => true,
            'log_level' => 'debug',
        ];

        $this->enabled = (bool) ($cfg['logging_enabled'] ?? true);
        $this->min_level = isset(self::$levels[$cfg['log_level'] ?? 'debug'])
            ? $cfg['log_level']
            : 'debug';

        $dir = trailingslashit(BZJ_PGB_ROOT) . 'log/';

        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
        }

        $this->file = $dir . $this->component . '.log';

        // Touch the component log on bootstrap so the presence/permissions of
        // the logging directory can be diagnosed even before the first event.
        if (!file_exists($this->file)) {
            @touch($this->file);
        }
    }

    public function log($level, $message, array $context = []) {
        $level = strtolower((string) $level);

        if (!isset(self::$levels[$level])) {
            return;
        }

        // Server error_log remains active for error/critical events even when
        // file logging is deliberately disabled. This prevents a logging toggle
        // from hiding a fatal bridge problem.
        $safe = $this->sanitize($context);

        if (in_array($level, ['error', 'critical'], true)) {
            error_log('[BZJ-PGB][' . $this->component . '][' . $level . '] ' . (string) $message);
        }

        if (!$this->enabled || self::$levels[$level] < self::$levels[$this->min_level]) {
            return;
        }

        $line = wp_json_encode([
            'time' => gmdate('c'),
            'level' => $level,
            'component' => $this->component,
            'message' => (string) $message,
            'context' => $safe,
        ], JSON_UNESCAPED_SLASHES);

        if ($line !== false) {
            @file_put_contents($this->file, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
        }
    }

    public function debug($message, array $context = []) {
        $this->log('debug', $message, $context);
    }

    public function info($message, array $context = []) {
        $this->log('info', $message, $context);
    }

    public function warning($message, array $context = []) {
        $this->log('warning', $message, $context);
    }

    public function error($message, array $context = []) {
        $this->log('error', $message, $context);
    }

    public function critical($message, array $context = []) {
        $this->log('critical', $message, $context);
    }

    private function sanitize($value) {
        if (is_array($value)) {
            $out = [];

            foreach ($value as $key => $item) {
                $lower_key = strtolower((string) $key);

                if (preg_match('/secret|token|cookie|password|authorization|signature|consumer_key|consumer_secret|api_key|api_secret/i', $lower_key)) {
                    $out[$key] = '[redacted]';
                    continue;
                }

                $out[$key] = $this->sanitize($item);
            }

            return $out;
        }

        if (is_object($value)) {
            return '[object]';
        }

        if (is_string($value) && strlen($value) > 1000) {
            return substr($value, 0, 997) . '...';
        }

        return $value;
    }
}
