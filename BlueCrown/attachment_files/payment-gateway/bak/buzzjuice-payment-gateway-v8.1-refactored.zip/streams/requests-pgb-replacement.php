<?php
/* Replace the existing BlueCrown PGB block in streams/requests.php with this block. */
if ($f === 'payment' && isset($_POST['payment_type']) && $_POST['payment_type'] === 'wow_payment') {
    require_once dirname(__DIR__) . '/shared/payment-gateway/pgb-client-streams.php';
    $result = pgb_streams_create_pending($_POST, $wo, $sqlConnect);
    http_response_code((int)($result['status'] ?? 500));
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($result);
    exit();
}
