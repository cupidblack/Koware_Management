-- Additive migration. Run after confirming the existing Wo_Payment_Transactions schema.
ALTER TABLE Wo_Payment_Transactions ADD COLUMN pgb_state VARCHAR(32) NULL;
ALTER TABLE Wo_Payment_Transactions ADD COLUMN pgb_fulfilled_at DATETIME NULL;
ALTER TABLE Wo_Payment_Transactions ADD COLUMN pgb_last_error TEXT NULL;
ALTER TABLE Wo_Payment_Transactions ADD INDEX idx_pgb_state (pgb_state);
ALTER TABLE Wo_Payment_Transactions ADD INDEX idx_woo_order_id (woo_order_id);
