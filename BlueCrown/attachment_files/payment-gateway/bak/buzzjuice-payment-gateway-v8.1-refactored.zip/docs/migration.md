# Migration sequence

1. Back up both WordPress and WoWonder databases and the existing payment files.
2. Add the columns in `schema.sql` after inspecting the exact current table definition.
3. Configure `BUZZ_PGB_SECRET` in the server environment on both runtimes.
4. Create the Woo-side product mapping options:
   * `bzj_pgb_product_wow_market_id`
   * `bzj_pgb_product_wow_pro_package_id`
   * `bzj_pgb_product_wow_wallet_topup_id`
   * `bzj_pgb_product_wow_crowdfund_id`
   These must point to the actual WooCommerce product/variation IDs. For subscription products, use the subscription product/variation that WooCommerce Subscriptions recognizes.
5. Install `wp-content/mu-plugins/bzj-pgb-engine.php`. Keep **no subfolders** under `mu-plugins`.
6. Copy `shared/payment-gateway` to the server.
7. Replace the old Streams `wow-pgb_init.php` path with the new client call from `requests.php`.
8. Remove WooCommerce API key/secret fields from the Buzzjuice Streams PGB settings UI after the new flow is verified.
9. Do not delete the old sync/webhook until the test matrix below passes. Disable them after cutover, then archive them outside webroot.
10. Test: PRO, WALLET, DONATE, PRODUCT/PURCHASE, failed payment, cancelled payment, duplicate browser refresh, duplicate Woo hook execution, subscription creation/activation, AffiliateWP referral, currency conversion, and Jewel integration.
11. Only after successful production verification remove:
    * `streams/assets/wow-pgb/wow-pgb_init.php`
    * `streams/wow-pgb_webhook.php`
    * `wp-content/plugins/blue-crown-wp/wow-pgb_sync/wow-pgb_sync.php`
    * `wp-content/mu-plugins/buzzjuice-affwp-order-complete.php`
