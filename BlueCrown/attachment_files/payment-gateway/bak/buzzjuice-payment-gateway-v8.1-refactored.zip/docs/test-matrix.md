# Production test matrix

| Test | Expected result |
|---|---|
| PRO first payment | Pending Streams row → Woo subscription checkout → paid hook → subscription activated by Woo Subscriptions |
| Wallet | Paid hook increments wallet exactly once |
| Donate | Funding contribution recorded exactly once |
| Product/Purchase | Purchase/owner accounting occurs only after paid confirmation |
| Failed payment | Streams row becomes failed; no fulfillment |
| Cancelled order | Streams row becomes cancelled; no fulfillment |
| Browser refresh before payment | Same Woo order is reused; no duplicate order |
| Woo payment hook repeated | Fulfillment remains one-time |
| AffiliateWP | One referral for the Woo order |
| Jewel | One signed paid event |
| Logging OFF | No PGB application logs |
| Logging ON | Source-specific logs appear |
