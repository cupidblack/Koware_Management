# Buzzjuice Payment Gateway Bridge 8.1

## Runtime architecture

Streams (authenticated) → `requests.php` → `pgb-client-streams.php` → pending row in `Wo_Payment_Transactions` → browser redirect with HMAC → WordPress MU engine → native WooCommerce order → native checkout/payment → WooCommerce payment hooks → PGB fulfillment → Streams database.

No Streams-side cURL call to WooCommerce is required.

## Security model

* `BUZZ_PGB_SECRET` is the shared HMAC secret in the server environment.
* The browser receives only an order ID and HMAC token.
* The WordPress REST endpoint never accepts product price, product ID, user ID, or affiliate ID from the browser.
* WooCommerce product IDs are configured on the WordPress side.
* Do not use `Access-Control-Allow-Origin: *`.
* Do not put WooCommerce consumer keys/secrets in Streams payment settings for this bridge.

## Logs

Every source file gets its own log, e.g. `log/class-pgb-manager.log`. Logging is off by default and controlled in **Buzzjuice → Payment Gateways**.

## Important

The existing `Wo_Payment_Transactions` table must contain the legacy fields used by the current installation plus the new PGB fields listed in `docs/schema.sql`. The migration is additive.
