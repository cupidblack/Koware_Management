<?php
/**
 * Streams-side client. It must be included from the authenticated WoWonder
 * request handler; it never calls WooCommerce REST API.
 */
require_once dirname(__DIR__) . '/db_helpers.php';
if (!function_exists('pgb_streams_create_pending')) {
function pgb_streams_create_pending(array $input, array $wo, $sqlConnect) {
    if (empty($wo['loggedin']) || empty($wo['user']['user_id'])) return ['status'=>400,'message'=>'Authentication required.'];
    $userid=(int)$wo['user']['user_id'];
    $kind=strtoupper(preg_replace('/[^A-Z_]/','',(string)($input['transaction_kind']??'')));
    $allowed=['PRO','WALLET','DONATE','PRODUCT','PURCHASE'];
    if(!in_array($kind,$allowed,true))return ['status'=>400,'message'=>'Invalid transaction type.'];
    $price=(float)($input['product_price']??0);$qty=max(1,(int)($input['product_units']??1));$amount=round($price*$qty,2);
    if($price<=0 || $amount<=0)return ['status'=>400,'message'=>'Invalid amount.'];
    $currency=strtoupper(preg_replace('/[^A-Z]/','',(string)($input['wow_currency_code']??$wo['config']['currency']??'GHS')));
    if(strlen($currency)!==3)return ['status'=>400,'message'=>'Invalid currency.'];
    $wow_order_id='wow_'.bin2hex(random_bytes(16));
    $notes='Buzzjuice PGB v8 initiation';
    $stmt=$sqlConnect->prepare("INSERT INTO Wo_Payment_Transactions (userid,amount,order_id,kind,currency_code,payment_status,notes,transaction_dt) VALUES (?,?,?,?,?,?,?,NOW())");
    if(!$stmt)return ['status'=>500,'message'=>'Could not prepare payment transaction.'];
    $status='pending';$stmt->bind_param('idsssss',$userid,$amount,$wow_order_id,$kind,$currency,$status,$notes);
    if(!$stmt->execute()){ $stmt->close();return ['status'=>500,'message'=>'Could not store payment transaction.']; }
    $stmt->close();
    // Shared secret is required only for HMAC handoff. It is never returned to the browser.
    $secret=getenv('BUZZ_PGB_SECRET');
    if(!$secret && defined('BUZZ_PGB_SECRET'))$secret=BUZZ_PGB_SECRET;
    if(!$secret)return ['status'=>500,'message'=>'Payment bridge secret is not configured.'];
    $token=hash_hmac('sha256',$wow_order_id,$secret);
    $base=rtrim((string)($wo['config']['wow_store_url']??getenv('WP_BASE_SITE_URL')), '/');
    $url=$base.'/wp-json/bzj-pgb/v1/checkout?order='.rawurlencode($wow_order_id).'&token='.rawurlencode($token);
    return ['status'=>200,'url'=>$url,'wow_order_id'=>$wow_order_id];
}}
if(php_sapi_name()!=='cli' && basename($_SERVER['SCRIPT_FILENAME']??'')===basename(__FILE__)){
    require_once dirname(__DIR__,2).'/streams/config.php';
}
