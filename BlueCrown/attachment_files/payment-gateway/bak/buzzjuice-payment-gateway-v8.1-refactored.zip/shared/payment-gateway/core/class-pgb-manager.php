<?php
defined('ABSPATH') || exit;
class PGB_Manager {
    private static $instance; private $db; private $logger;
    public static function instance(){ return self::$instance ?: (self::$instance=new self); }
    private function __construct(){ $this->logger=PGB_Logger::instance(); $this->db=new PGB_Streams_DB(); }
    public function register_hooks() {
        add_action('woocommerce_payment_complete',[$this,'payment_complete'],20);
        add_action('woocommerce_order_status_completed',[$this,'status_completed'],20);
        add_action('woocommerce_order_status_processing',[$this,'status_processing'],20);
        add_action('woocommerce_order_status_failed',[$this,'status_failed'],20);
        add_action('woocommerce_order_status_cancelled',[$this,'status_cancelled'],20);
    }
    public function checkout_from_streams(WP_REST_Request $r) {
        $id=sanitize_text_field((string)$r->get_param('order'));
        $token=(string)$r->get_param('token');
        if(!$id || !PGB_Order::verify_token($id,$token)) return new WP_Error('pgb_auth','Invalid payment handoff.', ['status'=>403]);
        $row=$this->db->get($id);
        if(!$row) return new WP_Error('pgb_not_found','Payment transaction not found.',['status'=>404]);
        if(!empty($row['woo_order_id'])) {
            $order=wc_get_order((int)$row['woo_order_id']);
            if($order) return new WP_REST_Response(['status'=>'success','checkout_url'=>$order->get_checkout_payment_url(),'woo_order_id'=>$order->get_id()],200);
        }
        try {
            $order=$this->create_order($row);
            $this->db->update($id,['woo_order_id'=>$order->get_id(),'pgb_state'=>'woo_order_created','pgb_last_error'=>'']);
            $this->logger->info('WooCommerce order created',['wow_order_id'=>$id,'woo_order_id'=>$order->get_id()],__FILE__);
            return new WP_REST_Response(['status'=>'success','checkout_url'=>$order->get_checkout_payment_url(),'woo_order_id'=>$order->get_id()],200);
        } catch(Throwable $e) {
            $this->db->update($id,['pgb_state'=>'error','pgb_last_error'=>$e->getMessage()]);
            $this->logger->error('Checkout order creation failed',['wow_order_id'=>$id,'error'=>$e->getMessage()],__FILE__);
            return new WP_Error('pgb_create_failed','Unable to prepare checkout.',['status'=>500]);
        }
    }
    public function status_from_streams(WP_REST_Request $r) {
        $id=sanitize_text_field((string)$r->get_param('order'));$token=(string)$r->get_param('token');
        if(!$id || !PGB_Order::verify_token($id,$token)) return new WP_Error('pgb_auth','Invalid payment handoff.',['status'=>403]);
        $row=$this->db->get($id); if(!$row)return new WP_Error('pgb_not_found','Not found.',['status'=>404]);
        return new WP_REST_Response(['status'=>'success','payment_status'=>$row['payment_status']??'pending','pgb_state'=>$row['pgb_state']??'pending','woo_order_id'=>$row['woo_order_id']??''],200);
    }
    private function create_order($row) {
        if(!function_exists('wc_create_order')) throw new RuntimeException('WooCommerce is unavailable.');
        $woo_user=$this->db->find_user_wp_id((int)$row['userid']);
        if(!$woo_user) throw new RuntimeException('Mapped WordPress user not found.');
        $kind=strtoupper((string)$row['kind']);
        $product_id=$this->product_id_for_kind($kind);
        if(!$product_id) throw new RuntimeException('No WooCommerce product configured for transaction kind '.$kind.'.');
        $product=wc_get_product($product_id); if(!$product)throw new RuntimeException('Configured product does not exist.');
        $order=wc_create_order(['customer_id'=>$woo_user,'created_via'=>'buzzjuice_pgb']);
        $qty=max(1,(int)($row['quantity']??1));
        $order->add_product($product,$qty);
        $order->set_currency(strtoupper((string)$row['currency_code'] ?: get_woocommerce_currency()));
        $order->set_customer_id($woo_user);
        $order->update_meta_data('wow_order_id',(string)$row['order_id']);
        $order->update_meta_data('wow_user_id',(string)$row['userid']);
        $order->update_meta_data('_buzzjuice_origin','streams');
        $order->update_meta_data('_buzzjuice_pgb_version',BZJ_PGB_VERSION);
        $order->calculate_totals();
        $order->save();
        return $order;
    }
    private function product_id_for_kind($kind) {
        $map=['PURCHASE'=>'wow_market_id','PRODUCT'=>'wow_market_id','SALE'=>'wow_market_id','PRO'=>'wow_pro_package_id','WALLET'=>'wow_wallet_topup_id','DONATE'=>'wow_crowdfund_id'];
        $key=$map[$kind]??null; if(!$key)return 0;
        $id=0;
        // These values remain controlled in Streams. For Woo-side creation use WordPress options first.
        $id=(int)get_option('bzj_pgb_product_'.$key,0);
        if(!$id && defined('BUZZ_PGB_'.$key))$id=(int)constant('BUZZ_PGB_'.$key);
        return $id;
    }
    private function process_paid($order,$reason) {
        $wow_id=(string)PGB_Order::meta($order,'wow_order_id','');
        if(!$wow_id)return;
        $row=$this->db->get($wow_id); if(!$row)return;
        if(($row['pgb_fulfilled_at']??'')!=='') { $this->logger->debug('Fulfillment already complete',['wow_order_id'=>$wow_id],__FILE__); return; }
        $status=$order->get_status();
        if(!in_array($status,['processing','completed'],true) && !$order->is_paid())return;
        $this->db->update($wow_id,['payment_status'=>$status,'payment_method'=>$order->get_payment_method(),'amount'=>(float)$order->get_total(),'transaction_dt'=>current_time('mysql',true),'pgb_state'=>'paid']);
        do_action('bzj_pgb_paid',$order,$row);
        $this->db->update($wow_id,['pgb_state'=>'fulfilled','pgb_fulfilled_at'=>current_time('mysql',true)]);
        $this->logger->info('Paid order fulfilled',['wow_order_id'=>$wow_id,'woo_order_id'=>$order->get_id(),'reason'=>$reason],__FILE__);
        $this->redirect_streams_after_payment($order,$row);
    }
    public function payment_complete($order_id){$o=wc_get_order($order_id);if($o)$this->process_paid($o,'payment_complete');}
    public function status_completed($order_id){$o=wc_get_order($order_id);if($o)$this->process_paid($o,'completed');}
    public function status_processing($order_id){$o=wc_get_order($order_id);if($o && $o->is_paid())$this->process_paid($o,'processing');}
    public function status_failed($order_id){$o=wc_get_order($order_id);if(!$o)return;$id=PGB_Order::meta($o,'wow_order_id','');if($id)$this->db->update($id,['payment_status'=>'failed','pgb_state'=>'failed']);}
    public function status_cancelled($order_id){$o=wc_get_order($order_id);if(!$o)return;$id=PGB_Order::meta($o,'wow_order_id','');if($id)$this->db->update($id,['payment_status'=>'cancelled','pgb_state'=>'cancelled']);}
    private function redirect_streams_after_payment($order,$row) {
        $url=PGB_Config::streams_url(); if(!$url)return;
        $target=$url.'/index.php?link1=purchased';
        // Never perform an HTTP server-to-server request. The browser returns here from WooCommerce.
        $order->update_meta_data('_buzzjuice_return_url',$target); $order->save();
    }
    public static function render_admin_page() {
        if(!current_user_can('manage_options'))return;
        ?>
        <div class="wrap"><h1>Buzzjuice → Payment Gateways</h1>
        <form method="post" action="options.php"><?php settings_fields('bzj_pgb_settings'); ?>
        <table class="form-table">
        <tr><th>Enable detailed logging</th><td><input type="checkbox" name="bzj_pgb_logging_enabled" value="1" <?php checked(PGB_Config::logging_enabled()); ?>></td></tr>
        <tr><th>Minimum log level</th><td><select name="bzj_pgb_log_level">
        <?php foreach(['debug','info','warning','error','critical'] as $v): ?><option value="<?php echo esc_attr($v); ?>" <?php selected(PGB_Config::log_level(),$v); ?>><?php echo esc_html(ucfirst($v)); ?></option><?php endforeach; ?>
        </select></td></tr></table><?php submit_button('Save Payment Gateway Settings'); ?></form>
        <p><strong>Bridge:</strong> <?php echo esc_html(BZJ_PGB_VERSION); ?> · <strong>Logs:</strong> <?php echo esc_html(BZJ_PGB_LOG); ?></p></div>
        <?php
    }
}
