<?php
/**
 * Buzzjuice Streams Payment Gateway initializer.
 *
 * v15: the Streams-side transaction preparation remains here, while the
 * WooCommerce REST/cURL section is replaced by the shared PGB client.
 */

require_once dirname(__DIR__, 2) . '/config.php';
require_once dirname(__DIR__) . '/init.php';

if (empty($wo['loggedin'])) {
    $redirect_url = $wo['config']['site_url'] . '/login?redirect_url=' . urlencode($_SERVER['REQUEST_URI']);
    if (!headers_sent()) {
        header('Location: ' . $redirect_url);
    } else {
        echo '<script>window.location.href=' . json_encode($redirect_url) . ';</script>';
    }
    exit;
}

require_once dirname(__DIR__, 2) . '/../../shared/payment-gateway/pgb-client-streams.php';

header('Content-Type: application/json; charset=UTF-8');

try {
    $input = $_POST;

    $result = bzj_pgb_streams_init([
        'amount' => $input['amount'] ?? 0,
        'product_name' => $input['product_name'] ?? 'Product',
        'product_price' => $input['product_price'] ?? 0,
        'product_units' => $input['product_units'] ?? 1,
        'product_owner_id' => $input['product_owner_id'] ?? 0,
        'transaction_kind' => $input['transaction_kind'] ?? '',
        'wow_currency_code' => $input['wow_currency_code'] ?? 'GHS',
        'wow_post_id' => $input['wow_post_id'] ?? 0,
        'product_id' => $input['product_id'] ?? 0,
        'variation_id' => $input['variation_id'] ?? 0,
    ]);

    echo json_encode($result);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Unable to start payment.',
    ]);

    error_log('[BZJ-PGB] Streams init error: ' . $e->getMessage());
}
