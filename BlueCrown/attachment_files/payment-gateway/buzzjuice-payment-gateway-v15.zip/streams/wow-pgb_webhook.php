<?php
/**
 * DEPRECATED in Payment Gateway Bridge v15.
 *
 * Payment completion is now handled by WordPress/WooCommerce hooks in the
 * single MU plugin: wp-content/mu-plugins/bzj-payment-gateway.php.
 *
 * Keep this file during migration only. Do not register it as a webhook
 * endpoint for new orders.
 */

http_response_code(410);
header('Content-Type: application/json; charset=UTF-8');
echo json_encode([
    'status' => 'deprecated',
    'message' => 'Use the Buzzjuice Payment Gateway Bridge v15.',
]);
