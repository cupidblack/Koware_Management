<?php
if (!defined('ABSPATH')) exit;

/**
 * WooCommerce uses CRUD objects, keeping the bridge compatible with HPOS.
 * Do not query wp_posts/wp_postmeta directly for orders.
 */
