<?php
if (!defined('ABSPATH')) exit;

/**
 * Streams integration is intentionally database-based.
 * No wp-load.php is included into Streams and no Streams HTTP callback is required.
 */
