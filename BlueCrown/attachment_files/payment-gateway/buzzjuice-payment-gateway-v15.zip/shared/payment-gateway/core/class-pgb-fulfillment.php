<?php
if (!defined('ABSPATH')) exit;

if (!class_exists('BZJ_PGB_Fulfillment')) {
class BZJ_PGB_Fulfillment {
    private $logger;
    private $streams;

    public function __construct($logger, $streams) {
        $this->logger = $logger;
        $this->streams = $streams;
    }

    public function process($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            throw new RuntimeException('WooCommerce order not found.');
        }

        if ($order->get_meta('_bzj_pgb_fulfilled', true)) {
            return true;
        }

        if (!in_array($order->get_status(), ['processing', 'completed'], true)) {
            return false;
        }

        $bridge_id = absint($order->get_meta('_bzj_pgb_bridge_id', true));
        $wow_order_id = (string)$order->get_meta('wow_order_id', true);
        $wow_user_id = absint($order->get_meta('wow_user_id', true));

        if (!$bridge_id || !$wow_order_id || !$wow_user_id) {
            throw new RuntimeException('Required Buzzjuice payment metadata is missing.');
        }

        $this->run_addons($order);

        $order->update_meta_data('_bzj_pgb_fulfilled', gmdate('c'));
        $order->update_meta_data('_bzj_pgb_fulfillment_version', BZJ_PGB_VERSION);
        $order->save();

        $this->streams->mark_fulfilled($bridge_id, $order->get_id());

        $this->logger->log(__FILE__, 'Fulfillment completed', [
            'woo_order_id' => $order->get_id(),
            'wow_order_id' => $wow_order_id,
            'bridge_id' => $bridge_id,
        ]);

        do_action('bzj_pgb_fulfilled', $order);

        return true;
    }

    private function run_addons($order) {
        $callbacks = apply_filters('bzj_pgb_fulfillment_callbacks', []);
        foreach ($callbacks as $name => $callback) {
            if (!is_callable($callback)) continue;

            try {
                call_user_func($callback, $order, $this->logger);
            } catch (Throwable $e) {
                $this->logger->exception(__FILE__, $e, ['addon' => $name, 'order_id' => $order->get_id()]);
                throw $e;
            }
        }
    }
}
}
