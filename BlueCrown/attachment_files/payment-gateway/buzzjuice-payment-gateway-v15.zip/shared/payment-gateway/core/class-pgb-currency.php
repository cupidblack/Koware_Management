<?php
if (!defined('ABSPATH')) exit;

if (!class_exists('BZJ_PGB_Currency')) {
class BZJ_PGB_Currency {
    private $logger;

    public function __construct($logger) {
        $this->logger = $logger;
    }

    public function resolve($requested, $amount) {
        $source = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)$requested));
        $target = $this->detect_target_currency();

        if (!$source) {
            $source = get_woocommerce_currency();
        }
        if (!$target) {
            $target = get_woocommerce_currency();
        }

        if ($source === $target) {
            return [
                'source_currency' => $source,
                'target_currency' => $target,
                'source_amount' => (float)$amount,
                'target_amount' => (float)wc_format_decimal($amount, wc_get_price_decimals()),
                'rate' => 1.0,
            ];
        }

        $rates = $this->get_woocs_rates();
        if (!isset($rates[$source], $rates[$target])) {
            throw new RuntimeException("WOOCS rate unavailable for {$source} -> {$target}.");
        }

        $source_rate = (float)$rates[$source];
        $target_rate = (float)$rates[$target];

        if ($source_rate <= 0 || $target_rate <= 0) {
            throw new RuntimeException('Invalid WOOCS currency rate.');
        }

        $base_amount = (float)$amount / $source_rate;
        $converted = $base_amount * $target_rate;
        $effective_rate = $converted / max((float)$amount, 0.00000001);

        $this->logger->log(__FILE__, 'Currency converted', [
            'source_currency' => $source,
            'target_currency' => $target,
            'source_amount' => (float)$amount,
            'target_amount' => $converted,
            'rate' => $effective_rate,
        ]);

        return [
            'source_currency' => $source,
            'target_currency' => $target,
            'source_amount' => (float)$amount,
            'target_amount' => (float)wc_format_decimal($converted, wc_get_price_decimals()),
            'rate' => $effective_rate,
        ];
    }

    private function detect_target_currency() {
        if (!empty($_COOKIE['woocs_current_currency'])) {
            return strtoupper(sanitize_text_field(wp_unslash($_COOKIE['woocs_current_currency'])));
        }

        global $WOOCS;

        if (is_object($WOOCS)) {
            if (method_exists($WOOCS, 'current_currency')) {
                $value = $WOOCS->current_currency;
                if (is_string($value) && $value !== '') return strtoupper($value);
            }
            if (isset($WOOCS->current_currency) && is_string($WOOCS->current_currency)) {
                return strtoupper($WOOCS->current_currency);
            }
        }

        return strtoupper(get_woocommerce_currency());
    }

    private function get_woocs_rates() {
        $out = [];
        global $WOOCS;

        if (!is_object($WOOCS)) {
            return $out;
        }

        $currencies = null;

        if (method_exists($WOOCS, 'get_currencies')) {
            $currencies = $WOOCS->get_currencies();
        } elseif (isset($WOOCS->currencies) && is_array($WOOCS->currencies)) {
            $currencies = $WOOCS->currencies;
        }

        if (!is_array($currencies)) {
            return $out;
        }

        foreach ($currencies as $code => $row) {
            if (is_string($row) && is_numeric($row)) {
                $out[strtoupper($code)] = (float)$row;
                continue;
            }

            if (is_array($row)) {
                $currency = strtoupper((string)($row['name'] ?? $row['code'] ?? $code));
                $rate = $row['rate'] ?? null;
                if ($currency && is_numeric($rate)) {
                    $out[$currency] = (float)$rate;
                }
            }
        }

        $base = strtoupper(get_woocommerce_currency());
        if (!isset($out[$base])) {
            $out[$base] = 1.0;
        }

        return $out;
    }
}
}
