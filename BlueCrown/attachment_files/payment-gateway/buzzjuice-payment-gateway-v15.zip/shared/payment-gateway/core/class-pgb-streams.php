<?php
if (!defined('ABSPATH')) exit;

if (!class_exists('BZJ_PGB_Streams')) {
class BZJ_PGB_Streams {
    private $db;
    private $logger;

    public function __construct($logger) {
        $this->logger = $logger;
        $this->load_db_helpers();
        $this->db = function_exists('get_wowonder_db') ? get_wowonder_db() : false;
    }

    private function load_db_helpers() {
        $file = dirname(__DIR__, 2) . '/db_helpers.php';
        if (file_exists($file)) {
            require_once $file;
        }
    }

    public function db() {
        return $this->db;
    }

    public function ensure_schema() {
        if (!$this->db) {
            throw new RuntimeException('WoWonder database connection unavailable.');
        }

        $sql = "CREATE TABLE IF NOT EXISTS `" . BZJ_PGB_STREAMS_TABLE . "` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `token_hash` CHAR(64) NOT NULL,
            `wow_order_id` VARCHAR(191) NOT NULL,
            `wow_user_id` BIGINT UNSIGNED NOT NULL,
            `wp_user_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `transaction_kind` VARCHAR(50) NOT NULL,
            `currency` VARCHAR(10) NOT NULL,
            `amount` DECIMAL(20,8) NOT NULL DEFAULT 0,
            `payload_json` LONGTEXT NOT NULL,
            `status` VARCHAR(30) NOT NULL DEFAULT 'ready',
            `woo_order_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `error_code` VARCHAR(100) NOT NULL DEFAULT '',
            `error_message` TEXT NULL,
            `created_at` DATETIME NOT NULL,
            `expires_at` DATETIME NOT NULL,
            `claimed_at` DATETIME NULL,
            `fulfilled_at` DATETIME NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_token_hash` (`token_hash`),
            UNIQUE KEY `uq_wow_order_id` (`wow_order_id`),
            KEY `idx_status_expires` (`status`,`expires_at`),
            KEY `idx_woo_order_id` (`woo_order_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

        if (!$this->db->query($sql)) {
            throw new RuntimeException('Unable to create payment bridge table: ' . $this->db->error);
        }

        return true;
    }

    public function find_handoff($token_hash) {
        $stmt = $this->db->prepare(
            "SELECT * FROM `" . BZJ_PGB_STREAMS_TABLE . "` WHERE token_hash = ? LIMIT 1"
        );
        if (!$stmt) return null;

        $stmt->bind_param('s', $token_hash);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result ? $result->fetch_assoc() : null;
    }

    public function claim_handoff($id) {
        $stmt = $this->db->prepare(
            "UPDATE `" . BZJ_PGB_STREAMS_TABLE . "`
             SET status='claimed', claimed_at=UTC_TIMESTAMP()
             WHERE id=? AND status='ready' AND expires_at >= UTC_TIMESTAMP()"
        );
        if (!$stmt) return false;

        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->affected_rows === 1;
    }

    public function save_woo_order($id, $woo_order_id) {
        $stmt = $this->db->prepare(
            "UPDATE `" . BZJ_PGB_STREAMS_TABLE . "`
             SET woo_order_id=?, status='checkout'
             WHERE id=? AND status IN ('claimed','checkout')"
        );
        if (!$stmt) return false;
        $stmt->bind_param('ii', $woo_order_id, $id);
        return $stmt->execute();
    }

    public function mark_fulfilled($id, $woo_order_id) {
        $stmt = $this->db->prepare(
            "UPDATE `" . BZJ_PGB_STREAMS_TABLE . "`
             SET woo_order_id=?, status='fulfilled', fulfilled_at=UTC_TIMESTAMP()
             WHERE id=?"
        );
        if (!$stmt) return false;
        $stmt->bind_param('ii', $woo_order_id, $id);
        return $stmt->execute();
    }

    public function mark_failed($id, $code, $message) {
        $stmt = $this->db->prepare(
            "UPDATE `" . BZJ_PGB_STREAMS_TABLE . "`
             SET status='failed', error_code=?, error_message=?
             WHERE id=?"
        );
        if (!$stmt) return false;
        $stmt->bind_param('ssi', $code, $message, $id);
        return $stmt->execute();
    }
}
}
