<?php
if (!defined('ABSPATH')) exit;

if (!class_exists('BZJ_PGB_Hooks')) {
class BZJ_PGB_Hooks {
    public static function register($root, $logger) {
        add_action('template_redirect', function() use ($root, $logger) {
            self::handle_checkout_handoff($root, $logger);
        }, 1);

        add_action('woocommerce_payment_complete', function($order_id) use ($logger) {
            self::fulfill($order_id, $logger);
        }, 50);

        add_action('woocommerce_order_status_processing', function($order_id) use ($logger) {
            self::fulfill($order_id, $logger);
        }, 50);

        add_action('woocommerce_order_status_completed', function($order_id) use ($logger) {
            self::fulfill($order_id, $logger);
        }, 50);

        add_action('woocommerce_thankyou', function($order_id) use ($logger) {
            self::fulfill($order_id, $logger);
        }, 50);

        add_action('admin_menu', function() use ($root) {
            self::admin_menu();
        });

        add_action('admin_init', function() {
            register_setting('bzj_pgb_settings', 'bzj_pgb_logging', [
                'type' => 'boolean',
                'sanitize_callback' => function($v) { return !empty($v) ? 1 : 0; },
                'default' => 1,
            ]);
        });
    }

    private static function handle_checkout_handoff($root, $logger) {
        if (is_admin()) return;

        $request_path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
        $site_path = trim(parse_url(home_url('/'), PHP_URL_PATH), '/');

        if ($site_path && strpos($request_path, $site_path . '/') === 0) {
            $request_path = trim(substr($request_path, strlen($site_path) + 1), '/');
        }

        if ($request_path !== BZJ_PGB_ROUTE) {
            return;
        }

        $token = isset($_GET['token']) ? preg_replace('/[^a-f0-9]/', '', (string)wp_unslash($_GET['token'])) : '';
        $sig = isset($_GET['sig']) ? preg_replace('/[^a-f0-9]/', '', (string)wp_unslash($_GET['sig'])) : '';

        if (!$token || !$sig || !BZJ_PGB_SECRET) {
            status_header(400);
            wp_die('Invalid payment handoff.', 'Buzzjuice Payment Gateway', ['response' => 400]);
        }

        $expected = hash_hmac('sha256', $token, BZJ_PGB_SECRET);
        if (!hash_equals($expected, $sig)) {
            status_header(403);
            wp_die('Invalid payment handoff signature.', 'Buzzjuice Payment Gateway', ['response' => 403]);
        }

        $streams = new BZJ_PGB_Streams($logger);
        try {
            $streams->ensure_schema();
        } catch (Throwable $e) {
            $logger->exception(__FILE__, $e);
            wp_die('Payment gateway is temporarily unavailable.', 'Buzzjuice Payment Gateway', ['response' => 503]);
        }

        $row = $streams->find_handoff(hash('sha256', $token));
        if (!$row) {
            wp_die('Payment request not found or expired.', 'Buzzjuice Payment Gateway', ['response' => 404]);
        }

        if (strtotime($row['expires_at'] . ' UTC') < time()) {
            $streams->mark_failed($row['id'], 'expired', 'Payment handoff expired.');
            wp_die('Payment request expired. Please start the purchase again.', 'Buzzjuice Payment Gateway', ['response' => 410]);
        }

        $existing_order_id = absint($row['woo_order_id']);
        if ($existing_order_id) {
            $existing = wc_get_order($existing_order_id);
            if ($existing && in_array($existing->get_status(), ['pending','failed','on-hold'], true)) {
                wp_safe_redirect($existing->get_checkout_payment_url(false));
                exit;
            }
        }

        if ($row['status'] !== 'ready') {
            wp_die('This payment request has already been used or is being processed.', 'Buzzjuice Payment Gateway', ['response' => 409]);
        }

        if (!$streams->claim_handoff($row['id'])) {
            wp_die('This payment request is already being processed. Please wait and retry from Streams.', 'Buzzjuice Payment Gateway', ['response' => 409]);
        }

        try {
            $currency = new BZJ_PGB_Currency($logger);
            $order_factory = new BZJ_PGB_Order($logger, $streams, $currency);
            $order = $order_factory->create_from_handoff($row);

            $streams->save_woo_order($row['id'], $order->get_id());

            wp_safe_redirect($order->get_checkout_payment_url(false));
            exit;
        } catch (Throwable $e) {
            $streams->mark_failed($row['id'], 'order_create_failed', $e->getMessage());
            $logger->exception(__FILE__, $e, ['bridge_id' => $row['id']]);
            wp_die('Unable to prepare checkout. Please try again.', 'Buzzjuice Payment Gateway', ['response' => 500]);
        }
    }

    private static function fulfill($order_id, $logger) {
        if (!$order_id) return;

        $streams = new BZJ_PGB_Streams($logger);

        try {
            $streams->ensure_schema();
            $fulfillment = new BZJ_PGB_Fulfillment($logger, $streams);
            $fulfillment->process($order_id);
        } catch (Throwable $e) {
            $logger->exception(__FILE__, $e, ['order_id' => $order_id]);
        }
    }

    private static function admin_menu() {
        add_menu_page(
            'Buzzjuice',
            'Buzzjuice',
            'manage_options',
            'buzzjuice',
            function() { echo '<div class="wrap"><h1>Buzzjuice</h1></div>'; },
            'dashicons-networking',
            58
        );

        add_submenu_page(
            'buzzjuice',
            'Payment Gateways',
            'Payment Gateways',
            'manage_options',
            'buzzjuice-payment-gateways',
            function() {
                if (!current_user_can('manage_options')) return;
                ?>
                <div class="wrap">
                    <h1>Buzzjuice → Payment Gateways</h1>
                    <form method="post" action="options.php">
                        <?php settings_fields('bzj_pgb_settings'); ?>
                        <table class="form-table">
                            <tr>
                                <th scope="row">Bridge logging</th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="bzj_pgb_logging" value="1"
                                            <?php checked(get_option('bzj_pgb_logging', 1), 1); ?>>
                                        Enable diagnostic logging
                                    </label>
                                    <p class="description">
                                        Logs are written under <code>shared/payment-gateway/log/</code>.
                                        Secrets, cookies, sessions and signatures are redacted.
                                    </p>
                                </td>
                            </tr>
                        </table>
                        <?php submit_button('Save Payment Gateway Settings'); ?>
                    </form>
                    <h2>Handoff endpoint</h2>
                    <p><code><?php echo esc_html(home_url('/' . BZJ_PGB_ROUTE . '/')); ?></code></p>
                    <p>The endpoint is browser-facing. Streams does not perform a server-side HTTP request to WordPress.</p>
                </div>
                <?php
            }
        );
    }
}
}
