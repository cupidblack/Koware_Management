<?php
if (!defined('ABSPATH') && !defined('PGB_STREAMS_CONTEXT')) {
    exit;
}

if (!class_exists('BZJ_PGB_Logger')) {
class BZJ_PGB_Logger {
    const DEBUG = 'debug';
    const INFO = 'info';
    const WARNING = 'warning';
    const ERROR = 'error';
    const CRITICAL = 'critical';

    private $enabled;
    private $level;
    private $dir;

    private $weights = [
        'debug' => 10,
        'info' => 20,
        'warning' => 30,
        'error' => 40,
        'critical' => 50,
    ];

    public function __construct($enabled = null, $level = null, $dir = null) {
        $this->enabled = $enabled === null ? (function_exists('get_option') ? (bool)get_option('bzj_pgb_logging', defined('BZJ_PGB_LOGGING') ? BZJ_PGB_LOGGING : true) : (defined('BZJ_PGB_LOGGING') ? BZJ_PGB_LOGGING : true)) : (bool)$enabled;
        $this->level = $level ?: (defined('BZJ_PGB_LOG_LEVEL') ? BZJ_PGB_LOG_LEVEL : self::INFO);
        $this->dir = $dir ?: (defined('BZJ_PGB_LOG_DIR') ? BZJ_PGB_LOG_DIR : __DIR__ . '/../log');
    }

    public function enabled() {
        return $this->enabled;
    }

    public function log($source_file, $message, $context = [], $level = self::INFO) {
        if (!$this->enabled || !$this->should_log($level)) {
            return;
        }

        if (!is_dir($this->dir)) {
            @mkdir($this->dir, 0750, true);
        }

        if (!is_dir($this->dir) || !is_writable($this->dir)) {
            return;
        }

        $base = basename((string)$source_file, '.php');
        $base = preg_replace('/[^A-Za-z0-9._-]/', '-', $base ?: 'payment-gateway');
        $path = trailingslashit($this->dir) . $base . '.log';

        $entry = [
            'time' => gmdate('c'),
            'level' => $level,
            'message' => (string)$message,
            'context' => $this->redact($context),
        ];

        @file_put_contents(
            $path,
            wp_json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . PHP_EOL,
            FILE_APPEND | LOCK_EX
        );
    }

    public function exception($source_file, Throwable $e, $context = []) {
        $context['exception'] = [
            'type' => get_class($e),
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
        ];
        $this->log($source_file, 'Exception', $context, self::CRITICAL);
    }

    private function should_log($level) {
        $level = strtolower($level);
        $configured = strtolower($this->level);
        return ($this->weights[$level] ?? 20) >= ($this->weights[$configured] ?? 20);
    }

    private function redact($value) {
        if (is_array($value)) {
            $out = [];
            foreach ($value as $k => $v) {
                $key = strtolower((string)$k);
                if (preg_match('/pass|secret|token|cookie|session|authorization|consumer_key|consumer_secret|signature|api_key|api_secret/', $key)) {
                    $out[$k] = '[REDACTED]';
                } else {
                    $out[$k] = $this->redact($v);
                }
            }
            return $out;
        }

        if (is_object($value)) {
            return '[OBJECT ' . get_class($value) . ']';
        }

        if (is_string($value) && strlen($value) > 2000) {
            return substr($value, 0, 2000) . '…';
        }

        return $value;
    }
}
}
