<?php
if (!defined('ABSPATH')) exit;

if (!class_exists('BZJ_PGB_Bootstrap')) {
class BZJ_PGB_Bootstrap {
    private static $instance;
    private $root;
    private $logger;

    public static function instance($root = null) {
        if (!self::$instance) {
            self::$instance = new self($root ?: dirname(__DIR__));
        }
        return self::$instance;
    }

    private function __construct($root) {
        $this->root = rtrim($root, '/');
        require_once $this->root . '/core/class-pgb-logger.php';
        $this->logger = new BZJ_PGB_Logger();
    }

    public function boot() {
        $this->load_core();
        $this->load_integrations();
        $this->load_addons();

        BZJ_PGB_Hooks::register($this->root, $this->logger);

        $this->logger->log(__FILE__, 'Payment Gateway Bridge booted', [
            'version' => BZJ_PGB_VERSION,
            'root' => $this->root,
        ]);
    }

    private function load_core() {
        foreach ([
            '/core/class-pgb-streams.php',
            '/core/class-pgb-currency.php',
            '/core/class-pgb-order.php',
            '/core/class-pgb-fulfillment.php',
            '/core/class-pgb-hooks.php',
        ] as $file) {
            require_once $this->root . $file;
        }
    }

    private function load_integrations() {
        foreach (glob($this->root . '/int/pgb-int-*.php') ?: [] as $file) {
            require_once $file;
        }
    }

    private function load_addons() {
        foreach (glob($this->root . '/addons/pgb-addon-*.php') ?: [] as $file) {
            require_once $file;
        }
    }

    public function logger() {
        return $this->logger;
    }
}
}
