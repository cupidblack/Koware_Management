<?php
if (!defined('ABSPATH')) exit;

if (!class_exists('BZJ_PGB_Order')) {
class BZJ_PGB_Order {
    private $logger;
    private $streams;
    private $currency;

    public function __construct($logger, $streams, $currency) {
        $this->logger = $logger;
        $this->streams = $streams;
        $this->currency = $currency;
    }

    public function create_from_handoff($handoff) {
        if (!class_exists('WooCommerce') || !function_exists('wc_create_order')) {
            throw new RuntimeException('WooCommerce is not available.');
        }

        $payload = json_decode((string)$handoff['payload_json'], true);
        if (!is_array($payload)) {
            throw new RuntimeException('Invalid handoff payload.');
        }

        $wp_user_id = absint($payload['wp_user_id'] ?? $handoff['wp_user_id']);
        $product_id = absint($payload['product_id'] ?? 0);
        $variation_id = absint($payload['variation_id'] ?? 0);
        $quantity = max(1, absint($payload['quantity'] ?? 1));
        $amount = (float)($payload['amount'] ?? 0);
        $currency = (string)($payload['currency'] ?? $handoff['currency']);

        if (!$wp_user_id || !$product_id || $amount <= 0) {
            throw new RuntimeException('Invalid order data.');
        }

        $product = wc_get_product($variation_id ?: $product_id);
        if (!$product) {
            throw new RuntimeException('Mapped WooCommerce product/variation was not found.');
        }

        $converted = $this->currency->resolve($currency, $amount);

        $order = wc_create_order([
            'customer_id' => $wp_user_id,
            'created_via' => 'buzzjuice-pgb',
        ]);

        if (is_wp_error($order)) {
            throw new RuntimeException($order->get_error_message());
        }

        $order->set_currency($converted['target_currency']);
        $order->set_customer_id($wp_user_id);

        $item_id = $order->add_product($product, $quantity, [
            'subtotal' => $converted['target_amount'],
            'total' => $converted['target_amount'],
        ]);

        if (!$item_id) {
            $order->delete(true);
            throw new RuntimeException('Unable to add product to WooCommerce order.');
        }

        $meta = [
            '_buzzjuice_origin' => 'streams',
            '_bzj_pgb_version' => BZJ_PGB_VERSION,
            '_bzj_pgb_bridge_id' => absint($handoff['id']),
            '_bzj_pgb_token_hash' => hash('sha256', (string)$handoff['token_hash']),
            'wow_order_id' => sanitize_text_field($handoff['wow_order_id']),
            'userid' => absint($handoff['wow_user_id']),
            'wow_user_id' => absint($handoff['wow_user_id']),
            'transaction_kind' => sanitize_text_field($handoff['transaction_kind']),
            '_bzj_source_currency' => $converted['source_currency'],
            '_bzj_source_amount' => (string)$converted['source_amount'],
            '_bzj_exchange_rate' => (string)$converted['rate'],
            '_bzj_checkout_currency' => $converted['target_currency'],
        ];

        foreach ($payload['meta'] ?? [] as $key => $value) {
            $safe_key = sanitize_key($key);
            if ($safe_key === '') continue;
            $order->update_meta_data($safe_key, is_scalar($value) ? (string)$value : wp_json_encode($value));
        }

        foreach ($meta as $key => $value) {
            $order->update_meta_data($key, $value);
        }

        $user = get_user_by('id', $wp_user_id);
        if ($user) {
            $address = [
                'first_name' => $user->first_name ?: $user->display_name,
                'last_name' => $user->last_name,
                'email' => $user->user_email,
            ];
            $order->set_billing_first_name($address['first_name']);
            $order->set_billing_last_name($address['last_name']);
            $order->set_billing_email($address['email']);
        }

        $order->calculate_totals(false);
        $order->save();

        $this->logger->log(__FILE__, 'WooCommerce order created', [
            'bridge_id' => (int)$handoff['id'],
            'woo_order_id' => $order->get_id(),
            'wow_order_id' => $handoff['wow_order_id'],
            'currency' => $converted['target_currency'],
            'amount' => $converted['target_amount'],
        ]);

        return $order;
    }
}
}
