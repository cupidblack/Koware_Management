<?php
/**
 * Buzzjuice Payment Gateway Bridge - Streams client.
 *
 * This replaces the WooCommerce REST/cURL portion of wow-pgb_init.php.
 * It is loaded from the Streams environment, not WordPress.
 */

if (!defined('PGB_STREAMS_CONTEXT')) {
    define('PGB_STREAMS_CONTEXT', true);
}

require_once dirname(__DIR__, 2) . '/shared/db_helpers.php';
require_once __DIR__ . '/pgb-client.php';

function bzj_pgb_streams_log($event, $context = []) {
    $enabled = getenv('BUZZ_PGB_LOGGING');
    if ($enabled === false) $enabled = '1';

    if (!in_array(strtolower((string)$enabled), ['1','true','yes','on'], true)) {
        return;
    }

    $dir = __DIR__ . '/log';
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    if (!is_dir($dir) || !is_writable($dir)) return;

    $entry = [
        'time' => gmdate('c'),
        'event' => (string)$event,
        'context' => $context,
    ];

    @file_put_contents(
        $dir . '/pgb-client-streams.log',
        json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . PHP_EOL,
        FILE_APPEND | LOCK_EX
    );
}

function bzj_pgb_streams_init($data) {
    global $wo, $sqlConnect;

    if (empty($wo['loggedin']) || empty($wo['user']['user_id'])) {
        throw new RuntimeException('Authentication required.');
    }

    if (!function_exists('get_wowonder_db')) {
        throw new RuntimeException('Shared database helper unavailable.');
    }

    $db = get_wowonder_db();
    if (!$db) {
        throw new RuntimeException('Streams database unavailable.');
    }

    $wow_user_id = (int)$wo['user']['user_id'];
    $wp_user_id = 0;

    $stmt = $db->prepare("SELECT wp_user_id FROM Wo_Users WHERE user_id=? LIMIT 1");
    if (!$stmt) throw new RuntimeException('Unable to prepare user lookup.');
    $stmt->bind_param('i', $wow_user_id);
    $stmt->execute();
    $user_row = $stmt->get_result()->fetch_assoc();

    if ($user_row) {
        $wp_user_id = (int)($user_row['wp_user_id'] ?? 0);
    }

    if (!$wp_user_id) {
        throw new RuntimeException('WordPress user mapping is missing.');
    }

    $amount = (float)($data['amount'] ?? 0);
    $product_price = (float)($data['product_price'] ?? 0);
    $quantity = max(1, (int)($data['product_units'] ?? 1));
    $product_id = (int)($data['product_id'] ?? 0);
    $variation_id = (int)($data['variation_id'] ?? 0);
    $owner_id = (int)($data['product_owner_id'] ?? 0);
    $post_id = (int)($data['wow_post_id'] ?? 0);
    $kind = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($data['transaction_kind'] ?? ''));
    $currency = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)($data['wow_currency_code'] ?? 'GHS')));

    if ($amount <= 0 || $product_id <= 0 || !$kind || !$currency) {
        throw new RuntimeException('Invalid payment request.');
    }

    $wow_order_id = 'wow_' . bin2hex(random_bytes(16));
    $token = bin2hex(random_bytes(32));
    $token_hash = hash('sha256', $token);
    $payload = [
        'wp_user_id' => $wp_user_id,
        'wow_user_id' => $wow_user_id,
        'product_id' => $product_id,
        'variation_id' => $variation_id,
        'product_owner_id' => $owner_id,
        'wow_post_id' => $post_id,
        'transaction_kind' => $kind,
        'currency' => $currency,
        'amount' => $amount,
        'product_price' => $product_price,
        'quantity' => $quantity,
        'meta' => [
            'wow_post_id' => $post_id,
            'transaction_kind' => $kind,
            'product_owner_id' => $owner_id,
            '_buzzjuice_origin' => 'streams',
        ],
    ];

    $db->query("CREATE TABLE IF NOT EXISTS `Wo_Payment_Gateway_Bridge` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `token_hash` CHAR(64) NOT NULL,
        `wow_order_id` VARCHAR(191) NOT NULL,
        `wow_user_id` BIGINT UNSIGNED NOT NULL,
        `wp_user_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
        `transaction_kind` VARCHAR(50) NOT NULL,
        `currency` VARCHAR(10) NOT NULL,
        `amount` DECIMAL(20,8) NOT NULL DEFAULT 0,
        `payload_json` LONGTEXT NOT NULL,
        `status` VARCHAR(30) NOT NULL DEFAULT 'ready',
        `woo_order_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
        `error_code` VARCHAR(100) NOT NULL DEFAULT '',
        `error_message` TEXT NULL,
        `created_at` DATETIME NOT NULL,
        `expires_at` DATETIME NOT NULL,
        `claimed_at` DATETIME NULL,
        `fulfilled_at` DATETIME NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uq_token_hash` (`token_hash`),
        UNIQUE KEY `uq_wow_order_id` (`wow_order_id`),
        KEY `idx_status_expires` (`status`,`expires_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    if ($db->error) {
        throw new RuntimeException('Unable to initialize payment bridge table.');
    }

    $ttl = max(60, (int)(getenv('BUZZ_PGB_HANDOFF_TTL') ?: 900));
    $expires = gmdate('Y-m-d H:i:s', time() + $ttl);

    $stmt = $db->prepare(
        "INSERT INTO `Wo_Payment_Gateway_Bridge`
        (token_hash,wow_order_id,wow_user_id,wp_user_id,transaction_kind,currency,amount,payload_json,status,created_at,expires_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)"
    );

    if (!$stmt) {
        throw new RuntimeException('Unable to prepare payment handoff.');
    }

    $payload_json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $status = 'ready';
    $created = gmdate('Y-m-d H:i:s');

    $stmt->bind_param(
        'ssiiisdssss',
        $token_hash,
        $wow_order_id,
        $wow_user_id,
        $wp_user_id,
        $kind,
        $currency,
        $amount,
        $payload_json,
        $status,
        $created,
        $expires
    );

    if (!$stmt->execute()) {
        throw new RuntimeException('Unable to store payment handoff.');
    }

    $base = defined('WP_BASE_SITE_URL') && WP_BASE_SITE_URL ? WP_BASE_SITE_URL : 'https://buzzjuice.net';
    $base = rtrim($base, '/');
    $secret = getenv('BUZZ_PGB_SECRET');

    if (!$secret && function_exists('bzj_get_sso_secret')) {
        $secret = hash('sha256', bzj_get_sso_secret() . '|payment-gateway');
    }

    if (!$secret) {
        throw new RuntimeException('Payment gateway secret is not configured.');
    }

    $signature = bzj_pgb_client_signature($token, $secret);
    $url = $base . '/pgb-checkout/?token=' . rawurlencode($token) . '&sig=' . rawurlencode($signature);

    bzj_pgb_streams_log('handoff_created', [
        'wow_order_id' => $wow_order_id,
        'wow_user_id' => $wow_user_id,
        'wp_user_id' => $wp_user_id,
        'kind' => $kind,
        'currency' => $currency,
        'amount' => $amount,
        'bridge_id' => $db->insert_id,
    ]);

    return [
        'status' => 200,
        'url' => $url,
        'wow_order_id' => $wow_order_id,
    ];
}
