# Buzzjuice Payment Gateway Bridge v15

## Architecture

Streams -> durable Wo_Payment_Gateway_Bridge row -> browser handoff ->
WordPress MU plugin -> WooCommerce CRUD order -> WooCommerce checkout ->
payment gateway -> WooCommerce payment/status hooks -> PGB fulfillment ->
Streams update + subscriptions + AffiliateWP + Jewel integration.

There is no Streams -> WordPress cURL request and no WooCommerce REST order
creation call.

## Required environment

Recommended:

BUZZ_PGB_SECRET=<long random secret>
BUZZ_PGB_LOGGING=1
BUZZ_PGB_LOG_LEVEL=debug
BUZZ_PGB_HANDOFF_TTL=900

If BUZZ_PGB_SECRET is absent, the implementation derives a secret from the
existing Buzzjuice SSO secret and a payment-specific context string.

## Deployment

1. Back up the current payment bridge.
2. Create shared/payment-gateway/ and copy this package.
3. Install only bzj-payment-gateway.php in wp-content/mu-plugins/.
4. Disable/remove the old buzzjuice-affwp-order-complete.php hook.
5. Replace the Streams wow-pgb_init.php with the supplied v15 initializer.
6. Do not delete the old wow-pgb_sync.php until AffiliateWP/Jewel parity tests pass.
7. Run a test purchase for each transaction kind.
8. Verify WooCommerce order, payment, subscription, AffiliateWP referral,
   Jewel rebate, and Streams fulfillment status.
9. Only after successful migration remove the old REST credentials from the
   Streams payment settings.

## Important migration note

The supplied AffiliateWP adapter intentionally delegates to the existing
bluecrown_affiliatewp_post_checkout_verification() implementation because that
logic is already working in production. Move that function into the PGB
AffiliateWP addon only after line-by-line parity testing.

Likewise, move the established Jewel affiliate webhook/rebate rules into
pgb-int-jewel-affiliate.php before enabling the final rebate action.


## Business-rule extraction

For the first production cut, the AffiliateWP addon calls the existing proven
`bluecrown_affiliatewp_post_checkout_verification()` function and the Jewel
integration calls the established `jewel_affiliate_process()` function. This
prevents a transport refactor from simultaneously changing commission/rebate
business rules.

After parity testing, copy those proven functions into the corresponding
addon/integration files and remove the legacy Blue Crown/Streams dependencies.
Do not rewrite the formulas while performing that extraction.
