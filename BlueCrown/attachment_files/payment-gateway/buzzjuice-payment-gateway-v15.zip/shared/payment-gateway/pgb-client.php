<?php
/**
 * Generic Payment Gateway Bridge client helpers.
 *
 * This file contains no WordPress-only functions so it can be reused by
 * Streams-side code.
 */

if (!function_exists('bzj_pgb_client_signature')) {
    function bzj_pgb_client_signature($token, $secret) {
        return hash_hmac('sha256', (string)$token, (string)$secret);
    }
}
