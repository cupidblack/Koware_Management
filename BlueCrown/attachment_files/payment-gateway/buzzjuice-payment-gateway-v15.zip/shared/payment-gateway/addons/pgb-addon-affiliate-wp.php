<?php
if (!defined('ABSPATH')) exit;

/**
 * AffiliateWP adapter.
 *
 * The proven resolver in wow-pgb_sync.php should be moved here when the bridge
 * is migrated. Until then this adapter deliberately delegates to that public
 * bridge function instead of inventing a new attribution algorithm.
 */
add_filter('bzj_pgb_fulfillment_callbacks', function($callbacks) {
    $callbacks['affiliate-wp'] = function($order, $logger) {
        if (!class_exists('Affiliate_WP')) {
            return;
        }

        if ($order->get_meta('_affwp_bridge_processed', true)) {
            return;
        }

        $bridge = WP_CONTENT_DIR . '/plugins/blue-crown-wp/wow-pgb_sync/wow-pgb_sync.php';

        if (!function_exists('bluecrown_affiliatewp_post_checkout_verification') && is_readable($bridge)) {
            require_once $bridge;
        }

        if (!function_exists('bluecrown_affiliatewp_post_checkout_verification')) {
            $logger->log(__FILE__, 'Existing AffiliateWP bridge function unavailable; commission not processed.', [
                'order_id' => $order->get_id(),
            ], BZJ_PGB_Logger::WARNING);
            return;
        }

        bluecrown_affiliatewp_post_checkout_verification($order->get_id());

        $order->update_meta_data('_affwp_bridge_processed', gmdate('c'));
        $order->save();

        $logger->log(__FILE__, 'AffiliateWP bridge completed', [
            'order_id' => $order->get_id(),
        ]);
    };

    return $callbacks;
});
