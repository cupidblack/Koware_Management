<?php
if (!defined('ABSPATH')) exit;

/*
 * Currency conversion is performed before order creation by class-pgb-currency.php.
 * This addon exists as an extension point for future WOOCS-specific compatibility
 * logic without putting currency code inside the payment engine.
 */
add_action('bzj_pgb_fulfilled', function($order) {
    if (!$order instanceof WC_Order) {
        return;
    }
    $order->update_meta_data('_bzj_currency_finalized', gmdate('c'));
    $order->save();
}, 20);
