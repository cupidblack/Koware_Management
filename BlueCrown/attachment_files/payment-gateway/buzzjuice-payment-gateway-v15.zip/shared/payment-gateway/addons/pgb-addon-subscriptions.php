<?php
if (!defined('ABSPATH')) exit;

/**
 * WooCommerce Subscriptions adapter.
 *
 * The bridge creates the subscription from the already-created parent order
 * when a subscription product is present, then activates it after payment.
 */
add_filter('bzj_pgb_fulfillment_callbacks', function($callbacks) {
    $callbacks['subscriptions'] = function($order, $logger) {
        if (!function_exists('wcs_order_contains_subscription')) {
            return;
        }

        $subscriptions = wcs_get_subscriptions_for_order($order->get_id(), [
            'order_type' => 'parent',
        ]);

        if (empty($subscriptions)) {
            foreach ($order->get_items('line_item') as $item) {
                $product = $item->get_product();
                if (!$product || !class_exists('WC_Subscriptions_Product')) {
                    continue;
                }

                if (!WC_Subscriptions_Product::is_subscription($product)) {
                    continue;
                }

                if (!function_exists('wcs_create_subscription')) {
                    throw new RuntimeException('WooCommerce Subscriptions creation API is unavailable.');
                }

                $period = WC_Subscriptions_Product::get_period($product);
                $interval = WC_Subscriptions_Product::get_interval($product);
                $length = WC_Subscriptions_Product::get_length($product);

                $args = [
                    'parent' => $order,
                    'customer_id' => $order->get_customer_id(),
                    'billing_period' => $period,
                    'billing_interval' => $interval,
                    'start_date' => current_time('mysql', true),
                ];

                if ($length > 0) {
                    $args['end_date'] = gmdate('Y-m-d H:i:s', strtotime("+{$length} {$period}"));
                }

                $subscription = wcs_create_subscription($args);

                if (is_wp_error($subscription)) {
                    throw new RuntimeException($subscription->get_error_message());
                }

                $subscription->add_product($product, max(1, $item->get_quantity()), [
                    'subtotal' => $item->get_subtotal(),
                    'total' => $item->get_total(),
                ]);

                $subscription->set_currency($order->get_currency());
                $subscription->calculate_totals(false);
                $subscription->update_meta_data('_bzj_pgb_parent_order', $order->get_id());
                $subscription->save();

                $logger->log(__FILE__, 'Subscription created from paid order', [
                    'order_id' => $order->get_id(),
                    'subscription_id' => $subscription->get_id(),
                ]);

                $subscriptions[] = $subscription;
                break;
            }
        }

        foreach ($subscriptions as $subscription) {
            if (!$subscription || !is_a($subscription, 'WC_Subscription')) {
                continue;
            }

            if ($subscription->has_status(['pending', 'on-hold'])) {
                $subscription->update_status('active', 'Buzzjuice PGB payment completed.');
            }

            $subscription->update_meta_data('_bzj_pgb_processed', gmdate('c'));
            $subscription->save();

            $logger->log(__FILE__, 'Subscription processed', [
                'order_id' => $order->get_id(),
                'subscription_id' => $subscription->get_id(),
                'status' => $subscription->get_status(),
            ]);
        }

        $order->update_meta_data('_bzj_subscriptions_processed', gmdate('c'));
        $order->save();
    };

    return $callbacks;
});
