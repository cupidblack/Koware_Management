<?php
if (!defined('ABSPATH')) { exit; }

class PGB_DB {
    private static $conn = null;
    private static $table = null;

    public static function conn() {
        if (self::$conn) return self::$conn;
        $helper = dirname(ABSPATH) . '/shared/db_helpers.php';
        if (!is_file($helper)) throw new Exception('Buzzjuice shared/db_helpers.php not found');
        require_once $helper;
        if (!function_exists('get_palmier_db_conn')) throw new Exception('get_palmier_db_conn() unavailable');
        self::$conn = get_palmier_db_conn();
        if (!self::$conn) throw new Exception('Could not connect to Buzzjuice Streams database');
        return self::$conn;
    }

    public static function table() {
        if (!self::$table) {
            $name = 'Wo_Payment_Gateway_Bridge';
            self::$table = '`' . preg_replace('/[^A-Za-z0-9_]/', '', $name) . '`';
        }
        return self::$table;
    }

    public static function get_by_token_hash($hash) {
        $c = self::conn();
        $stmt = $c->prepare('SELECT * FROM ' . self::table() . ' WHERE token_hash=? LIMIT 1');
        if (!$stmt) throw new Exception($c->error);
        $stmt->bind_param('s', $hash);
        $stmt->execute();
        $res = $stmt->get_result();
        return $res ? $res->fetch_assoc() : null;
    }

    public static function claim($id) {
        $c = self::conn();
        $stmt = $c->prepare(
            'UPDATE ' . self::table() .
            ' SET status="claimed", claimed_at=UTC_TIMESTAMP() ' .
            'WHERE id=? AND status="pending" AND expires_at>UTC_TIMESTAMP()'
        );
        if (!$stmt) throw new Exception($c->error);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->affected_rows === 1;
    }

    public static function update($id, array $data) {
        if (!$data) return;
        $allowed = array('status','wc_order_id','wc_subscription_id','last_error');
        $sets = array(); $types = ''; $vals = array();
        foreach ($allowed as $key) {
            if (array_key_exists($key, $data)) {
                $sets[] = $key . '=?';
                $types .= ($key === 'wc_order_id' || $key === 'wc_subscription_id') ? 'i' : 's';
                $vals[] = $data[$key];
            }
        }
        if (!$sets) return;
        $c = self::conn();
        $stmt = $c->prepare('UPDATE ' . self::table() . ' SET ' . implode(',', $sets) . ' WHERE id=?');
        if (!$stmt) throw new Exception($c->error);
        $types .= 'i'; $vals[] = (int)$id;
        $stmt->bind_param($types, ...$vals);
        $stmt->execute();
    }
}
