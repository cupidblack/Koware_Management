<?php
if (!defined('ABSPATH')) { exit; }

class PGB_Logger {
    public static function enabled() {
        return defined('BZJ_PGB_LOGGING') && BZJ_PGB_LOGGING;
    }

    public static function log($message, array $context = array(), $level = 'INFO', $source = null) {
        if (!self::enabled()) return;
        $source = $source ?: 'class-pgb-logger';
        $safe = self::sanitize($context);
        $file = BZJ_PGB_LOG_DIR . '/' . sanitize_file_name(basename($source, '.php')) . '.log';
        if (!is_dir(BZJ_PGB_LOG_DIR)) @wp_mkdir_p(BZJ_PGB_LOG_DIR);
        $entry = array(
            'time' => gmdate('c'),
            'level' => strtoupper($level),
            'source' => basename($source),
            'message' => (string)$message,
            'context' => $safe,
        );
        @file_put_contents($file, wp_json_encode($entry) . PHP_EOL, FILE_APPEND | LOCK_EX);
    }

    private static function sanitize($value) {
        if (is_array($value)) {
            $out = array();
            foreach ($value as $k => $v) {
                $lk = strtolower((string)$k);
                if (preg_match('/token|secret|password|cookie|authorization|signature|api_key|api_secret|jwt|session/i', $lk)) {
                    $out[$k] = '[redacted]';
                } else {
                    $out[$k] = self::sanitize($v);
                }
            }
            return $out;
        }
        if (is_object($value)) return '[object]';
        if (is_string($value) && strlen($value) > 1000) return substr($value, 0, 997) . '...';
        return $value;
    }
}
