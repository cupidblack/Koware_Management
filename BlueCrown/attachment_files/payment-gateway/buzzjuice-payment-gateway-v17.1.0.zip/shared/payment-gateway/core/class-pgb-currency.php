<?php
if (!defined('ABSPATH')) { exit; }

class PGB_Currency {
    public function convert($amount, $from, $to) {
        $amount = (float)$amount;
        $from = strtoupper((string)$from);
        $to = strtoupper((string)$to);
        if ($amount < 0 || !$from || !$to) throw new Exception('Invalid currency conversion input');
        if ($from === $to) return array('amount' => $amount, 'rate' => 1.0);

        /*
         * Use the installed Fox WOOCS object/rates. The existing bridge already
         * uses this installed extension, so do not introduce a second FX source.
         */
        global $WOOCS, $woocs;
        $obj = null;
        if (is_object($WOOCS)) $obj = $WOOCS;
        elseif (is_object($woocs)) $obj = $woocs;

        if ($obj && isset($obj->rates) && is_array($obj->rates)
            && isset($obj->rates[$from]) && isset($obj->rates[$to])) {
            $fr = (float)$obj->rates[$from];
            $tr = (float)$obj->rates[$to];
            if ($fr > 0 && $tr > 0) {
                $rate = $tr / $fr;
                return array('amount' => round($amount * $rate, wc_get_price_decimals()), 'rate' => $rate);
            }
        }

        /*
         * Let WOOCS filters perform any site-specific conversion if available.
         */
        $filtered = apply_filters('woocs_exchange_value', null, $amount, $from, $to);
        if (is_numeric($filtered)) {
            $converted = (float)$filtered;
            return array('amount' => round($converted, wc_get_price_decimals()), 'rate' => $amount > 0 ? $converted / $amount : 0);
        }

        throw new Exception('WOOCS exchange rate unavailable for ' . $from . ' to ' . $to);
    }

    public function current_currency() {
        global $WOOCS, $woocs;
        $obj = is_object($WOOCS) ? $WOOCS : (is_object($woocs) ? $woocs : null);
        if ($obj && method_exists($obj, 'get_currency')) {
            $c = $obj->get_currency();
            if ($c) return strtoupper($c);
        }
        if (function_exists('wc_get_currency')) return strtoupper(wc_get_currency());
        return strtoupper(get_option('woocommerce_currency', 'GHS'));
    }
}
