<?php
if (!defined('ABSPATH')) { exit; }

class PGB_Bootstrap {
    private static $instance;
    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    public function init() {
        if (!BZJ_PGB_ENABLED) return;

        add_action('template_redirect', array($this, 'handoff'), 1);
        add_action('woocommerce_order_status_processing', array($this, 'paid'), 20);
        add_action('woocommerce_order_status_completed', array($this, 'paid'), 20);
        add_action('woocommerce_payment_complete', array($this, 'paid'), 20);

        add_action('admin_menu', array($this, 'admin_menu'), 99);
        add_action('admin_init', array($this, 'maybe_install_table'));

        PGB_Logger::log('Bootstrap initialized', array('version'=>BZJ_PGB_VERSION), 'INFO', __FILE__);
    }

    public function maybe_install_table() {
        if (!current_user_can('manage_options')) return;
        if (get_option('bzj_pgb_schema_version') === BZJ_PGB_VERSION) return;
        $sql = file_get_contents(BZJ_PGB_DIR . '/sql/001-create-bridge-table.sql');
        if (!$sql) return;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
        update_option('bzj_pgb_schema_version', BZJ_PGB_VERSION);
    }

    public function handoff() {
        $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        $target = trailingslashit(parse_url(home_url('/'), PHP_URL_PATH) . ltrim(BZJ_PGB_HANDOFF_PATH, '/'));
        $normalized = '/' . ltrim($path, '/');
        if (trailingslashit($normalized) !== trailingslashit(BZJ_PGB_HANDOFF_PATH)) return;

        $token = isset($_GET['token']) ? preg_replace('/[^A-Za-z0-9._~-]/', '', (string)$_GET['token']) : '';
        $sig = isset($_GET['sig']) ? preg_replace('/[^A-Fa-f0-9]/', '', (string)$_GET['sig']) : '';
        if (!$token || !$sig) $this->error_page('Invalid payment handoff.');

        $secret = $this->secret();
        $expected = hash_hmac('sha256', $token, $secret);
        if (!hash_equals($expected, $sig)) $this->error_page('Invalid payment handoff signature.');

        try {
            $row = PGB_DB::get_by_token_hash(hash('sha256', $token));
            if (!$row || $row['status'] !== 'pending' || strtotime($row['expires_at'] . ' UTC') < time()) {
                $this->error_page('This payment session has expired or was already used.');
            }
            if (!PGB_DB::claim((int)$row['id'])) {
                $this->error_page('This payment session is already being processed.');
            }

            $processor = new PGB_Order_Processor();
            $order = $processor->process_handoff($row);
            wp_safe_redirect($order->get_checkout_payment_url(false));
            exit;
        } catch (Throwable $e) {
            PGB_Logger::log('Payment handoff failed', array('error'=>$e->getMessage()), 'ERROR', __FILE__);
            if (!empty($row['id'])) {
                try { PGB_DB::update((int)$row['id'], array('status'=>'error','last_error'=>$e->getMessage())); } catch (Throwable $ignored) {}
            }
            $this->error_page('We could not prepare your payment. Please return to Buzzjuice and try again.');
        }
    }

    private function secret() {
        $helper = dirname(ABSPATH) . '/shared/db_helpers.php';
        if (is_file($helper)) require_once $helper;
        $secret = getenv('BZJ_PGB_SECRET');
        if (!$secret && function_exists('bzj_get_sso_secret')) $secret = bzj_get_sso_secret();
        if (!$secret) throw new Exception('BZJ_PGB_SECRET is not configured');
        return $secret;
    }

    public function paid($order_id) {
        try {
            (new PGB_Fulfillment())->handle_paid_order($order_id);
        } catch (Throwable $e) {
            PGB_Logger::log('Paid-order processing failed', array('order_id'=>$order_id,'error'=>$e->getMessage()), 'ERROR', __FILE__);
        }
    }

    public function admin_menu() {
        add_menu_page(
            'Buzzjuice',
            'Buzzjuice',
            'manage_options',
            'buzzjuice',
            function(){ echo '<div class="wrap"><h1>Buzzjuice</h1><p>Buzzjuice platform administration.</p></div>'; },
            'dashicons-networking',
            56
        );
        add_submenu_page(
            'buzzjuice',
            'Payment Gateways',
            'Payment Gateways',
            'manage_options',
            'buzzjuice-payment-gateways',
            array($this, 'admin_page')
        );
    }

    public function admin_page() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        if (isset($_POST['bzj_pgb_save'])) {
            check_admin_referer('bzj_pgb_settings');
            update_option('bzj_pgb_logging', !empty($_POST['logging']) ? 1 : 0);
            update_option('bzj_pgb_handoff_path', sanitize_text_field($_POST['handoff_path'] ?? '/pgb-checkout/'));
            echo '<div class="notice notice-success"><p>Payment Gateway settings saved.</p></div>';
        }
        $logging = (int)get_option('bzj_pgb_logging', BZJ_PGB_LOGGING ? 1 : 0);
        $path = get_option('bzj_pgb_handoff_path', BZJ_PGB_HANDOFF_PATH);
        echo '<div class="wrap"><h1>Buzzjuice &gt; Payment Gateways</h1>';
        echo '<form method="post">';
        wp_nonce_field('bzj_pgb_settings');
        echo '<table class="form-table"><tr><th>Bridge logging</th><td><label><input type="checkbox" name="logging" value="1" '.checked($logging,1,false).'> Enable detailed payment bridge logging</label></td></tr>';
        echo '<tr><th>Browser handoff path</th><td><input class="regular-text" name="handoff_path" value="'.esc_attr($path).'"><p class="description">Must match the Streams client handoff path.</p></td></tr></table>';
        submit_button('Save Changes','primary','bzj_pgb_save');
        echo '</form></div>';
    }

    private function error_page($message) {
        status_header(400);
        wp_die(esc_html($message), 'Buzzjuice Payment Gateway', array('response'=>400));
    }
}
