<?php
if (!defined('ABSPATH')) { exit; }

class PGB_Order_Processor {
    public function process_handoff($row) {
        $payload = json_decode($row['payload'], true);
        if (!is_array($payload)) throw new Exception('Invalid payment handoff payload');

        $existing = !empty($row['wc_order_id']) ? wc_get_order((int)$row['wc_order_id']) : false;
        if ($existing) {
            return $existing;
        }

        $wp_user_id = absint($payload['wp_user_id'] ?? 0);
        $streams_user_id = absint($payload['streams_user_id'] ?? 0);
        if (!$wp_user_id || !$streams_user_id) throw new Exception('Missing user mapping');

        $product_id = $this->resolve_product($payload);
        if (!$product_id) throw new Exception('WooCommerce product mapping failed');

        $product = wc_get_product($product_id);
        if (!$product) throw new Exception('Mapped WooCommerce product does not exist');

        $source_amount = (float)($payload['amount'] ?? 0);
        $source_currency = strtoupper((string)($payload['currency'] ?? 'GHS'));
        if ($source_amount <= 0) throw new Exception('Invalid source amount');

        $currency = new PGB_Currency();
        $target_currency = $currency->current_currency();
        $fx = $currency->convert($source_amount, $source_currency, $target_currency);

        $order = wc_create_order(array('customer_id' => $wp_user_id));
        if (is_wp_error($order)) throw new Exception($order->get_error_message());

        $qty = max(1, absint($payload['quantity'] ?? 1));
        $unit = $fx['amount'] / $qty;
        $item_id = $order->add_product($product, $qty, array(
            'subtotal' => wc_format_decimal($unit * $qty),
            'total'    => wc_format_decimal($unit * $qty),
        ));
        if (!$item_id) throw new Exception('Unable to add mapped product to order');

        $meta = array(
            '_buzzjuice_origin' => 'streams',
            '_buzzjuice_bridge_id' => (int)$row['id'],
            '_buzzjuice_transaction_kind' => sanitize_text_field($payload['transaction_kind'] ?? ''),
            '_buzzjuice_source_currency' => $source_currency,
            '_buzzjuice_source_amount' => wc_format_decimal($source_amount),
            '_buzzjuice_exchange_rate' => wc_format_decimal($fx['rate'], 10),
            '_buzzjuice_checkout_currency' => $target_currency,
            'wow_order_id' => sanitize_text_field($payload['wow_order_id'] ?? ''),
            'wow_user_id' => $streams_user_id,
            'userid' => $streams_user_id,
            'wow_post_id' => absint($payload['wow_post_id'] ?? 0),
            'qdw_order_id' => sanitize_text_field($payload['qdw_order_id'] ?? ''),
            'qdw_membershipType' => sanitize_text_field($payload['qdw_membershipType'] ?? ''),
            'qdw_transaction_kind' => sanitize_text_field($payload['qdw_transaction_kind'] ?? ''),
            'bzj_pgb_version' => BZJ_PGB_VERSION,
        );
        foreach ($meta as $k => $v) $order->update_meta_data($k, $v);

        $email = sanitize_email($payload['email'] ?? '');
        if ($email) {
            $order->set_billing_email($email);
            $order->set_billing_first_name(sanitize_text_field($payload['first_name'] ?? ''));
            $order->set_billing_last_name(sanitize_text_field($payload['last_name'] ?? ''));
        }
        $order->set_currency($target_currency);
        $order->calculate_totals();
        $order->save();

        PGB_DB::update((int)$row['id'], array(
            'status' => 'order_created',
            'wc_order_id' => $order->get_id(),
        ));

        PGB_Logger::log('WooCommerce order created', array(
            'bridge_id' => (int)$row['id'],
            'wc_order_id' => $order->get_id(),
            'streams_user_id' => $streams_user_id,
            'currency' => $target_currency,
        ), 'INFO', __FILE__);

        return $order;
    }

    private function resolve_product($p) {
        $explicit = absint($p['wc_product_id'] ?? 0);
        if ($explicit) return $explicit;

        $sku = sanitize_text_field($p['wc_sku'] ?? '');
        if (!$sku) {
            $kind = strtoupper(sanitize_text_field($p['transaction_kind'] ?? ''));
            $map = unserialize(BZJ_PGB_DEFAULT_WC_SKU_MAP);
            $sku = $map[$kind] ?? '';
        }
        if ($sku && function_exists('wc_get_product_id_by_sku')) {
            $id = wc_get_product_id_by_sku($sku);
            if ($id) return $id;
        }

        $kind = strtoupper(sanitize_text_field($p['transaction_kind'] ?? ''));
        $legacy_map = array(
            'PRO' => 'wow_pgb_product_id_' . sanitize_key($p['product_sku'] ?? ''),
            'WALLET' => 'wow_pgb_product_id_wow-pgb_wallet',
            'MARKET' => 'wow_pgb_product_id_wow-pgb_market',
            'FUND' => 'wow_pgb_product_id_wow-pgb_fund',
        );
        if (isset($legacy_map[$kind])) {
            $id = absint(get_option($legacy_map[$kind], 0));
            if ($id) return $id;
        }
        return 0;
    }
}
