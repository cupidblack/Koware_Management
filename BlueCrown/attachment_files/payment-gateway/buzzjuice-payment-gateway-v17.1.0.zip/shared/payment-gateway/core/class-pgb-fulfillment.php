<?php
if (!defined('ABSPATH')) { exit; }

class PGB_Fulfillment {
    public function handle_paid_order($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;
        if ($order->get_meta('_bzj_pgb_fulfilled_at')) return;
        if (!in_array($order->get_status(), array('processing','completed'), true)) return;

        $this->sync_subscription($order);
        $this->sync_wordpress_role($order);

        do_action('bzj_pgb_paid_order', $order);

        $order->update_meta_data('_bzj_pgb_fulfilled_at', gmdate('c'));
        $order->save();

        $bridge_id = absint($order->get_meta('_buzzjuice_bridge_id'));
        if ($bridge_id) PGB_DB::update($bridge_id, array('status'=>'fulfilled'));

        PGB_Logger::log('Paid order fulfilled', array('order_id'=>$order_id), 'INFO', __FILE__);
    }

    private function sync_subscription($order) {
        if (!function_exists('wcs_get_subscriptions_for_order')) return;
        $subs = wcs_get_subscriptions_for_order($order->get_id(), array('order_type'=>'parent'));
        if (!$subs) $subs = wcs_get_subscriptions_for_order($order->get_id());
        foreach ($subs as $sub) {
            $status = $sub->get_status();
            if (in_array($status, array('pending','on-hold'), true) && $order->is_paid()) {
                try { $sub->update_status('active', 'Activated by Buzzjuice Payment Gateway.'); }
                catch (Throwable $e) {
                    PGB_Logger::log('Subscription activation failed', array('order_id'=>$order->get_id(),'subscription_id'=>$sub->get_id(),'error'=>$e->getMessage()), 'ERROR', __FILE__);
                }
            }
            $order->update_meta_data('_bzj_subscription_id', $sub->get_id());
            $order->save();
        }
    }

    private function sync_wordpress_role($order) {
        $user_id = absint($order->get_customer_id());
        $post_id = absint($order->get_meta('wow_post_id'));
        if (!$user_id || !$post_id) return;

        $role_map = array(
            1 => 'classic_lifestyle',
            2 => 'silver_lifestyle',
            3 => 'rockstar_lifestyle',
            4 => 'premium_lifestyle',
        );
        if (!isset($role_map[$post_id])) return;

        $user = get_user_by('id', $user_id);
        if (!$user) return;
        $role = $role_map[$post_id];
        if (!in_array($role, (array)$user->roles, true)) {
            $user->add_role($role);
            PGB_Logger::log('WordPress role synchronized', array('user_id'=>$user_id,'role'=>$role), 'INFO', __FILE__);
        }
    }
}
