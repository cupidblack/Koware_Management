<?php
if (!defined('ABSPATH')) { exit; }

add_action('bzj_pgb_paid_order', function($order) {
    /*
     * This integration deliberately performs only durable state marking here.
     * Product-specific Streams fulfillment can be added from the proven
     * wow-pgb_sync.php routines without introducing an API dependency.
     */
    $streams_user_id = absint($order->get_meta('wow_user_id'));
    if (!$streams_user_id) return;

    PGB_Logger::log('Streams paid-order integration dispatched', array(
        'order_id'=>$order->get_id(),
        'streams_user_id'=>$streams_user_id,
        'transaction_kind'=>$order->get_meta('_buzzjuice_transaction_kind')
    ), 'INFO', __FILE__);

    do_action('bzj_pgb_streams_fulfillment', $order, $streams_user_id);
}, 50);
