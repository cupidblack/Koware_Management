<?php
if (!defined('ABSPATH')) { exit; }

/*
 * Jewel integration seam. The existing Streams webhook remains the authoritative
 * business rule until its exact rebate calculation is extracted into this file.
 * No rebate is guessed or duplicated here.
 */
add_action('bzj_pgb_paid_order', function($order) {
    $is_jewel = strtolower((string)$order->get_meta('jewel_affiliate')) === 'yes'
        || strtolower((string)$order->get_meta('affiliate_role')) === 'jewel_affiliate';

    if (!$is_jewel) return;

    do_action('bzj_pgb_jewel_paid_order', $order);
    PGB_Logger::log('Jewel affiliate order event dispatched', array('order_id'=>$order->get_id()), 'INFO', __FILE__);
}, 40);
