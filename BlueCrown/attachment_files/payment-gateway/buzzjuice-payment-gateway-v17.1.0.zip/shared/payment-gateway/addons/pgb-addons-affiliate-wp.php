<?php
if (!defined('ABSPATH')) { exit; }

/*
 * Migration-safe AffiliateWP adapter.
 *
 * The proven AffiliateWP routine from wow-pgb_sync.php is reused when it exists.
 * This prevents a second, competing commission implementation during Phase A.
 * Once the exact working logic has been extracted, this adapter becomes the
 * permanent home for it.
 */
add_action('bzj_pgb_paid_order', function($order) {
    if (!function_exists('bluecrown_affiliatewp_post_checkout_verification')) {
        PGB_Logger::log('AffiliateWP legacy verification function unavailable; no commission call made', array('order_id'=>$order->get_id()), 'WARNING', __FILE__);
        return;
    }

    try {
        bluecrown_affiliatewp_post_checkout_verification($order->get_id());
        PGB_Logger::log('AffiliateWP verification invoked', array('order_id'=>$order->get_id()), 'INFO', __FILE__);
    } catch (Throwable $e) {
        PGB_Logger::log('AffiliateWP processing failed', array('order_id'=>$order->get_id(),'error'=>$e->getMessage()), 'ERROR', __FILE__);
    }
}, 30);
