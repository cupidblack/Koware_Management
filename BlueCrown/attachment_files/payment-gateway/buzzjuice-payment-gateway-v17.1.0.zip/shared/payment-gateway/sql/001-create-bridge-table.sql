CREATE TABLE IF NOT EXISTS `Wo_Payment_Gateway_Bridge` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `token_hash` CHAR(64) NOT NULL,
  `signature_hash` CHAR(64) NOT NULL,
  `status` VARCHAR(32) NOT NULL DEFAULT 'pending',
  `payload` LONGTEXT NOT NULL,
  `wc_order_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `wc_subscription_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `claimed_at` DATETIME NULL DEFAULT NULL,
  `last_error` TEXT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_token_hash` (`token_hash`),
  KEY `idx_status_expires` (`status`,`expires_at`),
  KEY `idx_wc_order_id` (`wc_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
