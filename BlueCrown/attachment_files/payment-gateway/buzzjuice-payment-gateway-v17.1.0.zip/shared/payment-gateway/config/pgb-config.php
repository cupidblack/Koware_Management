<?php
if (!defined('ABSPATH')) { exit; }

if (!defined('BZJ_PGB_ENABLED')) define('BZJ_PGB_ENABLED', true);
if (!defined('BZJ_PGB_LOGGING')) define('BZJ_PGB_LOGGING', false);
if (!defined('BZJ_PGB_HANDOFF_PATH')) define('BZJ_PGB_HANDOFF_PATH', '/pgb-checkout/');
if (!defined('BZJ_PGB_TOKEN_TTL')) define('BZJ_PGB_TOKEN_TTL', 900);
if (!defined('BZJ_PGB_MAX_CLOCK_SKEW')) define('BZJ_PGB_MAX_CLOCK_SKEW', 300);

/*
 * Product mapping uses the existing WoWonder configuration first.
 * WordPress options can override it without requiring API credentials.
 */
if (!defined('BZJ_PGB_DEFAULT_WC_SKU_MAP')) {
    define('BZJ_PGB_DEFAULT_WC_SKU_MAP', serialize(array(
        'PRO'    => 'wow-pgb_pro',
        'WALLET' => 'wow-pgb_wallet',
        'MARKET' => 'wow-pgb_market',
        'FUND'   => 'wow-pgb_fund',
    )));
}
