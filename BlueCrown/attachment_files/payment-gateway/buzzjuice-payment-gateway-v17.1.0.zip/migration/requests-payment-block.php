<?php
/*
 * Replace only the old WoW-PGB payment block in streams/requests.php.
 *
 * OLD:
 *   require 'assets/wow-pgb/wow-pgb_init.php';
 *
 * NEW:
 */
if ($f == 'payment' && isset($_POST['payment_type']) && $_POST['payment_type'] === 'wow_payment') {
    require __DIR__ . '/../streams/assets/wow-pgb/pgb-streams-handler.php';
}
