# Buzzjuice Payment Gateway Bridge v17.1.0

## Important correction to the GitHub v17 proposal

The GitHub proposal is useful, but its `streams/requests.php` patch loads `wp-load.php`. That is explicitly incompatible with the Buzzjuice Streams architecture and is therefore NOT used here.

The browser handoff is the transport boundary:

Streams PHP -> Streams database -> browser HTTPS redirect -> WordPress MU plugin -> native WooCommerce CRUD.

No Streams PHP process calls `https://buzzjuice.net`, and Streams never loads WordPress.

## Deployment order

1. Add `BZJ_PGB_SECRET` to the shared `.env`.
2. Create `shared/payment-gateway/` and copy the package contents.
3. Install `wp-content/mu-plugins/bzj-payment-gateway.php`.
4. Create the bridge table. The MU plugin can install it from wp-admin after activation; alternatively run `sql/001-create-bridge-table.sql` against the Streams/Palmier database.
5. Replace only the WoW-PGB branch in `streams/requests.php` with `migration/requests-payment-block.php`.
6. Rename the old `streams/assets/wow-pgb/wow-pgb_init.php` to a backup outside the active path. Do not execute it.
7. Do NOT delete `wow-pgb_sync.php` or `buzzjuice-affwp-order-complete.php` yet.
8. During Phase A, the AffiliateWP addon calls the already-working `bluecrown_affiliatewp_post_checkout_verification()` routine if it is loaded.
9. Disable the old WooCommerce Thank You redirect in `wow-pgb_sync.php` before production cutover, otherwise two redirect handlers can compete. The exact old block is the `wp_footer` -> `wowonder_order_redirect` section.
10. Test PRO first, then WALLET, MARKET/FUND, and DONATE.

## Configuration

The existing Streams payment settings can continue to hold the product IDs/mappings. The old API URL/key/secret fields are no longer used by the new payment path and should eventually be removed from the payment-settings page.

The new WordPress page is:
Buzzjuice -> Payment Gateways

Logging is disabled by default. For troubleshooting, set the WordPress option `bzj_pgb_logging` to 1 and define `BZJ_PGB_LOGGING` accordingly in the configuration. Do not log tokens, signatures, cookies, API secrets or passwords.

## Product mapping

The client sends `wc_product_id` when available. Otherwise the WordPress engine resolves a SKU.

For PRO, use the existing subscription parent/variation SKU mapping from the installed WooCommerce products. Do not create duplicate products during this migration.

## Subscriptions

Do not manually create a subscription through the WooCommerce REST API. A subscription product in a native WooCommerce order should be allowed to flow through WooCommerce Subscriptions. The fulfillment layer only finds the subscription attached to the order and activates it if it is still pending/on-hold after payment.

## AffiliateWP

The working AffiliateWP routine is retained as a migration-safe adapter. This avoids inventing a new commission algorithm. After successful production tests, move the exact function body from `wow-pgb_sync.php` into `addons/pgb-addons-affiliate-wp.php` and remove the legacy dependency.

## Jewel

No Jewel rebate formula is invented in v17.1.0. The integration event is provided so the exact existing `jewel-affiliate-webhook.php` business rules can be moved into `int/pgb-int-jewel-affiliate.php` without changing the calculation.

## Logging

Logs are source-labelled:
- `log/class-pgb-bootstrap.log`
- `log/class-pgb-order-processor.log`
- `log/class-pgb-fulfillment.log`
- `log/class-pgb-currency.log` if added
- `log/pgb-client-streams.log`
- addon/integration log files use their own source names.

Never store raw payment tokens or signatures in logs.
