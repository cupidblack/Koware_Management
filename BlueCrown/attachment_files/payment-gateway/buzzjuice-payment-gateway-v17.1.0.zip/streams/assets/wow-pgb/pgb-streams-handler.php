<?php
/*
 * Buzzjuice Payment Gateway client for WoWonder/Streams.
 * IMPORTANT: This file never loads WordPress and never calls the WooCommerce API.
 */
require_once dirname(__DIR__, 3) . '/assets/init.php';
require_once dirname(__DIR__, 4) . '/../../shared/db_helpers.php';

function bzj_pgb_streams_log($message, $context = array()) {
    $enabled = defined('BZJ_PGB_STREAMS_LOGGING') ? BZJ_PGB_STREAMS_LOGGING : false;
    if (!$enabled) return;
    $dir = dirname(__DIR__, 4) . '/../../shared/payment-gateway/log';
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    $entry = array('time'=>gmdate('c'),'message'=>$message,'context'=>$context);
    @file_put_contents($dir . '/pgb-client-streams.log', json_encode($entry) . PHP_EOL, FILE_APPEND | LOCK_EX);
}

if (empty($wo['loggedin']) || empty($wo['user']['id'])) {
    http_response_code(403);
    exit('Please login or signup to continue.');
}

$conn = get_palmier_db_conn();
if (!$conn) {
    http_response_code(500);
    exit('Payment gateway database unavailable.');
}

$post = $_POST;
$kind = strtoupper(trim((string)($post['transaction_kind'] ?? '')));
if (!$kind) {
    $kind = strtoupper(trim((string)($post['transaction_type'] ?? '')));
}
$allowed = array('PRO','WALLET','MARKET','FUND','DONATE');
if (!in_array($kind, $allowed, true)) {
    http_response_code(400);
    exit('Invalid payment transaction.');
}

$streams_user_id = (int)$wo['user']['id'];
$wp_user_id = 0;
$stmt = $conn->prepare('SELECT wp_user_id,email FROM ' . T_USERS . ' WHERE user_id=? LIMIT 1');
$stmt->bind_param('i', $streams_user_id);
$stmt->execute();
$res = $stmt->get_result();
$user = $res ? $res->fetch_assoc() : null;
if (!$user || empty($user['wp_user_id'])) {
    http_response_code(400);
    exit('Your Buzzjuice account is not linked to WordPress.');
}
$wp_user_id = (int)$user['wp_user_id'];

$amount = isset($post['amount']) ? (float)$post['amount'] : 0;
$currency = strtoupper(trim((string)($post['currency'] ?? $wo['config']['currency'] ?? 'GHS')));
$quantity = max(1, (int)($post['product_units'] ?? 1));
if ($amount <= 0) {
    http_response_code(400);
    exit('Invalid payment amount.');
}

$wow_order_id = trim((string)($post['wow_order_id'] ?? ('bzj_' . bin2hex(random_bytes(10)))));
$wow_post_id = (int)($post['wow_post_id'] ?? 0);
$qdw_order_id = trim((string)($post['qdw_order_id'] ?? ''));
$product_sku = trim((string)($post['product_sku'] ?? ''));
$wc_product_id = (int)($post['wc_product_id'] ?? 0);
$email = !empty($user['email']) ? $user['email'] : trim((string)($post['email'] ?? ''));

$payload = array(
    'wp_user_id'=>$wp_user_id,
    'streams_user_id'=>$streams_user_id,
    'email'=>$email,
    'first_name'=>(string)($wo['user']['first_name'] ?? ''),
    'last_name'=>(string)($wo['user']['last_name'] ?? ''),
    'amount'=>$amount,
    'currency'=>$currency,
    'quantity'=>$quantity,
    'transaction_kind'=>$kind,
    'product_sku'=>$product_sku,
    'wc_product_id'=>$wc_product_id,
    'wow_order_id'=>$wow_order_id,
    'wow_post_id'=>$wow_post_id,
    'qdw_order_id'=>$qdw_order_id,
    'qdw_membershipType'=>(string)($post['qdw_membershipType'] ?? ''),
    'qdw_transaction_kind'=>(string)($post['qdw_transaction_kind'] ?? ''),
);

$token = rtrim(strtr(base64_encode(random_bytes(48)), '+/', '-_'), '=');
$hash = hash('sha256', $token);
$secret = getenv('BZJ_PGB_SECRET');
if (!$secret && function_exists('bzj_get_sso_secret')) $secret = bzj_get_sso_secret();
if (!$secret) {
    http_response_code(500);
    exit('Payment gateway secret is not configured.');
}

$signature = hash_hmac('sha256', $token, $secret);
$payload_json = json_encode($payload, JSON_UNESCAPED_SLASHES);

$stmt = $conn->prepare(
    'INSERT INTO Wo_Payment_Gateway_Bridge
    (token_hash,signature_hash,status,payload,created_at,expires_at)
    VALUES (?,?, "pending",?,UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 15 MINUTE))'
);
$signature_hash = hash('sha256', $signature);
$stmt->bind_param('sss', $hash, $signature_hash, $payload_json);

if (!$stmt->execute()) {
    bzj_pgb_streams_log('Bridge insert failed', array('error'=>$stmt->error,'wow_order_id'=>$wow_order_id));
    http_response_code(500);
    exit('Unable to create payment session.');
}

$id = $stmt->insert_id;
bzj_pgb_streams_log('Bridge handoff created', array('bridge_id'=>$id,'wow_order_id'=>$wow_order_id,'kind'=>$kind));

$base = rtrim((string)($wo['config']['wow_store_url'] ?? ''), '/');
if (!$base) $base = rtrim((string)($wo['config']['site_url'] ?? ''), '/');
$handoff = 'https://buzzjuice.net/pgb-checkout/';
$url = $handoff . '?token=' . rawurlencode($token) . '&sig=' . rawurlencode($signature);

header('Location: ' . $url, true, 302);
exit;
