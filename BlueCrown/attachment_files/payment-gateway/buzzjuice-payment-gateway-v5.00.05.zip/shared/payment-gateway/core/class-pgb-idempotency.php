<?php
defined('ABSPATH') || exit;

class PGB_Idempotency {
    private $log;
    public function __construct(PGB_Logger $log){$this->log=$log;}
    public function lock($key) {
        global $wpdb;
        $name='bzj_pgb_'.substr(hash('sha256',(string)$key),0,48);
        $ok=(int)$wpdb->get_var($wpdb->prepare("SELECT GET_LOCK(%s,%d)",$name,(int)bzj_pgb_config()['lock_timeout']));
        return ['name'=>$name,'acquired'=>$ok===1];
    }
    public function unlock($lock) {
        global $wpdb;
        if (!empty($lock['name'])) $wpdb->get_var($wpdb->prepare("SELECT RELEASE_LOCK(%s)",$lock['name']));
    }
    public function get($wow_order_id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}bzj_pgb_transactions WHERE wow_order_id=%s LIMIT 1",$wow_order_id));
    }
    public function create(array $data) {
        global $wpdb;
        $now=current_time('mysql',true);
        $ok=$wpdb->insert($wpdb->prefix.'bzj_pgb_transactions',[
            'wow_order_id'=>$data['wow_order_id'],'request_id'=>$data['request_id'],
            'wow_user_id'=>(int)$data['wow_user_id'],'wp_user_id'=>(int)$data['wp_user_id'],
            'transaction_kind'=>$data['transaction_kind'],'status'=>'initiated',
            'fulfillment_status'=>'pending','amount'=>$data['amount'],'currency'=>$data['currency'],
            'payload'=>wp_json_encode($data),'created_at'=>$now,'updated_at'=>$now
        ],['%s','%s','%d','%d','%s','%s','%s','%f','%s','%s','%s']);
        if (!$ok) {
            $row=$this->get($data['wow_order_id']);
            if ($row) return $row;
            throw new RuntimeException('Unable to create payment transaction ledger row: '.$wpdb->last_error);
        }
        return $this->get($data['wow_order_id']);
    }
    public function update($id,array $fields) {
        global $wpdb;
        $fields['updated_at']=current_time('mysql',true);
        $formats=[];
        foreach($fields as $k=>$v) $formats[] = is_int($v)?'%d':(is_float($v)?'%f':'%s');
        return $wpdb->update($wpdb->prefix.'bzj_pgb_transactions',$fields,['id'=>(int)$id],$formats,['%d']);
    }
}
