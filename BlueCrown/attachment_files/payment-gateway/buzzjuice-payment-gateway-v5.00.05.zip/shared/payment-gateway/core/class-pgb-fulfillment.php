<?php
defined('ABSPATH') || exit;

class PGB_Fulfillment {
    private $log; private $ledger;
    public function __construct(PGB_Logger $log,PGB_Idempotency $ledger){$this->log=$log;$this->ledger=$ledger;}

    public function on_paid($order_id,$context='hook') {
        $order=wc_get_order($order_id);
        if (!$order) return;
        if ($order->get_meta('_buzzjuice_origin',true)!=='streams') return;
        $paid=$order->is_paid() || in_array($order->get_status(),['processing','completed'],true);
        if (!$paid) return;
        $tx=$this->ledger->get($order->get_meta('wow_order_id',true));
        if (!$tx) {
            $this->log->warning('Paid order has no PGB ledger row',['woo_order_id'=>$order_id]);
            return;
        }
        if ($tx->fulfillment_status==='complete') return;
        $this->ledger->update($tx->id,['woo_order_id'=>(int)$order_id,'status'=>'paid','paid_at'=>current_time('mysql',true)]);
        try {
            do_action('bzj_pgb_before_fulfillment',$order,$tx);
            $this->sync_streams_transaction($order,$tx);
            do_action('bzj_pgb_fulfillment',$order,$tx);
            $this->ledger->update($tx->id,['fulfillment_status'=>'complete','status'=>'fulfilled','fulfilled_at'=>current_time('mysql',true),'last_error'=>'']);
            $order->update_meta_data('_bzj_pgb_fulfilled',current_time('mysql',true));
            $order->save();
            $this->log->info('Fulfillment complete',['woo_order_id'=>$order_id,'wow_order_id'=>$tx->wow_order_id,'context'=>$context]);
        } catch (Throwable $e) {
            $this->ledger->update($tx->id,['fulfillment_status'=>'failed','status'=>'fulfillment_failed','attempts'=>((int)$tx->attempts)+1,'last_error'=>$e->getMessage()]);
            $this->log->error('Fulfillment failed',['woo_order_id'=>$order_id,'error'=>$e->getMessage(),'attempts'=>((int)$tx->attempts)+1]);
            throw $e;
        }
    }

    private function sync_streams_transaction($order,$tx) {
        $db=$this->streams_db();
        if (!$db) throw new RuntimeException('Streams database connection unavailable.');
        $wow_order_id=$tx->wow_order_id;
        $status=$order->get_status();
        $method=$order->get_payment_method();
        $total=(float)$order->get_total();
        $currency=$order->get_currency();
        $stmt=$db->prepare("UPDATE Wo_Payment_Transactions SET payment_status=?, payment_method=?, woo_order_id=?, amount=?, currency_code=?, transaction_dt=NOW() WHERE order_id=? LIMIT 1");
        if (!$stmt) throw new RuntimeException('Streams transaction update prepare failed: '.$db->error);
        $wid=(string)$order->get_id();
        $stmt->bind_param('sssdss',$status,$method,$wid,$total,$currency,$wow_order_id);
        if (!$stmt->execute()) throw new RuntimeException('Streams transaction update failed: '.$stmt->error);
        $stmt->close();

        $user_id=(int)$tx->wow_user_id;
        $wallet_id=0; $crowdfund_id=0; $pro_ids=[];
        $post_id=(int)$order->get_meta('wow_post_id',true);
        $qdw=(string)$order->get_meta('qdw_order_id',true);
        $items=$order->get_items('line_item');
        $product_id=0;$variation_id=0;
        foreach($items as $item){$product_id=(int)$item->get_product_id();$variation_id=(int)$item->get_variation_id();break;}

        if ($tx->transaction_kind==='WALLET' && $qdw==='') {
            $stmt=$db->prepare("UPDATE Wo_Users SET wallet=wallet+? WHERE user_id=? LIMIT 1");
            if (!$stmt) throw new RuntimeException('Wallet update prepare failed: '.$db->error);
            $stmt->bind_param('di',$total,$user_id);
            if (!$stmt->execute()) throw new RuntimeException('Wallet update failed: '.$stmt->error);
            $stmt->close();
        }

        if ($tx->transaction_kind==='DONATE' && $post_id>0) {
            $now=time();
            $stmt=$db->prepare("INSERT INTO Wo_Funding_Raise (funding_id,user_id,amount,time) VALUES (?,?,?,?)");
            if (!$stmt) throw new RuntimeException('Funding insert prepare failed: '.$db->error);
            $stmt->bind_param('iidi',$post_id,$user_id,$total,$now);
            if (!$stmt->execute()) throw new RuntimeException('Funding insert failed: '.$stmt->error);
            $stmt->close();
        }

        $pro_type=0;
        if ($tx->transaction_kind==='PRO' && in_array($post_id,[1,2,3,4],true)) $pro_type=$post_id;
        if ($pro_type>0) {
            $now=time(); $is='1';
            $stmt=$db->prepare("UPDATE Wo_Users SET pro_time=?, is_pro=?, pro_type=? WHERE user_id=? LIMIT 1");
            if (!$stmt) throw new RuntimeException('Pro update prepare failed: '.$db->error);
            $stmt->bind_param('isis',$now,$is,$pro_type,$user_id);
            if (!$stmt->execute()) throw new RuntimeException('Pro update failed: '.$stmt->error);
            $stmt->close();
            if (function_exists('bzj_log_activity')) {
                do_action('bzj_pgb_membership_activated',$user_id,$pro_type,$order);
            }
        }
    }

    private function streams_db() {
        if (function_exists('get_streams_db_conn')) return get_streams_db_conn();
        if (function_exists('get_wo_db_conn')) return get_wo_db_conn();
        if (function_exists('get_wowonder_db_conn')) return get_wowonder_db_conn();
        if (function_exists('bzj_get_streams_db_conn')) return bzj_get_streams_db_conn();
        return null;
    }
}
