<?php
defined('ABSPATH') || exit;

class PGB_Validator {
    public static function request(array $data) {
        $required = ['wow_order_id','wow_user_id','wp_user_id','transaction_kind','amount','currency','product_id'];
        foreach ($required as $key) {
            if (!array_key_exists($key,$data) || $data[$key] === '' || $data[$key] === null) {
                return new WP_Error('pgb_missing_'.$key, 'Missing required payment field: '.$key, ['status'=>400]);
            }
        }
        $data['wow_order_id'] = preg_replace('/[^A-Za-z0-9._-]/','',(string)$data['wow_order_id']);
        if ($data['wow_order_id']==='') return new WP_Error('pgb_invalid_order','Invalid Buzzjuice order ID.',['status'=>400]);
        $data['wow_user_id'] = absint($data['wow_user_id']);
        $data['wp_user_id'] = absint($data['wp_user_id']);
        $data['product_id'] = absint($data['product_id']);
        $data['variation_id'] = !empty($data['variation_id']) ? absint($data['variation_id']) : 0;
        $data['quantity'] = max(1, absint($data['quantity'] ?? 1));
        $data['amount'] = round((float)$data['amount'],2);
        $data['product_price'] = round((float)($data['product_price'] ?? $data['amount']),2);
        $data['currency'] = strtoupper(preg_replace('/[^A-Z]/','',(string)$data['currency']));
        if ($data['amount'] <= 0 || strlen($data['currency']) !== 3) return new WP_Error('pgb_invalid_amount','Invalid amount or currency.',['status'=>400]);
        return $data;
    }
}
