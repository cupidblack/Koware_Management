<?php
defined('ABSPATH') || exit;

class PGB_Logger {
    private $component;
    private $file;
    private $enabled;
    private $min_level;
    private static $levels = ['debug'=>0,'info'=>1,'warning'=>2,'error'=>3,'critical'=>4];

    public function __construct($component) {
        $this->component = preg_replace('/[^A-Za-z0-9_.-]/', '-', (string)$component);
        $cfg = bzj_pgb_config();
        $this->enabled = (bool)$cfg['logging_enabled'];
        $this->min_level = $cfg['log_level'];
        $dir = trailingslashit(BZJ_PGB_ROOT) . 'log/';
        if (!is_dir($dir)) wp_mkdir_p($dir);
        $this->file = $dir . $this->component . '.log';
    }

    public function log($level, $message, array $context = []) {
        $level = strtolower((string)$level);
        if (!$this->enabled || !isset(self::$levels[$level]) || self::$levels[$level] < self::$levels[$this->min_level]) return;
        $safe = $this->sanitize($context);
        $line = wp_json_encode([
            'time'=>gmdate('c'),
            'level'=>$level,
            'component'=>$this->component,
            'message'=>(string)$message,
            'context'=>$safe,
        ], JSON_UNESCAPED_SLASHES);
        if ($line !== false) {
            @file_put_contents($this->file, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
        }
        if (in_array($level, ['error','critical'], true)) {
            error_log('[BZJ-PGB]['.$this->component.'] '.(string)$message);
        }
    }
    public function debug($m,array $c=[]){$this->log('debug',$m,$c);}
    public function info($m,array $c=[]){$this->log('info',$m,$c);}
    public function warning($m,array $c=[]){$this->log('warning',$m,$c);}
    public function error($m,array $c=[]){$this->log('error',$m,$c);}
    public function critical($m,array $c=[]){$this->log('critical',$m,$c);}

    private function sanitize($value) {
        if (is_array($value)) {
            $out=[];
            foreach ($value as $k=>$v) {
                $lk=strtolower((string)$k);
                if (preg_match('/secret|token|cookie|password|authorization|signature|consumer_key|consumer_secret|api_key|api_secret/i',$lk)) {
                    $out[$k]='[redacted]';
                } else {
                    $out[$k]=$this->sanitize($v);
                }
            }
            return $out;
        }
        if (is_object($value)) return '[object]';
        if (is_string($value) && strlen($value)>1000) return substr($value,0,997).'...';
        return $value;
    }
}
