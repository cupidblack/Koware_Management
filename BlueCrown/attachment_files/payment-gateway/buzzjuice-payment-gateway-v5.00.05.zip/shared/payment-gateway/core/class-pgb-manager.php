<?php
defined('ABSPATH') || exit;

class PGB_Manager {
    private $log; private $ledger; private $orders; private $fulfillment;
    public function __construct(PGB_Logger $log,PGB_Idempotency $ledger,PGB_Order $orders,PGB_Fulfillment $fulfillment){
        $this->log=$log;$this->ledger=$ledger;$this->orders=$orders;$this->fulfillment=$fulfillment;
    }
    public function create_order(array $data) {
        $lock=$this->ledger->lock('order:'.$data['wow_order_id']);
        if (!$lock['acquired']) throw new RuntimeException('Payment request is already being processed.');
        try {
            $existing=$this->ledger->get($data['wow_order_id']);
            if ($existing && $existing->woo_order_id) {
                $order=wc_get_order((int)$existing->woo_order_id);
                if ($order) return $order;
            }
            if (!$existing) $existing=$this->ledger->create($data);
            $order=$this->orders->create($data);
            $this->ledger->update($existing->id,['woo_order_id'=>(int)$order->get_id(),'status'=>'order_created']);
            return $order;
        } finally { $this->ledger->unlock($lock); }
    }
    public function handle_paid($order_id,$context='hook') {
        $lock=$this->ledger->lock('fulfill:'.$order_id);
        if (!$lock['acquired']) return;
        try {$this->fulfillment->on_paid($order_id,$context);} finally {$this->ledger->unlock($lock);}
    }
}
