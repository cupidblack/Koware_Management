<?php
defined('ABSPATH') || exit;

class PGB_Order {
    private $log;
    public function __construct(PGB_Logger $log){$this->log=$log;}

    public function create(array $d) {
        if (!function_exists('wc_get_order')) throw new RuntimeException('WooCommerce is not loaded.');
        $product=wc_get_product($d['variation_id'] ?: $d['product_id']);
        if (!$product) throw new RuntimeException('Configured WooCommerce product/variation was not found.');
        $order=new WC_Order();
        if ($d['wp_user_id']) $order->set_customer_id((int)$d['wp_user_id']);
        $order->set_currency($d['currency']);
        $order->set_customer_ip_address(isset($_SERVER['REMOTE_ADDR'])?wc_clean(wp_unslash($_SERVER['REMOTE_ADDR'])):'');
        $order->set_customer_user_agent(isset($_SERVER['HTTP_USER_AGENT'])?wc_clean(wp_unslash($_SERVER['HTTP_USER_AGENT'])):'');
        $this->set_address($order,$d);
        $item_id=$order->add_product($product,(int)$d['quantity'],[
            'subtotal'=>$d['product_price']*(int)$d['quantity'],
            'total'=>$d['amount'],
        ]);
        if (!$item_id) throw new RuntimeException('WooCommerce could not add the configured product to the order.');
        $meta=[
            'wow_order_id'=>$d['wow_order_id'],'wow_user_id'=>$d['wow_user_id'],
            'userid'=>$d['wow_user_id'],'wp_user_id'=>$d['wp_user_id'],
            'wow_post_id'=>$d['wow_post_id'] ?? 0,'qdw_order_id'=>$d['qdw_order_id'] ?? '',
            '_buzzjuice_origin'=>'streams','transaction_kind'=>$d['transaction_kind'],
            '_bzj_pgb_request_id'=>$d['request_id'],
        ];
        if (!empty($d['rebate_credit_cents'])) $meta['bz_rebate_credit_cents']=(int)$d['rebate_credit_cents'];
        if (!empty($d['affwp_snapshot'])) $meta['_buzzjuice_affwp_context_snapshot']=wp_json_encode($d['affwp_snapshot']);
        foreach($meta as $k=>$v) $order->update_meta_data($k,$v);
        $order->calculate_totals(false);
        $order->set_status('pending');
        $order->save();
        $this->log->info('WooCommerce order created',['woo_order_id'=>$order->get_id(),'wow_order_id'=>$d['wow_order_id']]);
        return $order;
    }

    private function set_address($order,$d) {
        $u=is_array($d['user'] ?? null)?$d['user']:[];
        $email=sanitize_email($u['email'] ?? $d['email'] ?? '');
        $first=sanitize_text_field($u['first_name'] ?? $u['username'] ?? 'Buzzjuice');
        $last=sanitize_text_field($u['last_name'] ?? 'Customer');
        $common=[
            'first_name'=>$first,'last_name'=>$last,'company'=>sanitize_text_field($u['company']??''),
            'address_1'=>sanitize_text_field($u['address']??''),'address_2'=>'',
            'city'=>sanitize_text_field($u['city']??''),'state'=>sanitize_text_field($u['state']??''),
            'postcode'=>sanitize_text_field($u['zip']??''),'country'=>strtoupper(sanitize_text_field($u['country_id']??'GH')),
            'email'=>$email,'phone'=>sanitize_text_field($u['phone_number']??''),
        ];
        $order->set_address($common,'billing');
        $order->set_address($common,'shipping');
    }
}
