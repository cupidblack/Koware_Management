<?php
defined('ABSPATH') || exit;

class PGB_Auth {
    public static function verify(WP_REST_Request $request, $raw_body, PGB_Logger $log) {
        $cfg=bzj_pgb_config();
        $secret=(string)$cfg['secret'];
        $ts=(string)$request->get_header('X-BZJ-PGB-Timestamp');
        $rid=(string)$request->get_header('X-BZJ-PGB-Request-ID');
        $sig=(string)$request->get_header('X-BZJ-PGB-Signature');
        if ($secret==='' || $ts==='' || $rid==='' || $sig==='') {
            $log->warning('Authentication headers or server secret missing');
            return new WP_Error('pgb_auth_missing','Payment bridge authentication failed.',['status'=>401]);
        }
        if (!ctype_digit($ts) || abs(time()-(int)$ts) > (int)$cfg['timestamp_tolerance']) {
            $log->warning('Request timestamp outside tolerance',['request_id'=>$rid]);
            return new WP_Error('pgb_auth_expired','Payment bridge request expired.',['status'=>401]);
        }
        if (!preg_match('/^[A-Za-z0-9._:-]{8,120}$/',$rid)) {
            return new WP_Error('pgb_auth_request_id','Invalid request ID.',['status'=>401]);
        }
        $message=$ts."\n".$rid."\n".$raw_body;
        $expected=hash_hmac('sha256',$message,$secret);
        if (!hash_equals($expected,$sig)) {
            $log->warning('Signature verification failed',['request_id'=>$rid]);
            return new WP_Error('pgb_auth_signature','Payment bridge authentication failed.',['status'=>401]);
        }
        return true;
    }
}
