<?php
defined('ABSPATH') || exit;
/* Streams fulfillment is intentionally registered by the core PGB_Fulfillment class.
 * This file is reserved for Streams-specific filters/hooks that do not belong in core.
 */
add_filter('bzj_pgb_streams_payload', function($payload){ return is_array($payload)?$payload:[]; });
