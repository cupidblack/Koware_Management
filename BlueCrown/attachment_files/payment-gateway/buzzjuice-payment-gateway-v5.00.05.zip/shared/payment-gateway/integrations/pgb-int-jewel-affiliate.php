<?php
defined('ABSPATH') || exit;

add_action('bzj_pgb_fulfillment', function($order,$tx){
    $log=new PGB_Logger('pgb-int-jewel-affiliate');
    if (!$order instanceof WC_Order) return;
    if ($order->get_meta('_bzj_jewel_processed',true)) return;

    $mapping=json_decode((string)get_option('bz_rebate_mapping_json',''),true);
    $mapping=is_array($mapping)?$mapping:[];
    $wow_user_id=(int)$order->get_meta('wow_user_id',true);
    if(!$wow_user_id) $wow_user_id=(int)$order->get_meta('userid',true);
    if(!$wow_user_id) {$log->warning('Jewel skipped: missing Streams user ID',['woo_order_id'=>$order->get_id()]);return;}

    $db=function_exists('get_streams_db_conn')?get_streams_db_conn():(function_exists('get_wo_db_conn')?get_wo_db_conn():null);
    if(!$db){$log->error('Jewel skipped: Streams DB unavailable');return;}

    $activated=[];
    foreach($order->get_items('line_item') as $item){
        $vid=(int)$item->get_variation_id(); if(!$vid)$vid=(int)$item->get_product_id();
        if(!isset($mapping[$vid])) continue;
        $map=$mapping[$vid]; $pro=(int)($map['wow_pro_type']??0);
        if($pro<1) continue;
        $now=time();$is='1';
        $stmt=$db->prepare("UPDATE Wo_Users SET pro_time=?, is_pro=?, pro_type=? WHERE user_id=? LIMIT 1");
        if(!$stmt) throw new RuntimeException('Jewel pro update prepare failed: '.$db->error);
        $stmt->bind_param('isis',$now,$is,$pro,$wow_user_id);
        if(!$stmt->execute()) throw new RuntimeException('Jewel pro update failed: '.$stmt->error);
        $stmt->close();$activated[]=$pro;
        $wp_user_id=(int)$order->get_customer_id();
        $role=trim((string)($map['wp_role']??''));
        if($wp_user_id && $role){
            $user=get_user_by('ID',$wp_user_id);
            if($user){
                $user->add_role('jewel_affiliate');
                $user->add_role($role);
                $primary=array_values(array_filter(array_map(function($r){return trim((string)($r['wp_role']??''));},$mapping)));
                foreach($primary as $r) if($r && $r!==$role) $user->remove_role($r);
            }
        }
    }

    $cents=(int)$order->get_meta('bz_rebate_credit_cents',true);
    if(!$cents){
        $raw=$order->get_meta('bz_rebate_credit_amount',true);
        if(is_numeric($raw)) $cents=(int)round((float)$raw*100);
    }
    if($cents>0){
        $amount=round($cents/100,2);
        $woo=(string)$order->get_id();
        $chk=$db->prepare("SELECT id FROM Wo_Payment_Transactions WHERE (woo_order_id=? OR order_id=?) AND userid=? AND notes LIKE '%Rebate%' LIMIT 1");
        $already=false;
        if($chk){$chk->bind_param('ssi',$woo,$woo,$wow_user_id);$chk->execute();$chk->store_result();$already=$chk->num_rows>0;$chk->close();}
        if(!$already){
            $db->begin_transaction();
            try{
                $u=$db->prepare("UPDATE Wo_Users SET wallet=wallet+? WHERE user_id=? LIMIT 1");
                if(!$u) throw new RuntimeException($db->error);
                $u->bind_param('di',$amount,$wow_user_id); if(!$u->execute()) throw new RuntimeException($u->error);$u->close();
                $note='Rebate - Subscription Rebate credit';
                $i=$db->prepare("INSERT INTO Wo_Payment_Transactions (userid,kind,amount,notes,order_id,payment_status,payment_method,woo_order_id,transaction_dt) VALUES (?,'RECEIVED',?,?,?,'completed','rebate',?,NOW())");
                if(!$i) throw new RuntimeException($db->error);
                $i->bind_param('idsss',$wow_user_id,$amount,$note,$woo,$woo);if(!$i->execute())throw new RuntimeException($i->error);$i->close();
                $db->commit();
            }catch(Throwable $e){$db->rollback();throw $e;}
        }
    }
    $order->update_meta_data('_bzj_jewel_processed',current_time('mysql'));$order->save();
    $log->info('Jewel fulfillment complete',['woo_order_id'=>$order->get_id(),'wow_user_id'=>$wow_user_id,'activated'=>$activated]);
},30,2);
