<?php
/**
 * Streams-side payment client. This file is included by wow-pgb_init.php.
 */
defined('WO_PGB_STREAMS_CLIENT') || define('WO_PGB_STREAMS_CLIENT', true);

function bzj_pgb_streams_sign($timestamp,$request_id,$body,$secret){
    return hash_hmac('sha256',$timestamp."\n".$request_id."\n".$body,$secret);
}
function bzj_pgb_streams_request(array $payload,$endpoint,$secret){
    $timestamp=(string)time();
    $request_id=!empty($payload['request_id']) ? (string)$payload['request_id'] : 'pgb_'.bin2hex(random_bytes(12));
    $body=json_encode($payload,JSON_UNESCAPED_SLASHES);
    $headers=[
        'Content-Type: application/json',
        'X-BZJ-PGB-Timestamp: '.$timestamp,
        'X-BZJ-PGB-Request-ID: '.$request_id,
        'X-BZJ-PGB-Signature: '.bzj_pgb_streams_sign($timestamp,$request_id,$body,$secret),
    ];
    $ch=curl_init($endpoint);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>20,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
    $raw=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
    if($raw===false||$code<200||$code>=300) throw new RuntimeException('Payment bridge request failed (HTTP '.$code.')'.($err?': '.$err:''));
    $json=json_decode($raw,true);
    if(!is_array($json)) throw new RuntimeException('Invalid payment bridge response.');
    return $json;
}
