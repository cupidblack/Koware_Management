<?php
defined('ABSPATH') || exit;

add_action('admin_menu',function(){
    add_menu_page('Payment Gateways','Payment Gateways','manage_options','bzj-payment-gateways','bzj_pgb_admin_page','dashicons-money-alt',58);
});
add_action('admin_init',function(){
    register_setting('bzj_pgb','bzj_pgb_logging',['type'=>'boolean','default'=>false]);
    register_setting('bzj_pgb','bzj_pgb_log_level',['type'=>'string','default'=>'info']);
    register_setting('bzj_pgb','bzj_pgb_streams_url',['type'=>'string','sanitize_callback'=>'esc_url_raw']);
    register_setting('bzj_pgb','bzj_pgb_streams_product_map',['type'=>'array','default'=>[]]);
});
function bzj_pgb_admin_page(){
    if(!current_user_can('manage_options'))return;
    $map=(array)get_option('bzj_pgb_streams_product_map',[]);
    ?>
    <div class="wrap"><h1>Buzzjuice Payment Gateways</h1>
    <form method="post" action="options.php"><?php settings_fields('bzj_pgb'); ?>
    <table class="form-table">
    <tr><th>Logging</th><td><label><input type="checkbox" name="bzj_pgb_logging" value="1" <?php checked(get_option('bzj_pgb_logging',false),true); ?>> Enabled</label></td></tr>
    <tr><th>Log level</th><td><select name="bzj_pgb_log_level"><?php foreach(['debug','info','warning','error','critical'] as $l): ?><option value="<?php echo esc_attr($l);?>" <?php selected(get_option('bzj_pgb_log_level','info'),$l);?>><?php echo esc_html(ucfirst($l));?></option><?php endforeach;?></select></td></tr>
    <tr><th>Streams URL</th><td><input class="regular-text" type="url" name="bzj_pgb_streams_url" value="<?php echo esc_attr(get_option('bzj_pgb_streams_url',''));?>"></td></tr>
    <?php foreach(['wow_market_id','wow_pro_package_id','wow_pro_package_id_2','wow_pro_package_id_3','wow_pro_package_id_4','wow_wallet_topup_id','wow_crowdfund_id'] as $k): ?>
    <tr><th><?php echo esc_html($k);?></th><td><input class="small-text" type="number" name="bzj_pgb_streams_product_map[<?php echo esc_attr($k);?>]" value="<?php echo esc_attr($map[$k]??0);?>"></td></tr>
    <?php endforeach;?>
    </table><?php submit_button('Save Payment Gateway Settings');?></form>
    <h2>Secret</h2><p>Set <code>BZJ_PGB_SECRET</code> in the server environment. It is deliberately not stored in WordPress options or Streams.</p>
    </div><?php
}
