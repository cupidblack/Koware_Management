# Buzzjuice Payment Gateway Bridge v5

## Runtime model

Streams creates a signed payment-intent request. WordPress receives it at:

`POST /wp-json/bzj-pgb/v1/order`

WordPress creates the WooCommerce order locally and returns its payment URL. No WooCommerce consumer key/secret is sent to Streams.

After payment, WooCommerce fires `woocommerce_payment_complete` and status-transition hooks. The MU plugin performs idempotent fulfillment. Browser redirects are presentation-only and are never the source of payment truth.

## Required server secret

Set the same high-entropy value as `BZJ_PGB_SECRET` in both PHP environments. Do not place it in Streams configuration, JavaScript, order metadata, or logs.

## Logs

Each component writes to `shared/payment-gateway/log/<component>.log`. Logging is controlled by the Blue Crown `Payment Gateways` page.

## Migration rule

Do not delete the old bridge until paid-order regression tests have passed for products, wallet, crowdfund, all four PRO plans, AffiliateWP attribution, Jewel, QuickDate metadata, currency conversion, and renewal/subscription behaviour.
