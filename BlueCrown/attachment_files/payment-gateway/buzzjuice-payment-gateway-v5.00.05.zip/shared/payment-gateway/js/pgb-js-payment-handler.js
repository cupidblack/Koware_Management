(function($){
'use strict';
window.BZJ_PGB = window.BZJ_PGB || {};
BZJ_PGB.start = function(url, data, button){
    if(!url) return;
    var $button=$(button);
    if($button.data('bzjBusy')) return;
    $button.data('bzjBusy',true).prop('disabled',true);
    $.ajax({url:url,method:'POST',data:data,dataType:'json'})
      .done(function(r){ if(r && r.status===200 && r.url){ window.location.href=r.url; return; } alert((r&&r.message)||'Unable to start payment.'); })
      .fail(function(xhr){ var r=xhr.responseJSON||{}; alert(r.message||'Unable to start payment.'); })
      .always(function(){ $button.data('bzjBusy',false).prop('disabled',false); });
};
})(jQuery);
