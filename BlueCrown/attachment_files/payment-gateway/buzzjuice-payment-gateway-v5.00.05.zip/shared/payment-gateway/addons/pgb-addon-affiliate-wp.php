<?php
defined('ABSPATH') || exit;

add_action('bzj_pgb_fulfillment', function($order,$tx){
    $log=new PGB_Logger('pgb-addon-affiliate-wp');
    if (!$order instanceof WC_Order) return;
    if ($order->get_meta('_bzj_affwp_processed',true)) return;
    if (!function_exists('affwp_add_referral') && !class_exists('Affiliate_WP_Referrals_DB')) {
        $log->warning('AffiliateWP APIs unavailable'); return;
    }
    global $wpdb;
    $customer_id=0;
    if (function_exists('affwp_get_customer_by')) {
        $customer=affwp_get_customer_by('email',$order->get_billing_email());
        if (is_object($customer)) $customer_id=(int)$customer->customer_id;
    }
    if (!$customer_id && function_exists('affwp_add_customer')) {
        $customer_id=(int)affwp_add_customer([
            'email'=>$order->get_billing_email(),
            'user_id'=>$order->get_customer_id(),
            'date_created'=>current_time('mysql'),
        ]);
    }
    if (!$customer_id) {
        $log->error('Unable to resolve AffiliateWP customer',['woo_order_id'=>$order->get_id()]);
        return;
    }
    $affiliate_id=0; $source='';
    $tables=[
        ['affiliate_wp_lifetime_customers','affwp_customer_id',$customer_id],
        ['affiliate_wp_customermeta','affwp_customer_id',$customer_id],
    ];
    $table=$wpdb->prefix.'affiliate_wp_lifetime_customers';
    if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'")) {
        $affiliate_id=(int)$wpdb->get_var($wpdb->prepare("SELECT affiliate_id FROM {$table} WHERE affwp_customer_id=%d ORDER BY lifetime_customer_id DESC LIMIT 1",$customer_id));
        if ($affiliate_id) $source='lifetime';
    }
    if (!$affiliate_id) {
        $table=$wpdb->prefix.'affiliate_wp_customermeta';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'")) {
            foreach(['affiliate_id','referring_affiliate_id'] as $key){
                $affiliate_id=(int)$wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$table} WHERE affwp_customer_id=%d AND meta_key=%s LIMIT 1",$customer_id,$key));
                if($affiliate_id){$source='customermeta:'.$key;break;}
            }
        }
    }
    $snap=json_decode((string)$order->get_meta('_buzzjuice_affwp_context_snapshot',true),true);
    if (!$affiliate_id && !empty($snap['affwp_affiliate_id'])) {$affiliate_id=(int)$snap['affwp_affiliate_id'];$source='snapshot';}
    if (!$affiliate_id) {$log->info('No affiliate attribution found',['woo_order_id'=>$order->get_id()]); return;}

    $rate_type='percentage'; $rate=0.0;
    $settings=(array)get_option('affwp_settings',[]);
    $rate_type=$settings['referral_rate_type']??'percentage'; $rate=(float)($settings['referral_rate']??0);
    $commission=0.0;$products=[];
    foreach($order->get_items('line_item') as $item){
        $product_id=(int)$item->get_product_id();$variation_id=(int)$item->get_variation_id();
        $item_total=(float)$item->get_total();$c=0.0;
        $product=wc_get_product($variation_id?:$product_id);
        $pr=$product?$product->get_meta('_affwp_product_rate',true):'';
        $prt=$product?$product->get_meta('_affwp_product_rate_type',true):'';
        if($pr!=='' && is_numeric($pr) && in_array($prt,['percentage','flat'],true)){
            $c=$prt==='percentage'?round($item_total*((float)$pr/100),4):round((float)$pr,4);
        } elseif($rate>0){$c=$rate_type==='percentage'?round($item_total*($rate/100),4):round($rate,4);}
        $commission+=$c;
        $products[]=['product_id'=>$product_id,'variation_id'=>$variation_id,'name'=>$item->get_name(),'item_total'=>$item_total,'commission'=>$c];
    }
    if($commission<=0){$order->update_meta_data('_bzj_affwp_processed',current_time('mysql'));$order->save();return;}

    $reference=(string)$order->get_id();
    $existing=0;
    $ref_table=$wpdb->prefix.'affiliate_wp_referrals';
    if($wpdb->get_var("SHOW TABLES LIKE '{$ref_table}'")){
        $existing=(int)$wpdb->get_var($wpdb->prepare("SELECT referral_id FROM {$ref_table} WHERE reference=%s LIMIT 1",$reference));
    }
    if($existing){$order->update_meta_data('_bzj_affwp_processed',current_time('mysql'));$order->save();return;}

    $payload=[
        'affiliate_id'=>$affiliate_id,'customer_id'=>$customer_id,'amount'=>round($commission,4),
        'status'=>'unpaid','currency'=>$order->get_currency(),'context'=>'woocommerce',
        'reference'=>$reference,'description'=>'Buzzjuice Streams order '.$reference,
        'products'=>maybe_serialize($products),
        'custom'=>maybe_serialize(['origin'=>'streams','resolution_source'=>$source]),
        'date'=>current_time('mysql'),
    ];
    $referral_id=0;
    if(function_exists('affwp_add_referral')) $referral_id=(int)affwp_add_referral($payload);
    if(!$referral_id && class_exists('Affiliate_WP_Referrals_DB')){
        $db=new Affiliate_WP_Referrals_DB();
        if(method_exists($db,'insert')) $referral_id=(int)$db->insert($payload);
    }
    if(!$referral_id){$log->error('AffiliateWP referral creation failed',['woo_order_id'=>$order->get_id(),'affiliate_id'=>$affiliate_id]);return;}
    $order->update_meta_data('_bzj_affwp_referral_id',$referral_id);
    $order->update_meta_data('_bzj_affwp_processed',current_time('mysql'));
    $order->save();
    $log->info('AffiliateWP referral created',['woo_order_id'=>$order->get_id(),'referral_id'=>$referral_id,'affiliate_id'=>$affiliate_id,'commission'=>$commission]);
},20,2);
