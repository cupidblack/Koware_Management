<?php
defined('ABSPATH') || exit;

add_action('bzj_pgb_fulfillment', function($order,$tx){
    $log=new PGB_Logger('pgb-addon-subscriptions');
    if(!$order instanceof WC_Order) return;
    if($order->get_meta('_bzj_subscription_processed',true)) return;
    if(!function_exists('wcs_create_subscription') || !function_exists('wcs_get_subscriptions_for_order') || !class_exists('WC_Subscriptions_Product')) return;
    $existing=wcs_get_subscriptions_for_order($order,['subscriptions_per_page'=>1,'orderby'=>'date','order'=>'DESC']);
    if(!empty($existing)){$order->update_meta_data('_bzj_subscription_processed',current_time('mysql'));$order->save();return;}
    $subscription_product=null;
    foreach($order->get_items('line_item') as $item){
        $p=$item->get_product();
        if($p && WC_Subscriptions_Product::is_subscription($p)){$subscription_product=$p;break;}
    }
    if(!$subscription_product) return;
    $period=WC_Subscriptions_Product::get_period($subscription_product);
    $interval=(int)WC_Subscriptions_Product::get_interval($subscription_product);
    if(!$period || $interval<1) throw new RuntimeException('Invalid subscription product billing schedule.');
    $subscription=wcs_create_subscription([
        'order_id'=>$order->get_id(),
        'customer_id'=>$order->get_customer_id(),
        'billing_period'=>$period,
        'billing_interval'=>$interval,
        'start_date'=>gmdate('Y-m-d H:i:s'),
    ]);
    if(is_wp_error($subscription)) throw new RuntimeException($subscription->get_error_message());
    if(!$subscription || !is_object($subscription)) throw new RuntimeException('WooCommerce Subscriptions did not return a subscription object.');
    foreach($order->get_items('line_item') as $item){
        $p=$item->get_product();
        if($p && WC_Subscriptions_Product::is_subscription($p)) $subscription->add_product($p,$item->get_quantity());
    }
    $subscription->set_address($order->get_address('billing'),'billing');
    $subscription->set_address($order->get_address('shipping'),'shipping');
    $subscription->set_currency($order->get_currency());
    $subscription->calculate_totals(false);
    $subscription->update_meta_data('_bzj_pgb_parent_order',$order->get_id());
    $subscription->update_meta_data('_buzzjuice_origin','streams');
    $subscription->save();
    if(method_exists($subscription,'update_status')) $subscription->update_status('active','Activated from paid Buzzjuice Streams order.');
    $order->update_meta_data('_bzj_subscription_id',$subscription->get_id());
    $order->update_meta_data('_bzj_subscription_processed',current_time('mysql'));
    $order->save();
    $log->info('Subscription created by WooCommerce Subscriptions API',['woo_order_id'=>$order->get_id(),'subscription_id'=>$subscription->get_id()]);
},25,2);
