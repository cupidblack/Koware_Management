<?php
require_once dirname(__DIR__,2).'/config.php';
require_once dirname(__DIR__).'/init.php';
require_once dirname(__DIR__,2).'/../shared/payment-gateway/pgb-client-streams.php';

header('Content-Type: application/json');

if (empty($wo['loggedin'])) {
    http_response_code(401);
    echo json_encode(['status'=>'error','message'=>'Please log in to continue.']);
    exit;
}
if (!defined('BZJ_PGB_SECRET')) {
    $secret=(string)getenv('BZJ_PGB_SECRET');
} else $secret=BZJ_PGB_SECRET;
if ($secret==='') {
    http_response_code(500);
    echo json_encode(['status'=>'error','message'=>'Payment bridge is not configured.']);
    exit;
}
$wow_user_id=(int)($wo['user']['user_id']??0);
$wp_user_id=0;
if($wow_user_id && isset($sqlConnect)){
    $stmt=$sqlConnect->prepare("SELECT wp_user_id FROM ".T_USERS." WHERE user_id=? LIMIT 1");
    if($stmt){$stmt->bind_param('i',$wow_user_id);$stmt->execute();$stmt->bind_result($wp_user_id);$stmt->fetch();$stmt->close();}
}
if(!$wow_user_id||!$wp_user_id){
    http_response_code(400);
    echo json_encode(['status'=>'error','message'=>'Your Buzzjuice account could not be linked to WordPress.']);
    exit;
}
$required=['amount','product_name','product_price','product_units','transaction_kind','wow_currency_code'];
foreach($required as $k) if(!isset($_POST[$k])||$_POST[$k]===''){http_response_code(400);echo json_encode(['status'=>'error','message'=>'Missing required payment parameter.']);exit;}

$kind=strtoupper(preg_replace('/[^A-Z0-9_-]/','',(string)$_POST['transaction_kind']));
if($kind==='PRODUCT')$kind='PURCHASE';
$wow_order_id='wow_'.gmdate('YmdHis').'_'.bin2hex(random_bytes(8));
$payload=[
 'wow_order_id'=>$wow_order_id,'wow_user_id'=>$wow_user_id,'wp_user_id'=>$wp_user_id,
 'transaction_kind'=>$kind,'amount'=>round((float)$_POST['amount'],2),
 'product_price'=>round((float)$_POST['product_price'],2),'quantity'=>max(1,(int)$_POST['product_units']),
 'currency'=>strtoupper(preg_replace('/[^A-Z]/','',(string)$_POST['wow_currency_code'])),
 'product_id'=>(int)($_POST['product_id']??0),'variation_id'=>(int)($_POST['variation_id']??0),
 'product_name'=>sanitize_text_field($_POST['product_name']),
 'wow_post_id'=>(int)($_POST['wow_post_id']??0),'qdw_order_id'=>sanitize_text_field($_POST['qdw_order_id']??''),
 'rebate_credit_cents'=>(int)($_POST['rebate_credit_cents']??0),
 'email'=>sanitize_email($wo['user']['email']??''),
 'user'=>[
   'email'=>sanitize_email($wo['user']['email']??''),'username'=>sanitize_text_field($wo['user']['username']??''),
   'first_name'=>sanitize_text_field($wo['user']['first_name']??''),'last_name'=>sanitize_text_field($wo['user']['last_name']??''),
   'address'=>sanitize_text_field($wo['user']['address']??''),'city'=>sanitize_text_field($wo['user']['city']??''),
   'state'=>sanitize_text_field($wo['user']['state']??''),'zip'=>sanitize_text_field($wo['user']['zip']??''),
   'country_id'=>sanitize_text_field($wo['user']['country_id']??'GH'),'phone_number'=>sanitize_text_field($wo['user']['phone_number']??''),
 ],
 'affwp_snapshot'=>[
   'affwp_ref'=>isset($_COOKIE['affwp_ref'])?(string)$_COOKIE['affwp_ref']:'',
   'affwp_visit_id'=>isset($_COOKIE['affwp_visit_id'])?(int)$_COOKIE['affwp_visit_id']:0,
   'affwp_affiliate_id'=>isset($_COOKIE['affwp_affiliate_id'])?(int)$_COOKIE['affwp_affiliate_id']:0,
   'timestamp'=>gmdate('c'),'wp_user_id'=>$wp_user_id,
 ],
 'request_id'=>'pgb_'.bin2hex(random_bytes(12)),
];
$store=rtrim((string)($wo['config']['wow_store_url']??''),'/');
if(!$store){http_response_code(500);echo json_encode(['status'=>'error','message'=>'Payment store URL is not configured.']);exit;}
try{
    $response=bzj_pgb_streams_request($payload,$store.'/wp-json/bzj-pgb/v1/order',$secret);
    echo json_encode(['status'=>200,'url'=>$response['payment_url']??'','woo_order_id'=>$response['woo_order_id']??0,'wow_order_id'=>$wow_order_id]);
}catch(Throwable $e){
    http_response_code(502);echo json_encode(['status'=>'error','message'=>'Payment could not be started.']);
}
exit;
