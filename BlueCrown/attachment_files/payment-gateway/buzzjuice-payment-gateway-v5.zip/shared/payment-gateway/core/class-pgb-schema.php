<?php
defined('ABSPATH') || exit;

class PGB_Schema {
    public static function install() {
        global $wpdb;
        $table=$wpdb->prefix.'bzj_pgb_transactions';
        $charset=$wpdb->get_charset_collate();
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $sql="CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            wow_order_id VARCHAR(191) NOT NULL,
            request_id VARCHAR(120) NOT NULL,
            wow_user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            wp_user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            woo_order_id BIGINT UNSIGNED NULL,
            transaction_kind VARCHAR(50) NOT NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'initiated',
            fulfillment_status VARCHAR(30) NOT NULL DEFAULT 'pending',
            amount DECIMAL(20,4) NOT NULL DEFAULT 0,
            currency VARCHAR(10) NOT NULL,
            attempts INT UNSIGNED NOT NULL DEFAULT 0,
            last_error TEXT NULL,
            payload LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            paid_at DATETIME NULL,
            fulfilled_at DATETIME NULL,
            PRIMARY KEY(id),
            UNIQUE KEY uq_wow_order_id(wow_order_id),
            UNIQUE KEY uq_request_id(request_id),
            KEY idx_woo_order_id(woo_order_id),
            KEY idx_status(status),
            KEY idx_fulfillment_status(fulfillment_status)
        ) {$charset};";
        dbDelta($sql);
    }
}
