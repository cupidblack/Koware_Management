<?php
defined('ABSPATH') || exit;
require_once BZJ_PGB_ROOT.'config/pgb-config.php';
require_once BZJ_PGB_ROOT.'core/class-pgb-logger.php';
require_once BZJ_PGB_ROOT.'core/class-pgb-auth.php';
require_once BZJ_PGB_ROOT.'core/class-pgb-validator.php';
require_once BZJ_PGB_ROOT.'core/class-pgb-schema.php';
require_once BZJ_PGB_ROOT.'core/class-pgb-idempotency.php';
require_once BZJ_PGB_ROOT.'core/class-pgb-order.php';
require_once BZJ_PGB_ROOT.'core/class-pgb-fulfillment.php';
require_once BZJ_PGB_ROOT.'core/class-pgb-manager.php';

class PGB_Bootstrap {
    private static $instance; public $manager; public $log;
    public static function instance(){return self::$instance ?: (self::$instance=new self());}
    private function __construct(){
        $this->log=new PGB_Logger('class-pgb-bootstrap');
        if (!class_exists('WooCommerce')) { $this->log->warning('WooCommerce is not loaded'); return; }
        $this->log->info('Payment Gateway Bridge booting',['version'=>BZJ_PGB_VERSION]);
        $this->manager=new PGB_Manager($this->log,new PGB_Idempotency($this->log),new PGB_Order($this->log),new PGB_Fulfillment($this->log));
        PGB_Schema::install();
        $this->load_components();
        add_action('rest_api_init',[$this,'register_rest']);
        add_action('woocommerce_payment_complete',[$this,'paid'],20,1);
        add_action('woocommerce_order_status_processing',[$this,'status_paid'],20,1);
        add_action('woocommerce_order_status_completed',[$this,'status_paid'],20,1);
        add_action('admin_init',[$this,'ensure_options']);
    }
    private function load_components(){
        $addons=glob(BZJ_PGB_ROOT.'addons/pgb-addon-*.php') ?: [];
        $ints=glob(BZJ_PGB_ROOT.'integrations/pgb-int-*.php') ?: [];
        foreach(array_merge($addons,$ints) as $file) if(is_readable($file)) require_once $file;
        $admin=BZJ_PGB_ROOT.'admin/pgb-admin.php'; if(is_readable($admin)) require_once $admin;
    }
    public function register_rest(){
        register_rest_route('bzj-pgb/v1','/order',[
            'methods'=>WP_REST_Server::CREATABLE,
            'permission_callback'=>'__return_true',
            'callback'=>[$this,'rest_order'],
        ]);
    }
    public function rest_order(WP_REST_Request $request){
        $raw=$request->get_body();
        $auth=PGB_Auth::verify($request,$raw,$this->log);
        if(is_wp_error($auth)) return $auth;
        $json=json_decode($raw,true);
        if(!is_array($json)) return new WP_Error('pgb_json','Invalid JSON.',['status'=>400]);
        $data=PGB_Validator::request($json);
        if(is_wp_error($data)) return $data;
        try {
            $order=$this->manager->create_order($data);
            $this->log->info('Payment initiation accepted',['woo_order_id'=>$order->get_id(),'wow_order_id'=>$data['wow_order_id']]);
            return new WP_REST_Response([
                'status'=>200,'woo_order_id'=>$order->get_id(),
                'wow_order_id'=>$data['wow_order_id'],
                'payment_url'=>$order->get_checkout_payment_url(),
                'order_key'=>$order->get_order_key(),
            ],200);
        } catch(Throwable $e) {
            $this->log->error('Payment initiation failed',['error'=>$e->getMessage(),'wow_order_id'=>$data['wow_order_id']]);
            return new WP_Error('pgb_order_create','Unable to create payment order.',['status'=>500]);
        }
    }
    public function paid($id){$this->manager->handle_paid($id,'woocommerce_payment_complete');}
    public function status_paid($id){$this->manager->handle_paid($id,'woocommerce_status_transition');}
    public function ensure_options(){
        if (get_option('bzj_pgb_streams_product_map',null)===null) {
            update_option('bzj_pgb_streams_product_map',[
                'wow_market_id'=>(int)get_option('wow_market_id',0),
                'wow_pro_package_id'=>(int)get_option('wow_pro_package_id',0),
                'wow_pro_package_id_2'=>(int)get_option('wow_pro_package_id_2',0),
                'wow_pro_package_id_3'=>(int)get_option('wow_pro_package_id_3',0),
                'wow_pro_package_id_4'=>(int)get_option('wow_pro_package_id_4',0),
                'wow_wallet_topup_id'=>(int)get_option('wow_wallet_topup_id',0),
                'wow_crowdfund_id'=>(int)get_option('wow_crowdfund_id',0),
            ],false);
        }
    }
}
