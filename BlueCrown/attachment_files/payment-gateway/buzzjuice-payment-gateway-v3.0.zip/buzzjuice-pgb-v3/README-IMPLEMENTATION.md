# Buzzjuice Streams Payment Gateway Bridge v3.0

## Authoritative flow

Streams UI
→ `streams/requests.php`
→ `streams/assets/wow-pgb/wow-pgb_init.php`
→ HMAC-signed HTTPS request
→ WordPress REST endpoint `/wp-json/bzj-pgb/v1/intent`
→ PGB transaction table
→ native WooCommerce order
→ WooCommerce payment
→ `woocommerce_payment_complete` / processing / completed
→ one PGB fulfillment processor
→ Streams database update
→ AffiliateWP
→ Jewel
→ redirect.

## Why this removes the dropped-order class of failure

1. A dedicated WordPress transaction table persists the intent before the Woo order is created.
2. `idempotency_key` prevents a retry/double click from creating another Woo order.
3. WooCommerce is accessed natively, so Streams no longer carries Woo REST credentials or relies on a second HTTP hop into Woo.
4. Payment completion is driven by WooCommerce lifecycle hooks, not a browser thank-you page.
5. Fulfillment uses a database claim so repeated payment hooks cannot perform the same fulfillment twice.
6. Failed integrations are placed in a retry state and Action Scheduler/WP-Cron retries them.
7. The legacy webhook remains only as a compatibility acknowledgement.
8. AffiliateWP is resolved at WordPress completion time, not in the Streams browser request.

## Security

- Streams→WordPress requests use HMAC-SHA256.
- Requests have timestamp and nonce headers.
- TLS certificate verification is enabled.
- Browser-supplied price/name/currency is treated as intent, not trusted HTML.
- PRO price is read from the mapped WooCommerce product.
- WooCommerce order creation uses CRUD APIs.
- SQL uses prepared statements.
- Logs redact secrets/tokens/cookies.

## Required configuration

### WordPress / Blue Crown → Payment Gateway
- Streams base URL
- Shared HMAC secret
- Detailed logging toggle
- Request TTL

### Streams → Payment settings
- WordPress base URL
- Same HMAC secret
- PGB logging toggle
- Existing bridge product mappings remain:
  - wow-pgb_pro_1..4
  - wow-pgb_wallet
  - wow-pgb_fund
  - wow-pgb_market

## Important migration rule

Do not run the old `wow-pgb_sync.php` completion engine simultaneously with v3.
Keep it disabled or reduce it to an archive/compatibility file before enabling the MU bridge.

## Existing AffiliateWP logic

The current proven accounting logic should remain available as the authoritative reference during migration.
The new addon performs:
- customer/affiliate resolution in WordPress
- product-specific/default rate calculation
- referral insertion through `affwp_add_referral`
- duplicate-reference guard
- post-insert verification

If the existing production AffiliateWP logic contains additional lifetime-commission behavior specific to this installation,
merge that logic into `PGB_Addon_Affiliate_WP::process()` rather than keeping two independent referral engines.

## Testing matrix

Test all transaction kinds:
- PRO 1, 2, 3, 4
- WALLET
- DONATE/FUND
- MARKET/PRODUCT/PURCHASE

For every kind:
- normal payment
- double click
- browser refresh
- dropped response after order creation
- repeated Woo completion hook
- failed AffiliateWP
- failed Jewel
- retry after transient failure
- wrong signature
- expired signature
- mismatched Streams/WP user
- invalid product mapping
- currency conversion
- already-paid order

Expected invariant:
**one PGB transaction → one Woo order → one fulfillment → one AffiliateWP referral.**
