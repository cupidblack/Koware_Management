<?php
/**
 * WoWonder-specific Payment Gateway Bridge client.
 * The file is included by Streams and is deliberately independent of WordPress runtime.
 */
defined('WO_API') || defined('ABSPATH') || exit;

require_once __DIR__.'/pgb-client.php';

if (!function_exists('bzj_pgb_streams_init')) {
    function bzj_pgb_streams_init(array $wo, $sqlConnect, array $post) {
        $logger_enabled = !isset($wo['config']['wow_pgb_logging_enabled']) || $wo['config']['wow_pgb_logging_enabled'] !== 'no';
        $log=function($msg) use ($logger_enabled) {
            if($logger_enabled) @error_log('[PGB-STREAMS] '.$msg);
        };

        if (empty($wo['loggedin']) || empty($wo['user']['user_id'])) {
            return ['status'=>'error','message'=>'Please login to continue.'];
        }

        $sid=(int)$wo['user']['user_id'];
        $wpid=(int)($wo['user']['wp_user_id'] ?? 0);
        if(!$wpid && !empty($wo['user']['email']) && function_exists('get_wp_db_conn')) {
            $wpdb=get_wp_db_conn();
            if($wpdb) {
                $email=$wo['user']['email'];
                $stmt=$wpdb->prepare("SELECT ID FROM wp_users WHERE user_email=? LIMIT 1");
                if($stmt){$stmt->bind_param('s',$email);$stmt->execute();$r=$stmt->get_result()->fetch_assoc();$wpid=(int)($r['ID']??0);$stmt->close();}
            }
        }
        if(!$wpid) return ['status'=>'error','message'=>'Your Buzzjuice account mapping is incomplete.'];

        $kind=strtoupper(preg_replace('/[^A-Z_]/','',(string)($post['transaction_kind']??'')));
        if($kind==='PRODUCT') $kind='PURCHASE';
        if(!in_array($kind,['PRO','WALLET','DONATE','FUND','MARKET','PRODUCT','PURCHASE','SALE'],true)) return ['status'=>'error','message'=>'Invalid payment type.'];

        $amount=(float)($post['amount']??0);
        $qty=max(1,(int)($post['product_units']??$post['quantity']??1));
        $currency=strtoupper(trim((string)($post['wow_currency_code']??$wo['config']['currency']??'GHS')));
        if($amount<=0) return ['status'=>'error','message'=>'Invalid payment amount.'];

        $transaction_id='pgb_'.bin2hex(random_bytes(16));
        $idempotency='idem_'.hash('sha256',$sid.'|'.$kind.'|'.($post['wow_post_id']??0).'|'.$amount.'|'.$currency.'|'.microtime(true).'|'.random_bytes(8));
        $wow_order_id='wow_'.bin2hex(random_bytes(12));
        $request_id='req_'.bin2hex(random_bytes(10));

        // Preserve the existing Streams transaction trail, but do not fulfill it here.
        $table=defined('T_PAYMENT_TRANSACTIONS')?T_PAYMENT_TRANSACTIONS:'Wo_Payment_Transactions';
        $stmt=$sqlConnect->prepare("INSERT INTO {$table} (userid, amount, order_id, kind, currency_code) VALUES (?, ?, ?, ?, ?)");
        if(!$stmt) return ['status'=>'error','message'=>'Unable to record payment intent.'];
        $stmt->bind_param('idsss',$sid,$amount,$wow_order_id,$kind,$currency);
        if(!$stmt->execute()) { $stmt->close(); return ['status'=>'error','message'=>'Unable to record payment intent.']; }
        $stmt->close();

        $secret=(string)($wo['config']['wow_pgb_shared_secret']??getenv('BZJ_PGB_SHARED_SECRET'));
        $wp_url=trim((string)($wo['config']['wow_pgb_wordpress_url']??getenv('BZJ_PGB_WORDPRESS_URL')));
        if(!$wp_url) {
            $store=(string)($wo['config']['wow_store_url']??'');
            $parts=parse_url($store);
            if(!empty($parts['scheme'])&&!empty($parts['host'])) $wp_url=$parts['scheme'].'://'.$parts['host'];
        }
        if(!$wp_url||!filter_var($wp_url,FILTER_VALIDATE_URL)||!$secret) {
            $log('WordPress URL or shared secret is not configured.');
            return ['status'=>'error','message'=>'Payment gateway is not configured.'];
        }

        $payload=[
            'transaction_id'=>$transaction_id,
            'idempotency_key'=>$idempotency,
            'request_id'=>$request_id,
            'wow_order_id'=>$wow_order_id,
            'streams_user_id'=>$sid,
            'wp_user_id'=>$wpid,
            'transaction_kind'=>$kind,
            'wow_post_id'=>(int)($post['wow_post_id']??0),
            'product_owner_id'=>(int)($post['product_owner_id']??0),
            'quantity'=>$qty,
            'amount'=>$amount,
            'currency'=>$currency,
            'product_name'=>sanitize_text_field($post['product_name']??$kind),
            'product_price'=>(float)($post['product_price']??$amount),
            'address_id'=>(int)($post['address_id']??0),
        ];

        $endpoint=rtrim($wp_url,'/').'/wp-json/bzj-pgb/v1/intent';
        $response=bzj_pgb_streams_request($payload,$endpoint,$secret,25);
        if(!$response['ok']) {
            $log('PGB intent failed HTTP '.$response['http_code'].' '.($response['error']?:json_encode($response['data'])));
            return ['status'=>'error','message'=>$response['data']['message']??'Payment gateway connection failed.','retryable'=>true];
        }

        return [
            'status'=>200,
            'url'=>$response['data']['payment_url']??'',
            'transaction_id'=>$response['data']['transaction_id']??$transaction_id,
            'woo_order_id'=>$response['data']['woo_order_id']??0,
        ];
    }
}
