<?php
defined('ABSPATH') || exit;

class PGB_Integration_Streams {
    private $logger;

    public function __construct($logger) { $this->logger = $logger; }

    private function db() {
        if (function_exists('get_wowonder_db')) return get_wowonder_db();
        if (function_exists('get_wowonder_db_conn')) return get_wowonder_db_conn();
        return false;
    }

    private function table($name) {
        if (defined('WOWONDER_DB_PREFIX')) return WOWONDER_DB_PREFIX . $name;
        return $name;
    }

    public function resolve_user($streams_user_id, $wp_user_id) {
        $db = $this->db();
        if (!$db) throw new RuntimeException('WoWonder database connection is unavailable.');
        $table = $this->table('Wo_Users');
        $stmt = $db->prepare("SELECT user_id, wp_user_id, email, username FROM {$table} WHERE user_id=? AND wp_user_id=? LIMIT 1");
        if (!$stmt) throw new RuntimeException('Unable to prepare Streams user lookup.');
        $sid = absint($streams_user_id); $wid = absint($wp_user_id);
        $stmt->bind_param('ii', $sid, $wid);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row ?: false;
    }

    public function mark_paid($txn) {
        $db = $this->db();
        if (!$db) throw new RuntimeException('WoWonder database connection is unavailable.');

        $sid = absint($txn['streams_user_id']);
        $amount = (float)$txn['converted_amount'];
        $order_hash = (string)$txn['wow_order_id'];
        $currency = (string)$txn['approved_currency'];
        $kind = strtoupper((string)$txn['transaction_kind']);
        $post_id = absint($txn['streams_post_id']);
        $owner = absint($txn['product_owner_id']);
        $qty = max(1, absint($txn['quantity']));
        $name = sanitize_text_field($txn['product_name'] ?? $kind);
        $price = $qty ? $amount / $qty : $amount;
        $now = time();

        $txn_table = $this->table('Wo_Payment_Transactions');
        $purchase_table = $this->table('Wo_Purchases');

        // Mark the existing pending transaction as paid where the legacy table has a status column.
        $columns = $db->query("SHOW COLUMNS FROM {$txn_table}");
        $has_status = false; $has_notes = false;
        if ($columns) {
            while ($c = $columns->fetch_assoc()) {
                if ($c['Field'] === 'status') $has_status = true;
                if ($c['Field'] === 'notes') $has_notes = true;
            }
        }
        if ($has_status) {
            $stmt = $db->prepare("UPDATE {$txn_table} SET status='paid' WHERE order_id=?");
            if ($stmt) { $stmt->bind_param('s', $order_hash); $stmt->execute(); $stmt->close(); }
        }
        if ($has_notes) {
            $note = 'PGB paid; WooCommerce order ' . absint($txn['woo_order_id']);
            $stmt = $db->prepare("UPDATE {$txn_table} SET notes=? WHERE order_id=?");
            if ($stmt) { $stmt->bind_param('ss', $note, $order_hash); $stmt->execute(); $stmt->close(); }
        }

        if (in_array($kind, ['PRODUCT','PURCHASE','SALE','MARKET'], true)) {
            // Avoid duplicate owner SALE rows and duplicate purchases.
            $stmt = $db->prepare("SELECT COUNT(*) c FROM {$txn_table} WHERE order_id=? AND kind='SALE' AND userid=?");
            $exists_sale = 0;
            if ($stmt) { $stmt->bind_param('si', $order_hash, $owner); $stmt->execute(); $r=$stmt->get_result()->fetch_assoc(); $exists_sale=(int)($r['c']??0); $stmt->close(); }
            if ($owner > 0 && $exists_sale === 0) {
                $owner_kind = 'SALE'; $owner_note = 'Product Sale';
                $stmt = $db->prepare("INSERT INTO {$txn_table} (userid, amount, order_id, kind, currency_code, notes) VALUES (?, ?, ?, ?, ?, ?)");
                if ($stmt) { $stmt->bind_param('idssss', $owner, $amount, $order_hash, $owner_kind, $currency, $owner_note); $stmt->execute(); $stmt->close(); }
            }

            $stmt = $db->prepare("SELECT COUNT(*) c FROM {$purchase_table} WHERE order_hash_id=? AND user_id=? LIMIT 1");
            $exists_purchase = 0;
            if ($stmt) { $stmt->bind_param('si', $order_hash, $sid); $stmt->execute(); $r=$stmt->get_result()->fetch_assoc(); $exists_purchase=(int)($r['c']??0); $stmt->close(); }
            if ($exists_purchase === 0) {
                $data = wp_json_encode([
                    'name' => $name,
                    'product_id' => $post_id,
                    'units' => $qty,
                    'currency' => $currency,
                    'timestamp' => $now,
                    'woo_order_id' => absint($txn['woo_order_id']),
                    'pgb_transaction_id' => $txn['transaction_id'],
                ]);
                $commission = 0;
                $stmt = $db->prepare("INSERT INTO {$purchase_table} (user_id, order_hash_id, owner_id, data, final_price, commission, price, timestamp, time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                if (!$stmt) throw new RuntimeException('Unable to prepare Streams purchase insert.');
                $stmt->bind_param('isissddii', $sid, $order_hash, $owner, $data, $amount, $commission, $price, $now, $now);
                if (!$stmt->execute()) throw new RuntimeException('Streams purchase insert failed: ' . $stmt->error);
                $stmt->close();
            }
        } elseif ($kind === 'WALLET') {
            $users = $this->table('Wo_Users');
            // WoWonder wallet implementations vary. Prefer the documented balance column if present.
            $cols = $db->query("SHOW COLUMNS FROM {$users}");
            $balance_col = '';
            if ($cols) while ($c=$cols->fetch_assoc()) {
                if (in_array($c['Field'], ['balance','wallet','wallet_amount'], true)) { $balance_col=$c['Field']; break; }
            }
            if ($balance_col) {
                $sql = "UPDATE {$users} SET `{$balance_col}` = COALESCE(`{$balance_col}`,0) + ? WHERE user_id=?";
                $stmt=$db->prepare($sql);
                if (!$stmt) throw new RuntimeException('Unable to prepare wallet credit.');
                $stmt->bind_param('di',$amount,$sid);
                $stmt->execute(); $stmt->close();
            } else {
                $this->logger->log('Wallet paid but no recognized Wo_Users balance column was found.', 'warning', __FILE__, __LINE__, ['streams_user_id'=>$sid]);
            }
        }

        if ($kind === 'DONATE' || $kind === 'FUND') {
            $this->logger->log('Donation/fund payment recorded; fund-specific bookkeeping should remain in the existing Streams fund layer.', 'info', __FILE__, __LINE__, ['wow_order_id'=>$order_hash]);
        }

        return true;
    }

    public function redirect_url($txn) {
        $base = PGB_Config::instance()->get('streams_url', '');
        if ($base === '') return '';
        $kind = strtoupper((string)$txn['transaction_kind']);
        $post = absint($txn['streams_post_id']);
        if ($kind === 'PRO') return $base . '/upgraded?pgb=' . rawurlencode($txn['transaction_id']);
        if ($kind === 'WALLET') return $base . '/wallet/?pgb=' . rawurlencode($txn['transaction_id']);
        if (in_array($kind, ['PRODUCT','PURCHASE','SALE','MARKET'], true)) return $base . '/purchased?pgb=' . rawurlencode($txn['transaction_id']);
        if (in_array($kind, ['DONATE','FUND'], true) && $post > 0) return $base . '/show_fund/' . $post . '?pgb=' . rawurlencode($txn['transaction_id']);
        return $base . '/?pgb=' . rawurlencode($txn['transaction_id']);
    }
}
