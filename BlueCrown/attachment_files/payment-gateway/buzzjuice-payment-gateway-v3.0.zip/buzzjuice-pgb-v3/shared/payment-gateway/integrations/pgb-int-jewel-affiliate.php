<?php
defined('ABSPATH') || exit;

class PGB_Integration_Jewel_Affiliate {
    private $logger;
    public function __construct($logger) { $this->logger=$logger; }

    public function process($order, $txn) {
        $hook = apply_filters('bzj_pgb_jewel_hook', 'bzj_pgb_jewel_affiliate_paid');
        do_action($hook, $order, $txn);

        $url = apply_filters('bzj_pgb_jewel_webhook_url', '');
        if (!$url) return ['status'=>'queued','reason'=>'No Jewel webhook URL configured'];

        $secret = (string)apply_filters('bzj_pgb_jewel_webhook_secret', '');
        $payload = wp_json_encode([
            'event'=>'payment.completed',
            'transaction_id'=>$txn['transaction_id'],
            'woo_order_id'=>(int)$order->get_id(),
            'wow_order_id'=>$txn['wow_order_id'],
            'streams_user_id'=>(int)$txn['streams_user_id'],
            'amount'=>(float)$txn['converted_amount'],
            'currency'=>$txn['approved_currency'],
        ]);
        $headers=['Content-Type'=>'application/json'];
        if ($secret) $headers['X-BZJ-Jewel-Signature']=hash_hmac('sha256',$payload,$secret);
        $response=wp_remote_post($url,['timeout'=>15,'headers'=>$headers,'body'=>$payload]);
        if (is_wp_error($response)) throw new RuntimeException('Jewel webhook failed: '.$response->get_error_message());
        $code=(int)wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) throw new RuntimeException('Jewel webhook returned HTTP '.$code);
        return ['status'=>'processed','http_code'=>$code];
    }
}
