<?php
defined('ABSPATH') || exit;

class PGB_Integration_Currency_Switcher {
    private $logger;
    public function __construct($logger) { $this->logger = $logger; }

    public function convert($amount, $from, $to) {
        $amount = (float)$amount;
        $from = strtoupper((string)$from);
        $to = strtoupper((string)$to);
        if ($from === $to) return ['amount' => $amount, 'rate' => 1.0];

        global $WOOCS;
        if (isset($WOOCS) && is_object($WOOCS) && method_exists($WOOCS, 'get_currencies')) {
            $currencies = $WOOCS->get_currencies();
            $default = strtoupper((string)($WOOCS->default_currency ?? get_option('woocommerce_currency', $from)));
            if (isset($currencies[$from]['rate'], $currencies[$to]['rate']) && (float)$currencies[$from]['rate'] > 0) {
                $rate = (float)$currencies[$to]['rate'] / (float)$currencies[$from]['rate'];
                return ['amount' => round($amount * $rate, wc_get_price_decimals()), 'rate' => $rate];
            }
            if ($from === $default && isset($currencies[$to]['rate'])) {
                $rate = (float)$currencies[$to]['rate'];
                return ['amount' => round($amount * $rate, wc_get_price_decimals()), 'rate' => $rate];
            }
        }

        $this->logger->log("Currency conversion unavailable for {$from} -> {$to}.", 'warning', __FILE__, __LINE__);
        return new WP_Error('pgb_currency_unavailable', 'The selected payment currency is not currently available.');
    }
}
