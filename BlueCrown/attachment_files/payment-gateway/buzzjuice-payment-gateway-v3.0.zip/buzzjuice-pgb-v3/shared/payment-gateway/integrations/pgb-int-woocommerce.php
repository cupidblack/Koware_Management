<?php
defined('ABSPATH') || exit;

class PGB_Integration_WooCommerce {
    private $logger;

    public function __construct($logger) {
        $this->logger = $logger;
    }

    public function available() {
        return function_exists('wc_create_order') && function_exists('wc_get_product');
    }

    public function product_for_transaction($kind, $post_id = 0) {
        $map = [
            'WALLET' => 'wow-pgb_wallet',
            'DONATE' => 'wow-pgb_fund',
            'FUND' => 'wow-pgb_fund',
            'MARKET' => 'wow-pgb_market',
            'PRODUCT' => 'wow-pgb_market',
            'PURCHASE' => 'wow-pgb_market',
            'SALE' => 'wow-pgb_market',
        ];
        if ($kind === 'PRO') {
            $sku = 'wow-pgb_pro_' . absint($post_id);
        } else {
            $sku = $map[strtoupper($kind)] ?? '';
        }
        if (!$sku) return false;
        $id = absint(get_option('wow_pgb_product_id_' . sanitize_key($sku), 0));
        if (!$id && function_exists('wc_get_product_id_by_sku')) $id = absint(wc_get_product_id_by_sku($sku));
        if (!$id) return false;
        return ['sku' => $sku, 'id' => $id, 'product' => wc_get_product($id)];
    }

    public function create_order($txn) {
        if (!$this->available()) throw new RuntimeException('WooCommerce is unavailable.');

        $product_info = $this->product_for_transaction($txn['transaction_kind'], $txn['streams_post_id']);
        if (!$product_info || !$product_info['product']) throw new RuntimeException('No mapped WooCommerce bridge product exists.');

        $product = $product_info['product'];
        $order = wc_create_order(['customer_id' => absint($txn['wp_user_id'])]);
        if (is_wp_error($order)) throw new RuntimeException($order->get_error_message());

        $order->set_currency($txn['approved_currency']);
        $qty = max(1, absint($txn['quantity']));
        $item_id = $order->add_product($product, $qty);
        if (!$item_id) {
            $order->delete(true);
            throw new RuntimeException('Unable to add the bridge product to the WooCommerce order.');
        }

        $item = $order->get_item($item_id);
        $total = (float)$txn['converted_amount'];
        $unit = $qty > 0 ? $total / $qty : $total;
        $item->set_subtotal(wc_format_decimal($total, wc_get_price_decimals()));
        $item->set_total(wc_format_decimal($total, wc_get_price_decimals()));
        $item->add_meta_data('_bzj_pgb_transaction_id', $txn['transaction_id'], true);
        $item->add_meta_data('_bzj_pgb_kind', $txn['transaction_kind'], true);
        $item->save();

        $meta = [
            '_buzzjuice_origin' => 'streams',
            'wow_order_id' => $txn['wow_order_id'],
            'wow_user_id' => $txn['streams_user_id'],
            'userid' => $txn['streams_user_id'],
            '_bzj_pgb_transaction_id' => $txn['transaction_id'],
            '_bzj_pgb_idempotency_key' => $txn['idempotency_key'],
            '_bzj_pgb_kind' => $txn['transaction_kind'],
            '_bzj_pgb_streams_post_id' => $txn['streams_post_id'],
            '_bzj_pgb_product_owner_id' => $txn['product_owner_id'],
            '_bzj_pgb_base_amount' => $txn['base_amount'],
            '_bzj_pgb_conversion_rate' => $txn['conversion_rate'],
            '_bzj_pgb_requested_currency' => $txn['requested_currency'],
            '_bzj_pgb_approved_currency' => $txn['approved_currency'],
        ];
        foreach ($meta as $key => $value) $order->update_meta_data($key, $value);

        $user = get_user_by('id', absint($txn['wp_user_id']));
        if ($user) {
            $order->set_billing_email($user->user_email);
            $order->set_billing_first_name($user->first_name ?: $user->display_name);
            $order->set_billing_last_name($user->last_name);
        }

        $order->calculate_totals(false);
        $order->set_status('pending', 'Buzzjuice Streams payment intent created.');
        $order->save();

        $order_id = $order->get_id();
        $payment_url = $order->get_checkout_payment_url(true);
        if (!$payment_url) throw new RuntimeException('WooCommerce did not provide a payment URL.');

        $this->logger->log("Created WooCommerce order {$order_id}.", 'info', __FILE__, __LINE__, [
            'transaction_id' => $txn['transaction_id'],
            'amount' => $total,
            'currency' => $txn['approved_currency'],
        ]);

        return ['order' => $order, 'order_id' => $order_id, 'payment_url' => $payment_url];
    }

    public function complete($order) {
        if (!$order || !is_a($order, 'WC_Order')) return false;
        if (!$order->is_paid()) {
            $order->payment_complete();
            $order = wc_get_order($order->get_id());
        }
        return $order && $order->is_paid();
    }
}
