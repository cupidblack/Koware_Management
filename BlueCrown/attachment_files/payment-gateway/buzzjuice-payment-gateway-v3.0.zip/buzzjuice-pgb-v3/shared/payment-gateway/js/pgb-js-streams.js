(function(window,$){
    'use strict';
    window.BZJ_PGB = window.BZJ_PGB || {};
    window.BZJ_PGB.start = function(button){
        var $b=$(button);
        if($b.data('pgbBusy')) return;
        $b.data('pgbBusy',true).prop('disabled',true);
        var form=$b.closest('form');
        var data=form.length ? form.serializeArray() : [];
        $.ajax({
            url: window.BZJ_PGB_ENDPOINT || (typeof Wo_Ajax_Requests_File==='function' ? Wo_Ajax_Requests_File()+'?f=payment' : ''),
            method:'POST',
            data:data,
            dataType:'json'
        }).done(function(r){
            if(r && r.url){ window.location.href=r.url; return; }
            alert((r&&r.message)||'Unable to start payment.');
            $b.data('pgbBusy',false).prop('disabled',false);
        }).fail(function(xhr){
            var r=xhr.responseJSON||{};
            alert(r.message||'Unable to start payment. Please try again.');
            $b.data('pgbBusy',false).prop('disabled',false);
        });
    };
})(window,jQuery);
