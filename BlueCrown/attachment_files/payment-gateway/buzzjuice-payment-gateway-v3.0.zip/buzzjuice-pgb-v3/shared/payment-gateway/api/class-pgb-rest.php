<?php
defined('ABSPATH') || exit;

class PGB_REST {
    private $logger;
    private $processor;

    public function __construct() {
        $this->logger=PGB_Logger::instance();
        $this->processor=new PGB_Processor();
    }

    public function register() {
        register_rest_route('bzj-pgb/v1','/intent',[
            'methods'=>WP_REST_Server::CREATABLE,
            'callback'=>[$this,'intent'],
            'permission_callback'=>'__return_true',
        ]);
        register_rest_route('bzj-pgb/v1','/status/(?P<transaction_id>[A-Za-z0-9_-]+)',[
            'methods'=>WP_REST_Server::READABLE,
            'callback'=>[$this,'status'],
            'permission_callback'=>'__return_true',
        ]);
    }

    private function headers() {
        $headers=[];
        foreach(['X-BZJ-PGB-Timestamp','X-BZJ-PGB-Nonce','X-BZJ-PGB-Signature'] as $h) {
            $key='HTTP_'.strtoupper(str_replace('-','_',$h));
            if(isset($_SERVER[$key])) $headers[$h]=sanitize_text_field(wp_unslash($_SERVER[$key]));
        }
        if(function_exists('getallheaders')) {
            foreach((array)getallheaders() as $k=>$v) {
                if(in_array(strtolower($k),['x-bzj-pgb-timestamp','x-bzj-pgb-nonce','x-bzj-pgb-signature'],true)) {
                    $canonical='X-BZJ-PGB-'.ucwords(str_replace('x-bzj-pgb-','',strtolower($k)),'-');
                    $headers[$canonical]=trim($v);
                }
            }
        }
        return $headers;
    }

    public function intent(WP_REST_Request $request) {
        $raw=$request->get_body();
        $auth=PGB_Security::verify_request($raw,$this->headers(),$this->logger);
        if(is_wp_error($auth)) return $auth;
        $data=json_decode($raw,true);
        if(!is_array($data)) return new WP_Error('pgb_json','Invalid JSON payload.',['status'=>400]);
        $result=$this->processor->create_intent($data);
        return is_wp_error($result) ? $result : new WP_REST_Response($result,200);
    }

    public function status(WP_REST_Request $request) {
        $id=sanitize_text_field($request['transaction_id']);
        $txn=$this->processor->repository()->by_id($id);
        if(!$txn) return new WP_Error('pgb_not_found','Transaction not found.',['status'=>404]);
        return new WP_REST_Response($this->processor->response_from_txn($txn),200);
    }
}
