<?php
defined('ABSPATH') || exit;

class PGB_Addon_Affiliate_WP {
    private $logger;
    public function __construct($logger) { $this->logger=$logger; }

    public function process($order, $txn) {
        if (!$order || !function_exists('affwp_add_referral')) {
            return ['status'=>'skipped','reason'=>'AffiliateWP unavailable'];
        }

        $existing = get_posts([
            'post_type' => 'any',
            'meta_key' => '_bzj_pgb_transaction_id',
            'meta_value' => $txn['transaction_id'],
            'posts_per_page' => 1,
            'fields' => 'ids',
        ]);
        unset($existing); // Transaction idempotency is enforced below by AffiliateWP reference.

        $customer_id = function_exists('affwp_get_customer_by_email')
            ? affwp_get_customer_by_email($order->get_billing_email())
            : false;

        $affiliate_id = 0;
        if ($customer_id && function_exists('affwp_get_customer')) {
            $customer = affwp_get_customer($customer_id);
            $affiliate_id = (int)($customer->affiliate_id ?? 0);
        }
        if (!$affiliate_id && function_exists('affwp_get_affiliate_id')) {
            $affiliate_id = (int)affwp_get_affiliate_id();
        }
        if (!$affiliate_id) {
            $affiliate_id = (int)$order->get_meta('_affwp_affiliate_id', true);
        }

        // Lifetime commission/customer mappings are intentionally resolved at completion,
        // not in Streams, because WordPress is authoritative for AffiliateWP.
        if (!$affiliate_id) return ['status'=>'skipped','reason'=>'No affiliate linked to purchasing customer'];

        global $wpdb;
        $table = $wpdb->prefix . 'affiliate_wp_referrals';
        $already = $wpdb->get_var($wpdb->prepare("SELECT referral_id FROM {$table} WHERE reference=%s LIMIT 1", (string)$order->get_id()));
        if ($already) return ['status'=>'already_processed','referral_id'=>(int)$already];

        $settings = get_option('affwp_settings', []);
        $rate_type = $settings['referral_rate_type'] ?? 'percentage';
        $default_rate = (float)($settings['referral_rate'] ?? 0);
        $commission = 0.0;
        $products = [];

        foreach ($order->get_items() as $item) {
            $target = $item->get_variation_id() ?: $item->get_product_id();
            $raw_rate = get_post_meta($target, '_affwp_woocommerce_product_rate', true);
            $raw_type = get_post_meta($target, '_affwp_woocommerce_product_rate_type', true);
            $item_total = (float)$item->get_total();
            if ($raw_rate !== '' && is_numeric($raw_rate) && in_array($raw_type, ['percentage','flat'], true)) {
                $rate = (float)$raw_rate;
                $item_commission = $raw_type === 'flat' ? $rate : $item_total * $rate / 100;
            } else {
                $item_commission = $rate_type === 'flat' ? $default_rate : $item_total * $default_rate / 100;
            }
            $commission += $item_commission;
            $products[] = ['product_id'=>$item->get_product_id(),'variation_id'=>$item->get_variation_id(),'total'=>$item_total,'commission'=>$item_commission];
        }

        if ($commission <= 0) return ['status'=>'skipped','reason'=>'Commission is zero'];

        $affwp_customer_id = $customer_id ? (int)$customer_id : 0;
        $data = [
            'affiliate_id' => $affiliate_id,
            'customer_id' => $affwp_customer_id,
            'parent_id' => 0,
            'description' => 'Buzzjuice Streams payment #' . $order->get_id(),
            'status' => 'unpaid',
            'amount' => round($commission, 4),
            'currency' => $order->get_currency(),
            'context' => 'woocommerce',
            'reference' => (string)$order->get_id(),
            'products' => maybe_serialize($products),
            'date' => current_time('mysql'),
            'custom' => maybe_serialize([
                'origin'=>'streams',
                'pgb_transaction_id'=>$txn['transaction_id'],
                'calculation_source'=>'pgb_addon_affiliate_wp',
            ]),
        ];
        $referral_id = affwp_add_referral($data);
        if (!$referral_id) throw new RuntimeException('AffiliateWP referral creation failed.');

        $verify = $wpdb->get_var($wpdb->prepare("SELECT referral_id FROM {$table} WHERE referral_id=%d AND reference=%s", $referral_id, (string)$order->get_id()));
        if (!$verify) throw new RuntimeException('AffiliateWP referral could not be verified after insertion.');

        $this->logger->log("AffiliateWP referral {$referral_id} created.", 'info', __FILE__, __LINE__, [
            'order_id'=>$order->get_id(), 'affiliate_id'=>$affiliate_id, 'commission'=>$commission
        ]);
        return ['status'=>'processed','referral_id'=>(int)$referral_id,'commission'=>$commission];
    }
}
