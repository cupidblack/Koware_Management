<?php
defined('ABSPATH') || exit;

class PGB_Admin {
    private $logger;
    private $processor;
    public function __construct($logger,$processor){$this->logger=$logger;$this->processor=$processor;}
    public function register(){
        add_action('admin_menu',[$this,'menu'],99);
        add_action('admin_init',[$this,'settings']);
    }
    private function parent_slug(){
        global $menu;
        foreach((array)$menu as $item){
            if(!empty($item[0]) && stripos(wp_strip_all_tags($item[0]),'Blue Crown')!==false && !empty($item[2])) return $item[2];
        }
        return 'options-general.php';
    }
    public function menu(){
        add_submenu_page($this->parent_slug(),'Payment Gateway','Payment Gateway','manage_options','bzj-payment-gateway',[$this,'page']);
    }
    public function settings(){
        register_setting('bzj_pgb_settings','bzj_pgb_logging_enabled',['type'=>'boolean','sanitize_callback'=>function($v){return !empty($v); }]);
        register_setting('bzj_pgb_settings','bzj_pgb_shared_secret',['type'=>'string','sanitize_callback'=>'sanitize_text_field']);
        register_setting('bzj_pgb_settings','bzj_pgb_streams_url',['type'=>'string','sanitize_callback'=>'esc_url_raw']);
        register_setting('bzj_pgb_settings','bzj_pgb_request_ttl',['type'=>'integer','sanitize_callback'=>'absint']);
        register_setting('bzj_pgb_settings','bzj_pgb_dynamic_min_amount',['type'=>'number','sanitize_callback'=>'floatval']);
        register_setting('bzj_pgb_settings','bzj_pgb_dynamic_max_amount',['type'=>'number','sanitize_callback'=>'floatval']);
    }
    public function page(){
        if(!current_user_can('manage_options')) wp_die('Permission denied.');
        if(empty(get_option('bzj_pgb_shared_secret'))){
            $secret=bin2hex(random_bytes(32));
            update_option('bzj_pgb_shared_secret',$secret,false);
        }
        $txn_table=PGB_Schema::table();
        global $wpdb;
        $stats=[
            'total'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$txn_table}"),
            'paid'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$txn_table} WHERE payment_status='paid'"),
            'completed'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$txn_table} WHERE fulfilment_status='completed'"),
            'retry'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$txn_table} WHERE fulfilment_status='retry'"),
        ];
        ?>
        <div class="wrap">
            <h1>Blue Crown — Payment Gateway</h1>
            <p>Durable Buzzjuice Streams payment bridge. WordPress/WooCommerce remains authoritative.</p>
            <h2>Bridge status</h2>
            <table class="widefat striped" style="max-width:720px"><tbody>
                <tr><td>Schema</td><td><?php echo esc_html(get_option('bzj_pgb_schema_version','not installed')); ?></td></tr>
                <tr><td>WooCommerce</td><td><?php echo function_exists('wc_create_order')?'Available':'Unavailable'; ?></td></tr>
                <tr><td>Logging</td><td><?php echo get_option('bzj_pgb_logging_enabled',true)?'Enabled':'Disabled'; ?></td></tr>
                <tr><td>Transactions</td><td><?php echo esc_html($stats['total']); ?></td></tr>
                <tr><td>Paid</td><td><?php echo esc_html($stats['paid']); ?></td></tr>
                <tr><td>Fulfilled</td><td><?php echo esc_html($stats['completed']); ?></td></tr>
                <tr><td>Retry queue</td><td><?php echo esc_html($stats['retry']); ?></td></tr>
            </tbody></table>
            <h2>Settings</h2>
            <form method="post" action="options.php">
                <?php settings_fields('bzj_pgb_settings'); ?>
                <table class="form-table">
                    <tr><th scope="row">Enable detailed logging</th><td><label><input type="checkbox" name="bzj_pgb_logging_enabled" value="1" <?php checked(get_option('bzj_pgb_logging_enabled',true)); ?>> Enable</label></td></tr>
                    <tr><th scope="row">Streams base URL</th><td><input type="url" class="regular-text" name="bzj_pgb_streams_url" value="<?php echo esc_attr(get_option('bzj_pgb_streams_url','')); ?>"><p class="description">Example: https://buzzjuice.net/streams</p></td></tr>
                    <tr><th scope="row">Shared HMAC secret</th><td><input type="password" class="large-text code" name="bzj_pgb_shared_secret" value="<?php echo esc_attr(get_option('bzj_pgb_shared_secret','')); ?>"><p class="description">This exact value must be configured in Streams Payment Gateway settings. Prefer a server environment constant BZJ_PGB_SHARED_SECRET for production.</p></td></tr>
                    <tr><th scope="row">Request TTL</th><td><input type="number" min="30" max="1800" name="bzj_pgb_request_ttl" value="<?php echo esc_attr(get_option('bzj_pgb_request_ttl',300)); ?>"> seconds</td></tr>
                    <tr><th scope="row">Dynamic payment minimum</th><td><input type="number" min="0.01" step="0.01" name="bzj_pgb_dynamic_min_amount" value="<?php echo esc_attr(get_option('bzj_pgb_dynamic_min_amount',0.01)); ?>"></td></tr>
                    <tr><th scope="row">Dynamic payment maximum</th><td><input type="number" min="1" step="0.01" name="bzj_pgb_dynamic_max_amount" value="<?php echo esc_attr(get_option('bzj_pgb_dynamic_max_amount',1000000)); ?>"></td></tr>
                </table>
                <?php submit_button('Save Payment Gateway Settings'); ?>
            </form>
        </div>
        <?php
    }
}
