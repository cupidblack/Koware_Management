<?php
defined('ABSPATH') || exit;

class PGB_Processor {
    private $logger;
    private $repo;
    private $woo;
    private $streams;
    private $currency;
    private $affiliate;
    private $jewel;

    public function __construct() {
        $this->logger=PGB_Logger::instance();
        $this->repo=new PGB_Repository($this->logger);
        $this->woo=new PGB_Integration_WooCommerce($this->logger);
        $this->streams=new PGB_Integration_Streams($this->logger);
        $this->currency=new PGB_Integration_Currency_Switcher($this->logger);
        $this->affiliate=new PGB_Addon_Affiliate_WP($this->logger);
        $this->jewel=new PGB_Integration_Jewel_Affiliate($this->logger);
    }

    public function create_intent($payload) {
        $required=['transaction_id','idempotency_key','request_id','wow_order_id','streams_user_id','wp_user_id','transaction_kind'];
        foreach($required as $key) if (empty($payload[$key])) return new WP_Error('pgb_missing','Missing '.$key,['status'=>400]);

        $existing=$this->repo->by_idempotency($payload['idempotency_key']);
        if($existing) {
            return $this->response_from_txn($existing);
        }

        $user=$this->streams->resolve_user($payload['streams_user_id'],$payload['wp_user_id']);
        if(!$user) return new WP_Error('pgb_user_mismatch','Streams and WordPress user mapping could not be verified.',['status'=>403]);

        $kind=strtoupper(preg_replace('/[^A-Z_]/','',(string)$payload['transaction_kind']));
        $post_id=absint($payload['wow_post_id'] ?? 0);
        $qty=max(1,absint($payload['quantity'] ?? 1));
        $requested_currency=strtoupper(sanitize_text_field($payload['currency'] ?? get_option('woocommerce_currency','GHS')));
        $base_currency=strtoupper(get_option('woocommerce_currency','GHS'));
        $requested_amount=(float)($payload['amount'] ?? 0);
        if($requested_amount <= 0) return new WP_Error('pgb_amount','Amount must be greater than zero.',['status'=>400]);
        if($kind !== 'PRO') {
            $min=(float)PGB_Config::instance()->get('dynamic_min_amount',0.01);
            $max=(float)PGB_Config::instance()->get('dynamic_max_amount',1000000);
            if($requested_amount < $min || $requested_amount > $max) {
                return new WP_Error('pgb_amount_range','The payment amount is outside the permitted range.',['status'=>400]);
            }
        }

        $product=$this->woo->product_for_transaction($kind,$post_id);
        if(!$product) return new WP_Error('pgb_product','No WooCommerce bridge product is mapped for this transaction.',['status'=>400]);

        $base_amount=$requested_amount;
        $rate=1.0;
        $approved_currency=$requested_currency;
        $converted=$requested_amount;

        // PRO prices are authoritative in WooCommerce. Dynamic transaction kinds use the
        // signed Streams amount as the transaction amount, while WordPress controls the product.
        if($kind==='PRO') {
            $wc_product=$product['product'];
            $base_amount=(float)$wc_product->get_price();
            if($base_amount<=0) {
                $base_amount=(float)$wc_product->get_regular_price();
            }
            if($base_amount<=0) return new WP_Error('pgb_price','The mapped PRO variation has no valid WooCommerce price.',['status'=>400]);
            $converted_result=$this->currency->convert($base_amount,$base_currency,$requested_currency);
            if(is_wp_error($converted_result)) return $converted_result;
            $converted=$converted_result['amount']; $rate=$converted_result['rate'];
        } else {
            // Dynamic Streams amounts (wallet, donations and marketplace purchases) are
            // already expressed in the currency selected by the authenticated Streams
            // session. Do not convert them a second time. The HMAC protects the server-to-
            // server intent; the Streams-side business rules remain responsible for the
            // allowed amount range for each dynamic payment.
            $base_amount = $requested_amount;
            $converted = $requested_amount;
            $rate = 1.0;
            $approved_currency = $requested_currency;
        }

        $txn=[
            'transaction_id'=>sanitize_text_field($payload['transaction_id']),
            'idempotency_key'=>sanitize_text_field($payload['idempotency_key']),
            'request_id'=>sanitize_text_field($payload['request_id']),
            'wow_order_id'=>sanitize_text_field($payload['wow_order_id']),
            'woo_order_id'=>0,
            'wp_user_id'=>absint($payload['wp_user_id']),
            'streams_user_id'=>absint($payload['streams_user_id']),
            'transaction_kind'=>$kind,
            'product_id'=>(int)$product['id'],
            'variation_id'=>$kind==='PRO'?(int)$product['id']:0,
            'streams_post_id'=>$post_id,
            'product_owner_id'=>absint($payload['product_owner_id'] ?? 0),
            'quantity'=>$qty,
            'requested_currency'=>$requested_currency,
            'approved_currency'=>$approved_currency,
            'base_amount'=>$base_amount,
            'conversion_rate'=>$rate,
            'converted_amount'=>$converted,
            'payment_status'=>'intent',
            'fulfilment_status'=>'pending',
            'affiliate_status'=>'pending',
            'addon_status'=>'pending',
            'payment_url'=>'',
            'redirect_url'=>'',
            'retry_count'=>0,
            'last_error'=>'',
            'next_retry_at'=>null,
            'payload'=>wp_json_encode($payload),
        ];
        $created=$this->repo->insert($txn);
        if(!$created) {
            $existing=$this->repo->by_idempotency($txn['idempotency_key']);
            if($existing) return $this->response_from_txn($existing);
            return new WP_Error('pgb_insert','Unable to create payment transaction.',['status'=>500]);
        }

        try {
            $result=$this->woo->create_order($created);
            $this->repo->update($created['transaction_id'],[
                'woo_order_id'=>$result['order_id'],
                'payment_status'=>'order_created',
                'payment_url'=>$result['payment_url'],
            ]);
            $updated=$this->repo->by_id($created['transaction_id']);
            return $this->response_from_txn($updated);
        } catch(Throwable $e) {
            $this->logger->exception($e,__FILE__);
            $this->repo->update($created['transaction_id'],[
                'payment_status'=>'error',
                'last_error'=>$e->getMessage(),
            ]);
            return new WP_Error('pgb_order','Unable to create the WooCommerce order.',['status'=>502]);
        }
    }

    public function process_order($order_id) {
        $order=wc_get_order($order_id);
        if(!$order) return false;
        $transaction_id=(string)$order->get_meta('_bzj_pgb_transaction_id',true);
        if(!$transaction_id) return false;
        $txn=$this->repo->by_id($transaction_id);
        if(!$txn) return false;

        if(!$order->is_paid()) return false;
        $this->repo->update($transaction_id,['payment_status'=>'paid','completed_at'=>current_time('mysql',true)]);

        if(!$this->repo->claim_fulfilment($transaction_id)) {
            $txn=$this->repo->by_id($transaction_id);
            if($txn && $txn['fulfilment_status']==='completed') return true;
            return false;
        }

        try {
            $txn['woo_order_id']=$order_id;
            $txn['product_name']=$order->get_items() ? reset($order->get_items())->get_name() : $txn['transaction_kind'];

            $this->streams->mark_paid($txn);

            try {
                $aff=$this->affiliate->process($order,$txn);
                $this->repo->update($transaction_id,['affiliate_status'=>$aff['status'] ?? 'processed']);
            } catch(Throwable $e) {
                $this->logger->exception($e,__FILE__);
                $this->repo->schedule_retry($transaction_id,'AffiliateWP: '.$e->getMessage(),120);
                return false;
            }

            try {
                $jewel=$this->jewel->process($order,$txn);
                $this->repo->update($transaction_id,['addon_status'=>$jewel['status'] ?? 'processed']);
            } catch(Throwable $e) {
                $this->logger->exception($e,__FILE__);
                $this->repo->schedule_retry($transaction_id,'Jewel: '.$e->getMessage(),180);
                return false;
            }

            $redirect=$this->streams->redirect_url($txn);
            $this->repo->update($transaction_id,[
                'fulfilment_status'=>'completed',
                'redirect_url'=>$redirect,
                'last_error'=>'',
            ]);
            do_action('bzj_pgb_fulfilment_completed',$order,$txn);
            return true;
        } catch(Throwable $e) {
            $this->logger->exception($e,__FILE__);
            $this->repo->schedule_retry($transaction_id,$e->getMessage(),120);
            return false;
        }
    }

    public function retry_due() {
        foreach($this->repo->all_due_retries(20) as $txn) {
            if(!empty($txn['woo_order_id'])) $this->process_order((int)$txn['woo_order_id']);
        }
    }

    public function response_from_txn($txn) {
        return [
            'status'=>'ok',
            'transaction_id'=>$txn['transaction_id'],
            'woo_order_id'=>(int)$txn['woo_order_id'],
            'payment_url'=>$txn['payment_url'],
            'payment_status'=>$txn['payment_status'],
            'fulfilment_status'=>$txn['fulfilment_status'],
            'redirect_url'=>$txn['redirect_url'],
            'currency'=>$txn['approved_currency'],
            'amount'=>(float)$txn['converted_amount'],
        ];
    }

    public function repository(){return $this->repo;}
}
