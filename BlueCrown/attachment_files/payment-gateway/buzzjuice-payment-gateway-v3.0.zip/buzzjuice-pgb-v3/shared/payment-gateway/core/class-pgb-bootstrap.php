<?php
defined('ABSPATH') || exit;

class PGB_Bootstrap {
    private static $instance;
    private $logger;
    private $processor;

    public static function instance() { return self::$instance ?: (self::$instance=new self()); }
    private function __construct() {
        $this->logger=PGB_Logger::instance();
        $this->processor=new PGB_Processor();
    }

    public function init() {
        if(get_option('bzj_pgb_schema_version') !== PGB_Schema::VERSION) PGB_Schema::install();

        add_action('rest_api_init', function(){
            (new PGB_REST())->register();
        });

        add_action('woocommerce_payment_complete', [$this,'order_event'], 20, 1);
        add_action('woocommerce_order_status_processing', [$this,'order_event'], 20, 1);
        add_action('woocommerce_order_status_completed', [$this,'order_event'], 20, 1);

        add_action('bzj_pgb_retry_due', [$this,'retry_due']);
        if(function_exists('as_schedule_recurring_action')) {
            if(!as_next_scheduled_action('bzj_pgb_retry_due')) as_schedule_recurring_action(time()+60, 300, 'bzj_pgb_retry_due', [], 'buzzjuice-pgb');
        } else {
            if(!wp_next_scheduled('bzj_pgb_retry_due')) wp_schedule_event(time()+60, 'five_minutes', 'bzj_pgb_retry_due');
        }

        add_filter('cron_schedules', function($s){
            if(!isset($s['five_minutes'])) $s['five_minutes']=['interval'=>300,'display'=>'Every 5 minutes'];
            return $s;
        });

        if(is_admin()) {
            require_once BZJ_PGB_DIR.'admin/class-pgb-admin.php';
            (new PGB_Admin($this->logger,$this->processor))->register();
        }

        do_action('bzj_pgb_bootstrap_loaded',$this);
        $this->logger->log('PGB bootstrap initialized.','info',__FILE__,__LINE__);
    }

    public function order_event($order_id) {
        try {
            $this->processor->process_order((int)$order_id);
        } catch(Throwable $e) {
            $this->logger->exception($e,__FILE__);
        }
    }
    public function retry_due(){ $this->processor->retry_due(); }
    public function processor(){return $this->processor;}
}
