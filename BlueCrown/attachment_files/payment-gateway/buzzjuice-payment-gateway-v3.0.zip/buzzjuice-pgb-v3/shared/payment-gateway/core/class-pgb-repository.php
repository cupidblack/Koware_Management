<?php
defined('ABSPATH') || exit;

class PGB_Repository {
    private $wpdb;
    private $table;
    private $logger;

    public function __construct($logger) {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->table = PGB_Schema::table();
        $this->logger = $logger;
    }

    public function by_id($transaction_id) {
        return $this->wpdb->get_row($this->wpdb->prepare("SELECT * FROM {$this->table} WHERE transaction_id=%s LIMIT 1", $transaction_id), ARRAY_A);
    }

    public function by_idempotency($key) {
        return $this->wpdb->get_row($this->wpdb->prepare("SELECT * FROM {$this->table} WHERE idempotency_key=%s LIMIT 1", $key), ARRAY_A);
    }

    public function by_woo_order($order_id) {
        return $this->wpdb->get_row($this->wpdb->prepare("SELECT * FROM {$this->table} WHERE woo_order_id=%d LIMIT 1", $order_id), ARRAY_A);
    }

    public function insert($data) {
        $now = current_time('mysql', true);
        $data['created_at'] = $now;
        $data['updated_at'] = $now;
        $formats = [];
        foreach ($data as $k => $v) {
            $formats[] = in_array($k, ['base_amount','conversion_rate','converted_amount'], true) ? '%f' :
                (in_array($k, ['woo_order_id','wp_user_id','streams_user_id','product_id','variation_id','streams_post_id','product_owner_id','quantity','retry_count'], true) ? '%d' : '%s');
        }
        $ok = $this->wpdb->insert($this->table, $data, $formats);
        if (!$ok) {
            $this->logger->log('Transaction insert failed: ' . $this->wpdb->last_error, 'error', __FILE__, __LINE__);
            return false;
        }
        return $this->by_id($data['transaction_id']);
    }

    public function update($transaction_id, $data) {
        $data['updated_at'] = current_time('mysql', true);
        $formats = [];
        foreach ($data as $k => $v) {
            $formats[] = in_array($k, ['base_amount','conversion_rate','converted_amount'], true) ? '%f' :
                (in_array($k, ['woo_order_id','wp_user_id','streams_user_id','product_id','variation_id','streams_post_id','product_owner_id','quantity','retry_count'], true) ? '%d' : '%s');
        }
        $ok = $this->wpdb->update($this->table, $data, ['transaction_id' => $transaction_id], $formats, ['%s']);
        if ($ok === false) {
            $this->logger->log('Transaction update failed: ' . $this->wpdb->last_error, 'error', __FILE__, __LINE__);
            return false;
        }
        return $this->by_id($transaction_id);
    }

    public function claim_fulfilment($transaction_id) {
        $now = current_time('mysql', true);
        $updated = $this->wpdb->query($this->wpdb->prepare(
            "UPDATE {$this->table}
             SET fulfilment_status='processing', updated_at=%s
             WHERE transaction_id=%s AND fulfilment_status IN ('pending','retry')",
            $now, $transaction_id
        ));
        return $updated === 1;
    }

    public function schedule_retry($transaction_id, $error, $seconds = 60) {
        $txn = $this->by_id($transaction_id);
        $count = $txn ? ((int)$txn['retry_count'] + 1) : 1;
        $when = gmdate('Y-m-d H:i:s', time() + max(10, (int)$seconds));
        return $this->update($transaction_id, [
            'fulfilment_status' => 'retry',
            'retry_count' => $count,
            'last_error' => substr((string)$error, 0, 5000),
            'next_retry_at' => $when,
        ]);
    }

    public function all_due_retries($limit = 20) {
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT * FROM {$this->table}
             WHERE fulfilment_status='retry' AND next_retry_at IS NOT NULL AND next_retry_at <= %s
             ORDER BY next_retry_at ASC LIMIT %d",
            current_time('mysql', true), $limit
        ), ARRAY_A);
    }
}
