<?php
defined('ABSPATH') || exit;

class PGB_Security {
    public static function verify_request($raw_body, $headers, $logger) {
        $secret = PGB_Config::instance()->get('shared_secret', '');
        if ($secret === '') {
            $logger->log('PGB shared secret is not configured.', 'error', __FILE__, __LINE__);
            return new WP_Error('pgb_secret_missing', 'Payment bridge authentication is not configured.', ['status' => 503]);
        }

        $timestamp = isset($headers['X-BZJ-PGB-Timestamp']) ? trim($headers['X-BZJ-PGB-Timestamp']) : '';
        $nonce = isset($headers['X-BZJ-PGB-Nonce']) ? trim($headers['X-BZJ-PGB-Nonce']) : '';
        $signature = isset($headers['X-BZJ-PGB-Signature']) ? trim($headers['X-BZJ-PGB-Signature']) : '';

        if (!ctype_digit($timestamp) || $nonce === '' || $signature === '') {
            return new WP_Error('pgb_auth_missing', 'Missing payment bridge authentication headers.', ['status' => 401]);
        }

        $age = abs(time() - (int) $timestamp);
        $ttl = max(30, (int) PGB_Config::instance()->get('request_ttl', 300));
        if ($age > $ttl) {
            return new WP_Error('pgb_auth_expired', 'Payment bridge request has expired.', ['status' => 401]);
        }

        $message = $timestamp . "\n" . $nonce . "\n" . hash('sha256', $raw_body);
        $expected = hash_hmac('sha256', $message, $secret);
        if (!hash_equals($expected, $signature)) {
            $logger->log('Invalid PGB request signature.', 'warning', __FILE__, __LINE__);
            return new WP_Error('pgb_auth_invalid', 'Invalid payment bridge signature.', ['status' => 403]);
        }
        return true;
    }

    public static function nonce() {
        return bin2hex(random_bytes(16));
    }

    public static function sign($body, $timestamp, $nonce, $secret) {
        return hash_hmac('sha256', $timestamp . "\n" . $nonce . "\n" . hash('sha256', $body), $secret);
    }
}
