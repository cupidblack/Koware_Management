<?php
defined('ABSPATH') || exit;

class PGB_Schema {
    const VERSION = '3.0.0';

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . 'bzj_pgb_transactions';
    }

    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table();
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            transaction_id varchar(64) NOT NULL,
            idempotency_key varchar(128) NOT NULL,
            request_id varchar(128) NOT NULL,
            wow_order_id varchar(128) NOT NULL,
            woo_order_id bigint(20) unsigned NOT NULL DEFAULT 0,
            wp_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            streams_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            transaction_kind varchar(32) NOT NULL,
            product_id bigint(20) unsigned NOT NULL DEFAULT 0,
            variation_id bigint(20) unsigned NOT NULL DEFAULT 0,
            streams_post_id bigint(20) unsigned NOT NULL DEFAULT 0,
            product_owner_id bigint(20) unsigned NOT NULL DEFAULT 0,
            quantity int unsigned NOT NULL DEFAULT 1,
            requested_currency varchar(12) NOT NULL DEFAULT '',
            approved_currency varchar(12) NOT NULL DEFAULT '',
            base_amount decimal(20,6) NOT NULL DEFAULT 0,
            conversion_rate decimal(20,10) NOT NULL DEFAULT 1,
            converted_amount decimal(20,6) NOT NULL DEFAULT 0,
            payment_status varchar(32) NOT NULL DEFAULT 'intent',
            fulfilment_status varchar(32) NOT NULL DEFAULT 'pending',
            affiliate_status varchar(32) NOT NULL DEFAULT 'pending',
            addon_status varchar(32) NOT NULL DEFAULT 'pending',
            payment_url text NULL,
            redirect_url text NULL,
            retry_count int unsigned NOT NULL DEFAULT 0,
            last_error text NULL,
            next_retry_at datetime NULL,
            payload longtext NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            completed_at datetime NULL,
            PRIMARY KEY (id),
            UNIQUE KEY transaction_id (transaction_id),
            UNIQUE KEY idempotency_key (idempotency_key),
            KEY request_id (request_id),
            KEY wow_order_id (wow_order_id),
            KEY woo_order_id (woo_order_id),
            KEY wp_user_id (wp_user_id),
            KEY streams_user_id (streams_user_id),
            KEY payment_status (payment_status),
            KEY fulfilment_status (fulfilment_status),
            KEY next_retry_at (next_retry_at),
            KEY created_at (created_at)
        ) {$charset};";
        dbDelta($sql);
        update_option('bzj_pgb_schema_version', self::VERSION, false);
    }
}
