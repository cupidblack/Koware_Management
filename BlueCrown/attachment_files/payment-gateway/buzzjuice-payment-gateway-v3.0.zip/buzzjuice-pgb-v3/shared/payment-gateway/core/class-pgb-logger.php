<?php
defined('ABSPATH') || exit;

class PGB_Logger {
    private static $instance;
    private $enabled;
    private $max_bytes = 5242880;

    public static function instance() {
        return self::$instance ?: (self::$instance = new self());
    }

    private function __construct() {
        $this->enabled = (bool) get_option('bzj_pgb_logging_enabled', true);
        if (!is_dir(BZJ_PGB_LOG_DIR)) {
            wp_mkdir_p(BZJ_PGB_LOG_DIR);
        }
    }

    public function enabled() { return $this->enabled; }

    public function log($message, $level = 'info', $file = null, $line = null, $context = []) {
        if (!$this->enabled) return;
        $name = $this->file_name($file ?: 'bzj-payment-gateway');
        $path = BZJ_PGB_LOG_DIR . $name . '.log';
        if (file_exists($path) && filesize($path) > $this->max_bytes) {
            @rename($path, $path . '.' . gmdate('YmdHis'));
        }
        $entry = [
            'time' => gmdate('c'),
            'level' => strtoupper($level),
            'message' => (string) $message,
        ];
        if ($line) $entry['line'] = (int) $line;
        if (!empty($context)) $entry['context'] = $this->redact($context);
        @file_put_contents($path, wp_json_encode($entry, JSON_UNESCAPED_SLASHES) . PHP_EOL, FILE_APPEND | LOCK_EX);
    }

    public function exception(Throwable $e, $file = null) {
        $this->log($e->getMessage(), 'error', $file ?: $e->getFile(), $e->getLine(), [
            'exception' => get_class($e),
            'trace' => $e->getTraceAsString(),
        ]);
    }

    private function file_name($file) {
        $base = basename((string) $file);
        $base = preg_replace('/\.php$/i', '', $base);
        $base = preg_replace('/[^A-Za-z0-9._-]/', '-', $base);
        return $base ?: 'bzj-payment-gateway';
    }

    private function redact($value) {
        if (is_array($value)) {
            $out = [];
            foreach ($value as $k => $v) {
                if (preg_match('/secret|password|token|signature|authorization|cookie|key/i', (string) $k)) {
                    $out[$k] = '[redacted]';
                } else {
                    $out[$k] = $this->redact($v);
                }
            }
            return $out;
        }
        if (is_object($value)) return $this->redact((array) $value);
        $value = (string) $value;
        return strlen($value) > 1000 ? substr($value, 0, 1000) . '…' : $value;
    }
}
