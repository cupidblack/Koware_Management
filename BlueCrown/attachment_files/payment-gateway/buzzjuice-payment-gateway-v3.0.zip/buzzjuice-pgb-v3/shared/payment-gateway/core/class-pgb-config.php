<?php
defined('ABSPATH') || exit;

class PGB_Config {
    private static $instance;
    private $logger;

    public static function instance() {
        return self::$instance ?: (self::$instance = new self(PGB_Logger::instance()));
    }

    private function __construct($logger) { $this->logger = $logger; }

    public function get($key, $default = null) {
        $defaults = [
            'logging_enabled' => true,
            'shared_secret' => '',
            'streams_url' => '',
            'return_path' => '/streams/',
            'request_ttl' => 300,
            'retry_delay' => 60,
            'max_retries' => 8,
            'dynamic_min_amount' => 0.01,
            'dynamic_max_amount' => 1000000,
        ];
        if ($key === 'shared_secret') {
            $value = defined('BZJ_PGB_SHARED_SECRET') ? BZJ_PGB_SHARED_SECRET : get_option('bzj_pgb_shared_secret', '');
            return is_string($value) ? trim($value) : '';
        }
        if ($key === 'streams_url') {
            return untrailingslashit((string) get_option('bzj_pgb_streams_url', $defaults['streams_url']));
        }
        if ($key === 'logging_enabled') {
            return (bool) get_option('bzj_pgb_logging_enabled', true);
        }
        return get_option('bzj_pgb_' . $key, $defaults[$key] ?? $default);
    }

    public function save($key, $value) {
        return update_option('bzj_pgb_' . sanitize_key($key), $value, false);
    }
}
