<?php
/**
 * Generic Streams-side Payment Gateway Bridge client.
 */
defined('WO_API') || defined('ABSPATH') || exit;

if (!function_exists('bzj_pgb_streams_request')) {
    function bzj_pgb_streams_request(array $payload, $endpoint, $secret, $timeout=20) {
        $body=json_encode($payload,JSON_UNESCAPED_SLASHES);
        $timestamp=(string)time();
        $nonce=bin2hex(random_bytes(16));
        $signature=hash_hmac('sha256',$timestamp."\n".$nonce."\n".hash('sha256',$body),$secret);
        $headers=[
            'Content-Type: application/json',
            'Accept: application/json',
            'X-BZJ-PGB-Timestamp: '.$timestamp,
            'X-BZJ-PGB-Nonce: '.$nonce,
            'X-BZJ-PGB-Signature: '.$signature,
        ];
        $ch=curl_init($endpoint);
        curl_setopt_array($ch,[
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_POST=>true,
            CURLOPT_POSTFIELDS=>$body,
            CURLOPT_HTTPHEADER=>$headers,
            CURLOPT_CONNECTTIMEOUT=>8,
            CURLOPT_TIMEOUT=>$timeout,
            CURLOPT_SSL_VERIFYPEER=>true,
            CURLOPT_SSL_VERIFYHOST=>2,
        ]);
        $raw=curl_exec($ch);
        $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
        $error=curl_error($ch);
        curl_close($ch);
        if($error) return ['ok'=>false,'http_code'=>$code,'error'=>$error,'data'=>null];
        $data=json_decode($raw,true);
        return ['ok'=>$code>=200&&$code<300&&is_array($data),'http_code'=>$code,'error'=>null,'data'=>$data,'raw'=>$raw];
    }
}
