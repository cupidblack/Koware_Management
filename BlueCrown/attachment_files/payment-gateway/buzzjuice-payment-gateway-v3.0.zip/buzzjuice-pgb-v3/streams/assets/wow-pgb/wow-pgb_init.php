<?php
/**
 * Buzzjuice Streams Payment Gateway Bridge — thin adapter.
 * All WooCommerce processing now occurs inside WordPress.
 */
require_once dirname(__DIR__,2).'/config.php';
require_once dirname(__DIR__).'/init.php';
require_once dirname(__DIR__,2).'/../../shared/payment-gateway/pgb-client-streams.php';

header('Content-Type: application/json; charset=UTF-8');

if (empty($wo['loggedin']) || empty($wo['user']['user_id'])) {
    http_response_code(401);
    echo json_encode(['status'=>'error','message'=>'Please login to continue.']);
    exit;
}

try {
    $result=bzj_pgb_streams_init($wo,$sqlConnect,$_POST);
    http_response_code(($result['status']??'error')===200?200:400);
    echo json_encode($result);
} catch(Throwable $e) {
    @error_log('[PGB-STREAMS] '.$e->getMessage().' @ '.$e->getFile().':'.$e->getLine());
    http_response_code(500);
    echo json_encode(['status'=>'error','message'=>'Payment initialization failed.']);
}
exit;
