<?php
/**
 * Legacy compatibility endpoint.
 * New WooCommerce completion events are handled by the WordPress MU plugin.
 * This endpoint intentionally does not perform fulfillment itself.
 */
require_once 'config.php';
require_once 'assets/init.php';

header('Content-Type: application/json; charset=UTF-8');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    echo json_encode(['status'=>'error','message'=>'Method not allowed']);
    exit;
}

$payload=file_get_contents('php://input');
$secret=(string)($wo['config']['wow_webhook_secret']??getenv('BZJ_PGB_WEBHOOK_SECRET'));
$sig=$_SERVER['HTTP_X_WC_WEBHOOK_SIGNATURE']??'';
$expected=$secret?base64_encode(hash_hmac('sha256',$payload,$secret,true)):'';
if(!$secret||!hash_equals($expected,$sig)){
    http_response_code(403);
    echo json_encode(['status'=>'error','message'=>'Invalid signature']);
    exit;
}

// Compatibility only: acknowledge the event. Do not duplicate the WordPress fulfillment path.
http_response_code(200);
echo json_encode(['status'=>'ok','message'=>'Legacy webhook acknowledged; WordPress PGB is authoritative.']);
exit;
