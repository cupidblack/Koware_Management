# Installation and cutover

## Files

Copy:
- `wp-content/mu-plugins/bzj-payment-gateway.php` as the only file in `mu-plugins`.
- `shared/payment-gateway/` to the site root.
- Replace `streams/assets/wow-pgb/wow-pgb_init.php`.
- Apply the `requests.php.pgb-change.txt` and `pgb-settings-fragment.phtml` changes.
- Replace the legacy `streams/wow-pgb_webhook.php` only after confirming the new hook path.

## Important installation-specific step

The current `wow-pgb_sync.php` contains proven business logic for:
- PRO activation/subscription handling,
- AffiliateWP lifetime commissions,
- Jewel affiliate wallet rebate/role handling,
- product/fund redirects.

Those operations cannot safely be guessed from a generic bridge. They must be moved, function-for-function, into:
- `pgb_streams_business_fulfillment`,
- `pgb_jewel_paid`,
- and the AffiliateWP addon.

The new engine must be enabled only after that migration because otherwise the payment can be recorded as paid while a site-specific business fulfillment remains unimplemented.

## WooCommerce

The bridge expects these existing SKUs:
- `wow-pgb_pro` or `wow-pgb_pro_1` ... `wow-pgb_pro_4`
- `wow-pgb_wallet`
- `wow-pgb_fund`
- `wow-pgb_market`

The PRO SKU/variation should carry the authoritative WooCommerce price.

## Security

Do not put WooCommerce consumer keys/secrets in Streams. The bridge uses one shared HMAC secret between the Streams server request and the WordPress MU plugin.
