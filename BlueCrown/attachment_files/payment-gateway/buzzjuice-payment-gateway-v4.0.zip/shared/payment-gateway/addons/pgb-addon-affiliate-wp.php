<?php
if (!defined('ABSPATH')) exit;

final class PGB_Addon_Affiliate_WP {
    public function __construct() {
        add_action('pgb_payment_completed',[$this,'process'],30,2);
    }

    public function process($order,$tx) {
        if(!function_exists('affwp_add_referral')) {
            PGB_DB::update($tx->id,['affiliate_status'=>'not_available']);
            return;
        }
        if($order->get_meta('_affwp_bridge_processed',true)) {
            PGB_DB::update($tx->id,['affiliate_status'=>'completed']);
            return;
        }

        global $wpdb;
        $affiliate_id=$this->resolve_affiliate($order);
        if($affiliate_id<=0) {
            PGB_DB::update($tx->id,['affiliate_status'=>'none']);
            return;
        }
        $existing=$wpdb->get_var($wpdb->prepare(
            "SELECT referral_id FROM {$wpdb->prefix}affiliate_wp_referrals WHERE reference=%s AND context IN ('woocommerce','streams-pgb') LIMIT 1",
            (string)$order->get_id()
        ));
        if($existing) {
            $order->update_meta_data('_affwp_bridge_processed',current_time('mysql',true)); $order->save();
            PGB_DB::update($tx->id,['affiliate_status'=>'completed']); return;
        }

        $customer_id=0;
        if(function_exists('affwp_get_customer')) {
            $c=affwp_get_customer($order->get_billing_email());
            if(is_object($c)) $customer_id=(int)$c->customer_id;
            elseif(is_array($c)) $customer_id=(int)($c['customer_id']??0);
        }

        $commission=$this->commission($order);
        if($commission<=0) {
            PGB_DB::update($tx->id,['affiliate_status'=>'none']);
            return;
        }

        $data=[
            'affiliate_id'=>$affiliate_id,
            'customer_id'=>$customer_id,
            'reference'=>(string)$order->get_id(),
            'parent_id'=>(int)$order->get_parent_id(),
            'description'=>'Buzzjuice Streams payment #'.$order->get_id(),
            'status'=>'unpaid',
            'amount'=>round($commission,4),
            'currency'=>$order->get_currency(),
            'context'=>'woocommerce',
            'campaign'=>'',
            'products'=>maybe_serialize($this->products($order)),
            'date'=>current_time('mysql',true),
            'custom'=>maybe_serialize(['origin'=>'streams','pgb_transaction_id'=>(int)$tx->id])
        ];

        $ref=affwp_add_referral($data);
        if(!$ref) throw new Exception('AffiliateWP referral creation failed');

        $order->update_meta_data('_affwp_bridge_processed',current_time('mysql',true));
        $order->update_meta_data('_affwp_bridge_referral_id',(int)$ref);
        $order->save();
        PGB_DB::update($tx->id,['affiliate_status'=>'completed']);
    }

    private function resolve_affiliate($order) {
        global $wpdb;
        $email=$order->get_billing_email();
        if(function_exists('affwp_get_affiliate_id')) {
            $id=(int)affwp_get_affiliate_id($email);
            if($id>0) return $id;
        }
        if(function_exists('affwp_get_customer')) {
            $c=affwp_get_customer($email);
            $cid=is_object($c)?(int)$c->customer_id:(is_array($c)?(int)($c['customer_id']??0):0);
            if($cid>0) {
                $id=(int)$wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->prefix}affiliate_wp_customermeta WHERE affwp_customer_id=%d AND meta_key IN ('affiliate_id','referring_affiliate_id') ORDER BY meta_id DESC LIMIT 1",$cid));
                if($id>0) return $id;
            }
        }
        $snapshot=$order->get_meta('_buzzjuice_affwp_context_snapshot',true);
        if($snapshot) {
            $a=is_array($snapshot)?$snapshot:json_decode((string)$snapshot,true);
            $id=(int)($a['affwp_affiliate_id']??$a['affiliate_id']??0);
            if($id>0) return $id;
        }
        return 0;
    }

    private function commission($order) {
        $settings=get_option('affwp_settings',[]);
        $rate=(float)($settings['referral_rate']??0);
        $type=$settings['referral_rate_type']??'percentage';
        if($rate<=0) return 0;
        $base=(float)$order->get_subtotal()-(float)$order->get_discount_total();
        return $type==='flat' ? $rate : $base*($rate/100);
    }

    private function products($order) {
        $out=[];
        foreach($order->get_items('line_item') as $item) $out[]=['product_id'=>$item->get_product_id(),'variation_id'=>$item->get_variation_id(),'qty'=>$item->get_quantity(),'total'=>(float)$item->get_total()];
        return $out;
    }
}
new PGB_Addon_Affiliate_WP();
