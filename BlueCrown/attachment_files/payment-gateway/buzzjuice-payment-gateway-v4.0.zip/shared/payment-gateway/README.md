# Buzzjuice Payment Gateway Bridge v4.0

## Runtime architecture

Streams browser -> `requests.php` -> `wow-pgb_init.php` -> signed WordPress REST request -> PGB MU plugin -> native WooCommerce order -> payment gateway -> WooCommerce payment/status hooks -> PGB fulfillment -> Streams DB / AffiliateWP / Jewel.

### Durability controls

- One MU-plugin file in `wp-content/mu-plugins/`.
- All bridge code lives under `shared/payment-gateway/`.
- HMAC authentication between Streams and WordPress.
- Request TTL.
- Persistent transaction table with unique idempotency key.
- Native WooCommerce CRUD instead of WooCommerce consumer-key REST calls.
- Payment completion does not depend on the customer reaching a thank-you page.
- Retry state is stored in the database.
- Action Scheduler is used when available; WP-Cron is the fallback.
- Component-specific logs.
- AffiliateWP executes only after confirmed payment and has duplicate protection.
- The legacy webhook is not a second fulfillment engine.

## Required migration

1. Back up files and databases.
2. Install the single MU plugin.
3. Install `shared/payment-gateway/`.
4. Configure the same shared secret in Streams and WordPress.
5. Confirm WooCommerce bridge products/SKUs.
6. Move the proven installation-specific PRO activation and Jewel wallet logic into the named PGB actions.
7. Disable the old `wow-pgb_sync.php` completion hooks before live testing.
8. Test duplicate clicks, abandoned checkout, successful payment, failed payment, repeated webhook/status events, AffiliateWP, Jewel, and retry recovery.
