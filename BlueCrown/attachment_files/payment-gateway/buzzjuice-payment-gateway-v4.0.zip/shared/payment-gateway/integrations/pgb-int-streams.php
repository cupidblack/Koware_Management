<?php
if (!defined('ABSPATH')) exit;

final class PGB_Int_Streams {
    public function __construct() {
        add_action('pgb_streams_pro_paid',[$this,'pro'],10,2);
        add_action('pgb_streams_wallet_paid',[$this,'wallet'],10,2);
        add_action('pgb_streams_fund_paid',[$this,'fund'],10,2);
        add_action('pgb_streams_product_paid',[$this,'product'],10,2);
    }

    private function mark($order,$tx,$kind) {
        $db=PGB_Streams::db();
        if(!$db) throw new Exception('WoWonder DB unavailable');
        $wow_user=(int)$tx->wow_user_id;
        $post=(int)$tx->wow_post_id;
        $order_id=(int)$order->get_id();

        if($kind==='wallet') {
            $stmt=$db->prepare("UPDATE Wo_Users SET wallet=wallet+? WHERE user_id=? LIMIT 1");
            if(!$stmt) throw new Exception($db->error);
            $amount=(float)$order->get_total(); $stmt->bind_param('di',$amount,$wow_user);
            if(!$stmt->execute()) { $e=$stmt->error;$stmt->close();throw new Exception($e); }
            $stmt->close();
            return;
        }

        /* Preserve existing Streams lifecycle by exposing a durable event.
           Installation-specific PRO/product/fund activation is delegated to
           the same named actions and can safely be retried. */
        do_action('pgb_streams_business_fulfillment',$kind,$order,$tx,$db,$wow_user,$post);
    }

    public function pro($o,$t){$this->mark($o,$t,'pro');}
    public function wallet($o,$t){$this->mark($o,$t,'wallet');}
    public function fund($o,$t){$this->mark($o,$t,'fund');}
    public function product($o,$t){$this->mark($o,$t,'product');}
}
new PGB_Int_Streams();
