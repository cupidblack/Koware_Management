<?php
if (!defined('ABSPATH')) exit;

/**
 * Jewel integration is deliberately event-driven. Existing Streams-side Jewel
 * business logic can be moved behind these actions without becoming a second
 * payment-completion engine.
 */
final class PGB_Int_Jewel_Affiliate {
    public function __construct() {
        add_action('pgb_payment_completed',[$this,'process'],40,2);
    }

    public function process($order,$tx) {
        $variation_ids=[];
        foreach($order->get_items('line_item') as $item) {
            $v=(int)$item->get_variation_id();
            if($v) $variation_ids[]=$v;
        }
        if(!$variation_ids) return;

        $mapping=get_option('jewel_affiliate_variation_mapping',[]);
        if(!is_array($mapping)) return;

        foreach($variation_ids as $vid) {
            if(empty($mapping[$vid]) || !is_array($mapping[$vid])) continue;
            $map=$mapping[$vid];
            do_action('pgb_jewel_paid',$order,$tx,$map);
            PGB_Logger::instance()->info('Jewel payment event dispatched','pgb-int-jewel-affiliate',['order_id'=>$order->get_id(),'variation_id'=>$vid]);
        }
    }
}
new PGB_Int_Jewel_Affiliate();
