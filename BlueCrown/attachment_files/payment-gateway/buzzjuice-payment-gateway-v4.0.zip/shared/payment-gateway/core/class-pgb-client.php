<?php
if (!defined('ABSPATH')) exit;

final class PGB_Client {
    public static function register_rest_routes() {
        register_rest_route('buzzjuice-pgb/v1','/init',[
            'methods'=>WP_REST_Server::CREATABLE,
            'callback'=>[__CLASS__,'init'],
            'permission_callback'=>[__CLASS__,'permission']
        ]);
        register_rest_route('buzzjuice-pgb/v1','/retry/(?P<id>\d+)',[
            'methods'=>WP_REST_Server::CREATABLE,
            'callback'=>[__CLASS__,'retry'],
            'permission_callback'=>function($r){ return current_user_can('manage_options'); }
        ]);
    }

    public static function permission(WP_REST_Request $r) {
        if(!PGB_Config::get('enabled',true)) return new WP_Error('pgb_disabled','Payment Gateway Bridge is disabled',['status'=>503]);
        $secret=PGB_Config::shared_secret();
        if($secret==='') return new WP_Error('pgb_secret','PGB shared secret is not configured',['status'=>503]);
        $timestamp=(string)$r->get_header('x-bzj-pgb-timestamp');
        $signature=(string)$r->get_header('x-bzj-pgb-signature');
        if($timestamp===''||$signature==='') return new WP_Error('pgb_auth','Missing PGB authentication',['status'=>401]);
        if(abs(time()-(int)$timestamp) > (int)PGB_Config::get('request_ttl',300)) return new WP_Error('pgb_expired','Expired PGB request',['status'=>401]);
        $body=$r->get_body();
        $expected=hash_hmac('sha256',$timestamp."\n".$body,$secret);
        if(!hash_equals($expected,$signature)) return new WP_Error('pgb_signature','Invalid PGB signature',['status'=>401]);
        return true;
    }

    public static function init(WP_REST_Request $r) {
        $data=$r->get_json_params();
        try {
            $result=self::create_order($data);
            return new WP_REST_Response($result,200);
        } catch(Throwable $e) {
            PGB_Logger::instance()->error($e->getMessage(),'class-pgb-client',$data);
            return new WP_REST_Response(['status'=>500,'message'=>$e->getMessage()],500);
        }
    }

    public static function create_order($d) {
        if(!function_exists('wc_create_order')) throw new Exception('WooCommerce is not loaded');
        $required=['wow_user_id','wow_order_id','request_id','idempotency_key','transaction_kind','currency','amount'];
        foreach($required as $k) if(!isset($d[$k]) || $d[$k]==='') throw new Exception('Missing field: '.$k);

        $wow_user=(int)$d['wow_user_id'];
        $streams=PGB_Streams::user($wow_user);
        if(!$streams) throw new Exception('Streams user not found');
        $wp_user=(int)$streams['wp_user_id'];
        if($wp_user<=0) throw new Exception('Streams user is not linked to WordPress');

        $idem=sanitize_text_field($d['idempotency_key']);
        $existing=PGB_DB::get_by_idempotency($idem);
        if($existing && (int)$existing->woo_order_id>0) {
            $o=wc_get_order((int)$existing->woo_order_id);
            return ['status'=>200,'transaction_id'=>(int)$existing->id,'woo_order_id'=>(int)$existing->woo_order_id,'url'=>$o?$o->get_checkout_payment_url():home_url('/')];
        }

        $amount=(float)$d['amount'];
        $currency=strtoupper(sanitize_text_field($d['currency']));
        if($amount<=0) throw new Exception('Invalid amount');
        $min=(float)PGB_Config::get('dynamic_min',0); $max=(float)PGB_Config::get('dynamic_max',0);
        if(in_array(strtoupper($d['transaction_kind']),['WALLET','DONATE'],true)) {
            if($min>0 && $amount<$min) throw new Exception('Amount is below the configured minimum');
            if($max>0 && $amount>$max) throw new Exception('Amount exceeds the configured maximum');
        }

        $product=self::resolve_product($d);
        if(!$product) throw new Exception('Payment bridge product is not configured');
        $wc_product=wc_get_product($product['product_id']);
        if(!$wc_product) throw new Exception('WooCommerce payment product not found');

        if(in_array(strtoupper($d['transaction_kind']),['PRO','PRODUCT'],true)) {
            $expected=(float)$wc_product->get_price();
            if($product['variation_id']) {
                $v=wc_get_product($product['variation_id']); if($v) $expected=(float)$v->get_price();
            }
            if($expected>0 && abs($expected-$amount)>0.01) {
                throw new Exception('Payment amount does not match the configured WooCommerce price');
            }
        }

        $tx_id=PGB_DB::create([
            'idempotency_key'=>$idem,
            'request_id'=>sanitize_text_field($d['request_id']),
            'wow_order_id'=>sanitize_text_field($d['wow_order_id']),
            'wow_user_id'=>$wow_user,
            'wp_user_id'=>$wp_user,
            'transaction_kind'=>sanitize_text_field($d['transaction_kind']),
            'wow_post_id'=>(int)($d['wow_post_id']??0),
            'currency'=>$currency,
            'requested_amount'=>$amount,
            'order_amount'=>$amount,
            'payload'=>wp_json_encode($d),
            'next_retry_at'=>gmdate('Y-m-d H:i:s')
        ]);
        if(!$tx_id) throw new Exception('Unable to create PGB transaction');

        $order=wc_create_order(['customer_id'=>$wp_user]);
        if(is_wp_error($order)) throw new Exception($order->get_error_message());
        $order->set_currency($currency);
        $order->set_customer_id($wp_user);
        $order->set_billing_email($streams['email']);

        $qty=max(1,(int)($d['units']??1));
        $line_total=$amount;
        $item_id=$order->add_product($wc_product,$qty,['subtotal'=>$line_total,'total'=>$line_total]);
        if(!$item_id) throw new Exception('Unable to add payment item to WooCommerce order');

        $meta=[
            '_bzj_pgb_origin'=>'streams',
            '_bzj_pgb_transaction_id'=>$tx_id,
            '_bzj_wow_user_id'=>$wow_user,
            '_bzj_wow_order_id'=>sanitize_text_field($d['wow_order_id']),
            '_bzj_wow_post_id'=>(int)($d['wow_post_id']??0),
            '_bzj_transaction_kind'=>sanitize_text_field($d['transaction_kind']),
            '_bzj_product_owner_id'=>(int)($d['product_owner_id']??0),
            '_bzj_streams_return_url'=>esc_url_raw($d['return_url']??''),
            '_bzj_address_id'=>(int)($d['address_id']??0),
        ];
        foreach($meta as $k=>$v) $order->update_meta_data($k,$v);
        $order->update_meta_data('_bzj_client_payload',wp_json_encode([
            'product_name'=>sanitize_text_field($d['product_name']??''),
            'currency'=>$currency,'units'=>$qty
        ]));
        $order->calculate_totals(false);
        $order->save();

        PGB_DB::update($tx_id,['woo_order_id'=>$order->get_id(),'order_amount'=>$order->get_total()]);
        try { PGB_Streams::insert_pending($wow_user,$order->get_total(),$d['wow_order_id'],$d['transaction_kind'],$currency); }
        catch(Throwable $e) { PGB_Logger::instance()->warning('Streams pending transaction insert failed: '.$e->getMessage(),'class-pgb-client'); }

        do_action('pgb_order_initialized',$order,$tx_id);
        return ['status'=>200,'transaction_id'=>$tx_id,'woo_order_id'=>$order->get_id(),'url'=>$order->get_checkout_payment_url()];
    }

    private static function resolve_product($d) {
        $kind=strtoupper((string)$d['transaction_kind']);
        $map=[
            'FUND'=>'wow-pgb_fund',
            'DONATE'=>'wow-pgb_fund',
            'WALLET'=>'wow-pgb_wallet',
            'PRODUCT'=>'wow-pgb_market',
            'PRO'=>'wow-pgb_pro'
        ];
        $sku=$map[$kind]??'wow-pgb_market';
        $variation=0;
        if($kind==='PRO') {
            $pid=(int)($d['wow_post_id']??0);
            $cfg=get_option('wow_pgb_product_ids',[]);
            if(is_array($cfg) && !empty($cfg['pro'][$pid])) $variation=(int)$cfg['pro'][$pid];
            if(!$variation) {
                $candidates=['wow-pgb_pro_'.$pid,'wow-pgb_pro_1','wow-pgb_pro_2','wow-pgb_pro_3','wow-pgb_pro_4'];
                foreach($candidates as $s) { $id=wc_get_product_id_by_sku($s); if($id){$variation=$id;break;} }
            }
        }
        $id=wc_get_product_id_by_sku($sku);
        return $id ? ['product_id'=>$id,'variation_id'=>$variation] : null;
    }

    public static function retry(WP_REST_Request $r) {
        try { PGB_Fulfillment::process_transaction((int)$r['id']); return ['status'=>200]; }
        catch(Throwable $e){ return new WP_Error('pgb_retry',$e->getMessage(),['status'=>500]); }
    }

    public static function signed_request($url,$payload) {
        $secret=PGB_Config::shared_secret();
        if(!$secret) throw new Exception('PGB shared secret is not configured');
        $body=wp_json_encode($payload,JSON_UNESCAPED_SLASHES);
        $ts=(string)time();
        $sig=hash_hmac('sha256',$ts."\n".$body,$secret);
        $response=wp_remote_post(rtrim($url,'/').'/wp-json/buzzjuice-pgb/v1/init',[
            'timeout'=>20,'redirection'=>2,'sslverify'=>true,
            'headers'=>['Content-Type'=>'application/json','X-BZJ-PGB-Timestamp'=>$ts,'X-BZJ-PGB-Signature'=>$sig],
            'body'=>$body
        ]);
        if(is_wp_error($response)) throw new Exception($response->get_error_message());
        $code=wp_remote_retrieve_response_code($response);
        $json=json_decode(wp_remote_retrieve_body($response),true);
        if($code!==200 || !is_array($json)) throw new Exception($json['message']??'PGB request failed');
        return $json;
    }
}
