<?php
if (!defined('ABSPATH')) exit;

final class PGB_DB {
    public static function table() { global $wpdb; return $wpdb->prefix . 'bzj_pgb_transactions'; }

    public static function maybe_install() {
        $version = get_option('bzj_pgb_db_version', '');
        if ($version === BZJ_PGB_VERSION) return;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table();
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            idempotency_key varchar(128) NOT NULL,
            request_id varchar(128) NOT NULL,
            wow_order_id varchar(128) NOT NULL,
            wow_user_id bigint(20) unsigned NOT NULL,
            wp_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            woo_order_id bigint(20) unsigned NOT NULL DEFAULT 0,
            transaction_kind varchar(32) NOT NULL,
            wow_post_id bigint(20) unsigned NOT NULL DEFAULT 0,
            currency varchar(16) NOT NULL,
            requested_amount decimal(20,8) NOT NULL DEFAULT 0,
            order_amount decimal(20,8) NOT NULL DEFAULT 0,
            payment_status varchar(32) NOT NULL DEFAULT 'pending',
            fulfillment_status varchar(32) NOT NULL DEFAULT 'pending',
            affiliate_status varchar(32) NOT NULL DEFAULT 'pending',
            retry_count int unsigned NOT NULL DEFAULT 0,
            next_retry_at datetime NULL,
            last_error text NULL,
            payload longtext NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY idempotency_key (idempotency_key),
            UNIQUE KEY wow_order_id (wow_order_id),
            KEY woo_order_id (woo_order_id),
            KEY wow_user_id (wow_user_id),
            KEY fulfillment_status (fulfillment_status),
            KEY next_retry_at (next_retry_at)
        ) {$charset};";
        dbDelta($sql);
        update_option('bzj_pgb_db_version', BZJ_PGB_VERSION, false);
    }

    public static function create($data) {
        global $wpdb;
        $now = current_time('mysql', true);
        $row = array_merge([
            'idempotency_key'=>'','request_id'=>'','wow_order_id'=>'',
            'wow_user_id'=>0,'wp_user_id'=>0,'woo_order_id'=>0,
            'transaction_kind'=>'','wow_post_id'=>0,'currency'=>'',
            'requested_amount'=>0,'order_amount'=>0,'payment_status'=>'pending',
            'fulfillment_status'=>'pending','affiliate_status'=>'pending',
            'retry_count'=>0,'next_retry_at'=>null,'last_error'=>null,
            'payload'=>null,'created_at'=>$now,'updated_at'=>$now
        ], $data);
        $wpdb->insert(self::table(), $row);
        return $wpdb->insert_id ? (int)$wpdb->insert_id : 0;
    }

    public static function get_by_idempotency($key) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE idempotency_key=%s LIMIT 1", $key));
    }
    public static function get($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d LIMIT 1", $id));
    }
    public static function get_by_woo($woo_id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE woo_order_id=%d LIMIT 1", $woo_id));
    }
    public static function update($id, $data) {
        global $wpdb;
        $data['updated_at'] = current_time('mysql', true);
        return false !== $wpdb->update(self::table(), $data, ['id'=>(int)$id]);
    }

    public static function retryable($limit=8) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM ".self::table()." WHERE fulfillment_status IN ('pending','retry') AND retry_count < %d AND next_retry_at IS NOT NULL AND next_retry_at <= UTC_TIMESTAMP() ORDER BY id ASC LIMIT 25",
            $limit
        ));
    }

    public static function stats() {
        global $wpdb;
        $table = self::table();
        return [
            'retry'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE fulfillment_status IN ('pending','retry')"),
            'completed'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE fulfillment_status='completed'"),
            'failed'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE fulfillment_status='failed'")
        ];
    }
}
