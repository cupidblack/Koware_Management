<?php
if (!defined('ABSPATH')) exit;

final class PGB_State {
    public static function claim_idempotency($key) {
        $existing = PGB_DB::get_by_idempotency($key);
        if ($existing) return ['new'=>false,'row'=>$existing];
        return ['new'=>true,'row'=>null];
    }

    public static function mark_retry($id, $error) {
        $row = PGB_DB::get($id);
        $count = $row ? ((int)$row->retry_count + 1) : 1;
        $delay = min(86400, max(60, (2 ** min($count, 10)) * 30));
        PGB_DB::update($id, [
            'fulfillment_status' => 'retry',
            'retry_count' => $count,
            'last_error' => substr((string)$error, 0, 4000),
            'next_retry_at' => gmdate('Y-m-d H:i:s', time() + $delay)
        ]);
    }
}
