<?php
if (!defined('ABSPATH')) exit;

final class PGB_Logger {
    private static $instance;
    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    public function log($message, $level = 'info', $file = 'pgb-general', $context = []) {
        $s = PGB_Config::settings();
        if (empty($s['logging_enabled'])) return;
        $levels = ['debug'=>10,'info'=>20,'warning'=>30,'error'=>40];
        $configured = $levels[$s['log_level']] ?? 20;
        $current = $levels[strtolower($level)] ?? 20;
        if ($current < $configured) return;

        $safe = $this->redact($message);
        if ($context) $safe .= ' ' . wp_json_encode($this->redact($context));
        $name = preg_replace('/[^a-z0-9_-]/i', '-', basename((string)$file));
        $name = preg_replace('/\.php$/i', '', $name);
        if ($name === '') $name = 'pgb-general';

        $dir = BZJ_PGB_ROOT . '/log';
        if (!is_dir($dir)) wp_mkdir_p($dir);
        $path = $dir . '/' . $name . '.log';
        $line = sprintf("[%s] [%s] %s\n", gmdate('c'), strtoupper($level), $safe);
        @file_put_contents($path, $line, FILE_APPEND | LOCK_EX);

        if (is_file($path) && filesize($path) > 5 * 1024 * 1024) {
            @rename($path, $path . '.' . gmdate('Ymd-His'));
        }
    }

    public function debug($m,$f,$c=[]){$this->log($m,'debug',$f,$c);}
    public function info($m,$f,$c=[]){$this->log($m,'info',$f,$c);}
    public function warning($m,$f,$c=[]){$this->log($m,'warning',$f,$c);}
    public function error($m,$f,$c=[]){$this->log($m,'error',$f,$c);}

    private function redact($value) {
        if (is_array($value)) {
            $out = [];
            foreach ($value as $k=>$v) {
                $key = strtolower((string)$k);
                if (preg_match('/secret|password|token|api[_-]?key|authorization|signature/', $key)) {
                    $out[$k] = '***REDACTED***';
                } else {
                    $out[$k] = $this->redact($v);
                }
            }
            return $out;
        }
        if (is_object($value)) return $this->redact((array)$value);
        $v = (string)$value;
        $v = preg_replace('/(secret|password|token|api[_-]?key|authorization)\s*[:=]\s*([^\s,]+)/i', '$1=***REDACTED***', $v);
        return strlen($v) > 2000 ? substr($v,0,1997).'...' : $v;
    }
}
