<?php
if (!defined('ABSPATH')) exit;

final class PGB_Bootstrap {
    private static $booted = false;

    public static function boot() {
        if (self::$booted) return;
        self::$booted = true;

        self::load('class-pgb-config.php');
        self::load('class-pgb-logger.php');
        self::load('class-pgb-db.php');
        self::load('class-pgb-state.php');
        self::load('class-pgb-streams.php');
        self::load('class-pgb-order.php');
        self::load('class-pgb-fulfillment.php');
        self::load('class-pgb-client.php');

        add_action('plugins_loaded', [__CLASS__, 'init'], 1);
        add_action('init', [__CLASS__, 'schedule_retry_worker'], 20);
    }

    private static function load($file) {
        $path = BZJ_PGB_ROOT . '/core/' . $file;
        if (is_readable($path)) require_once $path;
    }

    public static function init() {
        PGB_Logger::instance()->info('PGB bootstrap initialized', 'class-pgb-bootstrap');
        PGB_DB::maybe_install();

        PGB_Client::register_rest_routes();
        PGB_Order::register_hooks();
        PGB_Fulfillment::register_hooks();

        self::load_integrations();
        self::load_addons();

        add_action('admin_menu', [__CLASS__, 'admin_menu'], 30);
        add_action('admin_init', [__CLASS__, 'admin_init']);
    }

    private static function load_integrations() {
        $dir = BZJ_PGB_ROOT . '/integrations';
        foreach (glob($dir . '/pgb-int-*.php') ?: [] as $file) {
            try {
                require_once $file;
            } catch (Throwable $e) {
                PGB_Logger::instance()->error($e->getMessage(), basename($file, '.php'));
            }
        }
    }

    private static function load_addons() {
        $dir = BZJ_PGB_ROOT . '/addons';
        foreach (glob($dir . '/pgb-addon-*.php') ?: [] as $file) {
            try {
                require_once $file;
            } catch (Throwable $e) {
                PGB_Logger::instance()->error($e->getMessage(), basename($file, '.php'));
            }
        }
    }

    public static function schedule_retry_worker() {
        if (function_exists('as_has_scheduled_action') && function_exists('as_schedule_recurring_action')) {
            if (!as_has_scheduled_action('bzj_pgb_retry_worker')) {
                as_schedule_recurring_action(time() + 60, 300, 'bzj_pgb_retry_worker', [], 'buzzjuice-pgb');
            }
        } elseif (!wp_next_scheduled('bzj_pgb_retry_worker')) {
            wp_schedule_event(time() + 60, 'five_minutes', 'bzj_pgb_retry_worker');
        }
    }

    public static function admin_init() {
        register_setting('bzj_pgb_settings', 'bzj_pgb_settings', [
            'type' => 'array',
            'sanitize_callback' => function($input) {
                $old = get_option('bzj_pgb_settings', []);
                $out = is_array($old) ? $old : [];
                $out['enabled'] = !empty($input['enabled']);
                $out['logging_enabled'] = !empty($input['logging_enabled']);
                $out['log_level'] = in_array(($input['log_level'] ?? 'info'), ['debug','info','warning','error'], true) ? $input['log_level'] : 'info';
                $out['request_ttl'] = max(30, min(900, (int)($input['request_ttl'] ?? 300)));
                $out['retry_limit'] = max(1, min(20, (int)($input['retry_limit'] ?? 8)));
                $out['dynamic_min'] = max(0, (float)($input['dynamic_min'] ?? 0));
                $out['dynamic_max'] = max(0, (float)($input['dynamic_max'] ?? 0));
                $out['streams_url'] = esc_url_raw(trim($input['streams_url'] ?? ''));
                $secret = trim((string)($input['shared_secret'] ?? ''));
                if ($secret !== '') $out['shared_secret'] = $secret;
                return $out;
            }
        ]);
    }

    public static function admin_menu() {
        global $submenu;
        $parent = null;
        foreach ((array)$submenu as $slug => $items) {
            if (stripos($slug, 'blue-crown') !== false || stripos($slug, 'blue_crown') !== false) {
                $parent = $slug;
                break;
            }
        }
        if ($parent) {
            add_submenu_page(
                $parent,
                'Payment Gateway',
                'Payment Gateway',
                'manage_options',
                'bzj-payment-gateway',
                [__CLASS__, 'render_admin']
            );
        }
    }

    public static function render_admin() {
        if (!current_user_can('manage_options')) return;
        $s = PGB_Config::settings();
        $stats = PGB_DB::stats();
        ?>
        <div class="wrap">
            <h1>Buzzjuice Payment Gateway Bridge</h1>
            <p><strong>Version:</strong> <?php echo esc_html(BZJ_PGB_VERSION); ?></p>
            <table class="widefat striped" style="max-width:900px">
                <tbody>
                <tr><td>Enabled</td><td><?php echo !empty($s['enabled']) ? 'Yes' : 'No'; ?></td></tr>
                <tr><td>Logging</td><td><?php echo !empty($s['logging_enabled']) ? 'Enabled' : 'Disabled'; ?></td></tr>
                <tr><td>Pending / retry</td><td><?php echo (int)$stats['retry']; ?></td></tr>
                <tr><td>Completed fulfillment</td><td><?php echo (int)$stats['completed']; ?></td></tr>
                <tr><td>Failed fulfillment</td><td><?php echo (int)$stats['failed']; ?></td></tr>
                </tbody>
            </table>

            <form method="post" action="options.php" style="max-width:900px">
                <?php settings_fields('bzj_pgb_settings'); ?>
                <table class="form-table">
                    <tr><th>Bridge enabled</th><td><input type="checkbox" name="bzj_pgb_settings[enabled]" value="1" <?php checked(!empty($s['enabled'])); ?>></td></tr>
                    <tr><th>Logging enabled</th><td><input type="checkbox" name="bzj_pgb_settings[logging_enabled]" value="1" <?php checked(!empty($s['logging_enabled'])); ?>></td></tr>
                    <tr><th>Log level</th><td><select name="bzj_pgb_settings[log_level]">
                        <?php foreach (['debug','info','warning','error'] as $level): ?><option value="<?php echo esc_attr($level); ?>" <?php selected($s['log_level'], $level); ?>><?php echo esc_html(strtoupper($level)); ?></option><?php endforeach; ?>
                    </select></td></tr>
                    <tr><th>Request TTL (seconds)</th><td><input type="number" min="30" max="900" name="bzj_pgb_settings[request_ttl]" value="<?php echo esc_attr($s['request_ttl']); ?>"></td></tr>
                    <tr><th>Retry limit</th><td><input type="number" min="1" max="20" name="bzj_pgb_settings[retry_limit]" value="<?php echo esc_attr($s['retry_limit']); ?>"></td></tr>
                    <tr><th>Dynamic payment minimum</th><td><input type="number" step="0.01" min="0" name="bzj_pgb_settings[dynamic_min]" value="<?php echo esc_attr($s['dynamic_min']); ?>"></td></tr>
                    <tr><th>Dynamic payment maximum</th><td><input type="number" step="0.01" min="0" name="bzj_pgb_settings[dynamic_max]" value="<?php echo esc_attr($s['dynamic_max']); ?>"></td></tr>
                    <tr><th>Streams URL</th><td><input type="url" class="regular-text" name="bzj_pgb_settings[streams_url]" value="<?php echo esc_attr($s['streams_url']); ?>"></td></tr>
                    <tr><th>Shared HMAC secret</th><td><input type="password" class="regular-text" autocomplete="new-password" name="bzj_pgb_settings[shared_secret]" value="<?php echo esc_attr($s['shared_secret']); ?>"></td></tr>
                </table>
                <?php submit_button('Save Payment Gateway Settings'); ?>
            </form>
        </div>
        <?php
    }
}
