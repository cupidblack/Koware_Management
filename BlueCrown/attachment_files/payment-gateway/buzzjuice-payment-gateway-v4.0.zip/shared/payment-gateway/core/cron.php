<?php
if (!defined('ABSPATH')) exit;
add_filter('cron_schedules', function($schedules){
    if(!isset($schedules['five_minutes'])) $schedules['five_minutes']=['interval'=>300,'display'=>'Every 5 minutes'];
    return $schedules;
});
