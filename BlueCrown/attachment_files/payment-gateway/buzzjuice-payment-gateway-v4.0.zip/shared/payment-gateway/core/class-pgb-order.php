<?php
if (!defined('ABSPATH')) exit;

final class PGB_Order {
    public static function register_hooks() {
        add_action('woocommerce_payment_complete', [__CLASS__, 'paid'], 20, 1);
        add_action('woocommerce_order_status_processing', [__CLASS__, 'status'], 20, 1);
        add_action('woocommerce_order_status_completed', [__CLASS__, 'status'], 20, 1);
        add_filter('woocommerce_get_return_url', [__CLASS__, 'return_url'], 20, 2);
    }

    public static function status($order_id) { self::paid($order_id); }

    public static function paid($order_id) {
        $order=wc_get_order($order_id);
        if(!$order || $order->get_meta('_bzj_pgb_origin',true)!=='streams') return;
        try {
            PGB_Fulfillment::process_order($order);
        } catch(Throwable $e) {
            PGB_Logger::instance()->error($e->getMessage(),'class-pgb-order',['order_id'=>$order_id]);
        }
    }

    public static function return_url($url,$order) {
        if(!$order || $order->get_meta('_bzj_pgb_origin',true)!=='streams') return $url;
        $base = $order->get_meta('_bzj_streams_return_url',true);
        if(!$base) return $url;
        $status = $order->is_paid() ? 'success' : 'pending';
        return add_query_arg([
            'pgb_status'=>$status,
            'woo_order_id'=>$order->get_id(),
            'wow_order_id'=>$order->get_meta('_bzj_wow_order_id',true)
        ], esc_url_raw($base));
    }
}
