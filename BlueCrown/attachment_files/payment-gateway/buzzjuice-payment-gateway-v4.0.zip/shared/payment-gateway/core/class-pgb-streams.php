<?php
if (!defined('ABSPATH')) exit;

final class PGB_Streams {
    private static $db;

    public static function db() {
        if (self::$db instanceof mysqli) return self::$db;
        $helper = BZJ_PGB_ROOT . '/../db_helpers.php';
        if (!function_exists('get_wowonder_db') && is_readable($helper)) require_once $helper;
        if (function_exists('get_wowonder_db')) self::$db = get_wowonder_db();
        return self::$db;
    }

    public static function user($id) {
        $db = self::db();
        if (!$db) return null;
        $stmt = $db->prepare("SELECT user_id, username, email, wp_user_id FROM Wo_Users WHERE user_id=? LIMIT 1");
        if (!$stmt) return null;
        $id=(int)$id; $stmt->bind_param('i',$id); $stmt->execute();
        $stmt->bind_result($uid,$username,$email,$wpid);
        $ok=$stmt->fetch(); $stmt->close();
        return $ok ? ['user_id'=>(int)$uid,'username'=>$username,'email'=>$email,'wp_user_id'=>(int)$wpid] : null;
    }

    public static function update_payment($wow_order_id, $woo_order_id, $status, $method, $amount) {
        $db=self::db(); if(!$db) throw new Exception('WoWonder database unavailable');
        $stmt=$db->prepare("UPDATE Wo_Payment_Transactions SET payment_status=?, payment_method=?, woo_order_id=?, amount=?, transaction_dt=NOW() WHERE order_id=? LIMIT 1");
        if(!$stmt) throw new Exception($db->error);
        $status=(string)$status; $method=(string)$method; $woo=(int)$woo_order_id; $amount=(float)$amount; $ref=(string)$wow_order_id;
        $stmt->close();
        $stmt=$db->prepare("UPDATE Wo_Payment_Transactions SET payment_status=?, payment_method=?, woo_order_id=?, amount=?, transaction_dt=NOW() WHERE order_id=? LIMIT 1");
        if(!$stmt) throw new Exception($db->error);
        $stmt->bind_param('ssids',$status,$method,$woo,$amount,$ref);
        if(!$stmt->execute()) { $e=$stmt->error; $stmt->close(); throw new Exception($e); }
        $stmt->close();
    }

    public static function insert_pending($user_id,$amount,$wow_order_id,$kind,$currency) {
        $db=self::db(); if(!$db) throw new Exception('WoWonder database unavailable');
        $stmt=$db->prepare("INSERT INTO Wo_Payment_Transactions (userid, amount, order_id, kind, currency_code, payment_status, transaction_dt) VALUES (?,?,?,?,?,'pending',NOW())");
        if(!$stmt) throw new Exception($db->error);
        $uid=(int)$user_id;$amt=(float)$amount;$oid=(string)$wow_order_id;$kind=(string)$kind;$cur=(string)$currency;
        $stmt->bind_param('idsss',$uid,$amt,$oid,$kind,$cur);
        if(!$stmt->execute()) { $e=$stmt->error;$stmt->close();throw new Exception($e); }
        $stmt->close();
    }
}
