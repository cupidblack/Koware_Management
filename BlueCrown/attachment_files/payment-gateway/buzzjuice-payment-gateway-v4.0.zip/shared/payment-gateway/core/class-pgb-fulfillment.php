<?php
if (!defined('ABSPATH')) exit;

final class PGB_Fulfillment {
    public static function register_hooks() {
        add_action('bzj_pgb_retry_worker',[__CLASS__,'retry_worker']);
        add_action('woocommerce_order_status_failed',[__CLASS__,'failed'],20,1);
        add_action('woocommerce_order_status_cancelled',[__CLASS__,'failed'],20,1);
    }

    public static function process_order($order) {
        $id=(int)$order->get_meta('_bzj_pgb_transaction_id',true);
        if(!$id) return;
        self::process_transaction($id);
    }

    public static function process_transaction($tx_id) {
        $tx=PGB_DB::get($tx_id);
        if(!$tx) throw new Exception('PGB transaction not found');
        if($tx->fulfillment_status==='completed') return;
        $order=wc_get_order((int)$tx->woo_order_id);
        if(!$order) throw new Exception('WooCommerce order not found');
        if(!$order->is_paid()) {
            PGB_DB::update($tx_id,['payment_status'=>$order->get_status()]);
            return;
        }

        try {
            PGB_DB::update($tx_id,['payment_status'=>$order->get_status(),'fulfillment_status'=>'processing','last_error'=>null]);
            $kind=strtoupper($tx->transaction_kind);
            PGB_Streams::update_payment($tx->wow_order_id,$order->get_id(),$order->get_status(),$order->get_payment_method(),(float)$order->get_total());

            if($kind==='PRO') {
                do_action('pgb_streams_pro_paid',$order,$tx);
            } elseif($kind==='WALLET') {
                do_action('pgb_streams_wallet_paid',$order,$tx);
            } elseif($kind==='DONATE' || $kind==='FUND') {
                do_action('pgb_streams_fund_paid',$order,$tx);
            } elseif($kind==='PRODUCT') {
                do_action('pgb_streams_product_paid',$order,$tx);
            }

            do_action('pgb_payment_completed',$order,$tx);
            PGB_DB::update($tx_id,['fulfillment_status'=>'completed','last_error'=>null,'next_retry_at'=>null]);
        } catch(Throwable $e) {
            PGB_State::mark_retry($tx_id,$e->getMessage());
            PGB_Logger::instance()->error($e->getMessage(),'class-pgb-fulfillment',['transaction_id'=>$tx_id,'order_id'=>$order->get_id()]);
            throw $e;
        }
    }

    public static function retry_worker() {
        foreach(PGB_DB::retryable((int)PGB_Config::get('retry_limit',8)) as $tx) {
            try { self::process_transaction((int)$tx->id); }
            catch(Throwable $e) {}
        }
    }

    public static function failed($order_id) {
        $order=wc_get_order($order_id);
        if(!$order || $order->get_meta('_bzj_pgb_origin',true)!=='streams') return;
        $id=(int)$order->get_meta('_bzj_pgb_transaction_id',true);
        if($id) PGB_DB::update($id,['payment_status'=>$order->get_status()]);
    }
}
