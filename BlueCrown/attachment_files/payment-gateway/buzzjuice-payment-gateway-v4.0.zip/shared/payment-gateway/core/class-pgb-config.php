<?php
if (!defined('ABSPATH')) exit;

final class PGB_Config {
    public static function settings() {
        $defaults = [
            'enabled' => true,
            'logging_enabled' => false,
            'log_level' => 'info',
            'request_ttl' => 300,
            'retry_limit' => 8,
            'dynamic_min' => 0,
            'dynamic_max' => 0,
            'streams_url' => '',
            'shared_secret' => '',
        ];
        $saved = get_option('bzj_pgb_settings', []);
        $saved = is_array($saved) ? $saved : [];
        return array_merge($defaults, $saved);
    }

    public static function get($key, $default = null) {
        $s = self::settings();
        return array_key_exists($key, $s) ? $s[$key] : $default;
    }

    public static function shared_secret() {
        $secret = trim((string)self::get('shared_secret', ''));
        if ($secret !== '') return $secret;
        if (defined('BUZZ_SSO_SECRET') && BUZZ_SSO_SECRET) return BUZZ_SSO_SECRET;
        $env = getenv('BUZZ_SSO_SECRET');
        return $env ?: '';
    }

    public static function streams_url() {
        $url = trim((string)self::get('streams_url', ''));
        if ($url !== '') return rtrim($url, '/');
        if (defined('WP_BASE_SITE_URL') && WP_BASE_SITE_URL) return rtrim(WP_BASE_SITE_URL, '/');
        return '';
    }

    public static function woo_currency() {
        return function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : get_option('woocommerce_currency', '');
    }
}
