# Legacy migration map

- `streams/assets/wow-pgb/wow-pgb_init.php` -> replace with the thin client supplied here.
- `wp-content/plugins/blue-crown-wp/wow-pgb_sync/wow-pgb_sync.php` -> disable/remove its payment completion hooks after migration.
- `streams/wow-pgb_webhook.php` -> retain only as a temporary compatibility endpoint; it must not award wallet/affiliate/PRO benefits independently.
- `streams/jewel-affiliate-webhook.php` -> migrate its successful-order business logic behind `pgb_jewel_paid` or a dedicated integration file.
- Existing `Wo_Payment_Transactions` records remain the Streams audit/payment record.
- New `wp_bzj_pgb_transactions` records become the cross-system transaction/state record.
