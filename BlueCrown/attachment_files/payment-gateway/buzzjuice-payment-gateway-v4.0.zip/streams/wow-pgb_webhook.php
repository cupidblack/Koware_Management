<?php
/**
 * Compatibility acknowledgement only.
 * Do NOT duplicate payment fulfillment here.
 */
http_response_code(410);
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'success'=>false,
    'message'=>'Legacy PGB webhook endpoint retired. WooCommerce payment hooks now drive fulfillment.'
]);
exit;
