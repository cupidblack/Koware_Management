<?php
require_once dirname(__DIR__, 2) . '/config.php';
require_once dirname(__DIR__) . '/init.php';
require_once dirname(__DIR__, 3) . '/../shared/db_helpers.php';

header('Content-Type: application/json; charset=utf-8');

try {
    if (empty($wo['loggedin'])) throw new Exception('Please login to continue');
    if (($wo['config']['wow_payment'] ?? 'no') !== 'yes') throw new Exception('WooCommerce payment is disabled');

    $user_id=(int)($wo['user']['user_id']??0);
    if($user_id<=0) throw new Exception('Invalid user');

    $kind=strtoupper(preg_replace('/[^A-Z_]/','',(string)($_POST['transaction_kind']??'')));
    if(!in_array($kind,['PRO','PRODUCT','WALLET','DONATE','FUND'],true)) throw new Exception('Invalid transaction type');

    $units=max(1,(int)($_POST['product_units']??1));
    $post_id=(int)($_POST['wow_post_id']??0);
    $amount=(float)($_POST['amount']??0);
    $price=(float)($_POST['product_price']??0);
    $currency=sanitize_text_field($_POST['wow_currency_code']??($wo['config']['currency']??'GHS'));
    $owner=(int)($_POST['product_owner_id']??0);
    $name=sanitize_text_field($_POST['product_name']??$kind);

    if($amount<=0 || $price<0) throw new Exception('Invalid payment amount');
    if($kind==='PRODUCT' && $post_id<=0) throw new Exception('Product ID is required');

    $wow_order_id='wow_'.wp_generate_uuid4();
    $request_id='req_'.wp_generate_uuid4();
    $idempotency=hash('sha256', implode('|',[$user_id,$kind,$post_id,$amount,$units,$request_id]));

    $return_url=$wo['config']['site_url'].'/payment-status';

    $store=rtrim((string)($wo['config']['wow_store_url']??''),'/');
    if(!$store) $store=rtrim((string)($wo['config']['site_url']??''),'/');

    $payload=[
        'request_id'=>$request_id,
        'idempotency_key'=>$idempotency,
        'wow_order_id'=>$wow_order_id,
        'wow_user_id'=>$user_id,
        'transaction_kind'=>$kind,
        'wow_post_id'=>$post_id,
        'currency'=>strtoupper($currency),
        'amount'=>$amount,
        'units'=>$units,
        'product_price'=>$price,
        'product_name'=>$name,
        'product_owner_id'=>$owner,
        'address_id'=>(int)($_POST['address_id']??0),
        'return_url'=>$return_url
    ];

    $secret=trim((string)($wo['config']['wow_pgb_shared_secret']??''));
    if($secret==='') $secret=function_exists('bzj_get_sso_secret')?bzj_get_sso_secret():'';
    if($secret==='') throw new Exception('PGB shared secret is not configured');

    $body=json_encode($payload,JSON_UNESCAPED_SLASHES);
    $ts=(string)time();
    $sig=hash_hmac('sha256',$ts."\n".$body,$secret);

    $response=wp_remote_post($store.'/wp-json/buzzjuice-pgb/v1/init',[
        'timeout'=>20,'redirection'=>2,'sslverify'=>true,
        'headers'=>['Content-Type'=>'application/json','X-BZJ-PGB-Timestamp'=>$ts,'X-BZJ-PGB-Signature'=>$sig],
        'body'=>$body
    ]);
    if(is_wp_error($response)) throw new Exception($response->get_error_message());

    $code=wp_remote_retrieve_response_code($response);
    $data=json_decode(wp_remote_retrieve_body($response),true);
    if($code!==200 || !is_array($data) || empty($data['url'])) throw new Exception($data['message']??'Unable to initialize payment');

    echo json_encode($data);
} catch(Throwable $e) {
    http_response_code(400);
    echo json_encode(['status'=>400,'message'=>$e->getMessage()]);
}
exit;
