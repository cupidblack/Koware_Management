/*
 * Replace only the existing Wo_GetWooCommerceLink() function body with this
 * server-authoritative version. The browser sends intent; Streams validates
 * authentication and signs the request server-to-server.
 */
function Wo_GetWooCommerceLink(type, price, type2) {
    var button = document.querySelector('.btn-woocommerce');
    if (button) {
        button.disabled = true;
        button.innerHTML = '<span>Processing...</span>';
    }

    var pro_packages = <?php echo json_encode($wo['pro_packages']); ?>;
    var wow_post_id = $('#product_id').val() || $('#fund_donate_id').val() || '<?php echo isset($wo['product']['id']) ? (int)$wo['product']['id'] : 0; ?>';
    if (!wow_post_id && pro_packages[type]) wow_post_id = pro_packages[type]['id'];

    var product_price = $('#amount').val() || $('#fund_donate_amount').val() || '<?php echo isset($wo['product']['price']) ? (float)$wo['product']['price'] : 0; ?>';
    if (!product_price && pro_packages[type]) product_price = pro_packages[type]['price'];

    var units = $('#product_units').val() || '<?php echo isset($wo["item"]->units) ? (int)$wo["item"]->units : 1; ?>';
    var kind = window.location.href.includes('wallet') ? 'WALLET' :
               window.location.href.includes('fund') ? 'DONATE' :
               window.location.href.includes('checkout') ? 'PRODUCT' : 'PRO';

    $.ajax({
        url: Wo_Ajax_Requests_File() + '?f=payment',
        type: 'POST',
        dataType: 'json',
        data: {
            payment_type: 'wow_payment',
            transaction_kind: kind,
            wow_post_id: wow_post_id,
            product_price: product_price,
            product_units: units,
            amount: (parseFloat(product_price) * parseInt(units,10)),
            product_name: pro_packages[type] ? pro_packages[type]['name'] : 'Buzzjuice Payment',
            product_owner_id: $('#product_owner_id').val() || 0,
            wow_currency_code: '<?php echo addslashes($wo["config"]["currency"]); ?>',
            address_id: $('input[name=choose-address]:checked').val() || 0,
            hash_id: '<?php echo Wo_CreateSession();?>'
        },
        success: function(data) {
            if (data && data.status === 200 && data.url) {
                window.location.href = data.url;
                return;
            }
            if (button) {
                button.disabled = false;
                button.innerHTML = 'Debit/Credit Card/ Mobile Money';
            }
            $('.pay-go-pro-alert').html('<div class="alert alert-danger">' + (data.message || 'Unable to initialize payment') + '</div>');
        },
        error: function(xhr) {
            if (button) {
                button.disabled = false;
                button.innerHTML = 'Debit/Credit Card/ Mobile Money';
            }
            var msg = 'Unable to initialize payment';
            if (xhr.responseJSON && xhr.responseJSON.message) msg = xhr.responseJSON.message;
            $('.pay-go-pro-alert').html('<div class="alert alert-danger">' + msg + '</div>');
        }
    });
}
