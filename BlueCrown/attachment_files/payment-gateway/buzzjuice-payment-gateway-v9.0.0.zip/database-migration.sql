-- Run against the WoWonder database.
CREATE TABLE IF NOT EXISTS Wo_PGB_Orders (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 wow_order_id VARCHAR(100) NOT NULL UNIQUE,
 wow_user_id BIGINT UNSIGNED NOT NULL,
 wp_user_id BIGINT UNSIGNED NOT NULL,
 token_hash CHAR(64) NOT NULL,
 payload LONGTEXT NOT NULL,
 status VARCHAR(20) NOT NULL DEFAULT 'pending',
 woo_order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL,
 expires_at DATETIME NOT NULL,
 consumed_at DATETIME NULL,
 KEY token_hash(token_hash), KEY status(status), KEY wow_user_id(wow_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
