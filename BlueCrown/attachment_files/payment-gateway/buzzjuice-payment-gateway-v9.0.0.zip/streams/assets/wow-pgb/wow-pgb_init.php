<?php
/**
 * Buzzjuice Payment Gateway Bridge entry point for WoWonder.
 * WoWonder does not load WordPress; this file only loads the shared Streams client.
 */
require_once dirname(__DIR__,3).'/shared/payment-gateway/pgb-client-streams.php';
