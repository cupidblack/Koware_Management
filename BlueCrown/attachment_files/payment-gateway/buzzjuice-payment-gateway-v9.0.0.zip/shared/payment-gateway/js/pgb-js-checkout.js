/* Optional helper: Streams AJAX callers can redirect to response.url. */
(function(){'use strict';
window.BuzzjuicePGB={redirect:function(url){if(url) window.location.assign(url);}};
})();
