<?php
if (!defined('ABSPATH')) { exit; }
/*
 * Compatibility loader during migration.
 * Before deleting the old plugin file, copy its complete contents into this
 * file. This loader is intentionally fail-safe and does not execute arbitrary
 * remote code.
 */
$legacy = ABSPATH.'wp-content/plugins/blue-crown-wp/wow-pgb_sync/wow-pgb_sync.php';
if (is_readable($legacy)) require_once $legacy;
