<?php
if (!defined('ABSPATH')) { exit; }

function bzj_pgb_config() {
    $env = static function($key, $default = '') {
        $v = getenv($key);
        return ($v !== false && $v !== '') ? $v : $default;
    };
    return [
        'logging_enabled' => filter_var($env('BZJ_PGB_LOGGING', '0'), FILTER_VALIDATE_BOOLEAN),
        'log_level' => strtolower($env('BZJ_PGB_LOG_LEVEL', 'info')),
        'secret' => $env('BZJ_PGB_SECRET', ''),
        'token_ttl' => max(60, (int)$env('BZJ_PGB_TOKEN_TTL', '900')),
        'endpoint_param' => 'bzj_pgb',
        'staging_table' => 'Wo_PGB_Orders',
        'transaction_table' => 'Wo_Payment_Transactions',
    ];
}
