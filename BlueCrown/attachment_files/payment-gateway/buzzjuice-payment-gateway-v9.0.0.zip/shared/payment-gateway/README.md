# Buzzjuice Payment Gateway Bridge v9

Architecture:
Streams -> WoWonder DB staging -> browser redirect -> WordPress MU plugin -> local WooCommerce order -> WooCommerce native order-pay URL -> payment -> WooCommerce hooks -> PGB fulfillment -> AffiliateWP adapter.

There is deliberately no Streams-to-WordPress cURL call.

The WordPress endpoint is the normal public web request made by the customer's browser, so a server-side DNS failure from cPanel does not affect the handoff.

Important migration rule:
1. Copy the current `wow-pgb_sync.php` implementation into `integrations/pgb-int-affiliate-wp-legacy.php` before removing the old plugin.
2. The compatibility loader may temporarily load the old file; after successful migration, replace the loader with the copied implementation.
3. Only `wp-content/mu-plugins/bzj-payment-gateway.php` remains in mu-plugins for PGB.

Environment:
BZJ_PGB_SECRET=<same 64-hex-character secret in both PHP runtimes>
BZJ_PGB_LOGGING=0
BZJ_PGB_LOG_LEVEL=info
BZJ_PGB_TOKEN_TTL=900
WP_BASE_SITE_URL=https://buzzjuice.net

Do not disable TLS verification in production.

## Important
The staging table is created automatically by the Streams client, but the supplied `database-migration.sql` is recommended for controlled deployment. The WordPress handoff creates the order with WooCommerce PHP APIs; it does not use `/wc/v3/orders`.
