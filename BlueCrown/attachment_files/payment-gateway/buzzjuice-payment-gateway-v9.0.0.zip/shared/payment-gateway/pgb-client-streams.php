<?php
/**
 * Runs inside WoWonder. No wp-load.php and no server-side HTTP request to WordPress.
 */
require_once dirname(__DIR__,2).'/streams/config.php';
require_once dirname(__DIR__,2).'/streams/init.php';

if (empty($wo['loggedin'])) { http_response_code(401); exit(json_encode(['status'=>'error','message'=>'Login required'])); }
if (!isset($sqlConnect) || !($sqlConnect instanceof mysqli)) { http_response_code(500); exit(json_encode(['status'=>'error','message'=>'Database unavailable'])); }

function bzj_pgb_stream_secret() {
    $s=getenv('BZJ_PGB_SECRET');
    if ($s===false || $s==='') $s=$GLOBALS['wo']['config']['bzj_pgb_secret']??'';
    return (string)$s;
}
function bzj_pgb_clean($v){return trim((string)$v);}
function bzj_pgb_fail($m,$c=400){http_response_code($c);echo json_encode(['status'=>'error','message'=>$m]);exit;}

$required=['amount','product_name','product_price','product_units','transaction_kind','wow_currency_code'];
foreach($required as $p) if(!isset($_POST[$p]) || $_POST[$p]==='') bzj_pgb_fail('Missing required parameter: '.$p);
$user=(int)($wo['user']['user_id']??0); if(!$user) bzj_pgb_fail('Invalid user',401);
$kind=strtoupper(preg_replace('/[^A-Z0-9_-]/','',$_POST['transaction_kind']));
$allowed=['PRODUCT','PRO','WALLET','DONATE']; if(!in_array($kind,$allowed,true)) bzj_pgb_fail('Invalid transaction kind');
$amount=(float)$_POST['amount']; $price=(float)$_POST['product_price']; $units=max(1,(int)$_POST['product_units']); $currency=strtoupper(bzj_pgb_clean($_POST['wow_currency_code']));
if($amount<=0||$price<0||!preg_match('/^[A-Z]{3}$/',$currency)) bzj_pgb_fail('Invalid payment amount or currency');
$email=filter_var($wo['user']['email']??'',FILTER_VALIDATE_EMAIL); if(!$email) bzj_pgb_fail('Invalid account email');

$wow_order_id='wow_'.bin2hex(random_bytes(16));
$product_id=(int)($_POST['product_id']??0);
$wow_post_id=(int)($_POST['wow_post_id']??0);
$owner=(int)($_POST['product_owner_id']??0);
$address=(int)($_POST['address_id']??0);
$wp_user=0;
$st=$sqlConnect->prepare('SELECT wp_user_id FROM '.T_USERS.' WHERE user_id=? LIMIT 1');
if($st){$st->bind_param('i',$user);$st->execute();$st->bind_result($wp_user);$st->fetch();$st->close();}
if(!$wp_user) bzj_pgb_fail('WordPress account link is missing',409);

if($kind==='PRO'){
    $map=[1=>$wo['config']['wow_pro_package_id']??0,2=>$wo['config']['wow_pro_package_id_2']??0,3=>$wo['config']['wow_pro_package_id_3']??0,4=>$wo['config']['wow_pro_package_id_4']??0];
    if(!isset($map[$wow_post_id]) || !$map[$wow_post_id]) bzj_pgb_fail('Invalid PRO package');
    $product_id=(int)$map[$wow_post_id];
} elseif($kind==='WALLET') {
    $product_id=(int)($wo['config']['wow_wallet_topup_id']??0);
} elseif($kind==='DONATE') {
    $product_id=(int)($wo['config']['wow_crowdfund_id']??0);
}

$payload=[
 'wow_user_id'=>$user,'wp_user_id'=>(int)$wp_user,'wow_order_id'=>$wow_order_id,
 'transaction_kind'=>$kind,'amount'=>$amount,'product_name'=>bzj_pgb_clean($_POST['product_name']),
 'product_price'=>$price,'product_units'=>$units,'product_id'=>$product_id,'wow_post_id'=>$wow_post_id,
 'product_owner_id'=>$owner,'address_id'=>$address,'currency'=>$currency,'email'=>$email,
 'username'=>bzj_pgb_clean($wo['user']['username']??''),'created_at'=>gmdate('c')
];
$payload_json=json_encode($payload,JSON_UNESCAPED_SLASHES);
$token=bin2hex(random_bytes(24)); $hash=hash_hmac('sha256',$token,bzj_pgb_stream_secret());
if(strlen(bzj_pgb_stream_secret())<32) bzj_pgb_fail('Payment bridge secret is not configured securely',500);

$table='Wo_PGB_Orders';
$create="CREATE TABLE IF NOT EXISTS {$table} (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 wow_order_id VARCHAR(100) NOT NULL UNIQUE,
 wow_user_id BIGINT UNSIGNED NOT NULL,
 wp_user_id BIGINT UNSIGNED NOT NULL,
 token_hash CHAR(64) NOT NULL,
 payload LONGTEXT NOT NULL,
 status VARCHAR(20) NOT NULL DEFAULT 'pending',
 woo_order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL,
 expires_at DATETIME NOT NULL,
 consumed_at DATETIME NULL,
 KEY token_hash(token_hash), KEY status(status), KEY wow_user_id(wow_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
if(!$sqlConnect->query($create)) bzj_pgb_fail('Bridge staging table unavailable',500);
$exp=date('Y-m-d H:i:s',time()+900);
$st=$sqlConnect->prepare("INSERT INTO {$table} (wow_order_id,wow_user_id,wp_user_id,token_hash,payload,status,created_at,expires_at) VALUES (?,?,?,?,?,'pending',NOW(),?)");
if(!$st) bzj_pgb_fail('Could not prepare bridge order',500);
$st->bind_param('siisss',$wow_order_id,$user,$wp_user,$hash,$payload_json,$exp);
if(!$st->execute()) bzj_pgb_fail('Could not store bridge order',500);
$st->close();

$tx=$sqlConnect->prepare("INSERT INTO Wo_Payment_Transactions (userid,amount,order_id,kind,currency_code,payment_status,transaction_dt) VALUES (?,?,?,? ,?,'pending',NOW())");
if(!$tx) bzj_pgb_fail('Could not prepare payment transaction',500);
$tx->bind_param('idsss',$user,$amount,$wow_order_id,$kind,$currency);
if(!$tx->execute()) { $tx->close(); bzj_pgb_fail('Could not store payment transaction',500); }
$tx->close();

$base=rtrim((string)($wo['config']['wow_store_url']??getenv('WP_BASE_SITE_URL')),'/');
if(!$base) bzj_pgb_fail('WooCommerce site URL is not configured',500);
$redirect=$base.'/?bzj_pgb=checkout&token='.rawurlencode($token);
header('Content-Type: application/json');
echo json_encode(['status'=>200,'url'=>$redirect,'order_id'=>$wow_order_id]);
exit;
