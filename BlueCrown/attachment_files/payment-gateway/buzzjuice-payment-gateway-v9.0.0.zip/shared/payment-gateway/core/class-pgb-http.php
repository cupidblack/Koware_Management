<?php
if (!defined('ABSPATH')) { exit; }

final class PGB_HTTP {
    public static function redirect($url) {
        wp_safe_redirect($url); exit;
    }
    public static function fail($code,$message) {
        status_header($code); wp_die(esc_html($message),'Buzzjuice Payment Gateway',['response'=>$code]);
    }
}
