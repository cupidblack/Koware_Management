<?php
if (!defined('ABSPATH')) { exit; }

final class PGB_Bootstrap {
    private static $instance;
    private $config,$logger,$manager;
    private function __construct() {
        require_once dirname(__DIR__).'/config/pgb-config.php';
        $this->config=bzj_pgb_config();
        require_once __DIR__.'/class-pgb-logger.php';
        $this->logger=new PGB_Logger($this->config);
        require_once __DIR__.'/class-pgb-http.php';
        require_once __DIR__.'/class-pgb-manager.php';
        $this->manager=new PGB_Manager($this->config,$this->logger);
        $this->load_extensions();
        $this->register_hooks();
    }
    public static function instance() { return self::$instance ?: (self::$instance=new self()); }
    public function logger(){return $this->logger;}
    public function manager(){return $this->manager;}
    public function config($k,$d=null){return $this->config[$k]??$d;}
    private function load_extensions() {
        foreach (['addons','integrations'] as $dir) {
            $path=dirname(__DIR__).'/'.$dir.'/';
            if (!is_dir($path)) continue;
            foreach (glob($path.'pgb-*.php') ?: [] as $file) require_once $file;
        }
    }
    private function register_hooks() {
        add_action('rest_api_init',[$this,'register_rest']);
        add_action('template_redirect',[$this,'checkout_handoff'],1);
        add_action('woocommerce_payment_complete',[$this,'payment_complete'],20,1);
        add_action('woocommerce_order_status_completed',[$this,'status_completed'],20,1);
        add_action('woocommerce_order_status_processing',[$this,'status_processing'],20,1);
    }
    public function register_rest() {
        register_rest_route('bzj-pgb/v1','/health',[
            'methods'=>'GET','permission_callback'=>'__return_true',
            'callback'=>function(){return new WP_REST_Response(['status'=>'ok','version'=>'9.0.0'],200);}
        ]);
    }
    public function checkout_handoff() {
        if (empty($_GET[$this->config['endpoint_param']]) || $_GET[$this->config['endpoint_param']] !== 'checkout') return;
        $token = isset($_GET['token']) ? preg_replace('/[^a-f0-9]/i','',wp_unslash($_GET['token'])) : '';
        if ($token === '') PGB_HTTP::fail(400,'Invalid payment bridge token.');
        $url=$this->manager->create_order_from_token($token);
        if (is_wp_error($url)) PGB_HTTP::fail($url->get_error_code()==='expired'?410:400,$url->get_error_message());
        PGB_HTTP::redirect($url);
    }
    public function payment_complete($order_id){$this->manager->complete((int)$order_id,'payment_complete');}
    public function status_completed($order_id){$this->manager->complete((int)$order_id,'status_completed');}
    public function status_processing($order_id){$this->manager->note((int)$order_id,'Order entered processing');}
}
