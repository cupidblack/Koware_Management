<?php
if (!defined('ABSPATH')) { exit; }

final class PGB_Manager {
    private $cfg,$log,$db;
    public function __construct($cfg,$log) {
        $this->cfg=$cfg; $this->log=$log;
        $helpers=dirname(__DIR__,2).'/db_helpers.php';
        if (is_readable($helpers)) require_once $helpers;
        $this->db=function_exists('get_wowonder_db')?get_wowonder_db():false;
    }
    public function create_order_from_token($token) {
        if (!class_exists('WooCommerce')) return new WP_Error('woocommerce_missing','WooCommerce is not loaded.');
        if (!$this->db) return new WP_Error('db_missing','WoWonder database is unavailable.');
        $secret=(string)($this->cfg['secret']??'');
        if (strlen($secret)<32) return new WP_Error('secret_missing','Payment bridge secret is not configured securely.');
        $hash=hash_hmac('sha256',$token,$secret);
        $table=$this->cfg['staging_table'];
        $this->db->begin_transaction();
        try {
            $st=$this->db->prepare("SELECT id,wow_order_id,payload,status,woo_order_id,expires_at FROM {$table} WHERE token_hash=? LIMIT 1 FOR UPDATE");
            if(!$st) throw new Exception('Staging lookup failed: '.$this->db->error);
            $st->bind_param('s',$hash); if(!$st->execute()) throw new Exception('Staging lookup failed: '.$st->error);
            $st->bind_result($id,$wow_order_id,$payload,$status,$existing_woo,$expires_at);
            if(!$st->fetch()){ $st->close(); $this->db->rollback(); return new WP_Error('invalid_token','Payment link is invalid or has expired.'); }
            $st->close();
            if($status==='completed' && $existing_woo){$this->db->commit();$o=wc_get_order((int)$existing_woo);return $o?$o->get_checkout_order_received_url():new WP_Error('order_missing','WooCommerce order is unavailable.');}
            if($status!=='pending') { $this->db->rollback(); return new WP_Error('used_token','Payment link is no longer available.'); }
            if(strtotime($expires_at)<time()){ $this->db->rollback(); return new WP_Error('expired','Payment link has expired. Please start the payment again.'); }
            $data=json_decode($payload,true);
            if(!is_array($data)) throw new Exception('Invalid staging payload.');
            $wp_user=(int)$data['wp_user_id']; $product_id=(int)$data['product_id']; $qty=max(1,(int)$data['product_units']);
            $product=wc_get_product($product_id);
            if(!$product) throw new Exception('WooCommerce product is unavailable.');
            $order=wc_create_order(['customer_id'=>$wp_user,'created_via'=>'buzzjuice-pgb']);
            if(is_wp_error($order)) throw new Exception($order->get_error_message());
            $price=(float)$data['product_price']; $total=(float)$data['amount'];
            $item_args=['subtotal'=>wc_format_decimal($price*$qty,2),'total'=>wc_format_decimal($total,2)];
            $item_id=$order->add_product($product,$qty,$item_args);
            if(!$item_id) throw new Exception('Could not add product to WooCommerce order.');
            $user=get_user_by('ID',$wp_user);
            $billing=[];
            if($user){
                $billing=[
                    'first_name'=>(string)$user->first_name,'last_name'=>(string)$user->last_name,
                    'email'=>(string)$user->user_email,
                    'phone'=>(string)get_user_meta($wp_user,'billing_phone',true),
                    'address_1'=>(string)get_user_meta($wp_user,'billing_address_1',true),
                    'address_2'=>(string)get_user_meta($wp_user,'billing_address_2',true),
                    'city'=>(string)get_user_meta($wp_user,'billing_city',true),
                    'state'=>(string)get_user_meta($wp_user,'billing_state',true),
                    'postcode'=>(string)get_user_meta($wp_user,'billing_postcode',true),
                    'country'=>(string)get_user_meta($wp_user,'billing_country',true),
                ];
                $order->set_address(array_filter($billing), 'billing');
            }
            $order->set_currency((string)$data['currency']);
            $meta=[
                '_bzj_wow_user_id'=>(int)$data['wow_user_id'],'_bzj_wow_order_id'=>(string)$data['wow_order_id'],
                '_bzj_transaction_kind'=>(string)$data['transaction_kind'],'_bzj_wow_post_id'=>(int)$data['wow_post_id'],
                '_bzj_product_owner_id'=>(int)$data['product_owner_id'],'_bzj_address_id'=>(int)$data['address_id'],
                '_bzj_pgb_version'=>'9.0.0','_bzj_pgb_staging_id'=>(int)$id,
            ];
            foreach($meta as $k=>$v)$order->update_meta_data($k,$v);
            $order->calculate_totals(false);
            $order->save();
            if(strtoupper($data['transaction_kind'])==='PRO' && function_exists('wcs_create_subscription') && function_exists('WC_Subscriptions_Product')) {
                $period='month';$interval=1;
                $packages=isset($GLOBALS['wo']['pro_packages'])&&is_array($GLOBALS['wo']['pro_packages'])?$GLOBALS['wo']['pro_packages']:[];
                foreach($packages as $package){if((int)($package['id']??0)===(int)$data['wow_post_id']){$period=(string)($package['time']??'month');$interval=max(1,(int)($package['count']??1));break;}}
                if(WC_Subscriptions_Product::is_subscription($product)){
                    $sub=wcs_create_subscription(['order_id'=>$order->get_id(),'customer_id'=>$wp_user,'created_via'=>'buzzjuice-pgb','currency'=>$order->get_currency(),'billing_period'=>$period,'billing_interval'=>$interval,'status'=>'pending']);
                    if(is_wp_error($sub)) throw new Exception($sub->get_error_message());
                    wcs_copy_order_address($order,$sub);
                    foreach($order->get_items() as $item){$sub->add_product($item->get_product(),$item->get_quantity(),['subtotal'=>$item->get_subtotal(),'total'=>$item->get_total()]);}
                    $sub->calculate_totals(false);$sub->save();
                }
            }
            $woo_id=$order->get_id();
            $up=$this->db->prepare("UPDATE {$table} SET status='claimed',woo_order_id=?,consumed_at=NOW() WHERE id=?");
            if(!$up) throw new Exception('Could not claim staging order: '.$this->db->error);
            $up->bind_param('ii',$woo_id,$id);if(!$up->execute())throw new Exception('Could not claim staging order: '.$up->error);$up->close();
            $this->db->commit();
            $this->log->log('WooCommerce order created from staging token',PGB_Logger::INFO,['staging_id'=>$id,'woo_order_id'=>$woo_id],__FILE__);
            return $order->get_checkout_payment_url();
        } catch(Throwable $e) {
            $this->db->rollback();
            $this->log->log('Checkout handoff failed',PGB_Logger::ERROR,['error'=>$e->getMessage()],__FILE__);
            return new WP_Error('handoff_failed',$e->getMessage());
        }
    }

    public function note($order_id,$message) {
        $o=wc_get_order($order_id); if ($o) $o->add_order_note('[PGB] '.$message);
    }
    public function complete($order_id,$reason='unknown') {
        $o=wc_get_order($order_id);
        if (!$o) { $this->log->log('Woo order not found',PGB_Logger::ERROR,['order_id'=>$order_id],__FILE__); return false; }
        if ($o->get_meta('_bzj_pgb_fulfilled_at')) return true;
        $kind=strtoupper((string)$o->get_meta('_bzj_transaction_kind'));
        try {
            if ($kind==='PRO') $this->sync_pro($o);
            elseif ($kind==='WALLET') $this->sync_wallet($o);
            elseif (in_array($kind,['PRODUCT','PURCHASE','SALE'],true)) $this->sync_product($o);
            elseif ($kind==='DONATE') $this->sync_donation($o);
            $this->sync_transaction($o);
            do_action('bzj_pgb_payment_fulfilled',$o,$reason);
            $o->update_meta_data('_bzj_pgb_fulfilled_at',gmdate('c'));
            $o->save();
            return true;
        } catch (Throwable $e) {
            $this->log->log('Fulfillment failed',PGB_Logger::CRITICAL,['order_id'=>$order_id,'error'=>$e->getMessage()],__FILE__);
            $o->add_order_note('[PGB] Fulfillment error: '.$e->getMessage());
            return false;
        }
    }
    private function sync_transaction($o) {
        if (!$this->db) throw new Exception('WoWonder DB unavailable');
        $wow=(int)$o->get_meta('_bzj_wow_user_id'); $wow_order=(string)$o->get_meta('_bzj_wow_order_id');
        if (!$wow || !$wow_order) throw new Exception('Missing Streams identifiers');
        $table=$this->cfg['transaction_table'];
        $status='completed'; $woo=(int)$o->get_id();
        $st=$this->db->prepare("UPDATE {$table} SET payment_status=?, woo_order_id=? WHERE order_id=?");
        if (!$st) throw new Exception('Transaction update prepare failed: '.$this->db->error);
        $st->bind_param('sis',$status,$woo,$wow_order);
        if (!$st->execute()) throw new Exception('Transaction update failed: '.$st->error);
        $st->close();
    }
    private function sync_product($o) {
        if (!$this->db) throw new Exception('WoWonder DB unavailable');
        $wow=(int)$o->get_meta('_bzj_wow_user_id'); $hash=(string)$o->get_meta('_bzj_wow_order_id');
        if (!$wow||!$hash) throw new Exception('Missing product identifiers');
        $existing=$this->db->prepare("SELECT id FROM Wo_Purchases WHERE order_hash_id=? LIMIT 1");
        if ($existing){$existing->bind_param('s',$hash);$existing->execute();$existing->store_result();if($existing->num_rows){$existing->close();return;}$existing->close();}
        $item=current($o->get_items());
        $name=$item?$item->get_name():'Product'; $qty=$item?max(1,(int)$item->get_quantity()):1;
        $owner=(int)$o->get_meta('_bzj_product_owner_id'); $post=(int)$o->get_meta('_bzj_wow_post_id'); $amount=(float)$o->get_total(); $price=$item?(float)$item->get_total():$amount; $now=time();
        $data=wp_json_encode(['name'=>$name,'product_id'=>$post,'units'=>$qty,'currency'=>$o->get_currency(),'timestamp'=>$now]);
        $commission=0.0;
        $st=$this->db->prepare("INSERT INTO Wo_Purchases (user_id,order_hash_id,owner_id,data,final_price,commission,price,timestamp,time) VALUES (?,?,?,?,?,?,?,?,?)");
        if(!$st) throw new Exception($this->db->error);
        $st->bind_param('isssddddd',$wow,$hash,$owner,$data,$amount,$commission,$price,$now,$now);
        if(!$st->execute()) throw new Exception($st->error); $st->close();
        $this->insert_user_order($wow,$hash,$owner,$post,(int)$o->get_meta('_bzj_address_id'),$amount,$qty,$now);
    }
    private function insert_user_order($user,$hash,$owner,$post,$address,$amount,$qty,$now) {
        $st=$this->db->prepare("INSERT INTO Wo_UserOrders (hash_id,user_id,product_owner_id,product_id,address_id,price,commission,final_price,units,status,time) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        if(!$st) throw new Exception($this->db->error);
        $commission=0.0;$status='placed';
        $st->bind_param('siiiiiddssi',$hash,$user,$owner,$post,$address,$amount,$commission,$amount,$qty,$status,$now);
        if(!$st->execute()) throw new Exception($st->error); $st->close();
    }
    private function sync_wallet($o) {
        if (!$this->db) throw new Exception('WoWonder DB unavailable');
        $u=(int)$o->get_meta('_bzj_wow_user_id'); $amt=(float)$o->get_total(); $hash=(string)$o->get_meta('_bzj_wow_order_id');
        $st=$this->db->prepare("SELECT id FROM Wo_Payment_Transactions WHERE userid=? AND order_id=? AND kind='WALLET_CREDIT' LIMIT 1");
        if($st){$st->bind_param('is',$u,$hash);$st->execute();$st->store_result();if($st->num_rows){$st->close();return;}$st->close();}
        $this->db->begin_transaction();
        try {
            $st=$this->db->prepare("UPDATE Wo_Users SET wallet=wallet+? WHERE user_id=? LIMIT 1"); if(!$st)throw new Exception($this->db->error);
            $st->bind_param('di',$amt,$u); if(!$st->execute())throw new Exception($st->error);$st->close();
            $kind='WALLET_CREDIT';$notes='WooCommerce wallet top-up';$status='completed';$currency=$o->get_currency();$woo=$o->get_id();
            $st=$this->db->prepare("INSERT INTO Wo_Payment_Transactions (userid,amount,order_id,kind,currency_code,notes,payment_status,woo_order_id,transaction_dt) VALUES (?,?,?,?,?,?,?,?,NOW())");
            if(!$st)throw new Exception($this->db->error);
            $st->bind_param('idssssii',$u,$amt,$hash,$kind,$currency,$notes,$status,$woo);if(!$st->execute())throw new Exception($st->error);$st->close();
            $this->db->commit();
        } catch(Throwable $e){$this->db->rollback();throw $e;}
    }
    private function sync_donation($o) { $this->sync_transaction($o); }
    private function sync_pro($o) {
        $this->sync_transaction($o);
        if (function_exists('wcs_get_subscriptions_for_order')) {
            $subs=wcs_get_subscriptions_for_order($o->get_id(),['order_type'=>'parent']);
            foreach($subs as $sub){ if($sub->has_status(['pending','on-hold'])) $sub->update_status('active','PGB initial payment completed.'); }
        }
    }
}
