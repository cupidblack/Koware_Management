<?php
if (!defined('ABSPATH')) { exit; }

class PGB_Logger {
    const DEBUG='debug', INFO='info', WARNING='warning', ERROR='error', CRITICAL='critical';
    private $enabled, $min, $dir;
    private $rank=[self::DEBUG=>10,self::INFO=>20,self::WARNING=>30,self::ERROR=>40,self::CRITICAL=>50];
    private $sensitive=['password','pass','secret','token','signature','consumer_key','consumer_secret','api_key','api_secret','authorization','cookie','card','cvv'];

    public function __construct($config) {
        $this->enabled=!empty($config['logging_enabled']);
        $this->min=$config['log_level'] ?? self::INFO;
        $this->dir=dirname(__DIR__).'/log/';
        if ($this->enabled && !is_dir($this->dir)) { @mkdir($this->dir,0755,true); }
    }
    public function log($message,$level=self::INFO,$context=[],$source=__FILE__) {
        if (!$this->enabled || !isset($this->rank[$level]) || $this->rank[$level] < ($this->rank[$this->min]??20)) return;
        $context=$this->redact($context);
        $name=pathinfo(basename($source),PATHINFO_FILENAME);
        $line='['.gmdate('Y-m-d H:i:s').'] ['.strtoupper($level).'] '.$message;
        if ($context) $line.=' | '.wp_json_encode($context);
        $line.="\n";
        @file_put_contents($this->dir.$name.'.log',$line,FILE_APPEND|LOCK_EX);
        if ($level===self::ERROR || $level===self::CRITICAL) error_log('[BZJ-PGB] '.$line);
    }
    private function redact($v) {
        if (!is_array($v)) return $v;
        $out=[];
        foreach ($v as $k=>$x) {
            if (in_array(strtolower((string)$k),$this->sensitive,true)) $out[$k]='[REDACTED]';
            else $out[$k]=is_array($x)?$this->redact($x):$x;
        }
        return $out;
    }
}
