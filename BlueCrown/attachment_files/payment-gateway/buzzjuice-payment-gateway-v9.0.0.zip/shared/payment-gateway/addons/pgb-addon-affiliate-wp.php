<?php
if (!defined('ABSPATH')) { exit; }
/**
 * AffiliateWP adapter. The existing proven bridge function remains the business
 * logic; this adapter lets the new MU engine invoke it without a second MU plugin.
 *
 * Migration: move the existing wow-pgb_sync.php implementation to
 * shared/payment-gateway/integrations/pgb-int-affiliate-wp-legacy.php and retain
 * the function bluecrown_affiliatewp_post_checkout_verification().
 */
add_action('bzj_pgb_payment_fulfilled', function($order) {
    if (!function_exists('bluecrown_affiliatewp_post_checkout_verification')) return;
    try {
        bluecrown_affiliatewp_post_checkout_verification($order->get_id());
    } catch (Throwable $e) {
        PGB_Bootstrap::instance()->logger()->log('AffiliateWP adapter failed',PGB_Logger::ERROR,['order_id'=>$order->get_id(),'error'=>$e->getMessage()],__FILE__);
    }
}, 999, 1);
