#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
OLD="$ROOT/wp-content/plugins/blue-crown-wp/wow-pgb_sync/wow-pgb_sync.php"
NEW="$ROOT/shared/payment-gateway/integrations/pgb-int-affiliate-wp-legacy.php"
if [ ! -f "$OLD" ]; then echo "Old AffiliateWP bridge not found: $OLD" >&2; exit 1; fi
cp "$OLD" "$NEW"
python3 - "$NEW" <<'PY'
from pathlib import Path
p=Path(__import__('sys').argv[1])
s=p.read_text()
if "defined('ABSPATH')" not in s[:1000]:
    s="<?php\nif (!defined('ABSPATH')) { exit; }\n"+s
p.write_text(s)
PY
echo "Copied existing working AffiliateWP bridge to $NEW"
echo "Test WooCommerce completion before deleting $OLD."
