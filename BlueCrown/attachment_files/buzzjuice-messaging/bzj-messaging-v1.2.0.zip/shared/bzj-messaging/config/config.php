<?php
defined('ABSPATH') || exit;

if (!defined('BZJ_MESSAGING_VERSION')) define('BZJ_MESSAGING_VERSION', '1.2.0');
if (!defined('BZJ_MESSAGING_BASE')) define('BZJ_MESSAGING_BASE', dirname(__DIR__));
if (!defined('BZJ_MESSAGING_LOG_DIR')) define('BZJ_MESSAGING_LOG_DIR', BZJ_MESSAGING_BASE . '/logs');
if (!defined('BZJ_MESSAGING_ADDON_DIR')) define('BZJ_MESSAGING_ADDON_DIR', BZJ_MESSAGING_BASE . '/addons');
if (!defined('BZJ_MESSAGING_INT_DIR')) define('BZJ_MESSAGING_INT_DIR', BZJ_MESSAGING_BASE . '/int');

if (!defined('BZJ_MESSAGING_LOG_ENABLED')) define('BZJ_MESSAGING_LOG_ENABLED', true);
if (!defined('BZJ_MESSAGING_LOG_LEVEL')) define('BZJ_MESSAGING_LOG_LEVEL', 'info');

if (!defined('BZJ_MESSAGING_SESSION_TTL')) define('BZJ_MESSAGING_SESSION_TTL', 15 * MINUTE_IN_SECONDS);
if (!defined('BZJ_MESSAGING_SESSION_RENEWAL')) define('BZJ_MESSAGING_SESSION_RENEWAL', 5 * MINUTE_IN_SECONDS);
if (!defined('BZJ_MESSAGING_AUTH_SKEW')) define('BZJ_MESSAGING_AUTH_SKEW', 300);
if (!defined('BZJ_MESSAGING_REQUEST_TTL')) define('BZJ_MESSAGING_REQUEST_TTL', 72 * HOUR_IN_SECONDS);

if (!defined('BZJ_MESSAGING_REALTIME_ENABLED')) define('BZJ_MESSAGING_REALTIME_ENABLED', false);
if (!defined('BZJ_MESSAGING_REALTIME_PROVIDER')) define('BZJ_MESSAGING_REALTIME_PROVIDER', 'polling');

if (!defined('BZJ_MESSAGING_SYNC_BATCH')) define('BZJ_MESSAGING_SYNC_BATCH', 50);
if (!defined('BZJ_MESSAGING_POLL_SECONDS')) define('BZJ_MESSAGING_POLL_SECONDS', 5);

/**
 * Platform credentials are intentionally separate from the existing connection-sync credentials.
 * Prefer constants/environment variables; never place secrets in this file.
 */
function bzj_messaging_secret($platform, $kind) {
    $platform = strtoupper(sanitize_key($platform));
    $kind = strtoupper(sanitize_key($kind));
    $name = 'BZJ_' . $platform . '_CHAT_' . $kind;
    $v = getenv($name);
    if ($v !== false && $v !== '') return (string)$v;
    if (defined($name) && constant($name) !== '') return (string)constant($name);
    return '';
}
