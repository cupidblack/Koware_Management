<?php
/**
 * Buzz Messaging external-platform client.
 * No WordPress functions are required.
 */
if (!class_exists('BZJ_Msg_Client')) {
final class BZJ_Msg_Client {
    private $platform,$base,$key_id,$secret,$log;

    public function __construct($platform,$base_url,$key_id,$secret,$log_file=null) {
        $this->platform=strtolower($platform);
        if (!in_array($this->platform,array('streams','socials'),true)) throw new InvalidArgumentException('Invalid platform.');
        $this->base=rtrim($base_url,'/');
        $this->key_id=(string)$key_id;
        $this->secret=(string)$secret;
        $this->log=$log_file ?: dirname(__FILE__).'/logs/bzj-msg-'.$this->platform.'-client.log';
    }

    private function uuid() {
        if (function_exists('random_bytes')) {
            $d=random_bytes(16); $d[6]=chr((ord($d[6])&15)|64); $d[8]=chr((ord($d[8])&63)|128);
            return vsprintf('%s%s-%s-%s-%s-%s%s%s',str_split(bin2hex($d),4));
        }
        return md5(uniqid('',true));
    }

    private function request($method,$path,$payload=null,$query=array()) {
        $body=$payload===null?'':json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        $ts=time(); $rid=$this->uuid();
        $url=$this->base.$path;
        if ($query) $url.='?'.http_build_query($query);
        $canonical=strtoupper($method)."\n".$path."\n".$ts."\n".$rid."\n".hash('sha256',$body);
        $sig=hash_hmac('sha256',$canonical,$this->secret);
        $headers=array(
            'Content-Type: application/json',
            'X-BZJ-Platform: '.$this->platform,
            'X-BZJ-Key-ID: '.$this->key_id,
            'X-BZJ-Timestamp: '.$ts,
            'X-BZJ-Request-ID: '.$rid,
        );
        $headers[]='X-BZJ-Signature: '.$sig;

        $ch=curl_init($url);
        curl_setopt_array($ch,array(
            CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>strtoupper($method),
            CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>15,CURLOPT_CONNECTTIMEOUT=>5,
            CURLOPT_POSTFIELDS=>$body
        ));
        $raw=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $err=curl_error($ch); curl_close($ch);
        if ($err) throw new RuntimeException($err);
        $data=json_decode((string)$raw,true);
        if (!is_array($data)) throw new RuntimeException('Invalid JSON response (HTTP '.$code.').');
        if ($code<200 || $code>=300) throw new RuntimeException(isset($data['message'])?$data['message']:'Messaging gateway error.');
        return $data;
    }

    public function send($sender_id,$recipient_id,$content,$thread_id=0) {
        return $this->request('POST','/wp-json/bzj-messaging/v1/message',array(
            'sender_id'=>(int)$sender_id,'recipient_id'=>(int)$recipient_id,
            'content'=>(string)$content,'thread_id'=>(int)$thread_id
        ));
    }
    public function accept($request_id,$recipient_id) {
        return $this->request('POST','/wp-json/bzj-messaging/v1/request/accept',array(
            'request_id'=>(int)$request_id,'recipient_id'=>(int)$recipient_id
        ));
    }
    public function decline($request_id,$recipient_id) {
        return $this->request('POST','/wp-json/bzj-messaging/v1/request/decline',array(
            'request_id'=>(int)$request_id,'recipient_id'=>(int)$recipient_id
        ));
    }
    public function sync($user_id,$after_id=0) {
        return $this->request('GET','/wp-json/bzj-messaging/v1/sync',null,array(
            'user_id'=>(int)$user_id,'after_id'=>(int)$after_id
        ));
    }
}
}
