/* Buzz Messaging external UI helper. Transport is deliberately abstract. */
window.BZJMessaging = window.BZJMessaging || {
    config: {pollSeconds:5, realtime:false},
    onEvent: function(event){ document.dispatchEvent(new CustomEvent('bzj:message',{detail:event})); },
    startPolling: function(fetcher){
        var self=this, timer=null, stopped=false, after=0;
        function tick(){
            if(stopped) return;
            fetcher(after).then(function(result){
                (result.events||[]).forEach(function(e){ after=Math.max(after,parseInt(e.id||0,10)); self.onEvent(e); });
            }).catch(function(){});
            timer=setTimeout(tick,(self.config.pollSeconds||5)*1000);
        }
        tick();
        return function(){ stopped=true; if(timer) clearTimeout(timer); };
    }
};
