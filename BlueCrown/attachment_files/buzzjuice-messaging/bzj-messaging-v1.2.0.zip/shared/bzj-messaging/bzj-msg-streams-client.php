<?php
require_once __DIR__.'/bzj-msg-client.php';
function bzj_msg_streams_client($base,$key_id,$secret) {
    return new BZJ_Msg_Client('streams',$base,$key_id,$secret,__DIR__.'/logs/bzj-msg-streams-client.log');
}
