<?php
defined('ABSPATH') || exit;

if (!class_exists('BZJ_Messaging_Gateway')) {
final class BZJ_Messaging_Gateway {

    public function register_routes() {
        register_rest_route('bzj-messaging/v1','/status',array(
            'methods'=>'GET','callback'=>array($this,'status'),'permission_callback'=>'__return_true'
        ));
        register_rest_route('bzj-messaging/v1','/message',array(
            'methods'=>'POST','callback'=>array($this,'message'),'permission_callback'=>'__return_true'
        ));
        register_rest_route('bzj-messaging/v1','/request/create',array(
            'methods'=>'POST','callback'=>array($this,'request_create'),'permission_callback'=>'__return_true'
        ));
        register_rest_route('bzj-messaging/v1','/request/accept',array(
            'methods'=>'POST','callback'=>array($this,'request_accept'),'permission_callback'=>'__return_true'
        ));
        register_rest_route('bzj-messaging/v1','/request/decline',array(
            'methods'=>'POST','callback'=>array($this,'request_decline'),'permission_callback'=>'__return_true'
        ));
        register_rest_route('bzj-messaging/v1','/sync',array(
            'methods'=>'GET','callback'=>array($this,'sync'),'permission_callback'=>'__return_true'
        ));
    }

    private function verify(WP_REST_Request $r, $body='') {
        $platform = strtolower(sanitize_key($r->get_header('X-BZJ-Platform')));
        $key = sanitize_text_field($r->get_header('X-BZJ-Key-ID'));
        $ts = (int)$r->get_header('X-BZJ-Timestamp');
        $sig = strtolower(trim($r->get_header('X-BZJ-Signature')));
        $rid = sanitize_text_field($r->get_header('X-BZJ-Request-ID'));

        if (!in_array($platform,array('streams','socials'),true) || $key==='' || !$ts || $sig==='' || $rid==='') {
            return new WP_Error('auth_missing','Missing messaging authentication headers.',array('status'=>401));
        }
        $expected_key = bzj_messaging_secret($platform,'KEY_ID');
        $secret = bzj_messaging_secret($platform,'SECRET');
        if ($secret==='' || !hash_equals($expected_key,$key)) {
            return new WP_Error('auth_invalid','Invalid messaging credentials.',array('status'=>401));
        }
        if (abs(time()-$ts) > BZJ_MESSAGING_AUTH_SKEW) {
            return new WP_Error('auth_expired','Messaging request expired.',array('status'=>401));
        }
        $canonical = strtoupper($r->get_method())."\n".$r->get_route()."\n".$ts."\n".$rid."\n".hash('sha256',$body);
        $calc = hash_hmac('sha256',$canonical,$secret);
        if (!hash_equals($calc,$sig)) {
            return new WP_Error('auth_signature','Invalid messaging signature.',array('status'=>401));
        }

        $replay_key = 'bzj_msg_replay_' . hash('sha256',$platform.'|'.$rid);
        if (get_transient($replay_key)) {
            return new WP_Error('auth_replay','Duplicate messaging request.',array('status'=>409));
        }
        set_transient($replay_key,1,BZJ_MESSAGING_AUTH_SKEW);
        return array('platform'=>$platform,'request_id'=>$rid);
    }

    private function identity($platform,$external_id) {
        $external_id=absint($external_id);
        if (!$external_id) return 0;
        $meta = $platform==='streams' ? 'wo_user_id' : 'qd_user_id';
        $users = get_users(array('meta_key'=>$meta,'meta_value'=>$external_id,'fields'=>'ID','number'=>1));
        return !empty($users) ? absint($users[0]) : 0;
    }

    public function status() {
        return rest_ensure_response(array(
            'status'=>'ok','version'=>BZJ_MESSAGING_VERSION,
            'realtime'=>array('enabled'=>BZJ_MESSAGING_REALTIME_ENABLED,'provider'=>BZJ_MESSAGING_REALTIME_PROVIDER)
        ));
    }

    public function message(WP_REST_Request $r) {
        $body=$r->get_body(); $auth=$this->verify($r,$body); if (is_wp_error($auth)) return $auth;
        $p=json_decode($body,true); if (!is_array($p)) return new WP_Error('bad_json','Invalid JSON.',array('status'=>400));
        $sender=$this->identity($auth['platform'],$p['sender_id']??0);
        $recipient=$this->identity($auth['platform'],$p['recipient_id']??0);
        if (!$sender || !$recipient) return new WP_Error('identity_not_found','User mapping not found.',array('status'=>404));
        $thread=absint($p['thread_id']??0);
        $policy = BZJ_Messaging_Policy::can_start($sender,$recipient);
        if (is_wp_error($policy)) return $policy;

        if (!$thread) {
            if (!empty($policy['request_required'])) {
                $req = BZJ_Messaging_Requests::create(array(
                    'initiator_wp_id'=>$sender,'recipient_wp_id'=>$recipient,
                    'initiator_platform'=>$auth['platform'],'recipient_platform'=>$auth['platform'],
                    'initiator_external_id'=>absint($p['sender_id']),
                    'recipient_external_id'=>absint($p['recipient_id']),
                    'message'=>sanitize_textarea_field($p['content']??'')
                ));
                if (is_wp_error($req)) return $req;
                return rest_ensure_response(array('success'=>true,'state'=>'request_pending','request_id'=>$req['request_id']));
            }
        }

        if ($thread) {
            $allowed=BZJ_Messaging_Policy::can_send($sender,$thread);
            if (is_wp_error($allowed)) return $allowed;
        }

        $result=BZJ_Messaging_Adapter::instance()->send($sender,$recipient,(string)($p['content']??''),$thread,array(
            'origin'=>$auth['platform'],'external_sender_id'=>absint($p['sender_id'])
        ));
        if (is_wp_error($result)) return $result;
        return rest_ensure_response(array('success'=>true,'state'=>'sent')+$result);
    }

    public function request_create(WP_REST_Request $r) {
        return $this->message($r);
    }

    public function request_accept(WP_REST_Request $r) {
        $body=$r->get_body(); $auth=$this->verify($r,$body); if (is_wp_error($auth)) return $auth;
        $p=json_decode($body,true); $recipient=$this->identity($auth['platform'],$p['recipient_id']??0);
        if (!$recipient) return new WP_Error('identity_not_found','User mapping not found.',array('status'=>404));
        $result=BZJ_Messaging_Requests::accept(absint($p['request_id']??0),$recipient);
        if (is_wp_error($result)) return $result;
        return rest_ensure_response(array('success'=>true)+$result);
    }

    public function request_decline(WP_REST_Request $r) {
        $body=$r->get_body(); $auth=$this->verify($r,$body); if (is_wp_error($auth)) return $auth;
        $p=json_decode($body,true); $recipient=$this->identity($auth['platform'],$p['recipient_id']??0);
        if (!$recipient) return new WP_Error('identity_not_found','User mapping not found.',array('status'=>404));
        $result=BZJ_Messaging_Requests::decline(absint($p['request_id']??0),$recipient);
        if (is_wp_error($result)) return $result;
        return rest_ensure_response(array('success'=>true)+$result);
    }

    public function sync(WP_REST_Request $r) {
        $auth=$this->verify($r,''); if (is_wp_error($auth)) return $auth;
        $uid=$this->identity($auth['platform'],$r->get_param('user_id'));
        if (!$uid) return new WP_Error('identity_not_found','User mapping not found.',array('status'=>404));
        $after=absint($r->get_param('after_id'));
        $rows=BZJ_Messaging_Dispatch::pending_for_user($uid,$after);
        $events=array();
        foreach($rows as $row) {
            $payload=json_decode($row->payload,true);
            if (is_array($payload)) $events[]=array('id'=>(int)$row->id,'uuid'=>$row->event_uuid,'type'=>$row->event_type,'data'=>$payload,'created_at'=>$row->created_at);
        }
        return rest_ensure_response(array('success'=>true,'events'=>$events,'next_after_id'=>!empty($rows)?(int)end($rows)->id:$after));
    }
}
}
