<?php
defined('ABSPATH') || exit;

if (!class_exists('BZJ_Messaging_Dispatch')) {
final class BZJ_Messaging_Dispatch {

    public static function on_message_sent($message) {
        if (!is_object($message)) return;
        $thread = absint($message->thread_id ?? 0);
        $sender = absint($message->sender_id ?? 0);
        if (!$thread || !$sender) return;

        $recipients = BZJ_Messaging_Adapter::instance()->recipients($thread);
        $payload = array(
            'event'=>'message_created',
            'message_id'=>absint($message->id ?? 0),
            'thread_id'=>$thread,
            'sender_wp_id'=>$sender,
            'recipient_wp_ids'=>$recipients,
            'content'=>(string)($message->message ?? ''),
            'created_at'=>(string)($message->date_sent ?? gmdate('Y-m-d H:i:s')),
        );
        do_action('bzj_messaging_external_event', $payload);
        self::queue($payload);
    }

    public static function queue($payload) {
        global $wpdb;
        $table = $wpdb->prefix . 'bzj_messaging_events';
        $wpdb->insert($table,array(
            'event_uuid'=>wp_generate_uuid4(),
            'event_type'=>'message_created',
            'payload'=>wp_json_encode($payload),
            'target_platforms'=>'streams,socials',
            'status'=>'pending',
            'attempts'=>0,
            'max_attempts'=>3,
            'next_attempt_at'=>gmdate('Y-m-d H:i:s'),
        ));
    }

    public static function pending_for_user($wp_user_id, $after_id=0) {
        global $wpdb;
        $table = $wpdb->prefix . 'bzj_messaging_events';
        $like = '%"'.$wpdb->esc_like((string)absint($wp_user_id)).'"%';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT id,event_uuid,event_type,payload,created_at
             FROM {$table}
             WHERE id>%d AND status IN ('pending','delivered')
             AND payload LIKE %s
             ORDER BY id ASC LIMIT %d",
            absint($after_id), $like, BZJ_MESSAGING_SYNC_BATCH
        ));
    }
}
}
