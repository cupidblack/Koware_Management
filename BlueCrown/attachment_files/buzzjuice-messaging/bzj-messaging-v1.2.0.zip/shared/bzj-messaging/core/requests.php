<?php
defined('ABSPATH') || exit;

if (!class_exists('BZJ_Messaging_Requests')) {
final class BZJ_Messaging_Requests {

    public static function table() { global $wpdb; return $wpdb->prefix . 'bzj_chat_requests'; }

    public static function create($data) {
        global $wpdb;
        $a = absint($data['initiator_wp_id'] ?? 0);
        $b = absint($data['recipient_wp_id'] ?? 0);
        if (!$a || !$b || $a === $b) return new WP_Error('invalid_users','Invalid participants.',array('status'=>400));

        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM ".self::table()."
             WHERE status='pending'
             AND ((initiator_wp_id=%d AND recipient_wp_id=%d)
               OR (initiator_wp_id=%d AND recipient_wp_id=%d))
             ORDER BY id DESC LIMIT 1",
            $a,$b,$b,$a
        ));
        if ($existing) return array('request_id'=>(int)$existing->id, 'status'=>'pending');

        $ok = $wpdb->insert(self::table(), array(
            'initiator_wp_id'=>$a,
            'initiator_platform'=>sanitize_key($data['initiator_platform']),
            'initiator_external_id'=>absint($data['initiator_external_id']),
            'recipient_wp_id'=>$b,
            'recipient_platform'=>sanitize_key($data['recipient_platform']),
            'recipient_external_id'=>absint($data['recipient_external_id']),
            'status'=>'pending',
            'message'=>wp_strip_all_tags((string)($data['message'] ?? '')),
            'expires_at'=>gmdate('Y-m-d H:i:s', time()+BZJ_MESSAGING_REQUEST_TTL),
        ));
        if (!$ok) return new WP_Error('request_create_failed','Could not create chat request.',array('status'=>500));
        $id = (int)$wpdb->insert_id;
        do_action('bzj_messaging_chat_request_created', $id, $data);
        return array('request_id'=>$id, 'status'=>'pending');
    }

    public static function get($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table()." WHERE id=%d LIMIT 1",$id));
    }

    public static function accept($id, $recipient_wp_id) {
        global $wpdb;
        $r = self::get($id);
        if (!$r || (int)$r->recipient_wp_id !== (int)$recipient_wp_id) {
            return new WP_Error('request_not_found','Chat request not found.',array('status'=>404));
        }
        if ($r->status !== 'pending' || strtotime($r->expires_at) < time()) {
            return new WP_Error('request_not_pending','Chat request is no longer pending.',array('status'=>409));
        }
        $policy = BZJ_Messaging_Policy::can_start((int)$r->initiator_wp_id,(int)$r->recipient_wp_id);
        if (is_wp_error($policy)) return $policy;

        $adapter = BZJ_Messaging_Adapter::instance();
        $thread_id = $adapter->create_thread(array((int)$r->initiator_wp_id,(int)$r->recipient_wp_id));
        if (is_wp_error($thread_id)) return $thread_id;

        $updated = $wpdb->update(self::table(), array(
            'status'=>'accepted','thread_id'=>(int)$thread_id,'accepted_at'=>gmdate('Y-m-d H:i:s')
        ), array('id'=>$id), array('%s','%d','%s'), array('%d'));
        if (!$updated) return new WP_Error('request_accept_failed','Could not accept chat request.',array('status'=>500));

        do_action('bzj_messaging_chat_request_accepted', $r, (int)$thread_id);
        return array('request_id'=>(int)$id,'thread_id'=>(int)$thread_id,'status'=>'accepted');
    }

    public static function decline($id, $recipient_wp_id) {
        global $wpdb;
        $r = self::get($id);
        if (!$r || (int)$r->recipient_wp_id !== (int)$recipient_wp_id) {
            return new WP_Error('request_not_found','Chat request not found.',array('status'=>404));
        }
        $ok = $wpdb->update(self::table(), array(
            'status'=>'declined','declined_at'=>gmdate('Y-m-d H:i:s')
        ), array('id'=>$id,'status'=>'pending'), array('%s','%s'), array('%d','%s'));
        if (!$ok) return new WP_Error('request_decline_failed','Could not decline request.',array('status'=>409));
        do_action('bzj_messaging_chat_request_declined', $r);
        return array('request_id'=>(int)$id,'status'=>'declined');
    }
}
}
