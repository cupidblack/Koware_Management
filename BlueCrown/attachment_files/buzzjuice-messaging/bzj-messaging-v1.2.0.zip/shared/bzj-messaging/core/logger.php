<?php
defined('ABSPATH') || exit;

if (!function_exists('bzj_messaging_log')) {
    function bzj_messaging_log($message, $context = array(), $level = 'info') {
        if (!BZJ_MESSAGING_LOG_ENABLED) return;
        $levels = array('debug'=>0,'info'=>1,'warning'=>2,'error'=>3);
        $wanted = $levels[strtolower((string)BZJ_MESSAGING_LOG_LEVEL)] ?? 1;
        $current = $levels[strtolower((string)$level)] ?? 1;
        if ($current < $wanted) return;

        if (!is_array($context)) $context = array('value'=>$context);
        $redact = function($value) use (&$redact) {
            if (is_array($value)) {
                $out = array();
                foreach ($value as $k=>$v) {
                    $lk = strtolower((string)$k);
                    $out[$k] = in_array($lk, array('secret','signature','token','session_token','authorization','cookie','password'), true)
                        ? '[REDACTED]' : $redact($v);
                }
                return $out;
            }
            return $value;
        };
        $entry = array(
            'time'=>gmdate('c'),
            'level'=>strtoupper($level),
            'request_id'=>function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : uniqid(),
            'message'=>(string)$message,
            'context'=>$redact($context),
        );
        if (!is_dir(BZJ_MESSAGING_LOG_DIR)) wp_mkdir_p(BZJ_MESSAGING_LOG_DIR);
        @file_put_contents(
            BZJ_MESSAGING_LOG_DIR . '/bzj-messaging.log',
            wp_json_encode($entry, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . PHP_EOL,
            FILE_APPEND|LOCK_EX
        );
    }
}
