<?php
defined('ABSPATH') || exit;

if (!class_exists('BZJ_Messaging_Adapter')) {
final class BZJ_Messaging_Adapter {

    private static $instance;
    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    public function create_thread($users) {
        if (!function_exists('Better_Messages')) return new WP_Error('bm_missing','BP Better Messages is not active.',array('status'=>503));
        $users = array_values(array_unique(array_filter(array_map('absint',(array)$users))));
        if (count($users) < 2) return new WP_Error('invalid_participants','At least two participants are required.',array('status'=>400));

        $id = Better_Messages()->functions->create_new_conversation($users, '');
        if (is_wp_error($id)) return $id;
        return absint($id);
    }

    public function send($sender, $recipient, $content, $thread_id=0, $meta=array()) {
        if (!function_exists('Better_Messages')) return new WP_Error('bm_missing','BP Better Messages is not active.',array('status'=>503));
        $args = array(
            'sender_id'=>absint($sender),
            'content'=>wp_kses_post($content),
            'return'=>'message_id',
            'error_type'=>'wp_error',
        );
        if ($thread_id) $args['thread_id']=absint($thread_id);
        else $args['recipients']=array(absint($recipient));

        $id = Better_Messages()->functions->new_message($args);
        if (is_wp_error($id)) return $id;
        $id = absint($id);

        if ($id && $meta) {
            foreach ($meta as $k=>$v) {
                Better_Messages()->functions->update_message_meta($id, 'bzj_'.$k, maybe_serialize($v));
            }
        }
        return array('message_id'=>$id,'thread_id'=>$thread_id ?: $this->message_thread($id));
    }

    public function message_thread($message_id) {
        if (!function_exists('Better_Messages')) return 0;
        $m = Better_Messages()->functions->get_message(absint($message_id));
        return $m ? absint($m->thread_id) : 0;
    }

    public function message($message_id) {
        return function_exists('Better_Messages') ? Better_Messages()->functions->get_message(absint($message_id)) : null;
    }

    public function recipients($thread_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'bpbm_recipients';
        return array_map('absint',(array)$wpdb->get_col($wpdb->prepare(
            "SELECT user_id FROM {$table} WHERE thread_id=%d",absint($thread_id)
        )));
    }
}
}
