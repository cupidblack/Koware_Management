<?php
defined('ABSPATH') || exit;

if (!class_exists('BZJ_Messaging_Policy')) {
final class BZJ_Messaging_Policy {

    public static function pair_blocked($a, $b) {
        global $wpdb;
        $table = $wpdb->prefix . 'bzj_relationships';
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT relationship_state, blocked_a, blocked_b
             FROM {$table}
             WHERE user_a=%d AND user_b=%d
             LIMIT 1",
            min($a,$b), max($a,$b)
        ));
        if (!$row) return false;
        return strtolower((string)$row->relationship_state) === 'blocked'
            || !empty($row->blocked_a) || !empty($row->blocked_b);
    }

    public static function connected($a, $b) {
        global $wpdb;
        $table = $wpdb->prefix . 'bzj_relationships';
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT relationship_state
             FROM {$table}
             WHERE user_a=%d AND user_b=%d
             LIMIT 1",
            min($a,$b), max($a,$b)
        ));
        return $row && strtolower((string)$row->relationship_state) === 'connected';
    }

    /**
     * Phase 1 deliberately does not implement Palmier/myCRED charging.
     * It returns a policy object so a later credit addon can authorize a per-message charge.
     */
    public static function can_start($sender, $recipient) {
        if ($sender < 1 || $recipient < 1 || $sender === $recipient) {
            return new WP_Error('invalid_users', 'Invalid messaging participants.', array('status'=>400));
        }
        if (self::pair_blocked($sender, $recipient)) {
            return new WP_Error('messaging_blocked', 'Messaging is unavailable between these users.', array('status'=>403));
        }
        if (self::connected($sender, $recipient)) {
            return array('allowed'=>true, 'connected'=>true, 'request_required'=>false, 'charge'=>0);
        }
        return array(
            'allowed'=>true,
            'connected'=>false,
            'request_required'=>true,
            'charge'=>0,
            'reason'=>'first_contact_request'
        );
    }

    public static function can_send($sender, $thread_id) {
        global $wpdb;
        $thread_id = absint($thread_id);
        if (!$thread_id) return new WP_Error('invalid_thread', 'Invalid conversation.', array('status'=>400));

        $recipients_table = $wpdb->prefix . 'bpbm_recipients';
        $participants = $wpdb->get_col($wpdb->prepare(
            "SELECT user_id FROM {$recipients_table} WHERE thread_id=%d",
            $thread_id
        ));
        $participants = array_values(array_unique(array_map('absint', (array)$participants)));
        if (!in_array((int)$sender, $participants, true)) {
            return new WP_Error('not_participant', 'You are not a participant in this conversation.', array('status'=>403));
        }

        foreach ($participants as $other) {
            if ($other === (int)$sender) continue;
            if (self::pair_blocked($sender, $other)) {
                return new WP_Error('messaging_blocked', 'Messaging is unavailable between these users.', array('status'=>403));
            }
            if (self::connected($sender, $other)) continue;

            global $wpdb;
            $req_table = $wpdb->prefix . 'bzj_chat_requests';
            $accepted = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$req_table}
                 WHERE status='accepted'
                 AND ((initiator_wp_id=%d AND recipient_wp_id=%d)
                   OR (initiator_wp_id=%d AND recipient_wp_id=%d))
                 ORDER BY id DESC LIMIT 1",
                $sender,$other,$other,$sender
            ));
            if (!$accepted) {
                return new WP_Error('chat_not_accepted', 'This chat request has not been accepted.', array('status'=>403));
            }
        }
        return true;
    }
}
}
