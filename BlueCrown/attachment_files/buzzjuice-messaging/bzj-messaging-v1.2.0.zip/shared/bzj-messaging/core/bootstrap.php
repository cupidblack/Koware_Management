<?php
defined('ABSPATH') || exit;

if (!class_exists('BZJ_Messaging_Bootstrap')) {
final class BZJ_Messaging_Bootstrap {
    private static $ready=false;
    public static function init() {
        if (self::$ready) return;
        self::$ready=true;

        if (!function_exists('Better_Messages')) {
            add_action('plugins_loaded',array(__CLASS__,'late_init'),99);
            return;
        }
        self::wire();
    }
    public static function late_init() { if (function_exists('Better_Messages')) self::wire(); }

    private static function wire() {
        self::tables();
        add_action('rest_api_init',array('BZJ_Messaging_Bootstrap','routes'));
        add_filter('better_messages_can_send_message',array('BZJ_Messaging_Bootstrap','can_send'),10,3);
        add_action('better_messages_message_sent',array('BZJ_Messaging_Dispatch','on_message_sent'),10,1);
        add_action('bzj_messaging_chat_request_created',array(__CLASS__,'notify_request'),10,2);
        add_action('bzj_messaging_chat_request_accepted',array(__CLASS__,'request_accepted'),10,2);
        self::load_modules();
        do_action('bzj_messaging_ready');
        bzj_messaging_log('Buzz Messaging initialized',array('version'=>BZJ_MESSAGING_VERSION));
    }

    public static function routes() { (new BZJ_Messaging_Gateway())->register_routes(); }

    public static function can_send($allowed,$user_id,$thread_id) {
        if (!$allowed) return false;
        $check=BZJ_Messaging_Policy::can_send(absint($user_id),absint($thread_id));
        if (is_wp_error($check)) {
            global $bp_better_messages_restrict_send_message;
            if (!is_array($bp_better_messages_restrict_send_message)) $bp_better_messages_restrict_send_message=array();
            $bp_better_messages_restrict_send_message['bzj_messaging']=$check->get_error_message();
            return false;
        }
        return true;
    }

    private static function notify_request($request_id,$data) {
        $r=BZJ_Messaging_Requests::get($request_id);
        if (!$r) return;
        if (function_exists('bp_core_add_notification')) {
            // BuddyBoss/BuddyPress notification is intentionally optional.
            do_action('bzj_messaging_notify_user',(int)$r->recipient_wp_id,(int)$request_id);
        }
    }

    private static function request_accepted($request,$thread_id) {
        // The recipient has accepted. External clients learn the thread through their normal signed sync cycle.
        do_action('bzj_messaging_thread_unlocked',$request,$thread_id);
    }

    private static function tables() {
        global $wpdb;
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $c=$wpdb->get_charset_collate();
        $sql=array(
        "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}bzj_chat_requests (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            initiator_wp_id BIGINT UNSIGNED NOT NULL,
            initiator_platform VARCHAR(20) NOT NULL,
            initiator_external_id BIGINT UNSIGNED NOT NULL,
            recipient_wp_id BIGINT UNSIGNED NOT NULL,
            recipient_platform VARCHAR(20) NOT NULL,
            recipient_external_id BIGINT UNSIGNED NOT NULL,
            thread_id BIGINT UNSIGNED NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            message LONGTEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP NOT NULL,
            accepted_at TIMESTAMP NULL,
            declined_at TIMESTAMP NULL,
            cancelled_at TIMESTAMP NULL,
            PRIMARY KEY(id),
            KEY initiator_wp_id(initiator_wp_id),
            KEY recipient_wp_id(recipient_wp_id),
            KEY status(status),
            KEY expires_at(expires_at)
        ) {$c};",
        "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}bzj_messaging_events (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            event_uuid VARCHAR(36) NOT NULL,
            event_type VARCHAR(50) NOT NULL,
            payload LONGTEXT NOT NULL,
            target_platforms VARCHAR(255) NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            attempts INT UNSIGNED NOT NULL DEFAULT 0,
            max_attempts INT UNSIGNED NOT NULL DEFAULT 3,
            next_attempt_at TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP NULL,
            PRIMARY KEY(id),
            UNIQUE KEY event_uuid(event_uuid),
            KEY status(status),
            KEY created_at(created_at)
        ) {$c};"
        );
        foreach($sql as $q) dbDelta($q);
    }

    private static function load_modules() {
        foreach (glob(BZJ_MESSAGING_ADDON_DIR.'/bzj-msg-addon-*.php') ?: array() as $file) require_once $file;
        foreach (glob(BZJ_MESSAGING_INT_DIR.'/bzj-msg-int-*.php') ?: array() as $file) require_once $file;
    }
}
BZJ_Messaging_Bootstrap::init();
}
