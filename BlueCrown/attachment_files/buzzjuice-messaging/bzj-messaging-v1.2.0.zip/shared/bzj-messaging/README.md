# Buzzjuice Unified Messaging v1.2.0

## Architecture
- WordPress + BP Better Messages is the canonical message store.
- Streams and Socials never write to Better Messages tables.
- Streams/Socials communicate with WordPress over HTTPS using per-platform HMAC credentials.
- Existing `wo_user_id` and `qd_user_id` WordPress usermeta remain the identity source of truth.
- Existing `bzj_relationships` remains the connection source of truth.
- First contact creates a Buzz chat request; it does **not** create an empty Better Messages thread.
- Accept creates the Better Messages conversation.
- Accepted conversations can then send messages through the canonical store.
- Group-chat and credit/minting rules are intentionally addon/policy work, not hard-coded into v1.

## Important corrections from the earlier draft
1. Bootstrap happens early enough for `rest_api_init` and Better Messages hooks. The previous `wp_loaded`-only initialization could leave REST routes unregistered.
2. `better_messages_message_sent` is the documented post-save event used for outbound synchronization.
3. `better_messages_can_send_message` is the server-side enforcement point; JavaScript is never trusted for authorization.
4. No direct Better Messages database writes are used for messages or threads; public Better Messages functions are used.
5. External identity resolves through existing `wo_user_id` / `qd_user_id` mappings instead of introducing a second authoritative identity ledger.
6. Replay protection uses a request ID + short WordPress transient.
7. Logging can be disabled globally and secrets/tokens/signatures are redacted.
8. Real-time transport is feature-flagged and can be added later without changing the canonical message model.

## Credentials
Set these outside this package:
- `BZJ_STREAMS_CHAT_KEY_ID`
- `BZJ_STREAMS_CHAT_SECRET`
- `BZJ_SOCIALS_CHAT_KEY_ID`
- `BZJ_SOCIALS_CHAT_SECRET`

Do not reuse the existing connection-sync secret.

## Installation
1. Back up WordPress and the three messaging systems.
2. Copy `wp-content/mu-plugins/bzj-messaging.php`.
3. Copy `shared/bzj-messaging/`.
4. Configure the four credentials in the server environment/constants.
5. Ensure BP Better Messages is active.
6. Verify `/wp-json/bzj-messaging/v1/status`.
7. Only after WordPress tests pass, include the appropriate client in Streams/Socials.
8. Adapt the existing chat send/accept/decline handlers to call the client. Do not reuse their existing message APIs as the integration transport.

## Suggested test order
A. WordPress bootstrap/logging.
B. HMAC status request.
C. Identity resolution.
D. First-contact request.
E. Accept/decline.
F. Message creation and BM display.
G. WP-originated message event.
H. Streams/Socials sync notification.
I. Block/connection enforcement.
J. Failure/retry handling.
K. Real-time Node transport.

## Not yet enabled
- Palmier/myCRED per-message charging.
- Minting/rewards.
- Group-chat restriction semantics.
- Media/sticker/GIF/voice/video/call addons.
- Node.js real-time transport.

These should be implemented behind policy/transport interfaces after the basic 1:1 path is stable.
