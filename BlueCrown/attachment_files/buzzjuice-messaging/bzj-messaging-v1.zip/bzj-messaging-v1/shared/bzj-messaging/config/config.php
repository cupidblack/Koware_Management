<?php
defined('ABSPATH') || exit;
if (!defined('BZJ_MSG_NS')) define('BZJ_MSG_NS', 'bzj/v1');
if (!defined('BZJ_MSG_AUTH_WINDOW')) define('BZJ_MSG_AUTH_WINDOW', 300);
if (!defined('BZJ_MSG_SESSION_TTL')) define('BZJ_MSG_SESSION_TTL', 900); // 15 min, silently renewable.
if (!defined('BZJ_MSG_POLL_LIMIT')) define('BZJ_MSG_POLL_LIMIT', 50);
if (!defined('BZJ_MSG_LOG_LIMIT')) define('BZJ_MSG_LOG_LIMIT', 2000);

function bzj_msg_env($name, $default = '') {
    $v = getenv($name);
    if ($v !== false && $v !== '') return (string) $v;
    if (defined($name) && constant($name) !== '') return (string) constant($name);
    return (string) $default;
}
function bzj_msg_secret($platform) {
    $platform = strtolower((string) $platform);
    return bzj_msg_env($platform === 'streams' ? 'BZJ_STREAMS_CHAT_SECRET' : 'BZJ_SOCIALS_CHAT_SECRET');
}
function bzj_msg_key_id($platform) {
    $platform = strtolower((string) $platform);
    return bzj_msg_env($platform === 'streams' ? 'BZJ_STREAMS_CHAT_KEY_ID' : 'BZJ_SOCIALS_CHAT_KEY_ID');
}
