<?php
defined('ABSPATH') || exit;

final class BZJ_Messaging_Requests {
    public static function ensure_schema() {
        global $wpdb; $t=bzj_msg_tables()['requests']; $c=$wpdb->get_charset_collate(); require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta("CREATE TABLE {$t} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            request_uuid char(36) NOT NULL,
            actor_wp_id bigint(20) unsigned NOT NULL,
            recipient_wp_id bigint(20) unsigned NOT NULL,
            thread_id bigint(20) unsigned NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'pending',
            reason varchar(50) NOT NULL DEFAULT '',
            created_at datetime NOT NULL,
            expires_at datetime NULL,
            responded_at datetime NULL,
            response_by bigint(20) unsigned NOT NULL DEFAULT 0,
            PRIMARY KEY(id), UNIQUE KEY request_uuid(request_uuid),
            KEY recipient_status(recipient_wp_id,status), KEY actor_recipient(actor_wp_id,recipient_wp_id,status)
        ) {$c};");
    }
    public static function create($actor,$recipient,$thread_id,$reason='first_contact') {
        global $wpdb; $t=bzj_msg_tables()['requests'];
        $existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE actor_wp_id=%d AND recipient_wp_id=%d AND status='pending' ORDER BY id DESC LIMIT 1",$actor,$recipient),ARRAY_A);
        if($existing) return $existing;
        $uuid=bzj_msg_uuid(); $now=gmdate('Y-m-d H:i:s'); $exp=gmdate('Y-m-d H:i:s',time()+7*DAY_IN_SECONDS);
        $wpdb->insert($t,array('request_uuid'=>$uuid,'actor_wp_id'=>absint($actor),'recipient_wp_id'=>absint($recipient),'thread_id'=>absint($thread_id),'status'=>'pending','reason'=>sanitize_key($reason),'created_at'=>$now,'expires_at'=>$exp));
        self::notify($recipient,$actor,$thread_id,$uuid);
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE request_uuid=%s",$uuid),ARRAY_A);
    }
    public static function respond($uuid,$recipient,$accept) {
        global $wpdb; $t=bzj_msg_tables()['requests'];
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE request_uuid=%s LIMIT 1",sanitize_text_field($uuid)),ARRAY_A);
        if(!$r) return bzj_msg_error('bzj_request_not_found','Chat request not found.',404);
        if((int)$r['recipient_wp_id']!==absint($recipient)) return bzj_msg_error('bzj_request_owner','You cannot respond to this request.',403);
        if($r['status']!=='pending') return $r;
        $status=$accept?'accepted':'declined';
        $wpdb->update($t,array('status'=>$status,'responded_at'=>gmdate('Y-m-d H:i:s'),'response_by'=>absint($recipient)),array('id'=>(int)$r['id']));
        if($accept) {
            self::accept_connection((int)$r['actor_wp_id'],absint($recipient));
        }
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id=%d",(int)$r['id']),ARRAY_A);
    }
    private static function accept_connection($requester,$acceptor) {
        if(function_exists('friends_add_friend') && function_exists('friends_get_friendship_id') && function_exists('friends_accept_friendship')) {
            $status=function_exists('friends_check_friendship_status') ? friends_check_friendship_status($requester,$acceptor) : '';
            if($status!=='is_friend') {
                if($status!=='pending') friends_add_friend($requester,$acceptor);
                $fid=(int)friends_get_friendship_id($requester,$acceptor);
                if($fid) friends_accept_friendship($fid);
            }
        }
    }
    private static function notify($recipient,$actor,$thread,$uuid) {
        $payload=array('type'=>'chat_request','request_uuid'=>$uuid,'recipient_wp_id'=>$recipient,'actor_wp_id'=>$actor,'thread_id'=>$thread);
        do_action('bzj_messaging_chat_request_created',$payload);
        bzj_msg_log('Chat request created',array('request_uuid'=>$uuid,'actor_wp_id'=>$actor,'recipient_wp_id'=>$recipient,'thread_id'=>$thread));
    }
}
