<?php
defined('ABSPATH') || exit;

final class BZJ_Messaging_Sessions {
    public static function ensure_schema() {
        global $wpdb; $t=bzj_msg_tables()['sessions'];
        $c=$wpdb->get_charset_collate();
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta("CREATE TABLE {$t} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            token_hash char(64) NOT NULL,
            platform varchar(20) NOT NULL,
            wp_user_id bigint(20) unsigned NOT NULL,
            external_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            expires_at datetime NOT NULL,
            last_seen_at datetime NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY token_hash(token_hash),
            KEY platform_user(platform,wp_user_id), KEY expires_at(expires_at)
        ) {$c};");
    }
    public static function issue($platform, $wp_user_id, $external_id=0) {
        global $wpdb; $t=bzj_msg_tables()['sessions'];
        $token=bin2hex(random_bytes(32)); $now=time(); $exp=$now+BZJ_MSG_SESSION_TTL;
        $wpdb->insert($t,array('token_hash'=>hash('sha256',$token),'platform'=>sanitize_key($platform),'wp_user_id'=>absint($wp_user_id),'external_user_id'=>absint($external_id),'expires_at'=>gmdate('Y-m-d H:i:s',$exp),'last_seen_at'=>gmdate('Y-m-d H:i:s',$now),'created_at'=>gmdate('Y-m-d H:i:s',$now)));
        return array('token'=>$token,'expires_at'=>gmdate('c',$exp),'ttl'=>BZJ_MSG_SESSION_TTL);
    }
    public static function touch($token) {
        global $wpdb; $t=bzj_msg_tables()['sessions']; $h=hash('sha256',(string)$token);
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE token_hash=%s LIMIT 1",$h),ARRAY_A);
        if(!$row || strtotime($row['expires_at'])<time()) return new WP_Error('bzj_session_expired','Messaging session expired.',array('status'=>401));
        $exp=time()+BZJ_MSG_SESSION_TTL; $wpdb->update($t,array('expires_at'=>gmdate('Y-m-d H:i:s',$exp),'last_seen_at'=>gmdate('Y-m-d H:i:s')),array('id'=>(int)$row['id']));
        $row['expires_at']=gmdate('Y-m-d H:i:s',$exp); return $row;
    }
}
