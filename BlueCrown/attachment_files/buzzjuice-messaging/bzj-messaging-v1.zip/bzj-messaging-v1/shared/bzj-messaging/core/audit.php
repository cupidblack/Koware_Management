<?php
defined('ABSPATH') || exit;

function bzj_msg_log($message, $context = array(), $file = 'bzj-messaging.log') {
    $dir = BZJ_MESSAGING_DIR . 'logs/';
    if (!is_dir($dir)) wp_mkdir_p($dir);
    if (!is_dir($dir) || !is_writable($dir)) return;
    $safe = is_array($context) ? $context : array('value' => (string) $context);
    unset($safe['authorization'], $safe['cookie'], $safe['token'], $safe['jwt'], $safe['secret'], $safe['signature']);
    @file_put_contents($dir . basename($file), bzj_msg_json(array(
        'time' => gmdate('c'), 'message' => (string) $message, 'context' => $safe
    )) . PHP_EOL, FILE_APPEND | LOCK_EX);
}
