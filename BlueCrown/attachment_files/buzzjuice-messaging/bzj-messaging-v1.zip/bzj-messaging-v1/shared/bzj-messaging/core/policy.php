<?php
defined('ABSPATH') || exit;

final class BZJ_Messaging_Policy {
    public static function level($wp_user_id) {
        // Deliberately neutral default. A future LearnDash addon should implement this filter.
        $level = (int) apply_filters('bzj_messaging_user_level', 0, absint($wp_user_id));
        return max(0, $level);
    }
    public static function relationship($a,$b) {
        global $wpdb; $t=$wpdb->prefix.'bzj_relationships';
        $p=array(min(absint($a),absint($b)),max(absint($a),absint($b)));
        $exists=$wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$t));
        if(!$exists) return array('state'=>'unknown','blocked'=>false);
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE user_a=%d AND user_b=%d LIMIT 1",$p[0],$p[1]),ARRAY_A);
        if(!$r) return array('state'=>'none','blocked'=>false);
        $blocked=!empty($r['block_a_to_b']) || !empty($r['block_b_to_a']);
        return array('state'=>(string)($r['connection_state']??'none'),'blocked'=>$blocked,'row'=>$r);
    }
    public static function access($actor,$recipient,$thread_id=0,$is_group=false) {
        $actor=absint($actor); $recipient=absint($recipient);
        $rel=self::relationship($actor,$recipient);
        if(!empty($rel['blocked'])) return array('allowed'=>false,'reason'=>'blocked','cost'=>0);
        if($is_group) return array('allowed'=>true,'reason'=>'group','cost'=>0);
        if($rel['state']==='connected'||$rel['state']==='friend') return array('allowed'=>true,'reason'=>'connected','cost'=>0);
        $a=self::level($actor); $b=self::level($recipient);
        $required=max($a,$b);
        $cost=(int)apply_filters('bzj_messaging_unconnected_cost',5,$actor,$recipient,$thread_id);
        $enabled=(bool)apply_filters('bzj_messaging_gating_enabled',false,$actor,$recipient,$thread_id);
        if(!$enabled) return array('allowed'=>true,'reason'=>'gating_disabled','cost'=>0,'level'=>$a,'recipient_level'=>$b);
        if($a >= $b) return array('allowed'=>true,'reason'=>'level_sufficient','cost'=>0,'level'=>$a,'recipient_level'=>$b);
        return array('allowed'=>false,'reason'=>'health_safety_level','required_level'=>$required,'cost'=>$cost,'level'=>$a,'recipient_level'=>$b);
    }
    public static function can_send($actor,$thread_id) {
        if(!$thread_id) return array('allowed'=>false,'reason'=>'missing_thread');
        $recipients=Better_Messages()->functions->get_recipients_ids($thread_id);
        $recipients=array_values(array_filter(array_map('absint',(array)$recipients),function($id)use($actor){return $id && $id!==absint($actor);}));
        if(count($recipients)!==1) return array('allowed'=>true,'reason'=>'group_or_multi');
        return self::access($actor,$recipients[0],$thread_id,false);
    }
}
