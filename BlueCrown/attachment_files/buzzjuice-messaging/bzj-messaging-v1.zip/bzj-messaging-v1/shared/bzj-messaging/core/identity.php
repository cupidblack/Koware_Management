<?php
defined('ABSPATH') || exit;

final class BZJ_Messaging_Identity {
    public static function ensure_schema() {
        global $wpdb;
        $t = bzj_msg_tables()['identity'];
        $v = get_option('bzj_messaging_schema_version', '');
        if ($v === BZJ_MESSAGING_VERSION) return;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$t} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            wp_user_id bigint(20) unsigned NOT NULL,
            streams_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            socials_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            streams_status varchar(20) NOT NULL DEFAULT 'unlinked',
            socials_status varchar(20) NOT NULL DEFAULT 'unlinked',
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY wp_user(wp_user_id),
            KEY streams_user(streams_user_id), KEY socials_user(socials_user_id)
        ) {$c};");
        update_option('bzj_messaging_schema_version', BZJ_MESSAGING_VERSION, false);
    }
    public static function wp_from_external($platform, $external_id) {
        global $wpdb;
        $platform = strtolower((string) $platform);
        $meta = $platform === 'streams' ? 'wo_user_id' : 'qd_user_id';
        $id = absint($external_id);
        if (!$id) return 0;
        $wp_id = (int) $wpdb->get_var($wpdb->prepare("SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key=%s AND meta_value=%s ORDER BY umeta_id ASC LIMIT 1", $meta, (string) $id));
        if ($wp_id) self::upsert($wp_id, $platform, $id);
        return $wp_id;
    }
    public static function external_from_wp($platform, $wp_id) {
        $platform = strtolower((string) $platform);
        $meta = $platform === 'streams' ? 'wo_user_id' : 'qd_user_id';
        return absint(get_user_meta(absint($wp_id), $meta, true));
    }
    public static function upsert($wp_id, $platform, $external_id) {
        global $wpdb;
        $t = bzj_msg_tables()['identity']; $wp_id = absint($wp_id); $external_id = absint($external_id);
        if (!$wp_id || !$external_id) return false;
        $now = gmdate('Y-m-d H:i:s');
        $row = $wpdb->get_row($wpdb->prepare("SELECT id FROM {$t} WHERE wp_user_id=%d", $wp_id), ARRAY_A);
        $field = strtolower($platform) === 'streams' ? 'streams_user_id' : 'socials_user_id';
        $status = strtolower($platform) === 'streams' ? 'streams_status' : 'socials_status';
        if ($row) return false !== $wpdb->update($t, array($field=>$external_id,$status=>'linked','updated_at'=>$now), array('id'=>(int)$row['id']));
        return false !== $wpdb->insert($t, array('wp_user_id'=>$wp_id,$field=>$external_id,$status=>'linked','created_at'=>$now,'updated_at'=>$now));
    }
    public static function describe($wp_id) {
        return array(
            'wp_user_id' => absint($wp_id),
            'streams_user_id' => self::external_from_wp('streams', $wp_id),
            'socials_user_id' => self::external_from_wp('socials', $wp_id),
        );
    }
}
