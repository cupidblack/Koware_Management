<?php
defined('ABSPATH') || exit;

function bzj_msg_uuid() {
    try { $d = random_bytes(16); }
    catch (Throwable $e) { $d = md5(uniqid('', true), true); }
    $d[6] = chr((ord($d[6]) & 0x0f) | 0x40);
    $d[8] = chr((ord($d[8]) & 0x3f) | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($d), 4));
}
function bzj_msg_json($data) {
    return wp_json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}
function bzj_msg_request_body() {
    $raw = file_get_contents('php://input');
    return is_string($raw) ? $raw : '';
}
function bzj_msg_clean_path($path) {
    $path = (string) $path;
    $q = strpos($path, '?');
    if ($q !== false) $path = substr($path, 0, $q);
    return '/' . ltrim($path, '/');
}
function bzj_msg_current_origin() {
    return isset($GLOBALS['bzj_msg_request_context']['origin']) ? (string) $GLOBALS['bzj_msg_request_context']['origin'] : '';
}
function bzj_msg_set_context($ctx) { $GLOBALS['bzj_msg_request_context'] = is_array($ctx) ? $ctx : array(); }
function bzj_msg_context() { return isset($GLOBALS['bzj_msg_request_context']) && is_array($GLOBALS['bzj_msg_request_context']) ? $GLOBALS['bzj_msg_request_context'] : array(); }
function bzj_msg_error($code, $message, $status = 400, $data = array()) { return new WP_Error($code, $message, array_merge(array('status' => $status), $data)); }
function bzj_msg_tables() {
    global $wpdb;
    return array(
        'identity' => $wpdb->prefix . 'bzj_chat_identity',
        'sessions' => $wpdb->prefix . 'bzj_chat_sessions',
        'requests' => $wpdb->prefix . 'bzj_chat_requests',
        'events'   => $wpdb->prefix . 'bzj_chat_events',
    );
}
