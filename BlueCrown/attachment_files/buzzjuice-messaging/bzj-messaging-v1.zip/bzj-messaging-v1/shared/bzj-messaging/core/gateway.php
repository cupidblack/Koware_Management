<?php
defined('ABSPATH') || exit;

final class BZJ_Messaging_Gateway {
    private static $instance; private $inbound=false;
    public static function instance(){ return self::$instance ?: self::$instance=new self(); }
    private function __construct(){
        BZJ_Messaging_Identity::ensure_schema(); BZJ_Messaging_Sessions::ensure_schema(); BZJ_Messaging_Requests::ensure_schema(); $this->ensure_events();
        add_action('rest_api_init',array($this,'routes'));
        add_filter('better_messages_forced_current_user_id',array($this,'forced_user'),999);
        add_filter('better_messages_can_send_message',array($this,'can_send'),20,3);
        add_action('better_messages_before_message_send',array($this,'before_send'),20,2);
        add_action('better_messages_message_sent',array($this,'message_sent'),20,1);
    }
    private function ensure_events(){
        global $wpdb; $t=bzj_msg_tables()['events']; $c=$wpdb->get_charset_collate(); require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta("CREATE TABLE {$t} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            event_uuid char(36) NOT NULL,
            recipient_wp_id bigint(20) unsigned NOT NULL,
            platform varchar(20) NOT NULL,
            event_type varchar(40) NOT NULL,
            payload longtext NOT NULL,
            delivered_at datetime NULL,
            attempts int(10) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY event_uuid(event_uuid), KEY recipient(recipient_wp_id,id), KEY delivery(delivered_at)
        ) {$c};");
    }
    public function routes(){
        register_rest_route(BZJ_MSG_NS,'/chat/session',array('methods'=>'POST','callback'=>array($this,'session'),'permission_callback'=>'__return_true'));
        register_rest_route(BZJ_MSG_NS,'/chat/threads',array('methods'=>'GET','callback'=>array($this,'threads'),'permission_callback'=>'__return_true'));
        register_rest_route(BZJ_MSG_NS,'/chat/thread',array('methods'=>'POST','callback'=>array($this,'start_thread'),'permission_callback'=>'__return_true'));
        register_rest_route(BZJ_MSG_NS,'/chat/thread/(?P<thread>\d+)',array('methods'=>'GET','callback'=>array($this,'thread'),'permission_callback'=>'__return_true'));
        register_rest_route(BZJ_MSG_NS,'/chat/thread/(?P<thread>\d+)/send',array('methods'=>'POST','callback'=>array($this,'send'),'permission_callback'=>'__return_true'));
        register_rest_route(BZJ_MSG_NS,'/chat/thread/(?P<thread>\d+)/read',array('methods'=>'POST','callback'=>array($this,'read'),'permission_callback'=>'__return_true'));
        register_rest_route(BZJ_MSG_NS,'/chat/updates',array('methods'=>'GET','callback'=>array($this,'updates'),'permission_callback'=>'__return_true'));
        register_rest_route(BZJ_MSG_NS,'/chat/updates/ack',array('methods'=>'POST','callback'=>array($this,'ack'),'permission_callback'=>'__return_true'));
        register_rest_route(BZJ_MSG_NS,'/chat/request/(?P<id>[0-9a-f-]{36})/accept',array('methods'=>'POST','callback'=>array($this,'accept'),'permission_callback'=>'__return_true'));
        register_rest_route(BZJ_MSG_NS,'/chat/request/(?P<id>[0-9a-f-]{36})/decline',array('methods'=>'POST','callback'=>array($this,'decline'),'permission_callback'=>'__return_true'));
    }
    private function auth(WP_REST_Request $r,$need_session=true){
        $origin=sanitize_key((string)$r->get_header('X-BZJ-Platform')); if(!in_array($origin,array('streams','socials'),true)) return bzj_msg_error('bzj_platform','Invalid platform.',403);
        $key=sanitize_text_field((string)$r->get_header('X-BZJ-Key-Id')); $expected_key=bzj_msg_key_id($origin); if(!$expected_key || !hash_equals($expected_key,$key)) return bzj_msg_error('bzj_key','Invalid messaging key.',401);
        $ts=(string)$r->get_header('X-BZJ-Timestamp'); $rid=sanitize_text_field((string)$r->get_header('X-BZJ-Request-Id')); $sig=trim((string)$r->get_header('X-BZJ-Signature')); $raw=bzj_msg_request_body();
        if(!ctype_digit($ts)||!$rid||!preg_match('/^[0-9a-f-]{36}$/i',$rid)||!$sig) return bzj_msg_error('bzj_auth','Missing messaging authentication.',401);
        if(abs(time()-(int)$ts)>BZJ_MSG_AUTH_WINDOW) return bzj_msg_error('bzj_expired','Messaging request expired.',401);
        $secret=bzj_msg_secret($origin); if(!$secret) return bzj_msg_error('bzj_secret','Messaging secret is not configured.',503);
        $path=bzj_msg_clean_path(isset($_SERVER['REQUEST_URI']) ? (string)$_SERVER['REQUEST_URI'] : $r->get_route()); $canonical=$ts.'.'.$r->get_method().'.'.$path.'.'.$raw; $expected=hash_hmac('sha256',$canonical,$secret); if(!hash_equals($expected,$sig)) return bzj_msg_error('bzj_signature','Invalid messaging signature.',401);
        $nonce='bzj_msg_nonce_'.hash('sha256',$origin.'|'.$rid); if(get_transient($nonce)) return bzj_msg_error('bzj_replay','Request already processed.',409); set_transient($nonce,1,BZJ_MSG_AUTH_WINDOW);
        $body=$r->get_json_params(); if(!is_array($body)) $body=array();
        $external=isset($body['external_user_id'])?absint($body['external_user_id']):absint($r->get_param('external_user_id'));
        $wp_id=$external?BZJ_Messaging_Identity::wp_from_external($origin,$external):0;
        if(!$wp_id && $need_session) {
            $token=(string)$r->get_header('X-BZJ-Session'); $s=$token?BZJ_Messaging_Sessions::touch($token):false; if(is_wp_error($s)) return $s; if(!$s) return bzj_msg_error('bzj_identity','External identity or session required.',401); $wp_id=(int)$s['wp_user_id'];
        }
        if(!$wp_id) return bzj_msg_error('bzj_identity','Could not map external user to WordPress user.',409);
        bzj_msg_set_context(array('origin'=>$origin,'wp_user_id'=>$wp_id,'request_id'=>$rid,'inbound'=>true));
        return array('origin'=>$origin,'wp_user_id'=>$wp_id,'external_user_id'=>$external,'body'=>$body);
    }
    public function forced_user($id){ $ctx=bzj_msg_context(); return !empty($ctx['inbound'])&&!empty($ctx['wp_user_id'])?(int)$ctx['wp_user_id']:$id; }
    public function session(WP_REST_Request $r){ $a=$this->auth($r,false); if(is_wp_error($a)) return $a; return rest_ensure_response(array('success'=>true,'session'=>BZJ_Messaging_Sessions::issue($a['origin'],$a['wp_user_id'],$a['external_user_id']))); }
    private function bm(){ return function_exists('Better_Messages') ? Better_Messages() : null; }
    public function threads(WP_REST_Request $r){ $a=$this->auth($r); if(is_wp_error($a))return $a; $bm=$this->bm(); if(!$bm)return bzj_msg_error('bzj_bm','Better Messages is unavailable.',503); $rows=$bm->functions->get_threads($a['wp_user_id']); return rest_ensure_response(array('success'=>true,'threads'=>$rows)); }
    public function start_thread(WP_REST_Request $r){
        $a=$this->auth($r); if(is_wp_error($a))return $a; $body=$a['body']; $target_ext=absint($body['target_external_id']??0); $target=absint($body['target_wp_id']??0); if(!$target && $target_ext)$target=BZJ_Messaging_Identity::wp_from_external($a['origin'],$target_ext); if(!$target||$target===$a['wp_user_id'])return bzj_msg_error('bzj_target','Valid target is required.',400);
        $group=array_values(array_unique(array_filter(array_map('absint',(array)($body['recipient_wp_ids']??array()))))); if($group) $group=array_values(array_diff($group,array($a['wp_user_id'])));
        $bm=$this->bm(); if(!$bm)return bzj_msg_error('bzj_bm','Better Messages is unavailable.',503);
        if($group){ $ids=array_values(array_unique(array_merge(array($a['wp_user_id'],$target),$group))); $thread=$bm->functions->create_new_conversation($ids,sanitize_text_field($body['subject']??'')); return rest_ensure_response(array('success'=>(bool)$thread,'thread_id'=>(int)$thread,'group'=>true)); }
        $access=BZJ_Messaging_Policy::access($a['wp_user_id'],$target,0,false); if(!$access['allowed']){
            if(!empty($body['request']) && ($access['reason']==='health_safety_level')) {
                $result=$bm->functions->create_new_conversation(array($a['wp_user_id'],$target),''); if(!$result)return bzj_msg_error('bzj_thread','Could not create chat thread.',500); $req=BZJ_Messaging_Requests::create($a['wp_user_id'],$target,(int)$result,$access['reason']); return rest_ensure_response(array('success'=>true,'status'=>'request_pending','thread_id'=>(int)$result,'request'=>$req,'access'=>$access));
            }
            return rest_ensure_response(array('success'=>false,'status'=>'restricted','access'=>$access));
        }
        $result=$bm->functions->get_private_conversation_id($target,$a['wp_user_id'],true,sanitize_text_field($body['subject']??'')); return rest_ensure_response(array('success'=>true,'result'=>$result));
    }
    public function thread(WP_REST_Request $r){ $a=$this->auth($r); if(is_wp_error($a))return $a; $id=absint($r['thread']); $bm=$this->bm(); if(!$bm)return bzj_msg_error('bzj_bm','Better Messages is unavailable.',503); $messages=$bm->functions->get_messages($id,false,'last_messages',50); return rest_ensure_response(array('success'=>true,'thread_id'=>$id,'messages'=>$messages)); }
    public function send(WP_REST_Request $r){ $a=$this->auth($r); if(is_wp_error($a))return $a; $id=absint($r['thread']); $body=$a['body']; $content=isset($body['content'])?wp_kses_post((string)$body['content']):''; if($content==='')return bzj_msg_error('bzj_content','Message content is required.',400); $bm=$this->bm(); if(!$bm)return bzj_msg_error('bzj_bm','Better Messages is unavailable.',503); $access=BZJ_Messaging_Policy::can_send($a['wp_user_id'],$id); if(!$access['allowed'])return rest_ensure_response(array('success'=>false,'status'=>'restricted','access'=>$access)); $mid=$bm->functions->new_message(array('sender_id'=>$a['wp_user_id'],'thread_id'=>$id,'content'=>$content,'return'=>'message_id','error_type'=>'wp_error')); if(is_wp_error($mid))return $mid; return rest_ensure_response(array('success'=>true,'message_id'=>(int)$mid,'thread_id'=>$id)); }
    public function read(WP_REST_Request $r){ $a=$this->auth($r); if(is_wp_error($a))return $a; $id=absint($r['thread']); $bm=$this->bm(); if(!$bm)return bzj_msg_error('bzj_bm','Better Messages is unavailable.',503); $ok=$bm->functions->mark_thread_read($id,$a['wp_user_id']); return rest_ensure_response(array('success'=>(bool)$ok)); }
    public function updates(WP_REST_Request $r){
        $a=$this->auth($r); if(is_wp_error($a))return $a; global $wpdb; $t=bzj_msg_tables()['events']; $since=absint($r->get_param('since')); $rows=$wpdb->get_results($wpdb->prepare("SELECT id,event_uuid,event_type,payload FROM {$t} WHERE recipient_wp_id=%d AND id>%d AND delivered_at IS NULL ORDER BY id ASC LIMIT %d",$a['wp_user_id'],$since,BZJ_MSG_POLL_LIMIT),ARRAY_A); $out=array(); $ids=array(); foreach($rows as $row){$out[]=array('id'=>(int)$row['id'],'event_uuid'=>$row['event_uuid'],'event_type'=>$row['event_type'],'payload'=>json_decode($row['payload'],true));$ids[]=(int)$row['id'];} if($ids){$wpdb->query("UPDATE {$t} SET attempts=attempts+1 WHERE id IN (".implode(',',array_map('absint',$ids)).")");} return rest_ensure_response(array('success'=>true,'events'=>$out,'last_id'=>$ids?max($ids):$since));
    }
    public function ack(WP_REST_Request $r){
        $a=$this->auth($r); if(is_wp_error($a))return $a; global $wpdb; $t=bzj_msg_tables()['events']; $ids=array_values(array_filter(array_map('absint',(array)($a['body']['ids']??array())))); if(!$ids)return rest_ensure_response(array('success'=>true,'acked'=>0)); $now=gmdate('Y-m-d H:i:s'); $sql="UPDATE {$t} SET delivered_at=%s WHERE recipient_wp_id=%d AND id IN (".implode(',',array_map('absint',$ids)).")"; $wpdb->query($wpdb->prepare($sql,$now,$a['wp_user_id'])); return rest_ensure_response(array('success'=>true,'acked'=>count($ids)));
    }
    public function accept(WP_REST_Request $r){$a=$this->auth($r);if(is_wp_error($a))return $a;return rest_ensure_response(array('success'=>true,'request'=>BZJ_Messaging_Requests::respond(sanitize_text_field($r['id']),$a['wp_user_id'],true)));}
    public function decline(WP_REST_Request $r){$a=$this->auth($r);if(is_wp_error($a))return $a;return rest_ensure_response(array('success'=>true,'request'=>BZJ_Messaging_Requests::respond(sanitize_text_field($r['id']),$a['wp_user_id'],false)));}
    public function can_send($allowed,$user_id,$thread_id){ $ctx=bzj_msg_context(); if(empty($ctx['inbound'])) return $allowed; $access=BZJ_Messaging_Policy::can_send($user_id,$thread_id); if(!$access['allowed']){global $bp_better_messages_restrict_send_message;$bp_better_messages_restrict_send_message['bzj_restricted']=self::restriction_text($access);return false;} return $allowed; }
    public function before_send(&$args,&$errors){ $ctx=bzj_msg_context(); if(empty($ctx['inbound'])) return; $access=BZJ_Messaging_Policy::can_send((int)$args['sender_id'],(int)$args['thread_id']); if(!$access['allowed'])$errors['bzj_restricted']=self::restriction_text($access); }
    private static function restriction_text($a){ if(($a['reason']??'')==='health_safety_level') return 'Complete the required Health & Safety lesson or use the available temporary chat option.'; if(($a['reason']??'')==='blocked') return 'Messaging is unavailable for this user.'; return 'You are not currently allowed to send messages in this conversation.'; }
    public function message_sent($message){
        $ctx=bzj_msg_context(); $recipients=(array)($message->recipients??array());
        foreach($recipients as $wp_id){ $wp_id=absint($wp_id); if(!$wp_id)continue; foreach(array('streams','socials') as $platform){ $external=BZJ_Messaging_Identity::external_from_wp($platform,$wp_id); if(!$external)continue; $this->queue_event($wp_id,$platform,'message',array('thread_id'=>(int)$message->thread_id,'message_id'=>(int)$message->id,'sender_wp_id'=>(int)$message->sender_id,'sender_external_id'=>BZJ_Messaging_Identity::external_from_wp($platform,(int)$message->sender_id),'recipient_external_id'=>$external,'content'=>(string)$message->message,'date_sent'=>(string)$message->date_sent,'origin'=>$ctx['origin']??'wordpress')); } }
        bzj_msg_log('Message sent',array('message_id'=>(int)$message->id,'thread_id'=>(int)$message->thread_id,'sender_wp_id'=>(int)$message->sender_id,'origin'=>$ctx['origin']??'wordpress'));
        bzj_msg_set_context(array());
    }
    private function queue_event($recipient,$platform,$type,$payload){ global $wpdb;$t=bzj_msg_tables()['events'];$wpdb->insert($t,array('event_uuid'=>bzj_msg_uuid(),'recipient_wp_id'=>absint($recipient),'platform'=>sanitize_key($platform),'event_type'=>sanitize_key($type),'payload'=>bzj_msg_json($payload),'created_at'=>gmdate('Y-m-d H:i:s'))); }
}
