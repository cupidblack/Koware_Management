/* Buzzjuice Messaging client. Phase 1 uses the host platform as a proxy; WebSocket can be added later. */
(function(window){
  'use strict';
  function BZJMessaging(options){
    options=options||{};this.pollUrl=options.pollUrl||null;this.ackUrl=options.ackUrl||null;this.interval=options.interval||5000;this.lastId=Number(options.lastId||0);this.timer=null;this.onEvent=typeof options.onEvent==='function'?options.onEvent:function(){};
  }
  BZJMessaging.prototype.start=function(){var self=this;if(!this.pollUrl)return;this.stop();var tick=function(){fetch(self.pollUrl+'&since='+encodeURIComponent(self.lastId),{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(d){if(!d||!Array.isArray(d.events))return;d.events.forEach(function(e){self.lastId=Math.max(self.lastId,Number(e.id||0));self.onEvent(e);document.dispatchEvent(new CustomEvent('bzj_message',{detail:e}));});if(self.ackUrl){fetch(self.ackUrl,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids:d.events.map(function(e){return Number(e.id||0);})})}).catch(function(){});}}).catch(function(){});};tick();this.timer=setInterval(tick,this.interval);};
  BZJMessaging.prototype.stop=function(){if(this.timer){clearInterval(this.timer);this.timer=null;}};
  window.BZJMessaging=BZJMessaging;
})(window);
