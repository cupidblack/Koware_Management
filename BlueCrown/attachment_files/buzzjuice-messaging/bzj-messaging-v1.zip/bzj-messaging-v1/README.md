# Buzzjuice Unified Messaging v1.0.0

This package implements the lean first-stage architecture agreed from the BP Better Messages audit and the GitHub review:

- WordPress + BP Better Messages is the canonical message store.
- Streams and Socials are signed clients; their native message databases are not authoritative.
- Better Messages' public `Better_Messages()->functions->new_message()` API is used; Better Messages tables are never written directly.
- A separate Buzzjuice request ledger handles first-contact accept/decline; Better Messages moderation/pending state is not reused as a connection request.
- The existing Buzzjuice relationship control plane remains authoritative for permanent connections.
- Short-lived messaging sessions are supported, with silent renewal.
- Signed requests use platform-specific key IDs/secrets and canonical HMAC input.
- Polling is the phase-1 real-time fallback. Node/WebSocket transport is deliberately deferred.
- Gating is server-side and disabled by default until the Health & Safety policy addon is installed.
- Extensions are loaded only from `bzj-msg-addon-*.php` and `bzj-msg-int-*.php` files.

## Important

Do **not** modify BP Better Messages core files. Do **not** copy `wp-load.php` into Streams/Socials for phase 1. Do **not** use the existing Streams/Socials messaging APIs as the canonical integration interface.

## Files

`wp-content/mu-plugins/bzj-messaging.php` is the bootstrap/orchestrator.

`shared/bzj-messaging/core/` contains the central identity, session, policy, request and gateway components.

`shared/bzj-messaging/bzj-msg-streams-client.php` and `bzj-msg-socials-client.php` are server-side bridge clients.

`shared/bzj-messaging/js/bzj-messaging.js` is a small browser event/polling helper for later platform UI work.

## Required environment variables

```text
BZJ_STREAMS_CHAT_KEY_ID=
BZJ_STREAMS_CHAT_SECRET=
BZJ_SOCIALS_CHAT_KEY_ID=
BZJ_SOCIALS_CHAT_SECRET=
WORDPRESS_API_BASE=https://buzzjuice.net/wp-json
```

Do not reuse `BUZZ_SSO_SECRET` or connection-sync secrets.

## Phase-1 API

```text
POST /wp-json/bzj/v1/chat/session
GET  /wp-json/bzj/v1/chat/threads
POST /wp-json/bzj/v1/chat/thread
GET  /wp-json/bzj/v1/chat/thread/{thread}
POST /wp-json/bzj/v1/chat/thread/{thread}/send
POST /wp-json/bzj/v1/chat/thread/{thread}/read
GET  /wp-json/bzj/v1/chat/updates
POST /wp-json/bzj/v1/chat/request/{uuid}/accept
POST /wp-json/bzj/v1/chat/request/{uuid}/decline
```

## Deployment order

1. Back up WordPress and the three messaging databases.
2. Create the shared directory and copy the package files.
3. Configure the four messaging credentials.
4. Install the MU plugin but leave Streams/Socials unchanged.
5. Confirm WordPress Better Messages still works normally.
6. Test signed session creation using a server-side script from Streams.
7. Test external message creation into a dedicated test account/thread.
8. Add Streams client integration only after WP tests pass.
9. Add Socials client integration only after Streams tests pass.
10. Add polling notifications.
11. Only then build the optional Node/WebSocket transport.
12. Add Health & Safety gating and credits as a separate addon.

## Caveat

The `read()` wrapper calls Better Messages' public `mark_thread_read()` method. If the installed plugin build exposes a different signature, adjust only that wrapper after confirming the installed plugin API. Message creation and message retrieval use the documented public API.
