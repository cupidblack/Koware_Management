# Buzzjuice Unified Messaging v1.4.0

## Architecture
WordPress + BP Better Messages is the canonical message store. Streams and Socials use signed HTTPS requests to this control plane. They do not load `wp-load.php` in Phase 1 and do not write Better Messages tables directly.

## Phase 1 endpoints
- `GET /wp-json/bzj-messaging/v1/status`
- `POST /wp-json/bzj-messaging/v1/session`
- `POST /wp-json/bzj-messaging/v1/relationship`
- `POST /wp-json/bzj-messaging/v1/request`
- `GET /wp-json/bzj-messaging/v1/requests`
- `POST /wp-json/bzj-messaging/v1/request/{id}/decision`
- `POST /wp-json/bzj-messaging/v1/thread/open`
- `GET /wp-json/bzj-messaging/v1/thread/{id}/messages`
- `POST /wp-json/bzj-messaging/v1/thread/{id}/send`
- `POST /wp-json/bzj-messaging/v1/thread/{id}/read`

## Authentication
External calls use per-platform HMAC credentials. Signature payload:
`METHOD + newline + ROUTE + newline + TIMESTAMP + newline + REQUEST_ID + newline + SHA256(BODY)`.

Do not reuse connection-sync secrets. Configure `BZJ_STREAMS_CHAT_KEY_ID`, `BZJ_STREAMS_CHAT_SECRET`, `BZJ_SOCIALS_CHAT_KEY_ID`, `BZJ_SOCIALS_CHAT_SECRET`.

## Logging
`shared/bzj-messaging/logs/bzj-messaging.log`. Never log raw secrets, cookies, signatures or access tokens.

## Phase 1 policy
- Existing canonical connection = free private chat.
- First contact between unconnected users creates a chat request.
- Recipient must accept before a private thread is created.
- Existing relationship blocks prevent messaging.
- Group-chat special rules and Palmier charging are intentionally not enabled yet.
- JS never enforces access; the server does.

## Important integration rule
The client wrappers are the only messaging integration surface that Streams/Socials should call. Legacy chat endpoints should become adapters around these functions rather than remaining a second source of truth.

## Phase 2
1. Add external thread-list/read synchronization.
2. Add notification bridge.
3. Add polling adapter.
4. Add optional Node/WebSocket transport behind `BZJ_MESSAGING_REALTIME_ENABLED`.
5. Add HS course gating and Palmier provider.
6. Add group/private transition rules, rewards, stickers, media, voice/video.
