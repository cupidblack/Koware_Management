<?php
/** Buzzjuice external messaging client. No WordPress functions required. */
if(!function_exists('bzj_msg_client')){
function bzj_msg_client_env($n){$v=getenv($n);return ($v!==false&&$v!=='')?(string)$v:'';}
function bzj_msg_client($platform,$operation,$actor_external_id,$params=array()){
    $platform=strtolower($platform); if(!in_array($platform,array('streams','socials'),true))throw new InvalidArgumentException('Invalid platform.');
    $base=rtrim(bzj_msg_client_env('WORDPRESS_API_BASE')?:'https://buzzjuice.net/wp-json','/');
    $path='/bzj-messaging/v1/'.$operation; $url=$base.$path; $key=bzj_msg_client_env('BZJ_'.strtoupper($platform).'_CHAT_KEY_ID'); $secret=bzj_msg_client_env('BZJ_'.strtoupper($platform).'_CHAT_SECRET'); if($key===''||$secret==='')throw new RuntimeException('Messaging credentials unavailable.');
    $params['actor_external_id']=(int)$actor_external_id; $body=json_encode($params,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); $ts=(string)time(); $rid=bin2hex(random_bytes(16)); $canonical='POST\n'.$path.'\n'.$ts.'\n'.$rid.'\n'.hash('sha256',$body); $sig=hash_hmac('sha256',$canonical,$secret);
    $ch=curl_init($url);curl_setopt_array($ch,array(CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_HTTPHEADER=>array('Content-Type: application/json','Accept: application/json','X-BZJ-Platform: '.$platform,'X-BZJ-Key-ID: '.$key,'X-BZJ-Timestamp: '.$ts,'X-BZJ-Request-ID: '.$rid,'X-BZJ-Signature: '.$sig),CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>20,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2));$raw=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);if($raw===false)throw new RuntimeException($err?:'Messaging request failed.');$out=json_decode($raw,true);if(!is_array($out))$out=array('success'=>false,'http_code'=>$http,'raw'=>$raw);$out['_http_code']=$http;return $out;
}
}
