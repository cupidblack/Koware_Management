<?php
defined('ABSPATH') || exit;
if (defined('BZJ_MESSAGING_CONFIG_LOADED')) return;
define('BZJ_MESSAGING_CONFIG_LOADED', true);

define('BZJ_MESSAGING_VERSION', '1.4.0');
define('BZJ_MESSAGING_BASE', dirname(__DIR__));
define('BZJ_MESSAGING_CORE', BZJ_MESSAGING_BASE . '/core');
define('BZJ_MESSAGING_CONFIG', BZJ_MESSAGING_BASE . '/config');
define('BZJ_MESSAGING_ADDONS', BZJ_MESSAGING_BASE . '/addons');
define('BZJ_MESSAGING_INT', BZJ_MESSAGING_BASE . '/int');
define('BZJ_MESSAGING_JS', BZJ_MESSAGING_BASE . '/js');
define('BZJ_MESSAGING_LOGS', BZJ_MESSAGING_BASE . '/logs');

define('BZJ_MESSAGING_MIN_PHP', '7.4.0');
define('BZJ_MESSAGING_MIN_WP', '6.0');
define('BZJ_MESSAGING_MIN_BM', '2.15.0');

define('BZJ_MESSAGING_NS', 'bzj-messaging/v1');
define('BZJ_MESSAGING_SESSION_TTL', 900);
define('BZJ_MESSAGING_CHAT_ACCESS_TTL', 900);
define('BZJ_MESSAGING_AUTH_WINDOW', 300);
define('BZJ_MESSAGING_REQUEST_TTL', 72 * HOUR_IN_SECONDS);
define('BZJ_MESSAGING_LOG_ENABLED', true);
define('BZJ_MESSAGING_LOG_LEVEL', 'info');
define('BZJ_MESSAGING_LOG_MAX_SIZE', 5 * 1024 * 1024);
define('BZJ_MESSAGING_REALTIME_ENABLED', false);
define('BZJ_MESSAGING_REALTIME_PROVIDER', 'polling');
define('BZJ_MESSAGING_RATE_LIMIT', 120);
define('BZJ_MESSAGING_RATE_WINDOW', 60);
define('BZJ_MESSAGING_ADDON_PATTERN', '/^bzj-msg-addon-[a-z0-9_-]+\.php$/i');
define('BZJ_MESSAGING_INT_PATTERN', '/^bzj-msg-int-[a-z0-9_-]+\.php$/i');

global $wpdb;
define('BZJ_MESSAGING_TABLE_SESSIONS', $wpdb->prefix . 'bzj_msg_sessions');
define('BZJ_MESSAGING_TABLE_REQUESTS', $wpdb->prefix . 'bzj_msg_requests');
define('BZJ_MESSAGING_TABLE_REPLAY', $wpdb->prefix . 'bzj_msg_replay');
define('BZJ_MESSAGING_TABLE_AUDIT', $wpdb->prefix . 'bzj_msg_audit');
define('BZJ_MESSAGING_TABLE_IDENTITY', $wpdb->prefix . 'bzj_msg_identity');

define('BZJ_MESSAGING_REL_TABLE', $wpdb->prefix . 'bzj_relationships');
