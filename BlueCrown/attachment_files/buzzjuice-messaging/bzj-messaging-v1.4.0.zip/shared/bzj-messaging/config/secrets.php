<?php
defined('ABSPATH') || exit;
if (!function_exists('bzj_msg_secret')) {
    function bzj_msg_env($name) {
        $v = getenv($name);
        if ($v !== false && $v !== '') return (string)$v;
        if (defined($name) && constant($name) !== '') return (string)constant($name);
        return '';
    }
    function bzj_msg_secret($platform, $type) {
        $platform = strtoupper(preg_replace('/[^A-Z0-9_]/i', '', $platform));
        $type = strtoupper(preg_replace('/[^A-Z0-9_]/i', '', $type));
        $v = bzj_msg_env('BZJ_' . $platform . '_CHAT_' . $type);
        return $v !== '' ? $v : bzj_msg_env('BZJ_MESSAGING_SECRET');
    }
}
