<?php
defined('ABSPATH') || exit;
function bzj_msg_uuid() { return function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : bin2hex(random_bytes(16)); }
function bzj_msg_json($v) { return wp_json_encode($v, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); }
function bzj_msg_error($code, $message, $status = 400, $data = array()) { return new WP_Error($code, $message, array_merge(array('status'=>$status), $data)); }
function bzj_msg_pair($a, $b) { $a=absint($a); $b=absint($b); return $a<$b ? array($a,$b) : array($b,$a); }
function bzj_msg_platform($p) { $p=strtolower((string)$p); return in_array($p,array('streams','socials'),true)?$p:''; }
