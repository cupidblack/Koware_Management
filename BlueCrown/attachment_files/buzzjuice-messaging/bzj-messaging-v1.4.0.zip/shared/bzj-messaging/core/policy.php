<?php
defined('ABSPATH') || exit;
final class BZJ_Messaging_Policy {
    public function relationship($a,$b){
        global $wpdb; list($a,$b)=bzj_msg_pair($a,$b); if(!$a||!$b)return array('state'=>'none','blocked'=>false,'requested_by'=>0);
        $t=BZJ_MESSAGING_REL_TABLE;
        $r=$wpdb->get_row($wpdb->prepare("SELECT connection_state,requested_by,block_a_to_b,block_b_to_a,user_a,user_b FROM {$t} WHERE user_a=%d AND user_b=%d LIMIT 1",$a,$b),ARRAY_A);
        if(!$r)return array('state'=>'none','blocked'=>false,'requested_by'=>0);
        $blocked=((int)$r['block_a_to_b']===1||(int)$r['block_b_to_a']===1);
        return array('state'=>$blocked?'blocked':(string)$r['connection_state'],'blocked'=>$blocked,'requested_by'=>absint($r['requested_by']));
    }
    public function private_access($sender,$recipient){
        $r=$this->relationship($sender,$recipient);
        if($r['blocked'])return array('allowed'=>false,'code'=>'blocked','message'=>'Messaging is unavailable between these users.');
        if($r['state']==='connected')return array('allowed'=>true,'mode'=>'connected','charge'=>false);
        return array('allowed'=>false,'mode'=>'request','charge'=>false,'code'=>'chat_request_required','message'=>'This is a first-contact chat. The recipient must accept the chat request before messaging can begin.');
    }
    public function thread_access($user,$thread){
        if(!function_exists('Better_Messages'))return array('allowed'=>false,'message'=>'Messaging service unavailable.');
        if(!Better_Messages()->functions->is_user_participant($thread,$user))return array('allowed'=>false,'message'=>'You are not a participant in this conversation.');
        $recipients=Better_Messages()->functions->get_recipients_ids($thread);
        if(count($recipients)===2){$other=0;foreach($recipients as $id){if((int)$id!==$user){$other=(int)$id;break;}}
            $r=$this->relationship($user,$other); if($r['blocked'])return array('allowed'=>false,'message'=>'Messaging is unavailable between these users.');
            if($r['state']!=='connected'){ $temporary=BZJ_Messaging_Requests::instance()->thread_access($thread,$user); if(!$temporary)return array('allowed'=>false,'message'=>'This chat is not active. Accept the chat request or connect with this person first.'); }
        }
        return array('allowed'=>true);
    }
}
