<?php
defined('ABSPATH') || exit;
final class BZJ_Messaging_Identity {
    private static $instance; private $cache=array();
    public static function instance(){return self::$instance ?: self::$instance=new self();}
    public function resolve($platform,$external_id){
        $platform=bzj_msg_platform($platform); $external_id=absint($external_id); if(!$platform||!$external_id)return 0;
        $key=$platform.':'.$external_id; if(isset($this->cache[$key]))return $this->cache[$key];
        $meta=$platform==='streams'?'wo_user_id':'qd_user_id';
        $ids=get_users(array('fields'=>'ID','number'=>1,'meta_key'=>$meta,'meta_value'=>(string)$external_id,'count_total'=>false));
        $id=!empty($ids)?absint($ids[0]):0; $this->cache[$key]=$id;
        if($id){global $wpdb; $wpdb->replace(BZJ_MESSAGING_TABLE_IDENTITY,array('platform'=>$platform,'external_user_id'=>$external_id,'wp_user_id'=>$id,'last_verified'=>current_time('mysql',true),'created_at'=>current_time('mysql',true)),array('%s','%d','%d','%s','%s'));}
        return $id;
    }
    public function external($platform,$wp_id){
        $platform=bzj_msg_platform($platform); $wp_id=absint($wp_id); if(!$platform||!$wp_id)return 0;
        $meta=$platform==='streams'?'wo_user_id':'qd_user_id'; return absint(get_user_meta($wp_id,$meta,true));
    }
}
