<?php
defined('ABSPATH') || exit;
final class BZJ_Messaging_Adapter {
    private static $instance; private $policy;
    public static function instance(){return self::$instance ?: self::$instance=new self();}
    private function __construct(){$this->policy=new BZJ_Messaging_Policy();}
    public function register_hooks(){
        add_filter('better_messages_can_send_message',array($this,'can_send'),20,3);
        add_action('better_messages_message_sent',array($this,'message_sent'),20,1);
        add_action('better_messages_before_new_thread',array($this,'before_new_thread'),20,2);
    }
    public function can_send($allowed,$user,$thread){
        if(!$allowed)return false; $r=$this->policy->thread_access((int)$user,(int)$thread); if(!$r['allowed']){$GLOBALS['bp_better_messages_restrict_send_message']['bzj_messaging']=$r['message'];return false;} return true;
    }
    public function before_new_thread(&$args,&$errors){
        $sender=isset($args['sender_id'])?absint($args['sender_id']):get_current_user_id(); $recipients=isset($args['recipients'])?(array)$args['recipients']:array();
        if(count($recipients)!==1)return; $p=$this->policy->private_access($sender,absint($recipients[0])); if(!$p['allowed'])$errors['bzj_messaging']=$p['message'];
    }
    public function message_sent($message){
        if(!is_object($message))return; do_action('bzj_messaging_message_sent',$message); bzj_messaging_log('Message sent',array('message_id'=>absint($message->id??0),'thread_id'=>absint($message->thread_id??0),'sender_id'=>absint($message->sender_id??0)),'debug');
    }
}
