<?php
defined('ABSPATH') || exit;
final class BZJ_Messaging_Dispatch {
    private static $instance; public static function instance(){return self::$instance ?: self::$instance=new self();}
    public function emit($event,$payload=array()){do_action('bzj_messaging_event_'.$event,$payload);return true;}
}
