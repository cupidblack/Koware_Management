<?php
defined('ABSPATH') || exit;
final class BZJ_Messaging_Sessions {
    private static $instance;
    public static function instance(){return self::$instance ?: self::$instance=new self();}
    public function issue($platform,$external_id,$wp_id){
        global $wpdb; $token=bin2hex(random_bytes(32)); $sid=bzj_msg_uuid(); $now=time();
        $wpdb->insert(BZJ_MESSAGING_TABLE_SESSIONS,array('session_id'=>$sid,'platform'=>$platform,'external_user_id'=>$external_id,'wp_user_id'=>$wp_id,'token_hash'=>hash('sha256',$token),'expires_at'=>gmdate('Y-m-d H:i:s',$now+BZJ_MESSAGING_SESSION_TTL),'created_at'=>gmdate('Y-m-d H:i:s',$now),'updated_at'=>gmdate('Y-m-d H:i:s',$now)),array('%s','%s','%d','%d','%s','%s','%s','%s'));
        return array('session_id'=>$sid,'token'=>$token,'expires_at'=>$now+BZJ_MESSAGING_SESSION_TTL);
    }
    public function verify($sid,$token,$platform,$external_id){
        global $wpdb; $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".BZJ_MESSAGING_TABLE_SESSIONS." WHERE session_id=%s AND platform=%s AND external_user_id=%d LIMIT 1",$sid,$platform,$external_id));
        if(!$r||!hash_equals((string)$r->token_hash,hash('sha256',$token))||strtotime($r->expires_at)<time())return false;
        $new=time()+BZJ_MESSAGING_SESSION_TTL; $wpdb->update(BZJ_MESSAGING_TABLE_SESSIONS,array('expires_at'=>gmdate('Y-m-d H:i:s',$new),'updated_at'=>gmdate('Y-m-d H:i:s')) ,array('id'=>$r->id),array('%s','%s'),array('%d'));
        return absint($r->wp_user_id);
    }
}
