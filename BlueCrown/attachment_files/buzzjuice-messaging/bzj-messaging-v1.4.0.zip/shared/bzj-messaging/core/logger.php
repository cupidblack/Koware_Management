<?php
defined('ABSPATH') || exit;
final class BZJ_Messaging_Logger {
    private static $instance;
    private $levels=array('debug'=>0,'info'=>1,'warning'=>2,'error'=>3);
    private $level='info';
    private function __construct(){ $v=strtolower((string)bzj_msg_env('BZJ_MESSAGING_LOG_LEVEL')); if(isset($this->levels[$v]))$this->level=$v; }
    public static function instance(){return self::$instance ?: self::$instance=new self();}
    public function write($level,$message,$context=array()){
        if(!BZJ_MESSAGING_LOG_ENABLED || !isset($this->levels[$level]) || $this->levels[$level]<$this->levels[$this->level])return;
        if(!is_dir(BZJ_MESSAGING_LOGS))wp_mkdir_p(BZJ_MESSAGING_LOGS);
        if(!is_dir(BZJ_MESSAGING_LOGS)||!is_writable(BZJ_MESSAGING_LOGS))return;
        $entry=array('time'=>gmdate('c'),'level'=>$level,'message'=>(string)$message,'context'=>$this->safe($context));
        $file=BZJ_MESSAGING_LOGS.'/bzj-messaging.log';
        @file_put_contents($file,bzj_msg_json($entry).PHP_EOL,FILE_APPEND|LOCK_EX);
        if(is_file($file)&&filesize($file)>BZJ_MESSAGING_LOG_MAX_SIZE)@rename($file,$file.'.'.time());
    }
    private function safe($v){
        if(is_array($v)){ $o=array(); foreach($v as $k=>$x){ $lk=strtolower((string)$k); if(strpos($lk,'secret')!==false||strpos($lk,'token')!==false||strpos($lk,'cookie')!==false||strpos($lk,'signature')!==false){$o[$k]='[redacted]';}else{$o[$k]=$this->safe($x);} } return $o; }
        if(is_object($v))return $this->safe((array)$v); return $v;
    }
    public function debug($m,$c=array()){ $this->write('debug',$m,$c); }
    public function info($m,$c=array()){ $this->write('info',$m,$c); }
    public function warning($m,$c=array()){ $this->write('warning',$m,$c); }
    public function error($m,$c=array()){ $this->write('error',$m,$c); }
}
function bzj_messaging_log($m,$c=array(),$l='info'){BZJ_Messaging_Logger::instance()->write($l,$m,$c);}
