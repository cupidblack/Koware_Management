<?php
defined('ABSPATH') || exit;
final class BZJ_Messaging_Requests {
    private static $instance;
    public static function instance(){return self::$instance ?: self::$instance=new self();}
    public function create($from,$to,$message=''){
        global $wpdb; $p=BZJ_Messaging_Identity::instance();
        $policy=(new BZJ_Messaging_Policy())->private_access($from,$to); if($policy['allowed'])return array('state'=>'connected','thread_id'=>$this->existing_thread($from,$to));
        if($policy['code']==='blocked')return bzj_msg_error('bzj_blocked',$policy['message'],403);
        $existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".BZJ_MESSAGING_TABLE_REQUESTS." WHERE requester_id=%d AND recipient_id=%d AND status='pending' AND expires_at>UTC_TIMESTAMP() ORDER BY id DESC LIMIT 1",$from,$to));
        if($existing)return array('state'=>'pending','request_id'=>absint($existing->id));
        $wpdb->insert(BZJ_MESSAGING_TABLE_REQUESTS,array('requester_id'=>$from,'recipient_id'=>$to,'initial_message'=>$message,'status'=>'pending','expires_at'=>gmdate('Y-m-d H:i:s',time()+BZJ_MESSAGING_REQUEST_TTL),'created_at'=>gmdate('Y-m-d H:i:s'),'updated_at'=>gmdate('Y-m-d H:i:s')),array('%d','%d','%s','%s','%s','%s','%s'));
        return array('state'=>'pending','request_id'=>absint($wpdb->insert_id));
    }
    public function list_for($user){global $wpdb;return $wpdb->get_results($wpdb->prepare("SELECT id,requester_id,recipient_id,initial_message,status,expires_at,created_at FROM ".BZJ_MESSAGING_TABLE_REQUESTS." WHERE recipient_id=%d AND status='pending' AND expires_at>UTC_TIMESTAMP() ORDER BY id DESC",$user),ARRAY_A);}
    public function decide($id,$user,$accept){
        global $wpdb; $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".BZJ_MESSAGING_TABLE_REQUESTS." WHERE id=%d AND recipient_id=%d AND status='pending' LIMIT 1",$id,$user));
        if(!$r)return bzj_msg_error('bzj_request','Chat request not found.',404);
        if(!$accept){$wpdb->update(BZJ_MESSAGING_TABLE_REQUESTS,array('status'=>'declined','updated_at'=>gmdate('Y-m-d H:i:s')),array('id'=>$id),array('%s','%s'),array('%d'));return array('state'=>'declined');}
        $wpdb->update(BZJ_MESSAGING_TABLE_REQUESTS,array('status'=>'accepted','access_until'=>gmdate('Y-m-d H:i:s',time()+BZJ_MESSAGING_CHAT_ACCESS_TTL),'updated_at'=>gmdate('Y-m-d H:i:s')),array('id'=>$id),array('%s','%s','%s'),array('%d'));
        return array('state'=>'accepted');
    }
    public function thread_access($thread,$user){
        global $wpdb;
        $r=$wpdb->get_row($wpdb->prepare("SELECT id,requester_id,recipient_id,access_until FROM ".BZJ_MESSAGING_TABLE_REQUESTS." WHERE thread_id=%d AND status='accepted' AND access_until>UTC_TIMESTAMP() AND (requester_id=%d OR recipient_id=%d) ORDER BY id DESC LIMIT 1",$thread,$user,$user));
        return $r ? array('allowed'=>true,'request_id'=>(int)$r->id,'expires_at'=>$r->access_until) : false;
    }
    public function renew_thread_access($thread,$user){
        global $wpdb; $r=$this->thread_access($thread,$user); if(!$r)return false;
        $wpdb->update(BZJ_MESSAGING_TABLE_REQUESTS,array('access_until'=>gmdate('Y-m-d H:i:s',time()+BZJ_MESSAGING_CHAT_ACCESS_TTL),'updated_at'=>gmdate('Y-m-d H:i:s')),array('id'=>$r['request_id']),array('%s','%s'),array('%d'));
        return true;
    }
    public function existing_thread($a,$b){
        if(!function_exists('Better_Messages'))return 0; $ids=Better_Messages()->functions->find_existing_threads($a,$b); return !empty($ids)?absint(reset($ids)):0;
    }
}
