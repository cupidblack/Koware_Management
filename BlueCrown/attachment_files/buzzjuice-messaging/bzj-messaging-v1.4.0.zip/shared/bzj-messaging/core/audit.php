<?php
defined('ABSPATH') || exit;
function bzj_msg_audit($event,$platform,$actor,$target=0,$data=array()){
    global $wpdb; $wpdb->insert(BZJ_MESSAGING_TABLE_AUDIT,array('event'=>$event,'platform'=>$platform,'actor_wp_id'=>absint($actor),'target_wp_id'=>absint($target),'data'=>bzj_msg_json($data),'created_at'=>gmdate('Y-m-d H:i:s')),array('%s','%s','%d','%d','%s','%s'));
}
