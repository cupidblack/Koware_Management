/* Phase-1 helper. Enforcement remains server-side. */
window.BZJMessaging=window.BZJMessaging||{};
BZJMessaging.poll=function(url,opts){opts=opts||{};var delay=opts.delay||10000;var fn=opts.fetch||function(){};return setInterval(fn,delay);};
