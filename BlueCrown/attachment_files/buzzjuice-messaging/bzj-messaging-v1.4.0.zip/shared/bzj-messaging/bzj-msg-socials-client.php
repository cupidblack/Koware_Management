<?php
require_once __DIR__.'/bzj-msg-client.php';
function bzj_socials_msg_request($actor,$target,$message=''){return bzj_msg_client('socials','request',$actor,array('target_external_id'=>(int)$target,'message'=>$message));}
function bzj_socials_msg_accept($actor,$request_id){return bzj_msg_client('socials','request/'.$request_id.'/decision',$actor,array('accept'=>true));}
function bzj_socials_msg_decline($actor,$request_id){return bzj_msg_client('socials','request/'.$request_id.'/decision',$actor,array('accept'=>false));}
function bzj_socials_msg_open($actor,$target){return bzj_msg_client('socials','thread/open',$actor,array('target_external_id'=>(int)$target));}
function bzj_socials_msg_send($actor,$thread,$message){return bzj_msg_client('socials','thread/'.$thread.'/send',$actor,array('message'=>$message));}
function bzj_socials_msg_messages($actor,$thread,$count=50){return bzj_msg_client('socials','thread/'.$thread.'/messages',$actor,array('count'=>(int)$count));}
function bzj_socials_msg_read($actor,$thread){return bzj_msg_client('socials','thread/'.$thread.'/read',$actor,array());}
