<?php
/**
 * Plugin Name: BZJ Connections Synchronization Control Plane
 * Description: Buzzjuice canonical relationship control plane. BuddyBoss/WordPress is the source of truth; Streams and Socials are projections.
 * Version: 8.4.1
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */
defined('ABSPATH') || exit;
if (defined('BZJ_CONNECTIONS_SYNC_LOADED')) return;
define('BZJ_CONNECTIONS_SYNC_LOADED', true);

final class BZJ_Connections_Sync {
    const VERSION='8.4.1';
    const NS='bzj/v6';
    const ROUTE='/connection-management';
    const LEDGER='bzj_relationships';
    const EVENTS='bzj_relationship_events';
    const LOG='/data/logs';
    const LOG_FILE='bzj-connections-sync.log';
    const RECOVERY='bzj_connections_sync_recovery_v841';
    const RECONCILE='bzj_connections_sync_reconcile_v841';
    const WINDOW=300;
    const MAX_ATTEMPTS=12;
    const O_WP='wordpress'; const O_STREAMS='streams'; const O_SOCIALS='socials';
    const REQUEST='connection_request'; const ACCEPT='connection_accept'; const REJECT='connection_reject';
    const WITHDRAW='connection_withdraw'; const REMOVE='connection_remove'; const FOLLOW='follow'; const UNFOLLOW='unfollow';
    const BLOCK='block'; const UNBLOCK='unblock';

    private static $i; private $ledger; private $events; private $ctx=[]; private $locks=[];
    public static function instance(){return self::$i ?: self::$i=new self();}
    private function __construct(){
        global $wpdb; $this->ledger=$wpdb->prefix.self::LEDGER; $this->events=$wpdb->prefix.self::EVENTS;
        add_action('rest_api_init',[$this,'routes']);
        add_action('friends_friendship_requested',[$this,'bb_requested'],20,4);
        add_action('friends_friendship_accepted',[$this,'bb_accepted'],20,4);
        add_action('friends_friendship_rejected',[$this,'bb_rejected'],20,2);
        add_action('friends_friendship_withdrawn',[$this,'bb_withdrawn'],20,2);
        add_action('friends_friendship_whithdrawn',[$this,'bb_withdrawn'],20,2);
        add_action('friends_friendship_deleted',[$this,'bb_deleted'],1,3);
        add_action('friends_friendship_post_delete',[$this,'bb_post_deleted'],20,2);
        add_action('bp_start_following',[$this,'bb_follow_start'],20,1);
        add_action('bp_stop_following',[$this,'bb_follow_stop'],20,1);
        add_action('bp_follow_start_following',[$this,'bb_follow_start'],20,1);
        add_action('bp_follow_stop_following',[$this,'bb_follow_stop'],20,1);
        /* BuddyBoss v8.1 lifecycle: do not replace these with bp_moderation_block_created/deleted. */
        add_action('bp_moderation_after_save',[$this,'bb_moderation_saved'],20,1);
        add_action('bb_moderation_after_delete',[$this,'bb_moderation_deleted'],20,1);
        add_action(self::RECOVERY,[$this,'recovery']);
        add_action(self::RECONCILE,[$this,'reconcile']);
        $this->schema(); $this->cron(); $this->startup_diagnostics();
    }

    private function schema(){
        $v=get_option('bzj_connections_sync_schema_version',''); if($v===self::VERSION)return;
        require_once ABSPATH.'wp-admin/includes/upgrade.php'; global $wpdb; $c=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$this->ledger} (
          id bigint(20) unsigned NOT NULL AUTO_INCREMENT,user_a bigint(20) unsigned NOT NULL,user_b bigint(20) unsigned NOT NULL,
          connection_state varchar(20) NOT NULL DEFAULT 'none',requested_by bigint(20) unsigned NOT NULL DEFAULT 0,
          follow_a_to_b tinyint(1) NOT NULL DEFAULT 0,follow_b_to_a tinyint(1) NOT NULL DEFAULT 0,
          block_a_to_b tinyint(1) NOT NULL DEFAULT 0,block_b_to_a tinyint(1) NOT NULL DEFAULT 0,
          version bigint(20) unsigned NOT NULL DEFAULT 1,last_event_uuid char(36) NOT NULL DEFAULT '',
          created_at datetime NOT NULL,updated_at datetime NOT NULL,PRIMARY KEY(id),UNIQUE KEY user_pair(user_a,user_b),
          KEY updated_at(updated_at),KEY state(connection_state)) $c;");
        dbDelta("CREATE TABLE {$this->events} (
          id bigint(20) unsigned NOT NULL AUTO_INCREMENT,event_uuid char(36) NOT NULL,origin varchar(20) NOT NULL,operation varchar(50) NOT NULL,
          actor_wp_id bigint(20) unsigned NOT NULL DEFAULT 0,target_wp_id bigint(20) unsigned NOT NULL DEFAULT 0,
          pair_a bigint(20) unsigned NOT NULL DEFAULT 0,pair_b bigint(20) unsigned NOT NULL DEFAULT 0,payload longtext NULL,
          status varchar(20) NOT NULL DEFAULT 'pending',attempts int unsigned NOT NULL DEFAULT 0,next_attempt_at datetime NOT NULL,
          last_error text NULL,processed_at datetime NULL,created_at datetime NOT NULL,updated_at datetime NOT NULL,
          PRIMARY KEY(id),UNIQUE KEY event_uuid(event_uuid),KEY queue(status,next_attempt_at),KEY pair(pair_a,pair_b)) $c;");
        update_option('bzj_connections_sync_schema_version',self::VERSION,false);
    }
    private function cron(){
        if(!wp_next_scheduled(self::RECOVERY)) wp_schedule_event(time()+120,'hourly',self::RECOVERY);
        if(!wp_next_scheduled(self::RECONCILE)) wp_schedule_event(time()+300,'hourly',self::RECONCILE);
    }
    private function log($m,$x=[]){
        $d=trailingslashit(ABSPATH).'data/logs'; if(!is_dir($d))wp_mkdir_p($d); if(!is_dir($d)||!is_writable($d))return;
        @file_put_contents($d.'/'.self::LOG_FILE,wp_json_encode(['time'=>gmdate('c'),'message'=>$m,'context'=>$x],JSON_UNESCAPED_SLASHES).PHP_EOL,FILE_APPEND|LOCK_EX);
    }
    private function startup_diagnostics(){
        if(get_transient('bzj_v841_startup_diag'))return; set_transient('bzj_v841_startup_diag',1,HOUR_IN_SECONDS);
        $this->log('v8.4.1 startup',[
          'wp_db'=>defined('DB_NAME')?DB_NAME:'unknown','ledger'=>$this->ledger,'events'=>$this->events,
          'streams'=>$this->db_info('streams'),'socials'=>$this->db_info('socials')
        ]);
    }

    public function routes(){
        register_rest_route(self::NS,self::ROUTE,['methods'=>WP_REST_Server::CREATABLE,'callback'=>[$this,'command'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS,self::ROUTE,['methods'=>WP_REST_Server::READABLE,'callback'=>[$this,'status'],'permission_callback'=>fn()=>current_user_can('manage_options')]);
        register_rest_route(self::NS,self::ROUTE.'/diagnostics',['methods'=>WP_REST_Server::READABLE,'callback'=>[$this,'diagnostics'],'permission_callback'=>fn()=>current_user_can('manage_options')]);
    }
    public function status($r){
        $a=absint($r->get_param('user_a'));$b=absint($r->get_param('user_b'));
        if($a<1||$b<1||$a===$b)return new WP_Error('bzj_pair','Two valid different user IDs required',['status'=>400]);
        return rest_ensure_response(['success'=>true,'version'=>self::VERSION,'relationship'=>$this->ledger_get($a,$b)]);
    }
    public function diagnostics($r){
        return rest_ensure_response(['success'=>true,'version'=>self::VERSION,'route'=>home_url('/wp-json/'.self::NS.self::ROUTE),
          'db'=>['streams'=>$this->db_info('streams'),'socials'=>$this->db_info('socials')],
          'hooks'=>['request'=>has_action('friends_friendship_requested',[$this,'bb_requested'])!==false,
          'accept'=>has_action('friends_friendship_accepted',[$this,'bb_accepted'])!==false,
          'withdraw'=>has_action('friends_friendship_withdrawn',[$this,'bb_withdrawn'])!==false,
          'follow'=>has_action('bp_start_following',[$this,'bb_follow_start'])!==false,
          'block_save'=>has_action('bp_moderation_after_save',[$this,'bb_moderation_saved'])!==false,
          'block_delete'=>has_action('bb_moderation_after_delete',[$this,'bb_moderation_deleted'])!==false],
          'logs'=>ABSPATH.'data/logs/'.self::LOG_FILE]);
    }
    public function command(WP_REST_Request $r){
        $raw=$r->get_body();$auth=$this->auth($r,$raw);if(is_wp_error($auth))return $auth;
        $p=json_decode($raw,true);if(!is_array($p))return new WP_Error('bzj_json','Malformed JSON',['status'=>400]);
        $o=sanitize_key($p['origin']??'');$platform_header=sanitize_key($r->get_header('X-BZJ-Platform'));if($platform_header!==$o)return new WP_Error('bzj_platform','Platform/origin mismatch',['status'=>403]);$op=sanitize_key($p['operation']??'');$uuid=sanitize_text_field($p['event_id']??'');
        $ae=absint($p['actor_id']??0);$te=absint($p['target_id']??0);
        if(!in_array($o,[self::O_STREAMS,self::O_SOCIALS],true))return new WP_Error('bzj_origin','Invalid origin',['status'=>400]);
        if(!in_array($op,[self::REQUEST,self::ACCEPT,self::REJECT,self::WITHDRAW,self::REMOVE,self::FOLLOW,self::UNFOLLOW,self::BLOCK,self::UNBLOCK],true))return new WP_Error('bzj_operation','Invalid operation',['status'=>400]);
        if(!$this->uuid($uuid)||$ae<1||$te<1||$ae===$te)return new WP_Error('bzj_payload','Invalid event/users',['status'=>400]);
        $a=$this->ext_to_wp($o,$ae);$b=$this->ext_to_wp($o,$te);
        if(!$a||!$b||$a===$b)return new WP_Error('bzj_mapping','External IDs are not mapped to WordPress users',['status'=>409]);
        if(isset($p['authenticated_id'])&&absint($p['authenticated_id'])!==$ae)return new WP_Error('bzj_actor','Authenticated actor mismatch',['status'=>403]);
        $old=$this->event_row($uuid);if($old)return rest_ensure_response(['success'=>true,'status'=>$old->status==='processed'?'already_processed':'accepted','event_id'=>$uuid,'relationship'=>$this->ledger_get($a,$b)]);
        if(!$this->lock($a,$b))return new WP_Error('bzj_locked','Pair is busy; retry',['status'=>503]);
        try{
            $this->event_insert($uuid,$o,$op,$a,$b,$p);
            $result=$this->external_operation($op,$a,$b,$uuid);
            if(is_wp_error($result)){ $this->retry($uuid,$result->get_error_message()); return $result; }
            $this->processed($uuid);
            return rest_ensure_response(['success'=>true,'status'=>'processed','event_id'=>$uuid,'relationship'=>$this->ledger_get($a,$b)]);
        }catch(Throwable $e){$this->retry($uuid,$e->getMessage());$this->log('REST operation failed',['event_id'=>$uuid,'operation'=>$op,'error'=>$e->getMessage()]);return new WP_Error('bzj_failed','Synchronization failed',['status'=>500,'event_id'=>$uuid]);}
        finally{$this->unlock($a,$b);}
    }
    private function auth($r,$raw){
        $ts=$r->get_header('X-BZJ-Timestamp');$sig=$r->get_header('X-BZJ-Signature');if(!$ts||!$sig||!ctype_digit((string)$ts))return new WP_Error('bzj_auth','Missing authentication',['status'=>401]);
        if(abs(time()-(int)$ts)>self::WINDOW)return new WP_Error('bzj_auth_time','Expired authentication',['status'=>401]);
        $platform=sanitize_key($r->get_header('X-BZJ-Platform'));if(!in_array($platform,[self::O_STREAMS,self::O_SOCIALS],true))return new WP_Error('bzj_platform','Missing or invalid X-BZJ-Platform header',['status'=>401]);$secret=$this->secret($platform);if(!$secret)return new WP_Error('bzj_secret','Synchronization secret unavailable',['status'=>503]);
        $expected=hash_hmac('sha256',$ts.'.'.$raw,$secret);if(!hash_equals($expected,trim($sig)))return new WP_Error('bzj_auth_sig','Invalid signature',['status'=>401]);return true;
    }
    private function secret($platform=''){
        $const=$platform==='streams'?'BZJ_STREAMS_SYNC_SECRET':($platform==='socials'?'BZJ_SOCIALS_SYNC_SECRET':'');
        if($const&&defined($const)&&constant($const))return constant($const);
        if(function_exists('bzj_get_sso_secret')&&bzj_get_sso_secret())return bzj_get_sso_secret();
        if(defined('BUZZ_SSO_SECRET')&&BUZZ_SSO_SECRET)return BUZZ_SSO_SECRET;
        return getenv('BUZZ_SSO_SECRET')?:'';
    }

    /* BuddyBoss -> external */
    private function bb_event($kind,$a,$b,$fid=0){
        if($a<1||$b<1||$a===$b||$this->internal())return;
        $uuid=wp_generate_uuid4();if(!$this->lock($a,$b)){ $this->event_insert($uuid,self::O_WP,'connection_'.$kind,$a,$b,['friendship_id'=>$fid]);$this->retry($uuid,'Pair lock busy');return;}
        try{
            $state='none';$req=0;
            if($kind==='requested'){$state='requested';$req=$a;}
            elseif($kind==='accepted')$state='connected';
            elseif(in_array($kind,['rejected','withdrawn'],true)){
                $s=$this->bb_state($a,$b);$state=$s==='is_friend'?'connected':($s==='pending'||$s==='awaiting_response'?'requested':'none');$req=$state==='requested'?$this->bb_requester($a,$b):0;
            }else{$state='none';}
            $uuid=$this->ensure_event_uuid($uuid,self::O_WP,'connection_'.$kind,$a,$b,['friendship_id'=>$fid]);
            $this->ledger_save($a,$b,['connection_state'=>$state,'requested_by'=>$req],$uuid);
            $this->project_connection($a,$b,$state,$uuid);
            $this->processed($uuid);
        }catch(Throwable $e){$this->retry($uuid,$e->getMessage());$this->log('BB connection projection failed',['kind'=>$kind,'a'=>$a,'b'=>$b,'error'=>$e->getMessage()]);}
        finally{$this->unlock($a,$b);}
    }
    public function bb_requested($fid,$initiator,$friend,$unused=null){$this->bb_event('requested',absint($initiator),absint($friend),absint($fid));}
    public function bb_accepted($fid,$initiator,$friend,$unused=null){$this->bb_event('accepted',absint($initiator),absint($friend),absint($fid));}
    private function friendship_obj($fid,$deleted=false){
        if(!is_object($fid)&&$fid&&class_exists('BP_Friends_Friendship'))return new BP_Friends_Friendship((int)$fid,true,$deleted?false:true);
        return is_object($fid)?$fid:null;
    }
    public function bb_rejected($fid,$friendship=null){
        if($this->internal())return;$f=$this->friendship_obj($fid,true);if(!$f)return;
        $this->bb_event('rejected',absint($f->initiator_user_id),absint($f->friend_user_id),absint($fid));
    }
    public function bb_withdrawn($fid,$friendship=null){
        if($this->internal())return;$f=$this->friendship_obj($fid,true);if(!$f)return;
        $this->bb_event('withdrawn',absint($f->initiator_user_id),absint($f->friend_user_id),absint($fid));
    }
    public function bb_deleted($fid,$initiator,$friend,$unused=null){if(!$this->internal())$this->bb_event('deleted',absint($initiator),absint($friend),absint($fid));}
    public function bb_post_deleted($initiator,$friend){if(!$this->internal())$this->bb_event('post_deleted',absint($initiator),absint($friend));}

    private function bb_follow($obj,$active){
        if($this->internal()||!is_object($obj))return;
        $f=absint($obj->follower_id??$obj->follower_user_id??0);$l=absint($obj->leader_id??$obj->leader_user_id??0);if(!$f||!$l||$f===$l)return;
        $uuid=wp_generate_uuid4();if(!$this->lock($f,$l)){ $this->event_insert($uuid,self::O_WP,$active?self::FOLLOW:self::UNFOLLOW,$f,$l);$this->retry($uuid,'Pair lock busy');return;}
        try{$this->ledger_save($f,$l,[ $this->follow_field($f,$l)=>$active?1:0],$uuid);$this->project_follow($f,$l,$active,'streams',$uuid);if($active)$this->processed($uuid);else $this->processed($uuid);}
        catch(Throwable $e){$this->retry($uuid,$e->getMessage());$this->log('BB follow projection failed',['actor'=>$f,'target'=>$l,'active'=>$active,'error'=>$e->getMessage()]);}
        finally{$this->unlock($f,$l);}
    }
    public function bb_follow_start($obj){$this->bb_follow($obj,true);}
    public function bb_follow_stop($obj){$this->bb_follow($obj,false);}

    public function bb_moderation_saved($m){
        if(!$this->is_block($m))return;$this->bb_block_event(self::BLOCK,absint($m->user_id),absint($m->item_id),absint($m->id??0));
    }
    public function bb_moderation_deleted($m){
        if(!$this->is_block($m))return;$this->bb_block_event(self::UNBLOCK,absint($m->user_id),absint($m->item_id),absint($m->id??0));
    }
    private function is_block($m){return is_object($m)&&($m->item_type??'')==='user'&&empty($m->user_report)&&absint($m->user_id)>0&&absint($m->item_id)>0;}
    private function bb_block_event($op,$a,$b,$mid){
        if($this->internal()||$a<1||$b<1||$a===$b)return;$uuid=wp_generate_uuid4();if(!$this->lock($a,$b)){$this->event_insert($uuid,self::O_WP,$op,$a,$b,['moderation_id'=>$mid]);$this->retry($uuid,'Pair lock busy');return;}
        try{
            $this->event_insert($uuid,self::O_WP,$op,$a,$b,['moderation_id'=>$mid]);
            if($op===self::BLOCK){
                $this->enforce_bb_block($a,$b,$uuid);
                $this->ledger_save($a,$b,[$this->block_field($a,$b)=>1,'connection_state'=>'none','requested_by'=>0,'follow_a_to_b'=>0,'follow_b_to_a'=>0],$uuid);
                $this->project_block($a,$b,true,'streams',$uuid);$this->project_block($a,$b,true,'socials',$uuid);
                $this->project_connection($a,$b,'none',$uuid);
            }else{
                $this->ledger_save($a,$b,[$this->block_field($a,$b)=>0],$uuid);
                $this->project_block($a,$b,false,'streams',$uuid);$this->project_block($a,$b,false,'socials',$uuid);
            }
            $this->processed($uuid);
        }catch(Throwable $e){$this->retry($uuid,$e->getMessage());$this->log('BB block projection failed',['operation'=>$op,'a'=>$a,'b'=>$b,'error'=>$e->getMessage()]);}
        finally{$this->unlock($a,$b);}
    }
    private function enforce_bb_block($a,$b,$uuid){
        if(function_exists('friends_check_friendship_status')&&function_exists('friends_remove_friend')&&friends_check_friendship_status($a,$b)==='is_friend'){
            $this->push(['event_uuid'=>$uuid]);try{friends_remove_friend($a,$b);}finally{$this->pop();}
        }
        if(function_exists('bp_stop_following')){
            foreach([[$a,$b],[$b,$a]] as $x){if(function_exists('bp_is_following')&&bp_is_following(['leader_id'=>$x[1],'follower_id'=>$x[0]])){
                $this->push(['event_uuid'=>$uuid]);try{bp_stop_following(['leader_id'=>$x[1],'follower_id'=>$x[0]]);}finally{$this->pop();}
            }}
        }
    }

    /* External -> BuddyBoss */
    private function external_operation($op,$a,$b,$uuid){
        if($op===self::REQUEST)return $this->bb_request($a,$b);
        if($op===self::ACCEPT)return $this->bb_accept($a,$b);
        if($op===self::REJECT)return $this->bb_reject($a,$b);
        if($op===self::WITHDRAW)return $this->bb_withdraw($a,$b);
        if($op===self::REMOVE)return $this->bb_remove($a,$b);
        if($op===self::FOLLOW)return $this->bb_follow_ext($a,$b);
        if($op===self::UNFOLLOW)return $this->bb_unfollow_ext($a,$b);
        if($op===self::BLOCK)return $this->bb_block_ext($a,$b,$uuid);
        if($op===self::UNBLOCK)return $this->bb_unblock_ext($a,$b,$uuid);
        return new WP_Error('bzj_unknown','Unknown operation');
    }
    private function bb_request($a,$b){
        if($this->bb_blocked($a,$b))return new WP_Error('bzj_blocked','Blocked pair cannot connect.');
        if(!function_exists('friends_add_friend'))return new WP_Error('bzj_bb','BuddyBoss functions unavailable.');
        $s=$this->bb_state($a,$b);if($s==='is_friend'||$s==='pending')return true;if($s==='awaiting_response')return new WP_Error('bzj_reverse','Reverse request already pending.');
        if(!friends_add_friend($a,$b))return new WP_Error('bzj_request_failed','BuddyBoss rejected connection request.');return true;
    }
    private function bb_accept($a,$b){
        if(!function_exists('friends_accept_friendship'))return new WP_Error('bzj_bb','BuddyBoss functions unavailable.');
        $fid=function_exists('friends_get_friendship_id')?(int)friends_get_friendship_id($b,$a):0;if(!$fid&&function_exists('friends_get_friendship_id'))$fid=(int)friends_get_friendship_id($a,$b);
        if(!$fid)return new WP_Error('bzj_missing_request','No pending request found.');
        if(!friends_accept_friendship($fid)&&$this->bb_state($a,$b)!=='is_friend')return new WP_Error('bzj_accept_failed','BuddyBoss could not accept request.');return true;
    }
    private function bb_reject($a,$b){
        if(!function_exists('friends_reject_friendship'))return new WP_Error('bzj_bb','BuddyBoss functions unavailable.');
        $fid=function_exists('friends_get_friendship_id')?(int)friends_get_friendship_id($b,$a):0;if(!$fid&&function_exists('friends_get_friendship_id'))$fid=(int)friends_get_friendship_id($a,$b);
        if($fid&&!friends_reject_friendship($fid)&&$this->bb_state($a,$b)!=='not_friends')return new WP_Error('bzj_reject_failed','BuddyBoss could not reject request.');return true;
    }
    private function bb_withdraw($a,$b){
        if(!function_exists('friends_withdraw_friendship'))return new WP_Error('bzj_bb','BuddyBoss functions unavailable.');
        if(!friends_withdraw_friendship($a,$b)&&$this->bb_state($a,$b)!=='not_friends')return new WP_Error('bzj_withdraw_failed','BuddyBoss could not withdraw request.');return true;
    }
    private function bb_remove($a,$b){
        if(!function_exists('friends_remove_friend'))return new WP_Error('bzj_bb','BuddyBoss functions unavailable.');
        if($this->bb_state($a,$b)==='is_friend'&&!friends_remove_friend($a,$b)&&!friends_remove_friend($b,$a))return new WP_Error('bzj_remove_failed','BuddyBoss could not remove connection.');return true;
    }
    private function bb_follow_ext($a,$b){
        if($this->bb_blocked($a,$b))return new WP_Error('bzj_blocked','Blocked pair cannot follow.');
        if(!function_exists('bp_start_following'))return new WP_Error('bzj_bb','BuddyBoss follow unavailable.');
        if(function_exists('bp_is_following')&&bp_is_following(['leader_id'=>$b,'follower_id'=>$a]))return true;
        $r=bp_start_following(['leader_id'=>$b,'follower_id'=>$a]);if(is_wp_error($r))return $r;
        if($r===false&&function_exists('bp_is_following')&&!bp_is_following(['leader_id'=>$b,'follower_id'=>$a]))return new WP_Error('bzj_follow_failed','BuddyBoss rejected follow.');return true;
    }
    private function bb_unfollow_ext($a,$b){
        if(!function_exists('bp_stop_following'))return new WP_Error('bzj_bb','BuddyBoss follow unavailable.');
        if(function_exists('bp_is_following')&&!bp_is_following(['leader_id'=>$b,'follower_id'=>$a]))return true;
        $r=bp_stop_following(['leader_id'=>$b,'follower_id'=>$a]);if(is_wp_error($r))return $r;
        if($r===false&&function_exists('bp_is_following')&&bp_is_following(['leader_id'=>$b,'follower_id'=>$a]))return new WP_Error('bzj_unfollow_failed','BuddyBoss rejected unfollow.');return true;
    }
    private function bb_block_ext($a,$b,$uuid){
        if(!class_exists('BP_Moderation')||!class_exists('BP_Moderation_Members'))return new WP_Error('bzj_moderation','BuddyBoss moderation unavailable.');
        if(!$this->bb_block_exists($a,$b)){
            $m=new BP_Moderation($b,BP_Moderation_Members::$moderation_type,$a);$m->user_report=0;$m->content='';
            $this->push(['event_uuid'=>$uuid,'origin'=>'external','operation'=>self::BLOCK]);try{if(!$m->save())return new WP_Error('bzj_block_failed','Could not create BuddyBoss block.');}finally{$this->pop();}
        }
        $this->enforce_bb_block($a,$b,$uuid);
        $this->ledger_save($a,$b,[$this->block_field($a,$b)=>1,'connection_state'=>'none','requested_by'=>0,'follow_a_to_b'=>0,'follow_b_to_a'=>0],$uuid);
        $this->project_block($a,$b,true,'streams',$uuid);$this->project_block($a,$b,true,'socials',$uuid);$this->project_connection($a,$b,'none',$uuid);
        return true;
    }
    private function bb_unblock_ext($a,$b,$uuid){
        if(!class_exists('BP_Moderation')||!class_exists('BP_Moderation_Members'))return new WP_Error('bzj_moderation','BuddyBoss moderation unavailable.');
        $m=new BP_Moderation($b,BP_Moderation_Members::$moderation_type,$a);
        if(!empty($m->id)&&empty($m->user_report)){ $this->push(['event_uuid'=>$uuid,'origin'=>'external','operation'=>self::UNBLOCK]);try{if(!$m->delete(false))return new WP_Error('bzj_unblock_failed','Could not remove BuddyBoss block.');}finally{$this->pop();}}
        $this->ledger_save($a,$b,[$this->block_field($a,$b)=>0],$uuid);
        $this->project_block($a,$b,false,'streams',$uuid);$this->project_block($a,$b,false,'socials',$uuid);
        return true;
    }

    /* Projections */
    private function project_follow($a,$b,$active,$platform,$uuid){
        $ea=$this->wp_to_ext($a,$platform);$eb=$this->wp_to_ext($b,$platform);if(!$ea||!$eb){$this->queue($platform,$active?self::FOLLOW:self::UNFOLLOW,$a,$b,$uuid,['reason'=>'missing_mapping']);return false;}
        $db=$this->db($platform);if(!$db){$this->queue($platform,$active?self::FOLLOW:self::UNFOLLOW,$a,$b,$uuid,['reason'=>'db_unavailable']);return false;}
        try{$table=$this->follow_table($db,$platform);if(!$table)throw new RuntimeException('followers table missing');
            if($active)$this->upsert_follow($db,$table,$eb,$ea);else $this->delete_follow_safe($db,$table,$eb,$ea,$a,$b);
            $this->verify_follow($db,$table,$eb,$ea,$active,$platform,$a,$b);return true;
        }catch(Throwable $e){$this->queue($platform,$active?self::FOLLOW:self::UNFOLLOW,$a,$b,$uuid,['error'=>$e->getMessage()]);$this->log('Follow projection failed',['platform'=>$platform,'a'=>$a,'b'=>$b,'error'=>$e->getMessage()]);return false;}
    }
    private function project_connection($a,$b,$state,$uuid){
        $qa=$this->wp_to_ext($a,'socials');$qb=$this->wp_to_ext($b,'socials');$db=$this->db('socials');
        if(!$qa||!$qb||!$db){$this->queue('socials','connection_'.$state,$a,$b,$uuid);return false;}
        try{
            if($state==='requested'){ $l=$this->ledger_get($a,$b);$r=absint($l['requested_by']);$recipient=$r===$a?$b:$a;$qr=$this->wp_to_ext($r,'socials');$qt=$this->wp_to_ext($recipient,'socials');if(!$qr||!$qt)throw new RuntimeException('Requester mapping missing');$this->qd_set_friend($db,$qr,$qt,0); }
            elseif($state==='connected'){ $this->qd_set_friend($db,$qa,$qb,1);$this->qd_set_friend($db,$qb,$qa,1); }
            else $this->qd_remove_connection_only($db,$a,$b);
            $this->log('QuickDate connection projection',['operation'=>$state,'wp_a'=>$a,'wp_b'=>$b,'qd_a'=>$qa,'qd_b'=>$qb,'db'=>$this->db_name($db),'table'=>'followers','event_id'=>$uuid]);
            return true;
        }catch(Throwable $e){$this->queue('socials','connection_'.$state,$a,$b,$uuid,['error'=>$e->getMessage()]);$this->log('QuickDate connection projection failed',['error'=>$e->getMessage(),'event_id'=>$uuid]);return false;}
    }
    private function project_block($a,$b,$blocked,$platform,$uuid){
        $ea=$this->wp_to_ext($a,$platform);$eb=$this->wp_to_ext($b,$platform);$db=$this->db($platform);if(!$ea||!$eb||!$db){$this->queue($platform,$blocked?self::BLOCK:self::UNBLOCK,$a,$b,$uuid);return false;}
        try{$ft=$this->follow_table($db,$platform);$bt=$this->block_table($db,$platform);if(!$bt)throw new RuntimeException('blocks table missing');
            if($blocked){$this->set_block($db,$bt,$ea,$eb,$platform);if($ft)$this->delete_pair($db,$ft,$ea,$eb);if($platform==='socials')$this->delete_social_rows($db,$ft,$ea,$eb);}
            else $this->delete_block($db,$bt,$ea,$eb,$platform);
            $this->log('External block projection',['platform'=>$platform,'operation'=>$blocked?self::BLOCK:self::UNBLOCK,'wp_actor'=>$a,'wp_target'=>$b,'external_actor'=>$ea,'external_target'=>$eb,'db'=>$this->db_name($db),'block_table'=>$bt,'event_id'=>$uuid]);
            return true;
        }catch(Throwable $e){$this->queue($platform,$blocked?self::BLOCK:self::UNBLOCK,$a,$b,$uuid,['error'=>$e->getMessage()]);$this->log('Block projection failed',['platform'=>$platform,'error'=>$e->getMessage(),'event_id'=>$uuid]);return false;}
    }

    private function upsert_follow($db,$table,$following,$follower){
        $s=$db->prepare("SELECT id FROM `$table` WHERE following_id=? AND follower_id=? LIMIT 1");if(!$s)throw new RuntimeException($db->error);$s->bind_param('ii',$following,$follower);$s->execute();$r=$s->get_result();$row=$r?$r->fetch_assoc():null;$s->close();
        if($row){$s=$db->prepare("UPDATE `$table` SET active=1 WHERE id=?");if(!$s)throw new RuntimeException($db->error);$id=(int)$row['id'];$s->bind_param('i',$id);if(!$s->execute())throw new RuntimeException($s->error);$s->close();return;}
        $cols=$this->columns($db,$table);$fields='following_id,follower_id,active';$vals='?,?,1';$types='ii';$params=[$following,$follower];
        if(isset($cols['created_at'])){$fields.=',created_at';$vals.=',?';$types.='i';$params[]=time();}
        $s=$db->prepare("INSERT INTO `$table` ($fields) VALUES ($vals)");if(!$s)throw new RuntimeException($db->error);
        if($types==='iii')$s->bind_param('iii',$params[0],$params[1],$params[2]);else $s->bind_param('ii',$params[0],$params[1]);
        if(!$s->execute())throw new RuntimeException($s->error);$s->close();
    }
    private function delete_follow_safe($db,$table,$following,$follower,$a,$b){
        $l=$this->ledger_get($a,$b);$pair=$this->pair($a,$b);$keepA=!empty($l['follow_a_to_b']);$keepB=!empty($l['follow_b_to_a']);
        if($following===$this->wp_to_ext($b,'streams')&&$follower===$this->wp_to_ext($a,'streams'))$keepA=false;
        if(!$keepA&&!$keepB){$this->delete_pair($db,$table,$following,$follower);return;}
        if(!$keepA){$ea=$this->wp_to_ext($pair[0],'streams');$eb=$this->wp_to_ext($pair[1],'streams');$this->delete_one($db,$table,$eb,$ea);}
        if(!$keepB){$ea=$this->wp_to_ext($pair[0],'streams');$eb=$this->wp_to_ext($pair[1],'streams');$this->delete_one($db,$table,$ea,$eb);}
    }
    private function verify_follow($db,$table,$following,$follower,$active,$platform,$a,$b){
        $s=$db->prepare("SELECT active FROM `$table` WHERE following_id=? AND follower_id=? LIMIT 1");if(!$s)throw new RuntimeException($db->error);$s->bind_param('ii',$following,$follower);$s->execute();$r=$s->get_result();$row=$r?$r->fetch_assoc():null;$s->close();
        if($active && (!$row||((int)$row['active']!==1)))throw new RuntimeException('Read-back verification failed for follow');
        if(!$active && $row)throw new RuntimeException('Read-back verification failed for unfollow');
    }
    private function ledger_follow_expected($a,$b,$platform,$following,$follower){return false;}
    private function qd_set_friend($db,$requester,$recipient,$active){
        $t=$this->follow_table($db,'socials');$s=$db->prepare("SELECT id FROM `$t` WHERE following_id=? AND follower_id=? LIMIT 1");if(!$s)throw new RuntimeException($db->error);$s->bind_param('ii',$recipient,$requester);$s->execute();$r=$s->get_result();$row=$r?$r->fetch_assoc():null;$s->close();
        if($row){$id=(int)$row['id'];$s=$db->prepare("UPDATE `$t` SET active=? WHERE id=?");if(!$s)throw new RuntimeException($db->error);$v=$active?1:0;$s->bind_param('ii',$v,$id);if(!$s->execute())throw new RuntimeException($s->error);$s->close();}
        else{$cols=$this->columns($db,$t);$fields='following_id,follower_id,active';$vals='?,?,?';$types='iii';$p=[$recipient,$requester,$active?1:0];if(isset($cols['created_at'])){$fields.=',created_at';$vals.=',?';$types='iiii';$p[]=time();}$s=$db->prepare("INSERT INTO `$t` ($fields) VALUES ($vals)");if(!$s)throw new RuntimeException($db->error);if($types==='iiii')$s->bind_param('iiii',$p[0],$p[1],$p[2],$p[3]);else $s->bind_param('iii',$p[0],$p[1],$p[2]);if(!$s->execute())throw new RuntimeException($s->error);$s->close();}
    }
    private function qd_remove_connection_only($db,$a,$b){
        $t=$this->follow_table($db,'socials');$qa=$this->wp_to_ext($a,'socials');$qb=$this->wp_to_ext($b,'socials');$l=$this->ledger_get($a,$b);
        /* Keep a direction if BuddyBoss still has the corresponding ordinary follow. */
        if(empty($l['follow_a_to_b']))$this->delete_one($db,$t,$qb,$qa);
        if(empty($l['follow_b_to_a']))$this->delete_one($db,$t,$qa,$qb);
    }
    private function delete_pair($db,$t,$a,$b){$s=$db->prepare("DELETE FROM `$t` WHERE (following_id=? AND follower_id=?) OR (following_id=? AND follower_id=?)");if(!$s)throw new RuntimeException($db->error);$s->bind_param('iiii',$a,$b,$b,$a);if(!$s->execute())throw new RuntimeException($s->error);$n=$s->affected_rows;$s->close();return $n;}
    private function delete_one($db,$t,$a,$b){$s=$db->prepare("DELETE FROM `$t` WHERE following_id=? AND follower_id=?");if(!$s)throw new RuntimeException($db->error);$s->bind_param('ii',$a,$b);if(!$s->execute())throw new RuntimeException($s->error);$s->close();}
    private function set_block($db,$t,$a,$b,$p){$s=$p==='streams'?$db->prepare("SELECT id FROM `$t` WHERE blocker=? AND blocked=? LIMIT 1"):$db->prepare("SELECT id FROM `$t` WHERE user_id=? AND block_userid=? LIMIT 1");if(!$s)throw new RuntimeException($db->error);$s->bind_param('ii',$a,$b);$s->execute();$r=$s->get_result();$row=$r?$r->fetch_assoc():null;$s->close();if($row)return;
        if($p==='streams')$s=$db->prepare("INSERT INTO `$t` (blocker,blocked) VALUES (?,?)");else{$cols=$this->columns($db,$t);$s=isset($cols['created_at'])?$db->prepare("INSERT INTO `$t` (user_id,block_userid,created_at) VALUES (?,?,?)"):$db->prepare("INSERT INTO `$t` (user_id,block_userid) VALUES (?,?)");}
        if(!$s)throw new RuntimeException($db->error);if($p==='socials'&&isset($cols['created_at'])){$now=time();$s->bind_param('iii',$a,$b,$now);}else $s->bind_param('ii',$a,$b);if(!$s->execute())throw new RuntimeException($s->error);$s->close();}
    private function delete_block($db,$t,$a,$b,$p){$q=$p==='streams'?"DELETE FROM `$t` WHERE blocker=? AND blocked=?":"DELETE FROM `$t` WHERE user_id=? AND block_userid=?";$s=$db->prepare($q);if(!$s)throw new RuntimeException($db->error);$s->bind_param('ii',$a,$b);if(!$s->execute())throw new RuntimeException($s->error);$s->close();}
    private function delete_social_rows($db,$t,$a,$b){if(!$t)return;$this->delete_pair($db,$t,$a,$b);}
    private function follow_table($db,$p){return $this->first_table($db,$p==='streams'?['Wo_Followers','wo_followers','followers']:['followers']);}
    private function block_table($db,$p){return $this->first_table($db,$p==='streams'?['Wo_Blocks','wo_blocks','blocks']:['blocks']);}
    private function first_table($db,$arr){foreach($arr as $t)if($this->table($db,$t))return $t;return false;}
    private function table($db,$t){$s=$db->prepare("SHOW TABLES LIKE ?");if(!$s)return false;$s->bind_param('s',$t);$s->execute();$r=$s->get_result();$ok=$r&&$r->num_rows>0;$s->close();return $ok;}
    private function columns($db,$t){$o=[];$r=$db->query("SHOW COLUMNS FROM `".preg_replace('/[^A-Za-z0-9_]/','',$t)."`");if($r){while($x=$r->fetch_assoc())$o[strtolower($x['Field'])]=true;$r->free();}return $o;}

    /* Ledger */
    private function pair($a,$b){$a=(int)$a;$b=(int)$b;return $a<$b?[$a,$b]:[$b,$a];}
    private function ledger_get($a,$b){global $wpdb;$p=$this->pair($a,$b);$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->ledger} WHERE user_a=%d AND user_b=%d LIMIT 1",$p[0],$p[1]),ARRAY_A);return $r?:['user_a'=>$p[0],'user_b'=>$p[1],'connection_state'=>'none','requested_by'=>0,'follow_a_to_b'=>0,'follow_b_to_a'=>0,'block_a_to_b'=>0,'block_b_to_a'=>0,'version'=>0,'last_event_uuid'=>''];}
    private function ledger_save($a,$b,$changes,$uuid=''){global $wpdb;$p=$this->pair($a,$b);$old=$this->ledger_get($a,$b);$now=gmdate('Y-m-d H:i:s');$data=$changes;$data['user_a']=$p[0];$data['user_b']=$p[1];$data['updated_at']=$now;$data['version']=((int)($old['version']??0))+1;if($uuid)$data['last_event_uuid']=$uuid;if(empty($old['version'])){$data['created_at']=$now;$wpdb->insert($this->ledger,$data);}else{$wpdb->update($this->ledger,$data,['user_a'=>$p[0],'user_b'=>$p[1]]);}return $this->ledger_get($a,$b);}
    private function follow_field($a,$b){$p=$this->pair($a,$b);return (int)$a===$p[0]?'follow_a_to_b':'follow_b_to_a';}
    private function block_field($a,$b){$p=$this->pair($a,$b);return (int)$a===$p[0]?'block_a_to_b':'block_b_to_a';}

    /* BB state */
    private function bb_state($a,$b){return function_exists('friends_check_friendship_status')?friends_check_friendship_status($a,$b):'not_friends';}
    private function bb_requester($a,$b){$s=$this->bb_state($a,$b);return $s==='pending'?$a:($s==='awaiting_response'?$b:0);}
    private function bb_follow_exists($a,$b){return function_exists('bp_is_following')&&bp_is_following(['leader_id'=>$b,'follower_id'=>$a]);}
    private function bb_blocked($a,$b){return $this->bb_block_exists($a,$b)||$this->bb_block_exists($b,$a);}
    private function bb_block_exists($a,$b){if(class_exists('BP_Moderation')&&class_exists('BP_Moderation_Members')){$m=new BP_Moderation($b,BP_Moderation_Members::$moderation_type,$a);if(!empty($m->id)&&empty($m->user_report))return true;}$l=$this->ledger_get($a,$b);$f=$this->block_field($a,$b);return !empty($l[$f]);}

    /* DB helpers / mappings */
    private function helpers(){static $ok=null;if($ok!==null)return $ok;$paths=[ABSPATH.'shared/db_helpers.php',dirname(ABSPATH).'/shared/db_helpers.php'];foreach($paths as $p)if(is_file($p)){require_once $p;$ok=true;return true;}$ok=false;$this->log('db_helpers.php not found',['paths'=>$paths]);return false;}
    private function db($p){if(!$this->helpers())return false;$d=$p==='streams'&&function_exists('get_wowonder_db')?get_wowonder_db():($p==='socials'&&function_exists('get_qd_db_conn')?get_qd_db_conn():false);return $d instanceof mysqli?$d:false;}
    private function db_name($db){$r=$db->query("SELECT DATABASE() AS db");$x=$r?$r->fetch_assoc():null;return $x['db']??'unknown';}
    private function db_info($p){$d=$this->db($p);if(!$d)return ['connected'=>false];$tables=$p==='streams'?['Wo_Followers','Wo_Blocks']:['followers','blocks'];$x=['connected'=>true,'database'=>$this->db_name($d),'tables'=>[]];foreach($tables as $t)$x['tables'][$t]=$this->table($d,$t);return $x;}
    private function wp_to_ext($wp,$p){return absint(get_user_meta((int)$wp,$p==='streams'?'wo_user_id':'qd_user_id',true));}
    private function ext_to_wp($p,$id){global $wpdb;$k=$p==='streams'?'wo_user_id':'qd_user_id';return (int)$wpdb->get_var($wpdb->prepare("SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key=%s AND meta_value=%s ORDER BY umeta_id ASC LIMIT 1",$k,(string)(int)$id));}

    /* Durable events */
    private function uuid($u){return (bool)preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i',$u);}
    private function event_row($u){global $wpdb;return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->events} WHERE event_uuid=%s LIMIT 1",$u));}
    private function event_insert($u,$o,$op,$a,$b,$p=[]){global $wpdb;if($this->event_row($u))return true;$pair=$this->pair($a,$b);$now=gmdate('Y-m-d H:i:s');return false!==$wpdb->insert($this->events,['event_uuid'=>$u,'origin'=>sanitize_key($o),'operation'=>sanitize_key($op),'actor_wp_id'=>$a,'target_wp_id'=>$b,'pair_a'=>$pair[0],'pair_b'=>$pair[1],'payload'=>wp_json_encode($p),'status'=>'pending','attempts'=>0,'next_attempt_at'=>$now,'created_at'=>$now,'updated_at'=>$now]);}
    private function ensure_event_uuid($u,$o,$op,$a,$b,$p){$this->event_insert($u,$o,$op,$a,$b,$p);return $u;}
    private function processed($u){global $wpdb;$wpdb->update($this->events,['status'=>'processed','processed_at'=>gmdate('Y-m-d H:i:s'),'updated_at'=>gmdate('Y-m-d H:i:s'),'last_error'=>null],['event_uuid'=>$u]);}
    private function retry($u,$e){global $wpdb;$r=$this->event_row($u);$n=$r?(int)$r->attempts+1:1;$status=$n>=self::MAX_ATTEMPTS?'failed':'pending';$next=gmdate('Y-m-d H:i:s',time()+min(3600,max(60,2**min(10,$n))));$wpdb->update($this->events,['status'=>$status,'attempts'=>$n,'next_attempt_at'=>$next,'last_error'=>substr((string)$e,0,65000),'updated_at'=>gmdate('Y-m-d H:i:s')],['event_uuid'=>$u]);}
    private function queue($platform,$op,$a,$b,$parent,$payload=[]){$u=wp_generate_uuid4();$payload['projection']=true;$payload['parent_event']=$parent;$this->event_insert($u,$platform,$op,$a,$b,$payload);return $u;}
    public function recovery(){global $wpdb;$rows=$wpdb->get_results("SELECT * FROM {$this->events} WHERE status='pending' AND next_attempt_at<=UTC_TIMESTAMP() ORDER BY id ASC LIMIT 50");foreach((array)$rows as $r)$this->replay($r);}
    private function replay($r){$a=(int)$r->actor_wp_id;$b=(int)$r->target_wp_id;if(!$a||!$b)return;if(!$this->lock($a,$b))return;try{$op=$r->operation;$ok=true;
        if($r->origin===self::O_WP){$l=$this->ledger_get($a,$b);if(strpos($op,'connection_')===0)$ok=$this->project_connection($a,$b,$l['connection_state'],$r->event_uuid);elseif($op===self::FOLLOW||$op===self::UNFOLLOW)$ok=$this->project_follow($a,$b,$op===self::FOLLOW,'streams',$r->event_uuid);elseif($op===self::BLOCK||$op===self::UNBLOCK){$ok=$this->project_block($a,$b,$op===self::BLOCK,'streams',$r->event_uuid)&&$this->project_block($a,$b,$op===self::BLOCK,'socials',$r->event_uuid);}}
        elseif(in_array($r->origin,[self::O_STREAMS,self::O_SOCIALS],true)){ $ok=!is_wp_error($this->external_operation($op,$a,$b,$r->event_uuid));}
        if($ok)$this->processed($r->event_uuid);else $this->retry($r->event_uuid,'Recovery projection failed');
    }catch(Throwable $e){$this->retry($r->event_uuid,$e->getMessage());}finally{$this->unlock($a,$b);}}
    public function reconcile(){global $wpdb;$rows=$wpdb->get_results("SELECT user_a,user_b FROM {$this->ledger} WHERE updated_at>=UTC_TIMESTAMP()-INTERVAL 2 DAY ORDER BY updated_at DESC LIMIT 250");foreach((array)$rows as $r){$a=(int)$r->user_a;$b=(int)$r->user_b;if(!$this->lock($a,$b))continue;try{$this->reconcile_pair($a,$b);}finally{$this->unlock($a,$b);}}}
    private function reconcile_pair($a,$b){$state=$this->bb_state($a,$b);$cs=$state==='is_friend'?'connected':($state==='pending'?'requested':($state==='awaiting_response'?'requested':'none'));$l=$this->ledger_get($a,$b);if(!empty($l['block_a_to_b'])||!empty($l['block_b_to_a'])){$cs='none';}$this->ledger_save($a,$b,['connection_state'=>$cs,'requested_by'=>$cs==='requested'?$this->bb_requester($a,$b):0,'follow_a_to_b'=>$this->bb_follow_exists($a,$b)?1:0,'follow_b_to_a'=>$this->bb_follow_exists($b,$a)?1:0,'block_a_to_b'=>$this->bb_block_exists($a,$b)?1:0,'block_b_to_a'=>$this->bb_block_exists($b,$a)?1:0],wp_generate_uuid4());$this->project_canonical($a,$b);}
    private function project_canonical($a,$b){$l=$this->ledger_get($a,$b);if(!empty($l['block_a_to_b'])){$this->project_block($a,$b,true,'streams',$l['last_event_uuid']);$this->project_block($a,$b,true,'socials',$l['last_event_uuid']);return;}if(!empty($l['block_b_to_a'])){$this->project_block($b,$a,true,'streams',$l['last_event_uuid']);$this->project_block($b,$a,true,'socials',$l['last_event_uuid']);return;}$this->project_connection($a,$b,$l['connection_state'],$l['last_event_uuid']);$this->project_follow($a,$b,!empty($l['follow_a_to_b']),'streams',$l['last_event_uuid']);$this->project_follow($b,$a,!empty($l['follow_b_to_a']),'streams',$l['last_event_uuid']);}

    /* Pair locks / internal context */
    private function lock($a,$b){global $wpdb;$p=$this->pair($a,$b);$k='bzj_pair_'.$p[0].'_'.$p[1];$ok=$wpdb->get_var($wpdb->prepare("SELECT GET_LOCK(%s,15)",$k));if((int)$ok===1){$this->locks[]=$k;return true;}return false;}
    private function unlock($a,$b){global $wpdb;$p=$this->pair($a,$b);$k='bzj_pair_'.$p[0].'_'.$p[1];$wpdb->get_var($wpdb->prepare("SELECT RELEASE_LOCK(%s)",$k));}
    private function push($c){$this->ctx[]=$c;}private function pop(){array_pop($this->ctx);}private function internal(){return !empty($this->ctx);}
}
BZJ_Connections_Sync::instance();
