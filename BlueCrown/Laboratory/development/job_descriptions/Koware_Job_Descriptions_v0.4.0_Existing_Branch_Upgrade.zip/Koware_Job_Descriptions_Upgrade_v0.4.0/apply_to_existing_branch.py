#!/usr/bin/env python3
"""Safely preview/apply v0.4.0 job descriptions to the EXISTING Koware dev branch.

By default the program makes no changes. --apply requires an existing clean checkout
of employment/job-descriptions-v0.1.0; it copies the role records onto their
same tracked paths, makes Git-internal backups, and NEVER commits/pushes.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

PACKAGE = Path(__file__).resolve().parent
BRANCH = "employment/job-descriptions-v0.1.0"
INDEX_PATH = Path("BlueCrown/Employment_Resources/JOB_DESCRIPTIONS_INDEX.md")
ROLE_DIR = Path("BlueCrown/Employment_Resources/Job_Descriptions")


def git(*args: str, cwd: Path) -> str:
    p = subprocess.run(["git", *args],cwd=cwd,capture_output=True,text=True)
    if p.returncode:
        raise RuntimeError(f"git {' '.join(args)} failed: {p.stderr.strip()}")
    return p.stdout.strip()


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repository",help="Path to local Koware_Management git checkout")
    parser.add_argument("--apply",action="store_true",help="Actually copy the validated role files after Git checks")
    args=parser.parse_args()
    repo=Path(args.repository).expanduser().resolve()
    if not repo.is_dir():
        raise RuntimeError(f"Repository folder not found: {repo}")
    root=Path(git("rev-parse","--show-toplevel",cwd=repo)).resolve()
    if root != repo:
        raise RuntimeError(f"Provide the repository ROOT, not a subfolder: {root}")
    branch=git("branch","--show-current",cwd=repo)
    if branch!=BRANCH:
        raise RuntimeError(f"Expected branch '{BRANCH}', got '{branch or 'detached HEAD'}'. Switch to the existing development branch first.")
    if not (repo/INDEX_PATH).is_file():
        raise RuntimeError(f"Existing collection index not found at {repo/INDEX_PATH}; cannot create an unrelated second collection")
    baseline=list((repo/ROLE_DIR).rglob("*_job_role.md"))
    if len(baseline) < 60:
        raise RuntimeError(f"Existing collection seems incomplete ({len(baseline)} job files); stop and inspect before applying")
    # Run the release validator BEFORE considering any writes.
    checker=subprocess.run([sys.executable,str(PACKAGE/"validate_collection.py")],capture_output=True,text=True)
    if checker.returncode:
        raise RuntimeError("Release integrity validation failed:\n"+checker.stdout+checker.stderr)
    source=PACKAGE/"BlueCrown"
    payload=sorted(p for p in source.rglob("*") if p.is_file())
    assert len(payload)==69, f"Unexpected payload size ({len(payload)} files)"
    additions=[]; changes=[]; same=[]
    for file in payload:
        rel=file.relative_to(PACKAGE)
        target=repo/rel
        if not target.exists(): additions.append(rel)
        elif target.read_bytes()==file.read_bytes(): same.append(rel)
        else: changes.append(rel)
    print("Koware Group Job Descriptions — existing-branch upgrade v0.4.0")
    print(f"Local repository: {repo}\nBranch: {branch}\nExisting role files detected: {len(baseline)}")
    print(f"Payload: {len(payload)} files = {len(changes)} changed, {len(additions)} added, {len(same)} identical")
    print("Source titles kept: Liaison Assistant (line 14); Liaison Personnel (line 17).")
    print("All current job-role paths preserved, including LIAISON_PERSONNEL; no deletions planned.")
    if additions:
        print("New supporting files:")
        for x in additions: print("  + "+str(x))
    if not args.apply:
        print("\nPREVIEW ONLY. Nothing changed. For installation, run again with --apply on a clean checkout.")
        return 0
    dirty=git("status","--porcelain=v1","--untracked-files=all",cwd=repo)
    if dirty:
        raise RuntimeError("Working tree is not clean. Commit/stash existing work first; refusing to overwrite files.")
    gitdir=Path(git("rev-parse","--absolute-git-dir",cwd=repo)).resolve()
    timestamp=dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup=gitdir/"koware-job-description-backups"/timestamp
    if backup.exists():
        raise RuntimeError(f"Backup folder already exists: {backup}")
    backup.mkdir(parents=True)
    replaced=[]; created=[]
    try:
        # Back up all overwritten material in .git (not as a duplicate published collection).
        for rel in changes:
            dest=backup/rel
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(repo/rel,dest)
            replaced.append(rel)
        for file in payload:
            rel=file.relative_to(PACKAGE)
            dest=repo/rel
            dest.parent.mkdir(parents=True,exist_ok=True)
            if not dest.exists(): created.append(rel)
            shutil.copy2(file,dest)
        # Verify exact published payload: don't silently leave a partial upgrade.
        for file in payload:
            rel=file.relative_to(PACKAGE)
            if (repo/rel).read_bytes()!=file.read_bytes():
                raise OSError(f"Post-copy integrity check failed for {rel}")
    except Exception:
        for rel in replaced:
            if (backup/rel).exists(): shutil.copy2(backup/rel,repo/rel)
        for rel in created:
            (repo/rel).unlink(missing_ok=True)
        raise
    print("\nAPPLIED onto the EXISTING branch; NOT COMMITTED OR PUSHED.")
    print(f"Backups saved inside Git metadata: {backup}")
    print("Review: git diff --stat && git diff -- BlueCrown/Employment_Resources")
    print("After approvals: git add BlueCrown/Employment_Resources && git commit -m 'Refactor Koware role canon v0.4.0'")
    print("Then push the SAME branch and update the existing draft pull request #4 using your own access.")
    return 0

if __name__=="__main__":
    try: sys.exit(main())
    except (RuntimeError,OSError,AssertionError) as e:
        print("ERROR:",e,file=sys.stderr)
        sys.exit(1)
