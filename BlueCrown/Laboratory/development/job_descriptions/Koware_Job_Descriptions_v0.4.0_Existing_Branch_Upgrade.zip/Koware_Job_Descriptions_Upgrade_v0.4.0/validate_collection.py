#!/usr/bin/env python3
"""Independently check the Koware job-description v0.4.0 release overlay.
Requires only Python 3.9+ standard library; no network or external packages.
"""
from __future__ import annotations
import json
import re
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = json.loads((ROOT / "ROLE_SOURCE_MANIFEST.json").read_text(encoding="utf-8"))
EMP = ROOT / "BlueCrown" / "Employment_Resources"
DOC_ROOT = EMP / "Job_Descriptions"
ERRORS: list[str] = []


def assert_check(condition: bool, issue: str) -> None:
    if not condition:
        ERRORS.append(issue)


def scalar(header: str, key: str) -> str | None:
    m = re.search(rf"(?m)^{re.escape(key)}:\s*(.*)$", header)
    if not m:
        return None
    val = m.group(1).strip()
    if len(val) > 1 and val[0] == val[-1] and val[0] in "\"'":
        val = val[1:-1].replace("''", "'")
    return val


def frontmatter(doc: str, path: str) -> str:
    m = re.match(r"\A---\s*\n(.*?)\n---\s*\n", doc, re.S)
    assert_check(bool(m), f"Missing YAML frontmatter: {path}")
    return m.group(1) if m else ""


roles = MANIFEST.get("roles", [])
assert_check(MANIFEST.get("collection_version") == "0.4.0", "Unexpected manifest version")
assert_check(len(roles) == 62, f"Expected 62 roles, got {len(roles)}")
assert_check([r["source_line"] for r in roles] == list(range(5, 67)), "Position source lines must cover 5–66 exactly")
assert_check(len({r["slug"] for r in roles}) == 62, "Duplicate role slugs")
assert_check(len({r["role_id"] for r in roles}) == 62, "Duplicate role identifiers")
assert_check(len({r["path"] for r in roles}) == 62, "Duplicate canonical paths")
assert_check([(r["source_line"],r["title"]) for r in roles if "Liaison Assistant" in r["title"]] == [(14,"Liaison Assistant")], "Incorrect Liaison Assistant mapping")
assert_check(next((r["title"] for r in roles if r["source_line"] == 17), None) == "Liaison Personnel", "Source line 17 must be Liaison Personnel")
assert_check(next((r["title"] for r in roles if r["source_line"] == 11), None) == "Legal Journalist (Law/Legislation vested Pastor/Theologian)", "Full source title missing at line 11")

seen = []
for r in roles:
    path = ROOT / r["path"]
    assert_check(path.is_file(), f"Missing role file: {r['path']}")
    if not path.is_file():
        continue
    seen.append(path)
    doc = path.read_text(encoding="utf-8")
    hdr = frontmatter(doc,r["path"])
    expected = {
        "document_id": r["role_id"],
        "position_title": r["title"],
        "source_chart_line": str(r["source_line"]),
        "source_chart_parent_line": str(r["parent_line"]),
        "reports_to": r["parent_title"],
        "source_chart_heading": r["title"],
        "document_version": "0.4.0",
        "document_status": "DRAFT_AWAITING_HUMAN_REVIEW",
        "document_type": "job-description",
        "approval_required": "true",
        "aliases_included": "false",
    }
    for key, value in expected.items():
        assert_check(scalar(hdr,key) == value, f"{r['slug']}: {key} differs from manifest; got {scalar(hdr,key)!r}")
    role_title_heading = f"# {r['title']} — Job Description"
    assert_check(role_title_heading in doc, f"Incorrect markdown heading for {r['slug']}")
    expected_children = [c for c in roles if c["parent_line"] == r["source_line"]]
    reported = re.findall(r"(?m)^- role_id:\s*(KOWARE-JD-[A-Z_]+)\s*$", hdr)
    assert_check(reported == [c["role_id"] for c in expected_children], f"Incorrect child list for {r['slug']}")
    for n in range(1,12):
        assert_check(bool(re.search(rf"(?m)^## {n:02d} · ",doc)), f"Missing section {n:02d} for {r['slug']}")
    duties = doc.split("## 03 · ",1)[-1].split("### Operating cadence",1)[0]
    outputs = doc.split("## 04 · ",1)[-1].split("## 05 · ",1)[0]
    kpis = doc.split("## 07 · ",1)[-1].split("## 08 · ",1)[0]
    assert_check(sum(x.startswith("- ") for x in duties.splitlines()) >= 6, f"Too few duties for {r['slug']}")
    assert_check(sum(x.startswith("- ") for x in outputs.splitlines()) >= 3, f"Too few deliverables for {r['slug']}")
    assert_check(sum(x.startswith("| ") for x in kpis.splitlines()) >= 4, f"Too few KPIs for {r['slug']}")
    assert_check(len(doc) > 3500, f"Document unexpectedly short: {r['slug']}")
    assert_check(not re.search(r"(?i)\b(?:TODO|TBD|FIXME|LOREM\s+IPSUM|INSERT\s+HERE|YOUR\s+NAME)\b",doc), f"Placeholder marker in {r['slug']}")
    assert_check("[Alias:" not in doc, f"Sensitive personal aliases leaked into {r['slug']}")

actual = sorted(DOC_ROOT.rglob("*_job_role.md"))
assert_check(len(actual) == 62, f"Incorrect number of role files: {len(actual)}")
assert_check(set(actual) == set(seen), "Unmapped or orphan job files present")

index = (EMP / "JOB_DESCRIPTIONS_INDEX.md").read_text(encoding="utf-8")
for r in roles:
    relative = "/".join(Path(r["path"]).parts[2:])
    # From EMP, suffix begins Job_Descriptions/...
    expected = f"./{relative}"
    assert_check(expected in index, f"Index lacks link to {r['slug']} ({expected})")
assert_check(index.count("| [Open](./Job_Descriptions/") == 62, "Index has incorrect count of role links")

charters={
    3: "Governance_Charters/Members_Representative/Members_Representative_charter.md",
    4: "Governance_Charters/Governing_Committee/Governing_Committee_charter.md",
    67: "Governance_Charters/Board_of_Directors/Board_of_Directors_charter.md",
}
for line, rel in charters.items():
    p = EMP / rel
    assert_check(p.is_file(),f"Missing charter {rel}")
    if p.is_file():
        doc = p.read_text(encoding="utf-8")
        hdr = frontmatter(doc,rel)
        assert_check(scalar(hdr,"source_chart_line") == str(line), f"Charter chart line wrong: {rel}")
        assert_check(scalar(hdr,"document_status") == "DRAFT_AWAITING_HUMAN_REVIEW", f"Charter not marked draft: {rel}")
        assert_check(scalar(hdr,"document_type") == "governance-charter", f"Incorrect charter type: {rel}")
        assert_check(len(doc) > 1500, f"Charter content unexpectedly short: {rel}")
        assert_check(f"./{rel}" in index, f"Charter omitted in index: {rel}")

for extra in ["JOB_DESCRIPTION_DOCUMENT_STANDARD.md","JOB_DESCRIPTIONS_REFACTOR_AUDIT.md","Governance_References/GOVERNANCE_STRUCTURE_SOURCE_NOTES.md"]:
    assert_check((EMP / extra).is_file(), f"Missing essential collection file: {extra}")

if ERRORS:
    print(f"FAILED: {len(ERRORS)} collection checks",file=sys.stderr)
    for issue in ERRORS:
        print("  - " + issue,file=sys.stderr)
    sys.exit(1)
print("PASS: 62/62 role descriptions, 3/3 charters; 67 chart lines accounted for across roles/governance;")
print("      unique IDs, line/title/parent/child mapping, substantive sections, duties, outputs,")
print("      KPI tables, 62 index links, controlled draft metadata and no data placeholders.")
