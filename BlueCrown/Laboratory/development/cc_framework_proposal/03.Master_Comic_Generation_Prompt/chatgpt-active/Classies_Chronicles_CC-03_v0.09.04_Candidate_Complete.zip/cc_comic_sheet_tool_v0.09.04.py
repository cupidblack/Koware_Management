#!/usr/bin/env python3
"""Classies Chronicles CC-03 2x2 page/sheet geometry and inventory utility.

This utility enforces literal 9:16 *measured* pixel geometry and exact page counts.
It does NOT generate comic art, determine licensing, validate character likeness,
inspect restricted challenge answers, certify native provenance, or publish assets.

Pillow is required. The command-line interface uses only actual existing files.
No existing output is silently overwritten; use an explicit new output path.
"""

from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image, ImageOps

VERSION = "0.09.04"
ID_RE = re.compile(r"^P([0-9]+)(?:[-_.]r[0-9]+)?\.[a-z0-9]+$", re.I)


class ComicAssetError(ValueError):
    pass


def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def hash_file(path: Path):
    dig = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            dig.update(chunk)
    return dig.hexdigest()


def require_new_file(path: Path):
    if path.exists():
        raise ComicAssetError(f"Refusing to overwrite existing asset: {path}")
    if not path.parent.is_dir():
        raise ComicAssetError(f"Output parent directory does not exist: {path.parent}")


def require_9_16(width, height):
    if width <= 0 or height <= 0 or width * 16 != height * 9:
        raise ComicAssetError(f"Expected true page 9:16, got {width}x{height}; 16*W != 9*H")


def validate_page_ids(paths, first_number):
    if len(paths) != 4:
        raise ComicAssetError(f"A complete sheet must contain exactly 4 pages; got {len(paths)}")
    if first_number < 1 or (first_number - 1) % 4:
        raise ComicAssetError("First page number must be 1, 5, 9, 13 ...")
    expected = list(range(first_number, first_number + 4))
    actual = []
    for path in paths:
        mat = ID_RE.match(path.name)
        if not mat:
            raise ComicAssetError(f"Page filenames must start with P01/P02 etc: {path.name}")
        actual.append(int(mat.group(1)))
    if actual != expected:
        raise ComicAssetError(f"Expected sequential row-major page IDs {expected}, got {actual}")


def perceptual_dhash(im):
    """Approximate duplicate flag ONLY; no quality or source-fidelity assertion."""
    gray = ImageOps.grayscale(im).resize((9, 8), Image.Resampling.LANCZOS)
    pix = list(gray.getdata())
    bits = 0
    for row in range(8):
        for col in range(8):
            bits = (bits << 1) | int(pix[row * 9 + col] > pix[row * 9 + col + 1])
    return bits


def reject_exact_duplicate_pixels(images):
    """A byte-identical pixel page under two page IDs is not a distinct comic page."""
    fingerprints = [hashlib.sha256(im.tobytes()).hexdigest() for im in images]
    if len(set(fingerprints)) != len(fingerprints):
        raise ComicAssetError("Two different page IDs contain exactly identical decoded pixels")


def dup_flags(images):
    signatures = [perceptual_dhash(im) for im in images]
    near = []
    for i in range(len(signatures)):
        for j in range(i + 1, len(signatures)):
            hamming = (signatures[i] ^ signatures[j]).bit_count()
            if hamming <= 3:
                near.append({"pages": [i + 1, j + 1], "dhash_hamming": hamming,
                             "interpretation": "POSSIBLY_SIMILAR_REVIEW_REQUIRED"})
    return near


def get_png_rgb(path):
    if not path.is_file():
        raise ComicAssetError(f"Missing image: {path}")
    with Image.open(path) as original:
        if original.n_frames > 1:
            raise ComicAssetError(f"Animated/multiframe file cannot be used as a static page: {path}")
        if original.getexif().get(274, 1) != 1:
            raise ComicAssetError(f"EXIF orientation not normalized; export an upright page: {path}")
        copy = original.convert("RGB")
        copy.load()
    require_9_16(*copy.size)
    return copy


def write_manifest(path, obj):
    if path is None:
        return
    require_new_file(path)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(obj, fh, ensure_ascii=False, sort_keys=True, indent=2)
        fh.write("\n")


def assemble(paths, output: Path, first_number: int, manifest: Path | None = None):
    validate_page_ids(paths, first_number)
    require_new_file(output)
    if manifest:
        require_new_file(manifest)
    ims = [get_png_rgb(path) for path in paths]
    try:
        sizes = {im.size for im in ims}
        if len(sizes) != 1:
            raise ComicAssetError(f"All four original page dimensions must be identical: {sizes}")
        reject_exact_duplicate_pixels(ims)
        width, height = ims[0].size
        sheet = Image.new("RGB", (width * 2, height * 2), "white")
        coords = [(0, 0), (width, 0), (0, height), (width, height)]
        for im, xy in zip(ims, coords):
            sheet.paste(im, xy)
        require_9_16(*sheet.size)
        sheet.save(output, format="PNG", optimize=True)
        rows = []
        for idx, (path, xy) in enumerate(zip(paths, coords)):
            rows.append({"page_id": f"P{first_number+idx:02d}",
                         "source_file": str(path), "source_sha256": hash_file(path),
                         "measured_pixels": [width, height],
                         "cell": ["TL", "TR", "BL", "BR"][idx],
                         "crop_box_ltrb": [xy[0], xy[1], xy[0] + width, xy[1] + height]})
        record = {
            "tool_version": VERSION, "operation": "assemble", "observed_utc": utcnow(),
            "sheet_id": f"S{(first_number + 3)//4:02d}",
            "sheet_file": str(output), "sheet_sha256": hash_file(output),
            "sheet_measured_pixels": list(sheet.size),
            "page_files_actually_created_by_this_operation": 0,
            "cells_present": 4, "cells": rows,
            "perceptual_duplicate_review_flags": dup_flags(ims),
            "original_native_renderer_provenance": "NOT_VERIFIED_BY_THIS_UTILITY",
            "pixel_story_text_rights_editorial_qa": "NOT_PERFORMED",
        }
        write_manifest(manifest, record)
        return record
    finally:
        for im in ims:
            im.close()


def slice_sheet(sheetpath: Path, outdir: Path, first_number: int, manifest: Path | None = None):
    if first_number < 1 or (first_number - 1) % 4:
        raise ComicAssetError("First page number must be 1, 5, 9, 13 ...")
    if not outdir.is_dir():
        raise ComicAssetError("Output directory must exist and be an actual directory")
    names = [outdir / f"P{i:02d}.png" for i in range(first_number, first_number + 4)]
    for p in names:
        require_new_file(p)
    if manifest:
        require_new_file(manifest)
    if not sheetpath.is_file():
        raise ComicAssetError(f"Missing sheet: {sheetpath}")
    with Image.open(sheetpath) as im:
        if im.n_frames > 1:
            raise ComicAssetError("Animated/multiframe sheet is not supported")
        if im.getexif().get(274, 1) != 1:
            raise ComicAssetError("EXIF rotated sheet needs an upright export")
        full = im.convert("RGB")
        full.load()
    if full.width % 2 or full.height % 2:
        raise ComicAssetError(f"Cannot exactly halve sheet dimensions {full.size}")
    require_9_16(*full.size)
    width, height = full.width // 2, full.height // 2
    require_9_16(width, height)
    boxes = [(0, 0, width, height), (width, 0, 2 * width, height),
             (0, height, width, 2 * height), (width, height, 2 * width, 2 * height)]
    crops = [full.crop(box) for box in boxes]
    reject_exact_duplicate_pixels(crops)
    try:
        for crop, path in zip(crops, names):
            crop.save(path, format="PNG", optimize=True)
        record = {"tool_version": VERSION, "operation": "slice", "observed_utc": utcnow(),
                  "source_sheet": str(sheetpath), "source_sheet_sha256": hash_file(sheetpath),
                  "source_measured_pixels": list(full.size),
                  "exact_crop_geometry": "ZERO_GUTTER_2_BY_2_ASSUMED_AND_MEASURED",
                  "page_files_actually_created_by_this_operation": 4,
                  "pages": [{"page_id": f"P{i+first_number:02d}", "file": str(path),
                             "measured_pixels": [width, height], "sha256": hash_file(path),
                             "cell": ["TL", "TR", "BL", "BR"][i],
                             "crop_box_ltrb": list(box)}
                            for i, (path, box) in enumerate(zip(names, boxes))],
                  "perceptual_duplicate_review_flags": dup_flags(crops),
                  "native_source_provenance": "NOT_VERIFIED_BY_THIS_UTILITY",
                  "pixel_story_text_rights_editorial_qa": "NOT_PERFORMED"}
        write_manifest(manifest, record)
        return record
    finally:
        full.close()
        for crop in crops:
            crop.close()


def inspect(paths):
    rows = []
    ims = []
    try:
        for path in paths:
            im = get_png_rgb(path)
            ims.append(im)
            rows.append({"file": str(path), "pixels": list(im.size),
                         "sha256": hash_file(path), "ratio": "9:16"})
        return {"tool_version": VERSION, "operation": "inspect", "observed_utc": utcnow(),
                "assets": rows, "perceptual_duplicate_review_flags": dup_flags(ims),
                "pixel_story_text_rights_editorial_qa": "NOT_PERFORMED"}
    finally:
        for im in ims:
            im.close()



def audit_set(paths, expected_count: int, manifest: Path | None = None):
    """Cross-sheet duplicate and P01..PN inventory check on real original page files."""
    if expected_count < 1:
        raise ComicAssetError("Expected count must be positive")
    if len(paths) != expected_count:
        raise ComicAssetError(f"Commission N={expected_count}, actual paths={len(paths)}")
    expected_ids = list(range(1, expected_count + 1))
    actual_ids = []
    for p in paths:
        match = ID_RE.match(p.name)
        if not match:
            raise ComicAssetError(f"Unrecognized page name: {p.name}")
        actual_ids.append(int(match.group(1)))
    if actual_ids != expected_ids:
        raise ComicAssetError(f"Page identity/order must be P01..P{expected_count:02d}; got {actual_ids}")
    if manifest:
        require_new_file(manifest)
    ims = [get_png_rgb(p) for p in paths]
    try:
        require_size = ims[0].size
        if any(im.size != require_size for im in ims):
            raise ComicAssetError("Every page in this commissioned set must have same actual dimensions")
        reject_exact_duplicate_pixels(ims)
        result = {"tool_version": VERSION, "operation": "audit_set", "observed_utc": utcnow(),
                  "exact_commissioned_page_count": expected_count,
                  "actual_unique_page_count": len(ims),
                  "complete_2x2_sheet_count_by_plan": expected_count // 4,
                  "individual_remainder_by_plan": expected_count % 4,
                  "source_pixel_dimensions": list(require_size),
                  "pages": [{"page_id": f"P{i:02d}", "file": str(path),
                             "measured_pixels": list(im.size), "sha256": hash_file(path)}
                            for i, (path, im) in enumerate(zip(paths, ims), 1)],
                  "perceptual_duplicate_review_flags": dup_flags(ims),
                  "cross_sheet_exact_duplicate_pixels": "NONE",
                  "real_art_story_text_licensing_and_phone_qa": "NOT_PERFORMED"}
        write_manifest(manifest, result)
        return result
    finally:
        for im in ims:
            im.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description="Classies 9:16 comic page 2x2 assembler/slicer")
    sub = parser.add_subparsers(dest="command", required=True)
    assm = sub.add_parser("assemble", help="Assemble EXACTLY four original native 9:16 pages")
    assm.add_argument("--pages", type=Path, nargs=4, required=True)
    assm.add_argument("--first", type=int, required=True)
    assm.add_argument("--output", type=Path, required=True)
    assm.add_argument("--manifest", type=Path)
    spl = sub.add_parser("slice", help="Split a known zero-gutter 2x2 sheet into four 9:16 pages")
    spl.add_argument("--sheet", type=Path, required=True)
    spl.add_argument("--first", type=int, required=True)
    spl.add_argument("--outdir", type=Path, required=True)
    spl.add_argument("--manifest", type=Path)
    insp = sub.add_parser("inspect", help="Measure actual 9:16 images and report duplicate review flags")
    insp.add_argument("--files", type=Path, nargs="+", required=True)
    aud = sub.add_parser("audit", help="Cross-sheet P01..PN exact inventory and duplicate audit")
    aud.add_argument("--pages", type=Path, nargs="+", required=True)
    aud.add_argument("--count", type=int, required=True)
    aud.add_argument("--manifest", type=Path)
    args = parser.parse_args(argv)
    try:
        if args.command == "assemble":
            obj = assemble(args.pages, args.output, args.first, args.manifest)
        elif args.command == "slice":
            obj = slice_sheet(args.sheet, args.outdir, args.first, args.manifest)
        elif args.command == "audit":
            obj = audit_set(args.pages, args.count, args.manifest)
        else:
            obj = inspect(args.files)
    except (ComicAssetError, OSError) as err:
        print(f"ERROR: {err}", file=sys.stderr)
        return 2
    print(json.dumps(obj, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
