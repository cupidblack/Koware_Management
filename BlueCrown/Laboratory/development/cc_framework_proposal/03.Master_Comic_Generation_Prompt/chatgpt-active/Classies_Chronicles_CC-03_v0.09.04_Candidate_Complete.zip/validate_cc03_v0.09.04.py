#!/usr/bin/env python3
"""Deterministic documentary + synthetic geometry tests for CC-03 v0.09.04.
Does not read private challenge materials or claim a live comic render pilot."""
from __future__ import annotations
import json
import hashlib
import re
import sys
import tempfile
from pathlib import Path
from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import importlib.util
spec = importlib.util.spec_from_file_location("cc03sheet", HERE / "cc_comic_sheet_tool_v0.09.04.py")
sheet = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sheet)


MASTER = HERE / "CC-03.01-Master_Comic_Generation_Prompt_v0.09.04_Candidate.md"
REVIEW = HERE / "CC-03.02-Comic_Refactor_Review_Conflict_Register_and_Change_Traceability_v0.09.04_Candidate.md"
PATCH = HERE / "CC-01.01_Comic_Default_Alignment_Amendment_v0.09.04_PROPOSED.md"
QA = HERE / "CC-03.03-Comic_QA_and_File_Manifest_v0.09.04_Candidate.md"
GATES = [
    "C01_COMMISSION", "C02_SOURCE_REVISION", "C03_FIDELITY", "C04_PAGE_PURPOSE",
    "C05_THREE_CLOCKS", "C06_CANON_CHARACTERS", "C07_MISSION_TECH", "C08_ENVIRONMENT",
    "C09_RIGHTS_CONSENT", "C10_ORIGINALITY", "C11_PAGE_ASPECT", "C12_PANEL_FLOW",
    "C13_LETTERING", "C14_VISIBLE_LABELS", "C15_CHALLENGE_SOURCE",
    "C16_CHALLENGE_PLACEMENT", "C17_NO_LEAKAGE", "C18_COUNT_INVENTORY",
    "C19_EXPORT_QUALITY", "C20_DEPENDENCY", "C21_RECORD_INTEGRITY", "C22_DISCLOSURE"]


class Checker:
    def __init__(self):
        self.results = []

    def check(self, name, passed, info=""):
        self.results.append({"test": name, "result": "PASS" if passed else "FAIL", "detail": info})

    def check_raises(self, name, f, exception=sheet.ComicAssetError):
        try:
            f()
            self.check(name, False, "Expected exception not raised")
        except exception:
            self.check(name, True)
        except Exception as exc:
            self.check(name, False, f"Wrong exception: {type(exc).__name__}: {exc}")


def visual_fixture(path, i, W=90, H=160):
    # Only simple synthetic geometry diagnostics; NOT actual Classies art.
    im = Image.new("RGB", (W, H), (i * 29 % 255, i * 57 % 255, i * 83 % 255))
    d = ImageDraw.Draw(im)
    d.rectangle((5 + i, 7 + i, 30 + i, 30 + i), outline="white", width=3)
    d.text((15, 60), f"P{i:02d}", fill="white")
    im.save(path)


def execute():
    t = Checker()
    srcs = {"master": MASTER, "review": REVIEW, "patch": PATCH,
            "utility": HERE / "cc_comic_sheet_tool_v0.09.04.py"}
    if QA.exists():
        srcs["qa"] = QA
    texts = {}
    for key, path in srcs.items():
        t.check(f"{key}_file_exists_nonempty", path.is_file() and path.stat().st_size > 100)
        if path.suffix == ".md":
            texts[key] = path.read_text(encoding="utf-8")
    m, r, patch = texts["master"], texts["review"], texts["patch"]
    t.check("master_correct_identity_version", "CC-03.01 / CC-MCGP" in m and "v0.09.04" in m)
    t.check("review_correct_identity_version", "CC-03.02 / CC-MCGP-REVIEW" in r and "v0.09.04" in r)
    t.check("master_has_31_ordered_sections", [int(x) for x in re.findall(r"(?m)^## ([0-9]+)\. ", m)] == list(range(1, 32)))
    t.check("master_end_signature", m.rstrip().endswith("**END — CC-03.01 / CC-MCGP v0.09.04 Candidate**"))
    t.check("review_end_signature", r.rstrip().endswith("**END — CC-03.02 / CC-MCGP-REVIEW v0.09.04 Candidate**"))
    t.check("n8_ordinary_default", "N=8" in m and "eight-page" in m.lower())
    t.check("n16_and_n20_overrides", "N=16" in m and "N=20" in m)
    t.check("upstream_n16_conflict_explicit", "§42" in m and "N=16" in patch)
    t.check("8_pages_2_sheets", "S01" in m and "S02" in m and "P08" in m)
    t.check("16_pages_4_sheets", "S04" in m and "P16" in m)
    t.check("20_pages_5_sheets", "S05" in m and "P20" in m)
    t.check("native_2x2_geometry", "2160×3840" in m and "1080×1920" in m)
    t.check("page_and_sheet_both_9_16", "9:16" in m and "2W×2H" in m)
    t.check("no_unqualified_rerender", "one-pass" in m.lower() and "same page ID" in m)
    t.check("motivated_toon_effects", "toony" in m.lower() and "temporary" in m.lower())
    t.check("character_bible", "appearance card" in m and "inter-sheet" in m)
    t.check("no_koware_title_lockup", "Never merge the Koware corporate logo" in m)
    t.check("terminal_challenge_once", "literal **bottom of the final" in m and "P08" in m)
    t.check("three_clocks", "**P**" in m and "**H**" in m and "**F**" in m)
    t.check("protected_B_restricted_C", "B1–B8" in m and "Challenge C" in m)
    t.check("master_gate_names_all", all(name in m for name in GATES))
    t.check("master_gate_exact_table_rows", re.findall(r"(?m)^\| `(C\d\d_[A-Z_]+)` \|", m) == GATES)
    t.check("review_all_22_image_ids", [int(x) for x in re.findall(r"(?m)^\| V(\d\d) \|", r)] == list(range(1, 23)))
    t.check("review_all_50_decision_ids", [int(x) for x in re.findall(r"(?m)^\| `CR-094-(\d\d)`", r)] == list(range(1, 51)))
    t.check("compilation_correctly_nonempty", "609 browser-text lines" in r)
    t.check("owner_approval_not_claimed", "PROPOSED_FOR_OWNER_REVIEW" in m and "PROPOSED CHANGE ONLY" in patch)
    t.check("patch_no_replacement_m01_m30", "media duration arithmetic" in patch and "C18_COUNT_INVENTORY" in patch)
    t.check("no_data_placeholder_tokens", not any(tok in m+r+patch for tok in ("{{", "}}", "<INSERT", "[PLACEHOLDER", "LOREM IPSUM")))
    t.check("no_shared_source_embedded_restricted_key", "the correct answer is" not in m.lower() and "correct option:" not in m.lower())
    t.check("3_proposed_core_files_declared", "CC-03.03" in m and "CC-03.02" in m)
    t.check("simulated_geometry_exact", 16 * 90 == 9 * 160 and 16 * 180 == 9 * 320)
    for n, sheets in ((4,1), (8,2), (16,4), (20,5), (32,8)):
        t.check(f"sheet_count_{n}", n//4 == sheets and sum(len(list(range(i*4+1,i*4+5))) for i in range(sheets)) == n)
    for n in range(1, 31):
        t.check(f"count_preservation_{n:02d}", 4*(n//4)+(n%4)==n)
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        inp = root / "input"
        cut = root / "slices"
        inp.mkdir(); cut.mkdir()
        for i in range(1,9):
            visual_fixture(inp / f"P{i:02d}.png", i)
        imgs = [inp / f"P{i:02d}.png" for i in range(1, 5)]
        m1 = root / "S01_manifest.json"
        out = root / "S01.png"
        record = sheet.assemble(imgs, out, 1, m1)
        t.check("assemble_sheet_2x2_geometry", Image.open(out).size == (180,320))
        t.check("assemble_sheet_count_and_order", record["cells_present"] == 4 and [x["page_id"] for x in record["cells"]] == ["P01","P02","P03","P04"])
        t.check("assembly_manifest_saved_real_digest", m1.exists() and json.loads(m1.read_text())["sheet_sha256"] == sheet.hash_file(out))
        t.check("assembly_honest_original_page_count", record["page_files_actually_created_by_this_operation"] == 0)
        sliced = sheet.slice_sheet(out, cut, 1, root / "S01_slice_manifest.json")
        t.check("slice_4_page_files_real", sliced["page_files_actually_created_by_this_operation"] == 4 and len(list(cut.glob("P*.png")))==4)
        t.check("slice_exact_pixels", all(Image.open(path).size==(90,160) for path in cut.glob("P*.png")))
        t.check("sliced_content_equals_original", all(Image.open(inp / f"P{i:02d}.png").tobytes()==Image.open(cut / f"P{i:02d}.png").tobytes() for i in range(1,5)))
        t.check("original_source_sha_accurate", record["cells"][0]["source_sha256"]==sheet.hash_file(imgs[0]))
        t.check("separate_second_sheet", sheet.assemble([inp / f"P{i:02d}.png" for i in range(5,9)], root / "S02.png",5)["sheet_id"]=="S02")
        t.check_raises("refuse_overwrite_sheet", lambda: sheet.assemble(imgs,out,1))
        t.check_raises("refuse_overwrite_page", lambda: sheet.slice_sheet(out,cut,1))
        t.check_raises("refuse_out_of_order_ids", lambda: sheet.assemble(list(reversed(imgs)),root/"wrong_order.png",1))
        t.check_raises("refuse_wrong_first_index", lambda: sheet.assemble(imgs,root/"wrong_first.png",2))
        real_pages = [inp / f"P{i:02d}.png" for i in range(1,9)]
        audited = sheet.audit_set(real_pages,8,root/"audit.json")
        t.check("audit_eight_pages_across_sheets", audited["actual_unique_page_count"] == 8 and audited["complete_2x2_sheet_count_by_plan"] == 2)
        t.check("audit_has_retrievable_real_manifest", (root/"audit.json").exists() and len(json.loads((root/"audit.json").read_text())["pages"]) == 8)
        t.check_raises("audit_wrong_N_rejected", lambda: sheet.audit_set(real_pages, 16))
        t.check_raises("audit_out_of_order_rejected", lambda: sheet.audit_set(real_pages[::-1], 8))
        # A duplicate P07 on another sheet is a real violation even if within-sheet uniqueness holds.
        Image.open(inp/"P03.png").save(inp/"P07.png")
        t.check_raises("audit_cross_sheet_duplicate_rejected", lambda: sheet.audit_set(real_pages, 8))
        visual_fixture(inp / "P07.png", 7)
        copybad = inp / "P04.png"
        Image.open(imgs[0]).save(copybad)
        t.check_raises("refuse_exact_duplicate_pixels", lambda: sheet.assemble(imgs,root/"duplicate.png",1))
        visual_fixture(copybad,4,W=100,H=160)
        t.check_raises("refuse_wrong_ratio", lambda: sheet.assemble(imgs,root/"bad_ratio.png",1))
    result = {"suite": "CC-03 v0.09.04 DOCUMENTARY + SYNTHETIC GEOMETRY ONLY",
              "execution_scope": "REAL_NEW_COMIC_PIXELS_NOT_GENERATED_OR_TESTED",
              "results": t.results,
              "pass": sum(x["result"]=="PASS" for x in t.results),
              "fail": sum(x["result"]=="FAIL" for x in t.results)}
    return result


if __name__ == "__main__":
    report = execute()
    (HERE / "QA_EXECUTION_LOG.txt").write_text("\n".join(f'{r["result"]} | {r["test"]}' + (f' | {r["detail"]}' if r["detail"] else "") for r in report["results"]) + "\n",encoding="utf-8")
    (HERE / "QA_MACHINE_READABLE.json").write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(f'{report["pass"]}/{len(report["results"])} PASS, {report["fail"]} FAIL')
    raise SystemExit(0 if report["fail"]==0 else 1)
