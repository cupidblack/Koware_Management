# Classies Chronicles — Cross-Platform Convergence Candidate Package
**Prepared:** 19 November 2026 UTC. **Reviewed master:** `CC-01.01 / CC-UPMP v0.09.01 Candidate`. **Daily suite:** `v0.09.03 Candidate`. **Context Merge specialist:** `v0.02.01 Candidate`. **Operation:** `REVIEW_ONLY`. **No adoption, GitHub write, story, comic, video, restricted key or publication executed.**

## Why this package exists
The previously generated v0.09.01 local daily package was produced before Compilation 3's actual content became accessible. This release reconciles the readable cross-platform compilation and the competing `chatgpt/`, `chatgpt-active/`, embedded `GITHUB-1`, and `claude/` proposals against the current governing master candidate. A public raw-page extraction now shows **987 text lines** with substantive contributions (not the old 0-byte report). Distinguish that extracted line count from measured raw bytes, which are not available in this local runtime.

## Files, roles and non-destructive naming
- `CC-02.01-Daily_Chronicle_Generation_Protocol_v0.09.03_Candidate.md` — daily operator runbook, original detailed baseline retained plus new convergence constraints.
- `CC-02.02-Episode_Continuity_Ledger-Production_Handover_v0.09.03_Candidate.md` — nineteen-family continuity ledger and fifteen-part B6, canonical logical CC-02.02 with no live schema migration.
- `CC-02.03-Daily_Protocol_and_Ledger_Alignment_Review_v0.09.03_Candidate.md` — comprehensive cross-platform adjudication (62 decisions), ID collision/migration and 60 test specifications.
- `CC-02.04-Daily_Chronicle_QA_and_File_Manifest_v0.09.03_Candidate.md` — executed local QA, measured document hashes and live-test limitations.
- `CC-05.01-Context_Merge_Engine_Master_Prompt_v0.02.01_Candidate.md` — complete eight-operation semantic engine and V1–V6 specialist.
- `CC-05.02-Context_Merge_Refactor_Review_and_Decision_Log_v0.02.01_Candidate.md` — 24 specialist decisions and regressions.
- `validate_convergence.py`, `QA_EXECUTION_LOG.txt`, `QA_MACHINE_READABLE.json` — locally reproducible static/synthetic checks and actual results.
- `SOURCE_PROVENANCE.json` — web-opened source URLs, observed platform blocks and explicit no-external-checksum boundaries.
- `SHA256SUMS.txt` — hashes of the generated Markdown, JSON, logs, README and validator files in this directory. The SHA file is itself excluded to avoid recursion.

## Locally verified QA
**88/88 PASS; 0 FAIL.** This validates text contracts and controlled synthetic calendar/accepted-event fixtures, not a live daily production, service integration, human approval or deployment. Re-run with `python validate_convergence.py`; a JSON report can be reproduced with `python validate_convergence.py --json`.

## Recommended adoption process
Compare the six candidate documents, obtain an owner decision on effective editions and namespaces, preserve historical paths and accepted episode state, stage any repository changes with reversible registry updates, pin true external source commits/rights, perform a one-day isolated pilot and independent handover review, run actual Q01–Q16 on that new story and only then separately authorize persistence/publication. The `CC-02.03` alignment review records the exact migration and owner approval gates.

**END — README Cross-Platform Convergence Candidate.**
