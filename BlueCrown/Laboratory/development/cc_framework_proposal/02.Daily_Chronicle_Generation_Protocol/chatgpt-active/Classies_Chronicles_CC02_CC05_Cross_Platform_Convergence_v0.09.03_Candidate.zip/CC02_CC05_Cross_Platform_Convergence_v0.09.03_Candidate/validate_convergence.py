#!/usr/bin/env python3
"""Reproducible documentary and synthetic regression QA for the CC-02/CC-05 candidate suite.
No external access, approval, actual story validation or repository mutation occurs.
"""
from __future__ import annotations
from pathlib import Path
from datetime import date,timedelta,datetime,timezone
from zoneinfo import ZoneInfo
import hashlib, json, re, sys

BASE=Path(__file__).resolve().parent
FILES={
  'runbook':'CC-02.01-Daily_Chronicle_Generation_Protocol_v0.09.03_Candidate.md',
  'ledger':'CC-02.02-Episode_Continuity_Ledger-Production_Handover_v0.09.03_Candidate.md',
  'alignment':'CC-02.03-Daily_Protocol_and_Ledger_Alignment_Review_v0.09.03_Candidate.md',
  'cme':'CC-05.01-Context_Merge_Engine_Master_Prompt_v0.02.01_Candidate.md',
  'cme_review':'CC-05.02-Context_Merge_Refactor_Review_and_Decision_Log_v0.02.01_Candidate.md',
}
Q=('Q01_SCOPE','Q02_CALENDAR','Q03_THREE_CLOCKS','Q04_IDENTIFIERS','Q05_CANON','Q06_ROLE_PROJECT','Q07_STUDY','Q08_VERSE_HS','Q09_RESEARCH','Q10_RIGHTS','Q11_STORY','Q12_CHALLENGE','Q13_RECORDS','Q14_DERIVATIVES','Q15_INTEGRITY','Q16_BOUNDARIES')
F=('episode_manifest','episode_context_snapshot','source_snapshot_register','daily_chronicle_record','research_register','source_permission_register','role_project_log','mission_state_record','character_state_record','storyline_register','continuity_event_log','challenge_public_register','challenge_answer_key','production_manifest','service_card_register','editorial_decision_log','exception_conflict_register','validation_report','handover_record')
V=('Eternal Dreamfall Bible Study','Eternal Dreamfall Chronicle','Refreshed Eternal Dreamfall','Headlined Eternal Dreamfall','Classies Eternal Dreamfall','Classies Chronicles')
B6=('Identity and snapshot','Source and authority basis','Production calendar','Temporal geometry','Cast and role spotlight','Character internal state','Mission and Edubeam state','Koware real-project boundary','Story events and scene dependency','Eternal Dreamfall derivation','Research and safety','Audience challenge state','Visual/media continuity','QA, conflicts and revisions','Next-day handoff')
OPERATIONS=('READ','DECOMPOSE','LOCK','CONNECT','TRANSFORM','PRESERVE','VALIDATE','REGISTER')
TRUTH=('VERIFIED_REAL_WORLD_FACT','HISTORICAL_INTERPRETATION','CANON_ACCEPTED','FICTIONAL_DRAFT','SPECULATIVE_PROBE_SCENARIO','OPERATIONAL_PROPOSAL','UNVERIFIED','RESTRICTED','CONTRADICTED')
PROJECT=('VERIFIED_PLANNED','VERIFIED_IN_PROGRESS','VERIFIED_COMPLETED','PROPOSED_REAL_ACTION','UNVERIFIED','FICTION_ONLY')


def first_monday(d):return d+timedelta(days=(7-d.weekday())%7)
def mapping(d,phase_start,phase_end,inclusive=True):
    """Illustrative strict full-block algorithm; actual owner calendar never presumed."""
    a=first_monday(phase_start)
    end=phase_end if inclusive else phase_end-timedelta(days=1)
    offset=(d-a).days
    if d<phase_start or d>end or offset<0:raise ValueError('OUTSIDE_PHASE')
    b, bd=divmod(offset,14)
    if b>3: raise ValueError('OUTSIDE_FOUR_EPISODES')
    if a+timedelta(days=14*b+13)>end:raise ValueError('PARTIAL_BLOCK')
    if bd in (5,6,12,13):raise ValueError('WEEKEND')
    slot=bd+1 if bd<5 else bd-1
    if d.weekday()>4:raise ValueError('WEEKDAY_MISMATCH')
    return b+1,slot,10*b+slot

def week_number(d):
    """Arithmetic fixture only, not an approved reading-to-entry assignment."""
    first=date(2025,1,5)
    return ((d-first).days//7)+1

def accepted_projection(events):
    """Minimal synthetic projection to check proposed/rejected/superseded do not alter accepted state."""
    state={}
    for e in sorted(events,key=lambda x:x['sequence']):
      if e['status']!='ACCEPTED' or not e.get('effective',False) or e.get('superseded',False):continue
      state[e['key']]=e['value']
    return state

def run():
  results=[]
  def ck(name,cond,details=''):
    results.append({'test':name,'result':'PASS' if bool(cond) else 'FAIL','details':details})
  paths={k:BASE/p for k,p in FILES.items()}
  for k,p in paths.items():ck(f'file:{k}:exists_nonempty',p.is_file() and p.stat().st_size>5000)
  if not all(p.exists() for p in paths.values()):return results,[]
  docs={k:p.read_text(encoding='utf8') for k,p in paths.items()}
  r=docs['runbook']; l=docs['ledger']; a=docs['alignment']; c=docs['cme']; cr=docs['cme_review']
  ids={'runbook':'CC-02.01 / CC-DCGP','ledger':'CC-02.02 / CC-ECLPM','alignment':'CC-02.03 / CC-ALIGN','cme':'CC-05.01 / CC-CME','cme_review':'CC-05.02'}
  for k,t in docs.items():
    ck(f'{k}:correct_identity',ids[k] in t[:1250])
    ck(f'{k}:master_reference', 'CC-01.01' in t and 'v0.09.01' in t)
    ck(f'{k}:explicit_candidate_status', 'candidate' in t[:2000].lower() and 'not' in t[:2000].lower())
    ck(f'{k}:no_editorial_placeholders',not bool(re.search(r'\{\{.+?\}\}|\b(?:TODO|TBD|FIXME|lorem ipsum)\b|\[INSERT\s',t,re.I|re.S)))
    ck(f'{k}:has_single_terminal_signature',len(re.findall(r'^\*\*END —',t,re.M))==1)
  section=r.split('## 10. Phase 8',1)[1].split('### 10.1',1)[0]
  found=re.findall(r'^\| `(Q\d\d_[A-Z_]+)` \|',section,re.M)
  ck('runbook:exact_16_Q_gates_order',tuple(found)==Q,str(found))
  family_section=l.split('## 4. Complete nineteen-family canonical inventory',1)[1].split('### 4.1',1)[0]
  fam=re.findall(r'^\|\s*(\d\d)\s*\|\s*`([a-z_]+)`\s*\|',family_section,re.M)
  ck('ledger:19_families_exact_order',tuple(x[1] for x in fam)==F and tuple(x[0] for x in fam)==tuple(f'{i:02}' for i in range(1,20)),str(fam))
  capsule=l.split('### 8.1 Mandatory B6 divisions',1)[1].split('### 8.2',1)[0]
  cap=re.findall(r'^(\d{1,2})\. \*\*([^*]+)\*\*',capsule,re.M)
  ck('ledger:exact_15_B6_divisions',tuple(x[1].strip('. ') for x in cap)==B6 and tuple(int(x[0]) for x in cap)==tuple(range(1,16)),str(cap))
  ck('ledger:historical_probe_alias',all(s in l for s in ('calendar_probe_record','legacy','nineteen')))
  ck('runbook:10_phase_sequence',all(f'Phase {i} —' in r for i in range(10)))
  ck('runbook:8_internal_B_sections',all(f'**B{i} —' in r for i in range(1,9)))
  ck('ledger:8_internal_B_sections',all(f'**B{i} —' in l for i in range(1,9)))
  ck('runbook:all_six_stages',all(stage in r for stage in V))
  ck('cme:all_six_stages',all(stage in c for stage in V))
  ck('cme:canonical_eight_operations',all(f'**{op}**' in c for op in OPERATIONS))
  ck('cme:exact_ordered_operations',tuple(re.findall(r'^\d\. \*\*([A-Z]+)\*\* —',c.split('## 4. The exact',1)[1].split('## 5.',1)[0],re.M))==OPERATIONS)
  ck('runbook:canonical_eight_operations',all(op in r for op in OPERATIONS))
  ck('runbook:truth_classes',all(t in r for t in TRUTH))
  ck('runbook:project_statuses',all(t in r for t in PROJECT))
  ck('ledger:project_statuses',all(t in l for t in PROJECT))
  ck('cme:truth_classes',all(t in c for t in TRUTH))
  ck('runbook:all_16_gate_names',all(t in r for t in Q))
  ck('alignment:all_16_gate_names',all(t in a for t in Q))
  ck('runbook:canonical_registry_filenames',all(f in r for f in FILES.values()))
  ck('alignment:canonical_registry_filenames',all(f in a for f in FILES.values()))
  ck('ledger:correct_actual_document_edition','Document candidate edition | `v0.09.03_Candidate`' in l)
  ck('ledger:legacy_collision_not_live_replaced','old `CC-02.02` filename still points' in l)
  ck('review:compilation_nonempty_987','987 web-text lines' in a and 'CHATGPT-1' in a and 'CLAUDE-1' in a and 'GITHUB-1' in a)
  ck('review:62_decisions',re.findall(r'^\| `(CP-\d{3})` \|',a,re.M)==[f'CP-{i:03}' for i in range(1,63)])
  ck('review:60_specifications',re.findall(r'^\| `(AT\d{2})` \|',a,re.M)==[f'AT{i:02}' for i in range(1,61)])
  ck('cme_review:24_decisions',re.findall(r'^\| `(CME-C\d{2})` \|',cr,re.M)==[f'CME-C{i:02}' for i in range(1,25)])
  ck('runbook:restricted_custody_exact','RESTRICTED OUTPUT NOT CREATED; HUMAN SECURE CUSTODY REQUIRED' in r)
  ck('ledger:restricted_custody_exact','RESTRICTED OUTPUT NOT CREATED; HUMAN SECURE CUSTODY REQUIRED' in l)
  ck('review:NULL_blocks_exact',all(t in a for t in ('COPILOT-1','JULES-1','PERPLEXITY-1','ANTIGRAVITY-1','KIROCREW-1','OTHER-1')))
  ck('suite:no_asserted_GitHub_write',all(('no' in text.lower() and 'write' in text.lower()) for text in docs.values()))

  # Synthetic calendar arithmetic; no actual production calendar is inferred.
  start=date(2026,1,5);end=start+timedelta(days=55)
  fixtures={0:(1,1,1),4:(1,5,5),7:(1,6,6),11:(1,10,10),14:(2,1,11),18:(2,5,15),21:(2,6,16),25:(2,10,20),28:(3,1,21),32:(3,5,25),35:(3,6,26),39:(3,10,30),42:(4,1,31),46:(4,5,35),49:(4,6,36),53:(4,10,40)}
  for offset,wanted in fixtures.items():
    got=mapping(start+timedelta(days=offset),start,end)
    ck(f'calendar:offset_{offset:02}',got==wanted,str(got))
  countok=0;countbad=0
  for offset in range(56):
    try:
      mapping(start+timedelta(days=offset),start,end)
      countok+=1
    except ValueError:countbad+=1
  ck('calendar:full_chapter_40_weekdays_16_weekends',countok==40 and countbad==16, f'{countok}/{countbad}')
  mid=date(2026,1,7)
  ck('calendar:Wednesday_start_anchor_next_Monday',first_monday(mid)==date(2026,1,12))
  try:mapping(mid,mid,mid+timedelta(days=60));rejected=False
  except ValueError:rejected=True
  ck('calendar:midweek_before_anchor_rejected',rejected)
  try:mapping(start+timedelta(days=42),start,start+timedelta(days=48));rejected=False
  except ValueError:rejected=True
  ck('calendar:incomplete_fourth_block_rejected',rejected)
  try:mapping(start+timedelta(days=5),start,end);rejected=False
  except ValueError:rejected=True
  ck('calendar:ordinary_Saturday_rejected',rejected)
  try:mapping(start+timedelta(days=53),start,end,inclusive=False);rejected=False
  except ValueError:rejected=True
  ck('calendar:phase_end_exclusive_effect',rejected)
  ck('calendar:reading_week_98_arithmetic_only',week_number(date(2026,11,19))==98)
  # Offset-aware UTC conversion: 23:30 UTC on preceding date is tomorrow in +03.
  utc=datetime(2026,11,18,23,30,tzinfo=timezone.utc)
  ck('calendar:UTC_to_local_day_correct',utc.astimezone(ZoneInfo('Africa/Nairobi')).date()==date(2026,11,19))
  ck('calendar:Accra_UTC_same_day',utc.astimezone(ZoneInfo('Africa/Accra')).date()==date(2026,11,18))
  # Synthetic accepted-state tests: a draft event must not update the saved projection.
  es=[{'sequence':1,'status':'ACCEPTED','effective':True,'key':'location','value':'field'},
      {'sequence':2,'status':'PROPOSED','effective':True,'key':'location','value':'HQ'},
      {'sequence':3,'status':'REJECTED','effective':True,'key':'knowledge','value':'secret'},
      {'sequence':4,'status':'ACCEPTED','effective':False,'key':'mission','value':'returned'},
      {'sequence':5,'status':'ACCEPTED','effective':True,'superseded':True,'key':'location','value':'lab'}]
  ck('ledger:projection_excludes_proposed_rejected_non_effective_and_superseded',accepted_projection(es)=={'location':'field'})
  es.append({'sequence':6,'status':'ACCEPTED','effective':True,'key':'location','value':'HQ'})
  ck('ledger:projection_applies_new_accepted_move',accepted_projection(es)=={'location':'HQ'})
  ck('suite:no_auto_reveal_date','No implicit date' in a and 'CHALLENGE_TIER_B' in a)

  files=[{'name':paths[k].name,'bytes':paths[k].stat().st_size,'lines':len(docs[k].splitlines()),'sha256':hashlib.sha256(paths[k].read_bytes()).hexdigest()} for k in FILES]
  return results,files

if __name__=='__main__':
  tests,files=run();failure=[x for x in tests if x['result']=='FAIL']
  evidence={'scope':'Local generated text and deterministic synthetic fixtures, not live source or story QA','test_count':len(tests),'passed':len(tests)-len(failure),'failed':len(failure),'tests':tests,'files':files,'external_sha_status':'NOT_MEASURED','live_episode_status':'NOT_RUN','editorial_approval':'NOT_PERFORMED','repository_deployment':'NOT_PERFORMED'}
  if '--json' in sys.argv:print(json.dumps(evidence,indent=2,ensure_ascii=False))
  else:
    print(f"LOCAL CC-02/CC-05 documentary and synthetic QA: {evidence['passed']}/{evidence['test_count']} PASS, {evidence['failed']} FAIL")
    for t in tests:print(t['result'],t['test'],t['details'] if t['result']=='FAIL' else '')
  raise SystemExit(1 if failure else 0)
