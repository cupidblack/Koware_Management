#!/usr/bin/env python3
"""CC-02 v0.09.01 candidate, deterministic documentary/calendar QA.

This script validates the *generated candidate documents* and synthetic calendar
arithmetic. It cannot ratify the master, test external sources or inspect a
live episode, source permissions, real media, repositories or key stores.

Usage:
    python cc02_contract_validator_v0.09.01.py
    python cc02_contract_validator_v0.09.01.py --json
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import re
from pathlib import Path

BASE = Path(__file__).resolve().parent
FILES = {
    "runbook": "CC-02.01-Daily_Chronicle_Generation_Protocol_v0.09.01_Candidate.md",
    "ledger": "CC-02.05-Episode_Continuity_Ledger-Production_Handover_v0.09.01_Candidate.md",
    "review": "CC-02.06-Daily_Protocol_and_Ledger_Alignment_Review_v0.09.01_Candidate.md",
}
Q = (
    "Q01_SCOPE", "Q02_CALENDAR", "Q03_THREE_CLOCKS", "Q04_IDENTIFIERS",
    "Q05_CANON", "Q06_ROLE_PROJECT", "Q07_STUDY", "Q08_VERSE_HS",
    "Q09_RESEARCH", "Q10_RIGHTS", "Q11_STORY", "Q12_CHALLENGE",
    "Q13_RECORDS", "Q14_DERIVATIVES", "Q15_INTEGRITY", "Q16_BOUNDARIES",
)
FAMILIES = (
    "episode_manifest", "episode_context_snapshot", "source_snapshot_register",
    "daily_chronicle_record", "research_register", "source_permission_register",
    "role_project_log", "mission_state_record", "character_state_record",
    "storyline_register", "continuity_event_log", "challenge_public_register",
    "challenge_answer_key", "production_manifest", "service_card_register",
    "editorial_decision_log", "exception_conflict_register", "validation_report",
    "handover_record",
)
STAGES = (
    "Eternal Dreamfall Bible Study", "Eternal Dreamfall Chronicle",
    "Refreshed Eternal Dreamfall", "Headlined Eternal Dreamfall",
    "Classies Eternal Dreamfall", "Classies Chronicles",
)
B = (
    "B1 — Run and temporal manifest", "B2 — Research/source register",
    "B3 — Character, Koware role and project register",
    "B4 — Mission and technology state", "B5 — Append-only continuity and story ledger",
    "B6 — Portable production handover", "B7 — Derivative/media and challenge status",
    "B8 — Validation, exceptions and approval register",
)
B6 = (
    "Identity and snapshot", "Source and authority basis", "Production calendar",
    "Temporal geometry", "Cast and role spotlight", "Character internal state",
    "Mission and Edubeam state", "Koware real-project boundary",
    "Story events and scene dependency", "Eternal Dreamfall derivation",
    "Research and safety", "Audience challenge state",
    "Visual/media continuity", "QA, conflicts and revisions", "Next-day handoff",
)


def first_monday_on_or_after(d: dt.date) -> dt.date:
    return d + dt.timedelta(days=(7 - d.weekday()) % 7)


def assign(date: dt.date, phase_start: dt.date, phase_end: dt.date,
           inclusive_end: bool = True, full_14_day_block: bool = True):
    """Synthetic standalone calendar oracle: raises ValueError if ineligible.

    phase_end is a DATE (not a datetime); duration and end convention are
    explicit. The real owner-approved calendar may separately authorize
    holidays or exceptional shorter spans and this oracle does NOT do so.
    """
    anchor = first_monday_on_or_after(phase_start)
    effective_last = phase_end if inclusive_end else phase_end - dt.timedelta(days=1)
    offset = (date - anchor).days
    if not (phase_start <= date <= effective_last) or offset < 0:
        raise ValueError("outside eligible local civil date range")
    block, block_day = divmod(offset, 14)
    if block > 3:
        raise ValueError("outside ordinary four-episode chapter")
    start = anchor + dt.timedelta(days=14 * block)
    required_last = start + dt.timedelta(days=13 if full_14_day_block else 11)
    if required_last > effective_last:
        raise ValueError("ordinary episode does not fully fit approved phase")
    if block_day in range(5):
        slot = block_day + 1
    elif block_day in range(7, 12):
        slot = block_day - 1
    else:
        raise ValueError("weekend, not an ordinary numbered chronicle")
    if date.weekday() >= 5:
        raise ValueError("internal weekday disagreement")
    return (block + 1, slot, 10 * block + slot)


def checksum(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def perform():
    checks = []
    def check(name: str, truth: bool, detail: str = ""):
        checks.append({"name": name, "result": "PASS" if truth else "FAIL", "detail": detail})

    paths = {name: BASE / fname for name, fname in FILES.items()}
    for name, p in paths.items():
        check(f"{name}: exists nonempty", p.is_file() and p.stat().st_size > 1000)
    if not all(p.is_file() for p in paths.values()):
        return checks, []
    docs = {name: p.read_text(encoding="utf-8") for name, p in paths.items()}
    r, l, v = (docs[n] for n in ("runbook", "ledger", "review"))
    for name, t in docs.items():
        check(f"{name}: candidate master referenced", "v0.09.01_Candidate" in t and "CC-01.01" in t)
        check(f"{name}: candidate release status is not presumed", "owner" in t.lower() and "candidate" in t.lower())
        check(f"{name}: no editorial placeholder brackets", not re.search(r"\{\{[^}]+\}\}|\bTODO\b|\bTBD\b|\[INSERT\b", t, re.I))
        check(f"{name}: file has complete end marker", bool(re.search(r"\*\*END — CC-02\.", t[-800:])))
    check("runbook stable logical ID", "CC-02.01 / CC-DCGP" in r)
    check("ledger stable logical ID", "CC-02.02 / CC-ECLPM" in l)
    check("review stable logical ID", "CC-02.03 / CC-ALIGN" in v)
    check("physical/logical collisions explicit", all(x in v for x in ("CC-02.02", "CC-02.03", "CC-02.05", "CC-02.06", "CC-05.01", "CC-05.02")))
    check("response compilation 3 observed empty not invented", "0 bytes" in v and "no substantive" in v.lower())

    # Runbook: parse the single canonical Q table rather than counting repeated prose mentions.
    section = r.split("## 10. Phase 8", 1)[1].split("### 10.1", 1)[0]
    rows = re.findall(r"^\| `(Q\d\d_[A-Z_]+)` \|", section, re.M)
    check("runbook exact 16 Q identifiers ordered", tuple(rows) == Q, str(rows))
    section = l.split("## 4. Complete nineteen-family canonical inventory", 1)[1].split("### 4.1", 1)[0]
    famrows = re.findall(r"^\|\s*(\d\d)\s*\|\s*`([a-z_]+)`\s*\|", section, re.M)
    check("ledger exact 19 family names ordered", tuple(x[1] for x in famrows) == FAMILIES and tuple(x[0] for x in famrows) == tuple(f"{i:02}" for i in range(1, 20)), str(famrows))
    check("legacy probe is alias not twentieth record", "legacy alias" in l.lower() and "not family #20" in l.lower())

    for name, t in docs.items():
        check(f"{name}: all 8 B section labels", all(b in t for b in B))
        check(f"{name}: all 6 stage titles", all(s in t for s in STAGES))
        check(f"{name}: 16 Q ID coverage", all(q in t for q in Q))
        check(f"{name}: 19 family coverage", all(f in t for f in FAMILIES))
    capsule = l.split("### 8.1 Mandatory B6 divisions", 1)[1].split("### 8.2", 1)[0]
    b6rows = re.findall(r"^(\d{1,2})\. \*\*([^*]+)\*\*", capsule, re.M)
    check("ledger exact B6 15 divisions names and order", tuple(x[1].strip(". ") for x in b6rows) == B6 and tuple(int(x[0]) for x in b6rows) == tuple(range(1,16)), str(b6rows))
    check("challenge key restricted only", "RESTRICTED OUTPUT NOT CREATED; HUMAN SECURE CUSTODY REQUIRED" in r and "RESTRICTED" in l)
    check("runbook mandates exact eight-operation merge loop", all(p in r for p in ("READ", "DECOMPOSE", "LOCK", "CONNECT", "TRANSFORM", "PRESERVE", "VALIDATE", "REGISTER")))
    check("runbook ten phase indices, Phase 0 through Phase 9", all(f"Phase {i} —" in r for i in range(10)))
    ids = re.findall(r"^\| `CC02-091-D(\d{2})` \|", v, re.M)
    check("review decision entries 01–45", ids == [f"{i:02}" for i in range(1,46)], f"count={len(ids)}")
    at_ids = re.findall(r"^\| `AT(\d{2})` \|", v, re.M)
    check("review acceptance specifications 01–45", at_ids == [f"{i:02}" for i in range(1,46)], f"count={len(at_ids)}")
    check("no implicit repository mutation", all("no" in t.lower() and "write" in t.lower() for t in (r,l,v)))

    # Synthetic arithmetic fixtures. Counts each broad group as one evidence-backed check.
    start = dt.date(2026, 1, 5)  # A synthetic Monday, not an approved production calendar.
    end = start + dt.timedelta(days=55)
    expected = {0:(1,1,1),4:(1,5,5),7:(1,6,6),11:(1,10,10),
                14:(2,1,11),18:(2,5,15),21:(2,6,16),25:(2,10,20),
                28:(3,1,21),39:(3,10,30),42:(4,1,31),53:(4,10,40)}
    check("calendar synthetic Monday first workday", start.weekday() == 0 and assign(start,start,end) == (1,1,1))
    check("calendar synthetic named 12 boundary fixtures", all(assign(start+dt.timedelta(days=i),start,end) == want for i,want in expected.items()))
    good, bad, matches = 0, 0, True
    for i in range(56):
        d = start + dt.timedelta(days=i)
        try:
            ep, slot, workday = assign(d,start,end)
            good += 1
            matches &= d.weekday() < 5 and 1 <= ep <= 4 and 1 <= slot <= 10 and workday == 10*(ep-1)+slot
        except ValueError:
            bad += 1
            matches &= d.weekday() >= 5
    check("calendar full synthetic four blocks 40 workdays 16 weekends", matches and good == 40 and bad == 16, f"weekday={good}; rejected={bad}")
    wednesday = dt.date(2026,1,7)
    anchor = first_monday_on_or_after(wednesday)
    check("calendar midweek start anchors next Monday", anchor == dt.date(2026,1,12))
    try:
        assign(wednesday,wednesday,wednesday+dt.timedelta(days=60))
        midweek_rejected = False
    except ValueError:
        midweek_rejected = True
    check("calendar partial midweek before first Monday rejected", midweek_rejected)
    partialend = start + dt.timedelta(days=48)
    try:
        assign(start + dt.timedelta(days=42),start,partialend)
        too_short_rejected = False
    except ValueError:
        too_short_rejected = True
    check("calendar fourth block truncated rejected", too_short_rejected)
    try:
        assign(start+dt.timedelta(days=5),start,end)
        weekend_rejected = False
    except ValueError:
        weekend_rejected = True
    check("calendar normal Saturday rejected", weekend_rejected)
    check("calendar independent chapter workday vs slot", assign(start+dt.timedelta(days=14),start,end) == (2,1,11))
    check("calendar end-exclusive bound honored", assign(start+dt.timedelta(days=53), start, end+dt.timedelta(days=1), inclusive_end=False) == (4,10,40))
    for i in range(54,56):
        d=start+dt.timedelta(days=i)
        try:
            assign(d,start,end)
            assert False, "expected weekend reject"
        except ValueError: pass
    check("calendar final 2 weekend days excluded", True)

    manifest = []
    for name,path in paths.items():
        manifest.append({"role":name, "file":path.name, "bytes":path.stat().st_size,
                         "lines": len(path.read_text(encoding="utf-8").splitlines()),
                         "sha256":checksum(path)})
    return checks, manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", action="store_true", help="emit machine readable evidence")
    args=parser.parse_args()
    checks, files = perform()
    passed=sum(item["result"] == "PASS" for item in checks)
    failed=len(checks)-passed
    payload={"scope":"candidate documentary and synthetic calendar arithmetic only",
             "checked":len(checks), "passed":passed, "failed":failed,
             "checks":checks, "files":files}
    if args.json:
        print(json.dumps(payload, indent=2, ensure_ascii=False))
    else:
        print(f"CC-02 candidate documentary checks: {passed}/{len(checks)} PASS; {failed} FAIL")
        for c in checks:
            print(f"{c['result']:4} {c['name']}" + (f" — {c['detail']}" if c['detail'] and c['result'] == 'FAIL' else ""))
        print("Local file hashes follow; no GitHub commit is claimed:")
        for f in files: print(f"{f['sha256']}  {f['file']}  ({f['bytes']} bytes, {f['lines']} lines)")
    raise SystemExit(1 if failed else 0)
