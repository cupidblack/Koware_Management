#!/usr/bin/env python3
"""Non-generative, auditable Classies Chronicles comic sheet cropper.

Requires Pillow (`python -m pip install Pillow`). No network access, no claims of rights.
This tool crops an existing user-authorized image into actual component pages,
validates source geometry, and writes source and crop hashes to JSON.
It never invents missing pixels or silently upscales to 1080x1920.

Examples:
  python cc_crop_comic_references.py --input S01.png --output-dir crops/S01 --rows 2 --cols 2 --start-page 1
  python cc_crop_comic_references.py --input legacy.png --output-dir crops/legacy --rows 4 --cols 4 --start-page 1 --allow-draft
  python cc_crop_comic_references.py --input sheet_gutter.png --output-dir crops/sheet --rows 2 --cols 2 --margin-x 20 --margin-y 20 --gutter-x 10 --gutter-y 10

Important: the example paths here describe CLI usage only and assert no files exist.
If the comics are not exactly divisible into given measured geometry, stop safely.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path
from PIL import Image, ImageOps

Image.MAX_IMAGE_PIXELS = 250_000_000

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()

def parse():
    ap = argparse.ArgumentParser(description='Crop actual rectangular comic sheets; no inferred assets or rights.')
    ap.add_argument('--input', type=Path, required=True, help='Existing rights-cleared input image')
    ap.add_argument('--output-dir', type=Path, required=True)
    ap.add_argument('--rows', type=int, choices=(1, 2, 3, 4), default=2)
    ap.add_argument('--cols', type=int, choices=(1, 2, 3, 4), default=2)
    ap.add_argument('--start-page', type=int, default=1)
    ap.add_argument('--margin-x', type=int, default=0, help='Measured exterior left AND right margin in pixels')
    ap.add_argument('--margin-y', type=int, default=0)
    ap.add_argument('--gutter-x', type=int, default=0, help='Measured space between each adjacent column')
    ap.add_argument('--gutter-y', type=int, default=0)
    ap.add_argument('--allow-draft', action='store_true', help='Permits dimension/aspect mismatch only as visibly classified draft crops')
    ap.add_argument('--make-stage', action='store_true', help='Also create non-distorted 1920x1080 F1 black-stage previews')
    ap.add_argument('--source-status', choices=('APPROVED_REFERENCE','PROVISIONAL_REFERENCE','UNKNOWN'), default='UNKNOWN')
    ap.add_argument('--rights-state', choices=('CLEARED_FOR_SPECIFIED_USE','NOT_VERIFIED','RESTRICTED'), default='NOT_VERIFIED')
    return ap.parse_args()

def stage16x9(im: Image.Image, size=(1920,1080)) -> Image.Image:
    page = im.convert('RGB')
    scaled = ImageOps.contain(page, size, Image.Resampling.LANCZOS)
    stage = Image.new('RGB', size, (18,21,27))
    stage.paste(scaled, ((size[0]-scaled.width)//2, (size[1]-scaled.height)//2))
    return stage

def main() -> int:
    a = parse()
    if not a.input.is_file():
        print('ERROR: source image does not exist; no crop performed', file=sys.stderr)
        return 2
    if a.start_page <= 0 or any(x < 0 for x in (a.margin_x,a.margin_y,a.gutter_x,a.gutter_y)):
        print('ERROR: page number must be positive, margins and gutters non-negative', file=sys.stderr)
        return 2
    if a.rights_state == 'RESTRICTED':
        print('ERROR: restricted source cannot be cropped under this workflow', file=sys.stderr)
        return 3
    with Image.open(a.input) as opened:
        im = ImageOps.exif_transpose(opened)
        im.load()
        image = im.copy()
    W, H = image.size
    available_w = W - 2*a.margin_x - (a.cols-1)*a.gutter_x
    available_h = H - 2*a.margin_y - (a.rows-1)*a.gutter_y
    if available_w <= 0 or available_h <= 0:
        print('ERROR: margins/gutters exceed source size', file=sys.stderr)
        return 2
    if available_w % a.cols or available_h % a.rows:
        print('ERROR: geometry does not divide exactly; measure gutters/margins first', file=sys.stderr)
        return 2
    cell_w, cell_h = available_w // a.cols, available_h // a.rows
    exact_ratio = (cell_w*16 == cell_h*9)
    native = cell_w >= 1080 and cell_h >= 1920 and exact_ratio
    if not exact_ratio and not a.allow_draft:
        print(f'ERROR: crop cell {cell_w}x{cell_h} is not 9:16; --allow-draft is preview-only',file=sys.stderr)
        return 4
    a.output_dir.mkdir(parents=True, exist_ok=True)
    source_hash = sha256(a.input)
    record = dict(tool='cc_crop_comic_references.py', checked_utc=datetime.now(timezone.utc).isoformat(),
        input_path=str(a.input.resolve()),input_sha256=source_hash,original_size=[W,H],layout=[a.rows,a.cols],
        margin_xy=[a.margin_x,a.margin_y],gutter_xy=[a.gutter_x,a.gutter_y],
        source_status=a.source_status,rights_state=a.rights_state,
        geometry_status='EXACT_9_16' if exact_ratio else 'DRAFT_NON_9_16',
        resolution_status='NATIVE_GEOMETRY_ELIGIBLE' if native else 'LOW_RES_OR_ASPECT_DRAFT',
        note='Geometric eligibility only; does not prove original native capture, legal license, visual readability, or actual editor approval.',
        output_pages=[])
    for r in range(a.rows):
        for c in range(a.cols):
            page_no = a.start_page + r*a.cols+c
            left = a.margin_x+c*(cell_w+a.gutter_x)
            top = a.margin_y+r*(cell_h+a.gutter_y)
            box=(left,top,left+cell_w,top+cell_h)
            crop=image.crop(box)
            name=f'P{page_no:02d}.png'
            p=a.output_dir/name
            crop.save(p,format='PNG')
            item=dict(page_id=f'P{page_no:02d}',row=r+1,column=c+1,box=list(box),
                      crop_path=str(p.resolve()),crop_sha256=sha256(p),size=[cell_w,cell_h],
                      source_sha256=source_hash,rights_state=a.rights_state,
                      status='CROPPED_GEOMETRY_VERIFIED' if exact_ratio else 'CROPPED_DRAFT_PREVIEW')
            if a.make_stage:
                sp=a.output_dir/f'P{page_no:02d}_F1_16x9_STAGE_PREVIEW.png'
                stage16x9(crop).save(sp,format='PNG')
                item['stage_preview_path']=str(sp.resolve())
                item['stage_preview_sha256']=sha256(sp)
                item['stage_preview_size']=[1920,1080]
            record['output_pages'].append(item)
    manifest=a.output_dir/'crop_manifest.json'
    manifest.write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'manifest':str(manifest.resolve()),'source_sha256':source_hash,
                      'pages_cropped':len(record['output_pages']),'cell_size':[cell_w,cell_h],
                      'resolution_status':record['resolution_status'],
                      'rights_state':a.rights_state},indent=2))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
