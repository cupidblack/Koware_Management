# CC-04 v0.09.06 — Source Review Index

**Source review date:** 19 November 2026 UTC. The URLs below are public repository documents inspected during this review; they are not immutable Git commit hashes and therefore do not prove unchanged revisions in the future. This index is discovery evidence only, not adoption or portrait/license permission.

## Classies Chronicles: Unified production, daily and continuity

- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-01.01-Unified_Production_Master_Prompt_v0.09.01_Candidate.md
- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-01.01_Comic_Default_Alignment_Amendment_v0.09.04_PROPOSED.md
- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-01.02-Convergence_QA_and_File_Manifest_v0.09.01_Candidate.md
- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-01.03-Convergence_Review_Decision_and_Traceability_v0.09.01_Candidate.md
- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-02.01-Daily_Chronicle_Generation_Protocol_v0.09.03_Candidate.md
- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-02.02-Episode_Continuity_Ledger-Production_Handover_v0.09.03_Candidate.md
- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-02.03-Daily_Protocol_and_Ledger_Alignment_Review_v0.09.03_Candidate.md
- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-02.04-Daily_Chronicle_QA_and_File_Manifest_v0.09.03_Candidate.md
- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-05.01-Context_Merge_Engine_Master_Prompt_v0.02.01_Candidate.md
- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-05.02-Context_Merge_Refactor_Review_and_Decision_Log_v0.02.01_Candidate.md

## Comic specialist

- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-03.01-Master_Comic_Generation_Prompt_v0.09.04_Candidate.md
- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-03.02-Comic_Refactor_Review_Conflict_Register_and_Change_Traceability_v0.09.04_Candidate.md
- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-03.03-Comic_QA_and_File_Manifest_v0.09.04_Candidate.md

## Media predecessors

- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-04.01-Master_Media_Generation_Prompt_v0.08.00.md
- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-04.02-Media_Refactor_Review_Conflict_Register_and_Change_Traceability_v0.08.00.md
- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-04.03-Media_QA_and_File_Manifest_v0.08.00.md
- https://raw.githubusercontent.com/cupidblack/Classies_Chronicles/refs/heads/main/CC_AI_DESK/CC-04.04-Top_20_Image_to_Video_Platforms_v0.08.00.md

## Studio and cross-platform response corpus

- https://raw.githubusercontent.com/cupidblack/Koware_Management/refs/heads/main/BlueCrown/Laboratory/development/Studio_Structure_Skeletal_Blueprint/Studio_Structure_Skeletal_Blueprint_v22.2.txt
- https://raw.githubusercontent.com/cupidblack/Koware_Management/refs/heads/main/BlueCrown/Laboratory/development/Studio_Structure_Skeletal_Blueprint/Studio_Structure_Skeletal_Blueprint_v22.1.txt
- https://raw.githubusercontent.com/cupidblack/Koware_Management/refs/heads/main/BlueCrown/Laboratory/development/cc_framework_proposal/04.Master_Media_Generation_Prompt/CC-Master_Media_Generation_Prompt_development_responses-3.txt

**Cross-platform attribution:** only `GITHUB-1` contained substantive proposed media prompt material in the supplied compilation; all other named platform response blocks contained `NULL`. Earlier historical candidate versions mentioned inside those documents are lineage only, not asserted freshly inspected file bytes here.
