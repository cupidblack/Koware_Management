# Classies Chronicles — Master Media Convergence Package
**Edition:** CC-04 v0.09.06 Candidate | **Prepared:** 19 November 2026 UTC

This package is a complete **proposed** CC-04 media specialist set, built against the cited November 2026 CC-01, CC-02, CC-03 and CC-05 candidate suites and Studio Blueprint v22.2. It has **not** changed the GitHub repository or been approved for real publication. It supplies a usable operator prompt, governance review, executed documentary QA, twenty-service candidate register and a runnable actual-image crop tool.

## Contents

- `CC-04.01-Master_Media_Generation_Prompt_v0.09.06_Candidate.md` — principal production prompt: 38 numbered sections, exact M01–M30 gates, T01–T30 intended regression scenarios, ten complete noncanonical image-to-video test prompts, governing hierarchy and 16:9 workflow.
- `CC-04.02-Media_Refactor_Review_Conflict_Register_and_Change_Traceability_v0.09.06_Candidate.md` — review and traceability (24 conflicts and 40 proposed decisions).
- `CC-04.03-Media_QA_and_File_Manifest_v0.09.06_Candidate.md` — candidate completeness, honest actual-test scope and non-executed production QA.
- `CC-04.04-Top_20_Image_to_Video_Platforms_v0.09.06_Candidate.md` — twenty-ranked services, evidence tiers, official evidence URLs and zero unsupported promises of free renewable access in any particular account.
- `cc_crop_comic_references.py` — non-generative Pillow image cropper; handles measured 2×2 or 4×4 sheet layouts, 9:16 compliance, optional F1 16:9 stage preview, original/crop SHA-256 and JSON crop manifest.
- `validate_media_suite.py` — actual static + synthetic QA runner.
- `QA_EXECUTION_LOG.txt`, `QA_MACHINE_READABLE.json` — 223 documentary/synthetic checks and exact results.
- `SOURCE_REVIEW_INDEX.md` — all primary materials indexed by exact source URL.

## Use the prompt

1. For a **review only**, load CC-04.01 and ask for `MEDIA_REVIEW_ONLY`; do not generate media automatically.
2. For an **actual episode film**, first supply the exact accepted Public Output A and authorized Challenge A, accepted ledger head, episode/date and intended runtime; separately authorize a media plan or generation as appropriate.
3. Select `MEDIA_PLATFORM_PROMPTS` to obtain **specific** paste-ready prompts from an actual approved script and source art; the ten generic R01–R10 treatments in the master are for calibrating motion on rights-cleared images, not invented story scenes.
4. If real approved comic art is a 2×2 sheet, use the crop script with a real path and permission. Only upload references after checking the provider terms, consent and exact account/model eligibility.
5. Respect 16:9 output, terminal challenge, all shot motion/camera/environment attributes, measured artifacts and separate human review.

## Crop tool command example

```bash
python cc_crop_comic_references.py --input /path/to/authorized/S01.png \
  --output-dir /path/to/output/S01 --rows 2 --cols 2 --start-page 1 \
  --source-status APPROVED_REFERENCE --rights-state CLEARED_FOR_SPECIFIED_USE \
  --make-stage
```

**Note:** The `/path/to` strings in this README are CLI illustrations, *not* file inventory declarations. The cropper errors for nonexistent images. If four page cells measure less than the intended 1080×1920, output is correctly marked a low-resolution or aspect draft; it is never called a native page merely because of a renamed file.

## Deterministic QA

```bash
python -m pip install Pillow
python validate_media_suite.py
```

This creates a temporary **synthetic** 2160×3840 2×2 sheet and tests its crops, then checks intentional failures, Markdown completeness and exact required identifiers. The last run achieved **223 PASS / 0 FAIL** on documentary/synthetic tests. Actual episode media M01–M30 remain `NOT_RUN` and cannot pass until real materials are commissioned and inspected.

## Unresolved policy and scope decisions

The CC-UPMP v0.09.01 candidate retains **16 pages** in §42; the CC-03.01 v0.09.04 candidate and a separate amendment propose **8 pages** as ordinary comic default. Until the owner formally adopts that alignment, use the **exact user-commissioned N** or the genuinely selected effective master. Video remains **16:9** no matter how many 9:16 comic pages supply its sources. A 160-second daily film and approximately 200-second Studio insert are different editable specifications. No character-specific crops or real generated video clips appear in this document-review package because a single accepted episode and approved visual source bytes were not supplied as the media-render input.

**Local candidate package only. No repository commit, external upload, rendering or release occurred.**
