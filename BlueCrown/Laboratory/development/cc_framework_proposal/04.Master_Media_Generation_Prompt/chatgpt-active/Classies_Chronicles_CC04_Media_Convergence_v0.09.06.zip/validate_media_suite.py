#!/usr/bin/env python3
"""Static document and synthetic geometry regression checks for CC-04 v0.09.06.
Not a substitute for commissioned media M01–M30 real-asset QA.
"""
import hashlib, json, re, subprocess, sys, tempfile
from pathlib import Path
from PIL import Image, ImageDraw
BASE=Path(__file__).parent
DOC={f'{n:02d}': next(BASE.glob(f'CC-04.{n:02d}-*v0.09.06_Candidate.md')) for n in range(1,5)}
master=DOC['01'].read_text(encoding='utf8')
review=DOC['02'].read_text(encoding='utf8')
providers=DOC['04'].read_text(encoding='utf8')
results=[]
def chk(name, condition, evidence=''):
    results.append(dict(check=name,result='PASS' if condition else 'FAIL',evidence=evidence))
# Structural checks
for k,p in DOC.items():
    chk(f'DOC{k}_EXISTS_NONEMPTY', p.exists() and p.stat().st_size > 2000,p.name)
    chk(f'DOC{k}_UTF8_END',bool(re.search(r'\*\*END [—\-] CC-04\.'+k+r'.*v0\.09\.06.*Candidate\.\*\*\s*$',p.read_text(encoding='utf8'))),'final document signature')
for word in ('PROPOSED_FOR_OWNER_REVIEW','MEDIA_REVIEW_ONLY','16:9','1920 × 1080','24 or 30','200 seconds','160 seconds','N=16','N=8','M01–M30','B1–B8'):
    chk('CONTRACT_'+re.sub(r'[^A-Z0-9]','_',word.upper()),word in master,word)
for word in ('PUBLIC','INTERNAL','RESTRICTED','PUBLIC_DELIVERY','P/H/F','EDUBEAM','challenge_answer_key'):
    if word=='EDUBEAM':
        ok='Edubeam' in master
    else:
        ok=word in master
    chk('BOUNDARY_'+word,ok,word)
for mode in ('MEDIA_REVIEW_ONLY','MEDIA_PLAN','MEDIA_SCRIPT','MEDIA_STORYBOARD','MEDIA_PLATFORM_PROMPTS','MEDIA_CROP_REFERENCES','MEDIA_GENERATE_ASSETS','MEDIA_EDIT_ASSEMBLE','MEDIA_REVISE','MEDIA_QA_RELEASE_REVIEW'):
    chk('MODE_'+mode,mode in master)
for motion in ('STATIONARY','SUBTLE_ANIMATED','FULL_MOTION','MIXED'):
    chk('MOTION_'+motion,motion in master)
for framing in ('F1_FIT_STAGE','F2_REFRAME_SAFE','F3_SPLIT_VIEW','F4_EDITED_STILL','F5_GRAPHIC_MONTAGE'):
    chk('FRAMING_'+framing,framing in master)
for i in range(1,31):
    key=f'M{i:02d}'
    chk('GATE_'+key, len(re.findall(r'^\| '+key+r' \|',master,re.M))==1, 'exactly one master matrix row')
for i in range(1,31):
    key=f'T{i:02d}'
    chk('TEST_SPEC_'+key, len(re.findall(r'^\| '+key+r' \|',master,re.M))==1, 'one test specification; not executed')
for i in range(1,11):
    key=f'R{i:02d}'
    chk('TEST_PROMPT_'+key, len(re.findall(r'^\*\*'+key+r' —',master,re.M))==1, 'one complete noncanonical prompt treatment')
for i in range(1,41):
    key=f'MD-{i:02d}'
    chk('DECISION_'+key, len(re.findall(r'^\| '+key+r' \|',review,re.M))==1,'one actual proposed decision record')
for i in range(1,25):
    key=f'CF-{i:02d}'
    chk('CONFLICT_'+key, len(re.findall(r'^\| '+key+r' \|',review,re.M))==1, 'one risk disposition')
for name in ('episode_manifest','episode_context_snapshot','source_snapshot_register','daily_chronicle_record',
             'research_register','source_permission_register','role_project_log','mission_state_record',
             'character_state_record','storyline_register','continuity_event_log','challenge_public_register',
             'challenge_answer_key','production_manifest','service_card_register','editorial_decision_log',
             'exception_conflict_register','validation_report','handover_record'):
    chk('LEDGER_'+name, name in master)
rows=re.findall(r'^\|\s*(\d{1,2})\s*\|\s*\*\*([^*]+)\*\*',providers,re.M)
chk('PROVIDER_20_ROWS',len(rows)==20,'Twenty ranked entries')
chk('PROVIDER_SEQUENTIAL', [int(x[0]) for x in rows]==list(range(1,21)))
chk('PROVIDER_UNIQUE',len(set(x[1].strip() for x in rows))==20)
for key in ('Magic Hour','Pika','Runway','Krea','Adobe Firefly','Ghana','NOT_VERIFIED'):
    chk('PROVIDER_CONDITION_'+re.sub(r'\W','_',key),key in providers)
chk('REVIEW_NULL_RESPONSES_RECOGNIZED', 'eight model authors' in review and 'GITHUB-1' in review)
chk('REVIEW_NOT_ADOPTED', 'not an accepted owner decision' in review)
chk('NO_LITERAL_TEMPLATE_BRACKETS', '{{' not in master and '}}' not in master)
# source geometry calculations
chk('GEOMETRY_2X2_1080x1920', 2*1080==2160 and 2*1920==3840 and 2160*16==3840*9)
chk('GEOMETRY_4X4_1080x1920',4*1080==4320 and 4*1920==7680 and 4320*16==7680*9)
chk('GEOMETRY_1024x1536_SHEET_NOT_9X16', 1024*16 != 1536*9)
# Run crop utility in a temporary directory with a synthetic source of exact dimensions.
with tempfile.TemporaryDirectory() as td:
    base=Path(td)
    src=base/'synthetic_2x2.png'
    im=Image.new('RGB',(2160,3840),'white')
    d=ImageDraw.Draw(im)
    for row in range(2):
        for col in range(2):
            i=row*2+col
            colr=((i*63)%256, (i*90)%256, (i*120)%256)
            d.rectangle((col*1080,row*1920,(col+1)*1080-1,(row+1)*1920-1),fill=colr)
    im.save(src)
    cmd=[sys.executable,str(BASE/'cc_crop_comic_references.py'),'--input',str(src),'--output-dir',str(base/'out'),'--source-status','PROVISIONAL_REFERENCE','--rights-state','NOT_VERIFIED']
    proc=subprocess.run(cmd,text=True,capture_output=True)
    chk('CROP_CMD_RETURN_OK',proc.returncode==0,proc.stderr[-150:])
    if proc.returncode==0:
        manifest=json.loads((base/'out'/'crop_manifest.json').read_text())
        chk('CROP_FOUR_DISTINCT_PAGES', len(manifest['output_pages'])==4)
        chk('CROP_IDENTICAL_SOURCE_HASH',all(c['source_sha256']==manifest['input_sha256'] for c in manifest['output_pages']))
        chk('CROP_NONDESTRUCTIVE',Image.open(src).size==(2160,3840))
        chk('CROP_PAGES_NATIVE_GEOMETRY', all(c['size']==[1080,1920] for c in manifest['output_pages']))
        positions=[p['box'] for p in manifest['output_pages']]
        chk('CROP_ROW_MAJOR_COORDS',positions==[[0,0,1080,1920],[1080,0,2160,1920],[0,1920,1080,3840],[1080,1920,2160,3840]])
        chk('CROP_RIGHTS_NOT_OVERCLAIMED', all(c['rights_state']=='NOT_VERIFIED' for c in manifest['output_pages']))
    else:
        for name in ('CROP_FOUR_DISTINCT_PAGES','CROP_IDENTICAL_SOURCE_HASH','CROP_NONDESTRUCTIVE','CROP_PAGES_NATIVE_GEOMETRY','CROP_ROW_MAJOR_COORDS','CROP_RIGHTS_NOT_OVERCLAIMED'):
            chk(name,False,'crop test failed')
    bad=base/'bad_ratio.png'; Image.new('RGB',(1024,1536),'white').save(bad)
    proc2=subprocess.run([sys.executable,str(BASE/'cc_crop_comic_references.py'),'--input',str(bad),'--output-dir',str(base/'badout')],capture_output=True,text=True)
    chk('CROP_FAILS_UNSAFE_RATIO',proc2.returncode==4)
    proc3=subprocess.run([sys.executable,str(BASE/'cc_crop_comic_references.py'),'--input',str(src),'--output-dir',str(base/'restricted'),'--rights-state','RESTRICTED'],capture_output=True,text=True)
    chk('CROP_BLOCKS_RESTRICTED',proc3.returncode==3)

report={'suite':'CC-04 v0.09.06 static + synthetic checks','scope':'DOCUMENT_AND_SYNTHETIC_TEST_ONLY',
        'pass':sum(x['result']=='PASS' for x in results),'fail':sum(x['result']=='FAIL' for x in results),'checks':results,
        'not_executed':'No real episode source, real comic crop, clip rendering, audio, release, M01–M30 production acceptance or provider balance verified.'}
(BASE/'QA_MACHINE_READABLE.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
(BASE/'QA_EXECUTION_LOG.txt').write_text('\n'.join(f"{x['result']:4s} {x['check']} {x.get('evidence','')}" for x in results)+f"\nTOTAL PASS={report['pass']} FAIL={report['fail']}\n",encoding='utf8')
print(f"Document/synthetic tests: {report['pass']} PASS; {report['fail']} FAIL")
sys.exit(1 if report['fail'] else 0)
