#!/usr/bin/env python3
"""Offline structural checks for the 62 proposed aliased character canon files."""
import csv, pathlib, re, sys
ROOT=pathlib.Path(__file__).resolve().parent
p=ROOT/'CHARACTER_CANON_MANIFEST.csv'
rows=list(csv.DictReader(p.open(encoding='utf-8',newline='')))
errors=[]
if len(rows)!=62: errors.append(f'Expected 62 manifest entries; found {len(rows)}')
seen=set(); ids=set();paths=set()
for e in rows:
 slug=e['character_slug'];target=ROOT/slug/(slug+'_character_cannon.md')
 if slug in seen:errors.append('Duplicate slug '+slug)
 seen.add(slug)
 if e['canonical_identifier'] in ids:errors.append('Duplicate ID '+e['canonical_identifier'])
 ids.add(e['canonical_identifier'])
 if not target.is_file():errors.append('Missing '+str(target));continue
 paths.add(target.resolve());body=target.read_text(encoding='utf-8')
 for needle in ['daily_diaries_url: null','visual_collage_url: null','## 13 · Editorial approval','source_alias:','chapter_check_days:']:
  if needle not in body:errors.append(f'{slug}: missing field or section: {needle}')
 for url in re.findall(r'\]\((\.\./[^)]*)\)',body):
  clean=url.split('#')[0]
  if not (target.parent/clean).exists() and 'CUPID_BLACK' not in clean:
   errors.append(f'{slug}: broken internal link {url}')
 # stop a family/relationship description being mislabelled as verified biographical fact
 if 'all fictional' not in body.lower() and 'all fiction' not in body.lower():
  errors.append(f'{slug}: missing fiction notice')
images=[f for f in ROOT.rglob('*') if f.is_file() and f.suffix.lower() in ('.jpg','.jpeg','.png','.webp','.gif','.svg')]
if images: errors.append(f'Unexpected images: {len(images)}')
actual=set(ROOT.glob('*/*_character_cannon.md'))
if len(actual)!=62: errors.append(f'Expected 62 character files, found {len(actual)}')
if actual!=set(pathlib.Path(x) for x in paths):errors.append('File set differs from manifest')
if errors:
 print('VALIDATION FAILED:');print('\n'.join(' - '+a for a in errors));sys.exit(1)
print('VALIDATION PASSED: 62 unique roles, slugs, IDs, source fields, diary and visual absent fields, relative links; 0 image files.')
