# Classies Chronicles — Character Canon File Migration

**Created:** 2026-11-05. **Deliverable:** 62 Markdown character canon drafts plus index and manifest. **No images generated.**

Extract this archive at the root of the `Classies_Chronicles` repository, retaining the nested path `CC_AI_DESK/04_CANON/CHARACTERS/`. Each aliased chart role has one own folder and one own `*_character_cannon.md` file.

**Do not treat these as approved franchise canon or real-person biographies.** All detailed personal attributes were fictionalized for narrative ideation. The chart establishes only source alias, role, placement and checks. The explicit existing `CUPID_BLACK` file was not copied, replaced or changed.

Use `CHARACTER_CANON_INDEX.md` for the navigation and editorial checklist. Use `character_canon_manifest.csv` for bulk import and review. GitHub publication and public-facing portrayal require the studio's editorial and consent process.
