---
canon_id: "CHAR-DEREK-SHIRASKA"
character_slug: "DEREK_SHIRASKA"
character_display: "Derek Shiraska"
document_version: "0.01.00"
status: "DRAFT — AWAITING HUMAN EDITORIAL REVIEW"
classification: "FICTIONAL CHARACTER DESIGN — NOT REAL-PERSON BIOGRAPHY"
created: "2026-11-05"
chart_check_days: "16,36"
daily_diaries_url: null
visual_collage_url: null
publication_consent: "UNKNOWN — NOT GRANTED BY SOURCE ALIAS"
---

# Derek Shiraska — Character Canon (Proposed)

> **EDITORIAL / PERSONAL-DATA FIREWALL:** This is a **fictional character double** created for story design from an aliased organizational chart, **not a biography, verified employment record, real likeness, genealogy, or statement of the named person’s preferences**. Except the quoted chart role/alias/check day and explicit references to existing Classies canon, **all birthdays, places, ethnic/cultural details, schooling, family, romance, physical dimensions, previous jobs, tastes and story events below are invented**. Do not publish or publicly portray an identifiable individual without valid editorial consent.

## 01. Canon record and authority

- **In-universe role:** Production Coordinator.
- **Chart alias as written:** `Derek Shiraska (GIMPA TA Golf City)`.
- **Organizational chapter working-day checks:** `16,36` (repeating 20-day slot, not episode day).
- **Reporting line / narrative hierarchy:** [Johnson Ortsin](../JOHNSON_ORTSIN/JOHNSON_ORTSIN_character_cannon.md) — Programme Manager.
- **Role checks source:** [Organizational_Chart_Structure-Aliased_Checks.txt](https://raw.githubusercontent.com/cupidblack/Koware_Management/refs/heads/main/Organizational_Chart_Structure-Aliased_Checks.txt), source line 55.
- **Repository target:** `CC_AI_DESK/04_CANON/CHARACTERS/DEREK_SHIRASKA/DEREK_SHIRASKA_character_cannon.md`.
- **Status:** Draft production proposal only. No profile assertion is an approved, locked or biographical fact.

## 02. Identity, origins and personal timeline (fictional)

- **Proposed date of birth:** 1993-04-16. Approximate age on 2026-11-05: **33**, based solely on fictional proposed date of birth.
- **Proposed place of birth:** Masvingo, Zimbabwe.
- **Proposed nation/citizenship:** Zimbabwean.
- **Proposed cultural/ethnic background:** Shona (purely fictional; do **not** infer ancestry, nationality or ethnicity of a real person from a name).
- **Languages used in draft scenes:** English and conversational Shona or Ndebele, as suited to the character arc.
- **Pronouns for the fictional role:** he/his.
- **Current story location:** unassigned; set from the approved episode’s location and temporal ledger rather than hard-coding headquarters.

## 03. Physical appearance and visual lock proposal

- **Proposed on-page build:** approximately 167 cm, about 53 kg; deep warm brown; dark brown eyes; near-black hair. These are *fictional visual-design cues*, not observed measurements.
- **Distinguishing silhouette:** Tall wiry frame, close curls and teal cap. A second silhouette cue is a careful forward lean while listening.
- **Voice and movement:** measured, low-volume sentences; reacts under stress by organizing objects into rows.
- **Continuity invariants:** retain the face shape, hair length/color family, skin undertone, silhouette, eyewear if used, and the signature item across comic pages. No celebrity/real-person likeness is implied.

## 04. Family, relationships and support network

In this *fiction-only* timeline, Derek grew up with parent figures Joyce and Yao; a younger sister lives in another town and calls on weekends. Their family values keeping promises, even when inconvenient; family names and occupations are wholly invented and must not be associated with a real person.

**Proposed relationship status:** separated amicably and co-parenting one unnamed child. Names and life circumstances in this paragraph are narrative inventions, not personal data.

## 05. Education, training and earlier life

- **Early education (fully fictional):** Cedar Walk Primary (primary, ages 6–12); Copperleaf Junior High (junior secondary, ages 12–15); Copper Coast Secondary School (secondary/senior high, ages 15–18). All are *invented in-universe institutions*; these are not assertions about the real alias.
- **Higher study or professional training:** Proposed diploma/degree focus in **Production scheduling and live-event logistics** at the **Fictional Westbridge Academy**; later short courses in ethics, first aid and collaborative problem-solving (all imagined, no credential claim).
- **Previous work (in-universe fiction):** Stage operations aide at the fictional Stonebridge Media House.
- **Reason for joining the Classies ensemble:** produce a flawless ethical broadcast from field conditions while contributing to the Koware-connected fictional narrative; not evidence of an actual appointment.

## 06. Koware role, routine and accountability

- **Role purpose:** Production Coordinator translates individual professional craft into reliable work, humane decisions and clear handovers during the story.
- **Role competencies:** instructional logistics, peer learning, scheduling and verification against evidence.
- **Potential mission interface:** prepare and review protocols without asserting courses, credentials or operations exist in the real world.
- **Safety / integrity line:** protect learners, access needs, academic integrity and labor limits.
- **Character’s regular work artifact:** Clipped production slate with yellow tape. Treat it as a prop, not a magical device or real company equipment.
- **Chapter spotlight use:** Prepare a role-appropriate chapter-day spotlight on working-day checks **16,36**. In one scene, show how the work is performed; in another, contrast it with a compatible role encountered in the historical or probe stream. Never claim the scene describes an actual Koware staff action or an authorized mission deployment.

## 07. Inner life, mannerisms and decision style

Derek Shiraska is a senior character within the imagined Koware-linked ensemble. The character’s distinctive gift can be summarized as “Recovers quickly when plans collapse”; the recurring blind spot is “Relies too much on last-minute brilliance.” The central ambition is to produce a flawless ethical broadcast from field conditions. The daily tension is not a superpower: it is whether professionalism survives an unfamiliar ethical demand.

- **Strength:** Recovers quickly when plans collapse. **Complicating flaw:** Relies too much on last-minute brilliance.
- **Long-range aspiration:** Produce a flawless ethical broadcast from field conditions.
- **Default dialogue texture:** grounded professional language; favors this invented personal line: “Keep the next cue human.” It is **not** an approved recurring catchphrase.
- **Under pressure:** asks a precise, potentially uncomfortable question before acting.
- **Moral boundary:** verify what happened, do not use people’s vulnerability as plot decoration, and prefer accountable choices to instant certainty.

## 08. Cultural life, entertainment, habits and taste

- **Favorite artist:** Aṣa (fictional preference); **favorite song:** “Jailer (Aṣa)” (title only; no lyrics).
- **Favorite film and series:** *Bend It Like Beckham* and *The Queen's Gambit*; character takes inspiration from patient craft.
- **Sports and games:** netball for movement; tabletop mysteries for thinking and sociability. Favorite weekly pastime: documentary screenings.
- **Food and drink:** akple with okro stew; iced coffee. Weekend comfort ritual: sharing food after a long project day.
- **Favorite imagined hangout:** a bowling alley lounge; chosen for peace and good listening.
- **Style code:** bright Ghanaian-print overshirts over dark basics; performance/workwear varies by mission hazard and location. The signature accessory is clipped production slate with yellow tape.
- **Strong likes:** competent teamwork, honest exchanges, local crafts and situations where the signature strength can matter (recovers quickly when plans collapse). **Dislikes:** needless plastic packaging; unverified rumor; being rushed into unverified promises.

## 09. Internal ensemble links

- **Organizational supervisor / mentor axis:** [Johnson Ortsin](../JOHNSON_ORTSIN/JOHNSON_ORTSIN_character_cannon.md) — Programme Manager.
- **Nearby role connections in the chart:** [Matthias Agbenorku](../MATTHIAS_AGBENORKU/MATTHIAS_AGBENORKU_character_cannon.md) — Director of Operations. These are **fictional professional storytelling links**, not assertions of personal friendship, kinship or private contact.
- **Conflict that could become solidarity:** the trait “relies too much on last-minute brilliance” clashes with a colleague who prizes a different form of truth; resolution must arise through earned conversation and consequence.
- **Trust model:** start as courteous professional peers; no invented romance, feud, familial link or confidential access with another named character becomes locked without a human editorial decision.

## 10. Story seeds, growth and continuity gates

- **First proposed scene:** A planned camera feed shows a street not yet built. It is a **fictional scenario prompt**, not an occurred episode event.
- **Mystery hook:** Clipped production slate with yellow tape becomes a mundane clue to a mismatch between production, historical-reference and probe/destination clocks; the clue does not prove supernatural causation.
- **Character choice:** investigate patiently, anchored by a strength (recovers quickly when plans collapse), or act too quickly when the blind spot surfaces (relies too much on last-minute brilliance).
- **Suggested payoff:** their aspiration to produce a flawless ethical broadcast from field conditions gains an ethical cost; the next episode should carry forward a changed habit rather than an unexplained power upgrade.
- **Temporal caution:** destination/Edubeam events are mission proposals only until written in an approved chronicle; do not assign a fictional character to real-world travel, dates, meetings, payroll or membership.
- **Potential narrative function:** an ordinary skill becomes the overlooked factor that prevents a bigger systems mistake; team actions must have limitations, witnesses and a recordable cost.

## 11. Visual production brief — asset pending

- **Proposed future collage filename:** `DEREK_SHIRASKA_CHARACTER_REFERENCE_COLLAGE.jpg` inside this folder. **NOT CREATED** (explicitly out of scope).
- **Future collage coverage:** front-facing neutral portrait; three-quarter expression study; full-body everyday outfit; role-specific workwear; close-up of hands and signature tool; three facial emotions; simple palette strip; daylight and indoor-light comparisons.
- **Style anchor:** Tall wiry frame, close curls and teal cap. Costume continuity: bright Ghanaian-print overshirts over dark basics.
- **No images yet:** `visual_collage_url: null`. Never mistake a future filename for an existing or approved file, and never improvise a likeness of the real alias.
- **Visual locks require approval:** silhouette, hairstyle, color cues and distinguishing details become firm only after explicit editorial review and any required likeness consent.

## 12. Daily Diaries link and episode-state handover

- **Daily Diaries (authorized URL):** `PENDING — INSERT LINK AFTER VERIFICATION AND PERMISSION REVIEW`.
- **Diary reference schema:** `diary_url`, `owner`, `scope` (private/internal/public), `consent_basis`, `last_verified_iso`, `eligible_excerpt_ids`, `excluded_private_content`; values are deliberately **unassigned**.
- **Diary usage:** no private diary quotation, biographical extraction, home location, family fact or plot event may be inferred without explicit access, consent and provenance.
- **Episode continuity state:** `debut_episode: UNASSIGNED`; `active_mission: NONE CONFIRMED`; `last_scene: NOT ESTABLISHED`; `open_threads: PROPOSED ONLY`; `latest_visual_revision: NONE`.

## 13. Editorial clearance, conflicts and revision history

- **Organization role mapping:** grounded only in the supplied aliased chart; source annotations in parentheses are reference labels, **not proof of school attendance, qualifications, employment or private biography**.
- **Creative inventions:** all supplementary attributes in §§02–11 are standalone story pitches. They must not be presented as established real-world facts.
- **Consent state:** `UNKNOWN`; public use is blocked for identifiable portrayal until an authorized review confirms the character design/identity and applicable permissions.
- **Canon decision required:** approve, amend, fictionalize further, anonymize or reject each invented detail; then version and lock only approved decisions.
- **Framework awareness:** CC Structured Master Prompt v0.03.01 and Comic Prompt v0.03.01 are proposed references, not automatic approval to change franchise canon.
- **Revision 0.01.00 — 2026-11-05:** first proposed standalone character canon. **No images generated. No GitHub files changed by this package.**
