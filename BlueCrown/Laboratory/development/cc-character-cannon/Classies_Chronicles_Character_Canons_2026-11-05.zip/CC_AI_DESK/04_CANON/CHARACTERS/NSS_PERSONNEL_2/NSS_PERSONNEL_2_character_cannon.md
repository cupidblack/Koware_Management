---
canon_id: "CHAR-NSS-PERSONNEL-2"
character_slug: "NSS_PERSONNEL_2"
character_display: "NSS Personnel-2"
document_version: "0.01.00"
status: "DRAFT — AWAITING HUMAN EDITORIAL REVIEW"
classification: "FICTIONAL CHARACTER DESIGN — NOT REAL-PERSON BIOGRAPHY"
created: "2026-11-05"
chart_check_days: "4,24"
daily_diaries_url: null
visual_collage_url: null
publication_consent: "UNKNOWN — NOT GRANTED BY SOURCE ALIAS"
---

# NSS Personnel-2 — Character Canon (Proposed)

> **EDITORIAL / PERSONAL-DATA FIREWALL:** This is a **fictional character double** created for story design from an aliased organizational chart, **not a biography, verified employment record, real likeness, genealogy, or statement of the named person’s preferences**. Except the quoted chart role/alias/check day and explicit references to existing Classies canon, **all birthdays, places, ethnic/cultural details, schooling, family, romance, physical dimensions, previous jobs, tastes and story events below are invented**. Do not publish or publicly portray an identifiable individual without valid editorial consent.

## 01. Canon record and authority

- **In-universe role:** Liaison Assistant.
- **Chart alias as written:** `NSS Personnel-2`.
- **Organizational chapter working-day checks:** `4,24` (repeating 20-day slot, not episode day).
- **Reporting line / narrative hierarchy:** [Enka YAMOAH](../ENKA_YAMOAH/ENKA_YAMOAH_character_cannon.md) — Corporate Manager.
- **Role checks source:** [Organizational_Chart_Structure-Aliased_Checks.txt](https://raw.githubusercontent.com/cupidblack/Koware_Management/refs/heads/main/Organizational_Chart_Structure-Aliased_Checks.txt), source line 14.
- **Repository target:** `CC_AI_DESK/04_CANON/CHARACTERS/NSS_PERSONNEL_2/NSS_PERSONNEL_2_character_cannon.md`.
- **Status:** Draft production proposal only. No profile assertion is an approved, locked or biographical fact.
**Fictional stage-name candidate:** Sena Ayitey (invented; **not** the name of the real NSS staff member).

## 02. Identity, origins and personal timeline (fictional)

- **Proposed date of birth:** 2003-03-23. Approximate age on 2026-11-05: **23**, based solely on fictional proposed date of birth.
- **Proposed place of birth:** Ho, Ghana.
- **Proposed nation/citizenship:** Ghanaian.
- **Proposed cultural/ethnic background:** Ewe (purely fictional; do **not** infer ancestry, nationality or ethnicity of a real person from a name).
- **Languages used in draft scenes:** English; conversational Ewe (fictional character proficiency, not evidence of ancestry).
- **Pronouns for the fictional role:** they/their.
- **Current story location:** unassigned; set from the approved episode’s location and temporal ledger rather than hard-coding headquarters.

## 03. Physical appearance and visual lock proposal

- **Proposed on-page build:** approximately 197 cm, about 80 kg; deep warm brown; dark brown eyes; black hair. These are *fictional visual-design cues*, not observed measurements.
- **Distinguishing silhouette:** Braided topknot and rounded acetate glasses. A second silhouette cue is an unhurried stride and open shoulders.
- **Voice and movement:** expressive pauses and quick clarifying questions; reacts under stress by seeking a quieter corner before answering.
- **Continuity invariants:** retain the face shape, hair length/color family, skin undertone, silhouette, eyewear if used, and the signature item across comic pages. No celebrity/real-person likeness is implied.

## 04. Family, relationships and support network

In this *fiction-only* timeline, NSS grew up with parent figures Adwoa and Yaw; a older brother lives in another town and calls on weekends. Their family values showing up for neighbours; family names and occupations are wholly invented and must not be associated with a real person.

**Proposed relationship status:** in a committed relationship with fictional partner Ruth. Names and life circumstances in this paragraph are narrative inventions, not personal data.

## 05. Education, training and earlier life

- **Early education (fully fictional):** Sunpath Basic School (primary, ages 6–12); Meadowline Junior High (junior secondary, ages 12–15); New Crescent Secondary School (secondary/senior high, ages 15–18). All are *invented in-universe institutions*; these are not assertions about the real alias.
- **Higher study or professional training:** Proposed diploma/degree focus in **Information science** at the **Fictional Harbor City University**; later short courses in ethics, first aid and collaborative problem-solving (all imagined, no credential claim).
- **Previous work (in-universe fiction):** Assistant at the fictional Everbright Records Annex.
- **Reason for joining the Classies ensemble:** create a dependable handover language while contributing to the Koware-connected fictional narrative; not evidence of an actual appointment.

## 06. Koware role, routine and accountability

- **Role purpose:** Liaison Assistant translates individual professional craft into reliable work, humane decisions and clear handovers during the story.
- **Role competencies:** liaison handovers, routing, listening and traceable decisions.
- **Potential mission interface:** record only verified mission observations, separate historical/current/probe clocks.
- **Safety / integrity line:** do not assume an alias establishes consent to public portrayal.
- **Character’s regular work artifact:** Tiny binder of color-coded checkpoints. Treat it as a prop, not a magical device or real company equipment.
- **Chapter spotlight use:** Prepare a role-appropriate chapter-day spotlight on working-day checks **4,24**. In one scene, show how the work is performed; in another, contrast it with a compatible role encountered in the historical or probe stream. Never claim the scene describes an actual Koware staff action or an authorized mission deployment.

## 07. Inner life, mannerisms and decision style

NSS Personnel-2 is a early-career character within the imagined Koware-linked ensemble. The character’s distinctive gift can be summarized as “Checks facts before sharing them”; the recurring blind spot is “Freezes when two authorities disagree.” The central ambition is to create a dependable handover language. The daily tension is not a superpower: it is whether professionalism survives an unfamiliar ethical demand.

- **Strength:** Checks facts before sharing them. **Complicating flaw:** Freezes when two authorities disagree.
- **Long-range aspiration:** Create a dependable handover language.
- **Default dialogue texture:** grounded professional language; favors this invented personal line: “I will confirm the address.” It is **not** an approved recurring catchphrase.
- **Under pressure:** begins doing helpful work before clarifying authority.
- **Moral boundary:** verify what happened, do not use people’s vulnerability as plot decoration, and prefer accountable choices to instant certainty.

## 08. Cultural life, entertainment, habits and taste

- **Favorite artist:** Burna Boy (fictional preference); **favorite song:** “On the Low (Burna Boy)” (title only; no lyrics).
- **Favorite film and series:** *The Martian* and *The Good Place*; character takes inspiration from second chances.
- **Sports and games:** tennis for movement; Oware for thinking and sociability. Favorite weekly pastime: public astronomy meetups.
- **Food and drink:** boiled plantain with palava sauce; unsweetened cocoa. Weekend comfort ritual: taking a slow walk before a home-cooked meal.
- **Favorite imagined hangout:** a campus badminton court; chosen for the people and stories.
- **Style code:** crisp shirts, tailored trousers and a handmade pin; performance/workwear varies by mission hazard and location. The signature accessory is tiny binder of color-coded checkpoints.
- **Strong likes:** competent teamwork, honest exchanges, local crafts and situations where the signature strength can matter (checks facts before sharing them). **Dislikes:** noise during deep-focus work; unsafe shortcuts; being rushed into unverified promises.

## 09. Internal ensemble links

- **Organizational supervisor / mentor axis:** [Enka YAMOAH](../ENKA_YAMOAH/ENKA_YAMOAH_character_cannon.md) — Corporate Manager.
- **Nearby role connections in the chart:** [NSS Personnel-1](../NSS_PERSONNEL_1/NSS_PERSONNEL_1_character_cannon.md) — Liaison Officer. These are **fictional professional storytelling links**, not assertions of personal friendship, kinship or private contact.
- **Conflict that could become solidarity:** the trait “freezes when two authorities disagree” clashes with a colleague who prizes a different form of truth; resolution must arise through earned conversation and consequence.
- **Trust model:** start as courteous professional peers; no invented romance, feud, familial link or confidential access with another named character becomes locked without a human editorial decision.

## 10. Story seeds, growth and continuity gates

- **First proposed scene:** A routine delivery slips across the wrong clock. It is a **fictional scenario prompt**, not an occurred episode event.
- **Mystery hook:** Tiny binder of color-coded checkpoints becomes a mundane clue to a mismatch between production, historical-reference and probe/destination clocks; the clue does not prove supernatural causation.
- **Character choice:** investigate patiently, anchored by a strength (checks facts before sharing them), or act too quickly when the blind spot surfaces (freezes when two authorities disagree).
- **Suggested payoff:** their aspiration to create a dependable handover language gains an ethical cost; the next episode should carry forward a changed habit rather than an unexplained power upgrade.
- **Temporal caution:** destination/Edubeam events are mission proposals only until written in an approved chronicle; do not assign a fictional character to real-world travel, dates, meetings, payroll or membership.
- **Potential narrative function:** an ordinary skill becomes the overlooked factor that prevents a bigger systems mistake; team actions must have limitations, witnesses and a recordable cost.

## 11. Visual production brief — asset pending

- **Proposed future collage filename:** `NSS_PERSONNEL_2_CHARACTER_REFERENCE_COLLAGE.jpg` inside this folder. **NOT CREATED** (explicitly out of scope).
- **Future collage coverage:** front-facing neutral portrait; three-quarter expression study; full-body everyday outfit; role-specific workwear; close-up of hands and signature tool; three facial emotions; simple palette strip; daylight and indoor-light comparisons.
- **Style anchor:** Braided topknot and rounded acetate glasses. Costume continuity: crisp shirts, tailored trousers and a handmade pin.
- **No images yet:** `visual_collage_url: null`. Never mistake a future filename for an existing or approved file, and never improvise a likeness of the real alias.
- **Visual locks require approval:** silhouette, hairstyle, color cues and distinguishing details become firm only after explicit editorial review and any required likeness consent.

## 12. Daily Diaries link and episode-state handover

- **Daily Diaries (authorized URL):** `PENDING — INSERT LINK AFTER VERIFICATION AND PERMISSION REVIEW`.
- **Diary reference schema:** `diary_url`, `owner`, `scope` (private/internal/public), `consent_basis`, `last_verified_iso`, `eligible_excerpt_ids`, `excluded_private_content`; values are deliberately **unassigned**.
- **Diary usage:** no private diary quotation, biographical extraction, home location, family fact or plot event may be inferred without explicit access, consent and provenance.
- **Episode continuity state:** `debut_episode: UNASSIGNED`; `active_mission: NONE CONFIRMED`; `last_scene: NOT ESTABLISHED`; `open_threads: PROPOSED ONLY`; `latest_visual_revision: NONE`.

## 13. Editorial clearance, conflicts and revision history

- **Organization role mapping:** grounded only in the supplied aliased chart; source annotations in parentheses are reference labels, **not proof of school attendance, qualifications, employment or private biography**.
- **Creative inventions:** all supplementary attributes in §§02–11 are standalone story pitches. They must not be presented as established real-world facts.
- **Consent state:** `UNKNOWN`; public use is blocked for identifiable portrayal until an authorized review confirms the character design/identity and applicable permissions.
- **Canon decision required:** approve, amend, fictionalize further, anonymize or reject each invented detail; then version and lock only approved decisions.
- **Framework awareness:** CC Structured Master Prompt v0.03.01 and Comic Prompt v0.03.01 are proposed references, not automatic approval to change franchise canon.
- **Revision 0.01.00 — 2026-11-05:** first proposed standalone character canon. **No images generated. No GitHub files changed by this package.**
