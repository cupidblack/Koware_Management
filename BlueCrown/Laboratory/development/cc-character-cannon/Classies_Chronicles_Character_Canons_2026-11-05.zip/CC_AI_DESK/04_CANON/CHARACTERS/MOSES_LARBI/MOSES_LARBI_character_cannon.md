---
canon_id: "CHAR-MOSES-LARBI"
character_slug: "MOSES_LARBI"
character_display: "Moses Larbi"
document_version: "0.01.00"
status: "DRAFT — AWAITING HUMAN EDITORIAL REVIEW"
classification: "FICTIONAL CHARACTER DESIGN — NOT REAL-PERSON BIOGRAPHY"
created: "2026-11-05"
chart_check_days: "15,35"
daily_diaries_url: null
visual_collage_url: null
publication_consent: "UNKNOWN — NOT GRANTED BY SOURCE ALIAS"
---

# Moses Larbi — Character Canon (Proposed)

> **EDITORIAL / PERSONAL-DATA FIREWALL:** This is a **fictional character double** created for story design from an aliased organizational chart, **not a biography, verified employment record, real likeness, genealogy, or statement of the named person’s preferences**. Except the quoted chart role/alias/check day and explicit references to existing Classies canon, **all birthdays, places, ethnic/cultural details, schooling, family, romance, physical dimensions, previous jobs, tastes and story events below are invented**. Do not publish or publicly portray an identifiable individual without valid editorial consent.

## 01. Canon record and authority

- **In-universe role:** Quality Assurance & Compliance Manager.
- **Chart alias as written:** `Moses Larbi (GIMPA QASA Miriam)`.
- **Organizational chapter working-day checks:** `15,35` (repeating 20-day slot, not episode day).
- **Reporting line / narrative hierarchy:** [James Evans](../JAMES_EVANS/JAMES_EVANS_character_cannon.md) — Director of Academic Programs.
- **Role checks source:** [Organizational_Chart_Structure-Aliased_Checks.txt](https://raw.githubusercontent.com/cupidblack/Koware_Management/refs/heads/main/Organizational_Chart_Structure-Aliased_Checks.txt), source line 52.
- **Repository target:** `CC_AI_DESK/04_CANON/CHARACTERS/MOSES_LARBI/MOSES_LARBI_character_cannon.md`.
- **Status:** Draft production proposal only. No profile assertion is an approved, locked or biographical fact.

## 02. Identity, origins and personal timeline (fictional)

- **Proposed date of birth:** 1984-01-04. Approximate age on 2026-11-05: **42**, based solely on fictional proposed date of birth.
- **Proposed place of birth:** Obuasi, Ghana.
- **Proposed nation/citizenship:** Ghanaian.
- **Proposed cultural/ethnic background:** Asante (purely fictional; do **not** infer ancestry, nationality or ethnicity of a real person from a name).
- **Languages used in draft scenes:** English; conversational Asante (fictional character proficiency, not evidence of ancestry).
- **Pronouns for the fictional role:** he/his.
- **Current story location:** unassigned; set from the approved episode’s location and temporal ledger rather than hard-coding headquarters.

## 03. Physical appearance and visual lock proposal

- **Proposed on-page build:** approximately 171 cm, about 64 kg; deep warm brown; dark brown eyes; dark brown hair. These are *fictional visual-design cues*, not observed measurements.
- **Distinguishing silhouette:** Shaved head, straight-backed posture. A second silhouette cue is an unhurried stride and open shoulders.
- **Voice and movement:** measured, low-volume sentences; reacts under stress by seeking a quieter corner before answering.
- **Continuity invariants:** retain the face shape, hair length/color family, skin undertone, silhouette, eyewear if used, and the signature item across comic pages. No celebrity/real-person likeness is implied.

## 04. Family, relationships and support network

In this *fiction-only* timeline, Moses grew up with parent figures Ama and Kojo; a older brother lives in another town and calls on weekends. Their family values keeping promises, even when inconvenient; family names and occupations are wholly invented and must not be associated with a real person.

**Proposed relationship status:** single and privately content with close friendships. Names and life circumstances in this paragraph are narrative inventions, not personal data.

## 05. Education, training and earlier life

- **Early education (fully fictional):** Asterfield Primary (primary, ages 6–12); Marigold Junior School (junior secondary, ages 12–15); Cedarline Senior High (secondary/senior high, ages 15–18). All are *invented in-universe institutions*; these are not assertions about the real alias.
- **Higher study or professional training:** Proposed diploma/degree focus in **Educational quality assurance and risk controls** at the **Fictional Meridian Institute of Technology**; later short courses in ethics, first aid and collaborative problem-solving (all imagined, no credential claim).
- **Previous work (in-universe fiction):** Standards reviewer at the fictional Goldleaf Institute.
- **Reason for joining the Classies ensemble:** build fair, low-burden quality controls while contributing to the Koware-connected fictional narrative; not evidence of an actual appointment.

## 06. Koware role, routine and accountability

- **Role purpose:** Quality Assurance & Compliance Manager translates individual professional craft into reliable work, humane decisions and clear handovers during the story.
- **Role competencies:** document chain-of-custody, quiet verification, discrepancy triage, access-controlled reports.
- **Potential mission interface:** paper and digital audit trail; preserve uncertain provenance and flag contradictory timestamps.
- **Safety / integrity line:** privacy, evidence quality and nonaccusatory reporting; no reading restricted diaries without authorization.
- **Character’s regular work artifact:** Pocket-sized transparent checklist board. Treat it as a prop, not a magical device or real company equipment.
- **Chapter spotlight use:** Prepare a role-appropriate chapter-day spotlight on working-day checks **15,35**. In one scene, show how the work is performed; in another, contrast it with a compatible role encountered in the historical or probe stream. Never claim the scene describes an actual Koware staff action or an authorized mission deployment.

## 07. Inner life, mannerisms and decision style

Moses Larbi is a senior character within the imagined Koware-linked ensemble. The character’s distinctive gift can be summarized as “Makes evidence standards intelligible”; the recurring blind spot is “Equates caution with loyalty to procedure.” The central ambition is to build fair, low-burden quality controls. The daily tension is not a superpower: it is whether professionalism survives an unfamiliar ethical demand.

- **Strength:** Makes evidence standards intelligible. **Complicating flaw:** Equates caution with loyalty to procedure.
- **Long-range aspiration:** Build fair, low-burden quality controls.
- **Default dialogue texture:** grounded professional language; favors this invented personal line: “Compliance serves learners.” It is **not** an approved recurring catchphrase.
- **Under pressure:** asks a precise, potentially uncomfortable question before acting.
- **Moral boundary:** verify what happened, do not use people’s vulnerability as plot decoration, and prefer accountable choices to instant certainty.

## 08. Cultural life, entertainment, habits and taste

- **Favorite artist:** Labi Siffre (fictional preference); **favorite song:** “Something Inside So Strong (Labi Siffre)” (title only; no lyrics).
- **Favorite film and series:** *Rafiki* and *Ted Lasso*; character takes inspiration from patient craft.
- **Sports and games:** table tennis for movement; Oware for thinking and sociability. Favorite weekly pastime: neighborhood reading circles.
- **Food and drink:** yam chips and grilled fish; sobolo. Weekend comfort ritual: taking a slow walk before a home-cooked meal.
- **Favorite imagined hangout:** a museum workshop café; chosen for peace and good listening.
- **Style code:** structured monochrome workwear with one patterned accent; performance/workwear varies by mission hazard and location. The signature accessory is pocket-sized transparent checklist board.
- **Strong likes:** competent teamwork, honest exchanges, local crafts and situations where the signature strength can matter (makes evidence standards intelligible). **Dislikes:** needlessly late meetings; noise during deep-focus work; being rushed into unverified promises.

## 09. Internal ensemble links

- **Organizational supervisor / mentor axis:** [James Evans](../JAMES_EVANS/JAMES_EVANS_character_cannon.md) — Director of Academic Programs.
- **Nearby role connections in the chart:** [Steven Sarpong](../STEVEN_SARPONG/STEVEN_SARPONG_character_cannon.md) — Academic Registrar; [Matthew Ebenezer](../MATTHEW_EBENEZER/MATTHEW_EBENEZER_character_cannon.md) — Academic Partnerships & Outreach Officer. These are **fictional professional storytelling links**, not assertions of personal friendship, kinship or private contact.
- **Conflict that could become solidarity:** the trait “equates caution with loyalty to procedure” clashes with a colleague who prizes a different form of truth; resolution must arise through earned conversation and consequence.
- **Trust model:** start as courteous professional peers; no invented romance, feud, familial link or confidential access with another named character becomes locked without a human editorial decision.

## 10. Story seeds, growth and continuity gates

- **First proposed scene:** An otherwise perfect course evaluation contains a missing date. It is a **fictional scenario prompt**, not an occurred episode event.
- **Mystery hook:** Pocket-sized transparent checklist board becomes a mundane clue to a mismatch between production, historical-reference and probe/destination clocks; the clue does not prove supernatural causation.
- **Character choice:** investigate patiently, anchored by a strength (makes evidence standards intelligible), or act too quickly when the blind spot surfaces (equates caution with loyalty to procedure).
- **Suggested payoff:** their aspiration to build fair, low-burden quality controls gains an ethical cost; the next episode should carry forward a changed habit rather than an unexplained power upgrade.
- **Temporal caution:** destination/Edubeam events are mission proposals only until written in an approved chronicle; do not assign a fictional character to real-world travel, dates, meetings, payroll or membership.
- **Potential narrative function:** an ordinary skill becomes the overlooked factor that prevents a bigger systems mistake; team actions must have limitations, witnesses and a recordable cost.

## 11. Visual production brief — asset pending

- **Proposed future collage filename:** `MOSES_LARBI_CHARACTER_REFERENCE_COLLAGE.jpg` inside this folder. **NOT CREATED** (explicitly out of scope).
- **Future collage coverage:** front-facing neutral portrait; three-quarter expression study; full-body everyday outfit; role-specific workwear; close-up of hands and signature tool; three facial emotions; simple palette strip; daylight and indoor-light comparisons.
- **Style anchor:** Shaved head, straight-backed posture. Costume continuity: structured monochrome workwear with one patterned accent.
- **No images yet:** `visual_collage_url: null`. Never mistake a future filename for an existing or approved file, and never improvise a likeness of the real alias.
- **Visual locks require approval:** silhouette, hairstyle, color cues and distinguishing details become firm only after explicit editorial review and any required likeness consent.

## 12. Daily Diaries link and episode-state handover

- **Daily Diaries (authorized URL):** `PENDING — INSERT LINK AFTER VERIFICATION AND PERMISSION REVIEW`.
- **Diary reference schema:** `diary_url`, `owner`, `scope` (private/internal/public), `consent_basis`, `last_verified_iso`, `eligible_excerpt_ids`, `excluded_private_content`; values are deliberately **unassigned**.
- **Diary usage:** no private diary quotation, biographical extraction, home location, family fact or plot event may be inferred without explicit access, consent and provenance.
- **Episode continuity state:** `debut_episode: UNASSIGNED`; `active_mission: NONE CONFIRMED`; `last_scene: NOT ESTABLISHED`; `open_threads: PROPOSED ONLY`; `latest_visual_revision: NONE`.

## 13. Editorial clearance, conflicts and revision history

- **Organization role mapping:** grounded only in the supplied aliased chart; source annotations in parentheses are reference labels, **not proof of school attendance, qualifications, employment or private biography**.
- **Creative inventions:** all supplementary attributes in §§02–11 are standalone story pitches. They must not be presented as established real-world facts.
- **Consent state:** `UNKNOWN`; public use is blocked for identifiable portrayal until an authorized review confirms the character design/identity and applicable permissions.
- **Canon decision required:** approve, amend, fictionalize further, anonymize or reject each invented detail; then version and lock only approved decisions.
- **Framework awareness:** CC Structured Master Prompt v0.03.01 and Comic Prompt v0.03.01 are proposed references, not automatic approval to change franchise canon.
- **Revision 0.01.00 — 2026-11-05:** first proposed standalone character canon. **No images generated. No GitHub files changed by this package.**
