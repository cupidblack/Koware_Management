---
canon_id: "CHAR-CORNELIUS-JEKORA"
character_slug: "CORNELIUS_JEKORA"
character_display: "Cornelius Jekora"
document_version: "0.01.00"
status: "DRAFT — AWAITING HUMAN EDITORIAL REVIEW"
classification: "FICTIONAL CHARACTER DESIGN — NOT REAL-PERSON BIOGRAPHY"
created: "2026-11-05"
chart_check_days: "12,32"
daily_diaries_url: null
visual_collage_url: null
publication_consent: "UNKNOWN — NOT GRANTED BY SOURCE ALIAS"
---

# Cornelius Jekora — Character Canon (Proposed)

> **EDITORIAL / PERSONAL-DATA FIREWALL:** This is a **fictional character double** created for story design from an aliased organizational chart, **not a biography, verified employment record, real likeness, genealogy, or statement of the named person’s preferences**. Except the quoted chart role/alias/check day and explicit references to existing Classies canon, **all birthdays, places, ethnic/cultural details, schooling, family, romance, physical dimensions, previous jobs, tastes and story events below are invented**. Do not publish or publicly portray an identifiable individual without valid editorial consent.

## 01. Canon record and authority

- **In-universe role:** Janitor.
- **Chart alias as written:** `Cornelius Jekora (Lucy Ibotson Accra)`.
- **Organizational chapter working-day checks:** `12,32` (repeating 20-day slot, not episode day).
- **Reporting line / narrative hierarchy:** [Esther Justine](../ESTHER_JUSTINE/ESTHER_JUSTINE_character_cannon.md) — Cleaning Technician.
- **Role checks source:** [Organizational_Chart_Structure-Aliased_Checks.txt](https://raw.githubusercontent.com/cupidblack/Koware_Management/refs/heads/main/Organizational_Chart_Structure-Aliased_Checks.txt), source line 41.
- **Repository target:** `CC_AI_DESK/04_CANON/CHARACTERS/CORNELIUS_JEKORA/CORNELIUS_JEKORA_character_cannon.md`.
- **Status:** Draft production proposal only. No profile assertion is an approved, locked or biographical fact.

## 02. Identity, origins and personal timeline (fictional)

- **Proposed date of birth:** 1991-06-23. Approximate age on 2026-11-05: **35**, based solely on fictional proposed date of birth.
- **Proposed place of birth:** Gweru, Zimbabwe.
- **Proposed nation/citizenship:** Zimbabwean.
- **Proposed cultural/ethnic background:** Shona (purely fictional; do **not** infer ancestry, nationality or ethnicity of a real person from a name).
- **Languages used in draft scenes:** English and conversational Shona or Ndebele, as suited to the character arc.
- **Pronouns for the fictional role:** he/his.
- **Current story location:** unassigned; set from the approved episode’s location and temporal ledger rather than hard-coding headquarters.

## 03. Physical appearance and visual lock proposal

- **Proposed on-page build:** approximately 161 cm, about 48 kg; deep warm brown; dark brown eyes; salt-and-pepper hair. These are *fictional visual-design cues*, not observed measurements.
- **Distinguishing silhouette:** Close-cropped curls, broad shoulders and work boots. A second silhouette cue is a careful forward lean while listening.
- **Voice and movement:** expressive pauses and quick clarifying questions; reacts under stress by organizing objects into rows.
- **Continuity invariants:** retain the face shape, hair length/color family, skin undertone, silhouette, eyewear if used, and the signature item across comic pages. No celebrity/real-person likeness is implied.

## 04. Family, relationships and support network

In this *fiction-only* timeline, Cornelius grew up with parent figures Joyce and Yao; a younger sister lives in another town and calls on weekends. Their family values showing up for neighbours; family names and occupations are wholly invented and must not be associated with a real person.

**Proposed relationship status:** in a committed relationship with fictional partner Fiona. Names and life circumstances in this paragraph are narrative inventions, not personal data.

## 05. Education, training and earlier life

- **Early education (fully fictional):** New Market Primary (primary, ages 6–12); Harborview Junior School (junior secondary, ages 12–15); Meridian Heights Academy (secondary/senior high, ages 15–18). All are *invented in-universe institutions*; these are not assertions about the real alias.
- **Higher study or professional training:** Proposed diploma/degree focus in **Building care and basic electrical safety** at the **Fictional Coastal Arts & Media College**; later short courses in ethics, first aid and collaborative problem-solving (all imagined, no credential claim).
- **Previous work (in-universe fiction):** Maintenance cleaner at the fictional Beacon Transit Hall.
- **Reason for joining the Classies ensemble:** become a certified facilities technician while contributing to the Koware-connected fictional narrative; not evidence of an actual appointment.

## 06. Koware role, routine and accountability

- **Role purpose:** Janitor translates individual professional craft into reliable work, humane decisions and clear handovers during the story.
- **Role competencies:** operational safety, humane service, hazard spotting, respectful facilities care.
- **Potential mission interface:** observe conditions and report; avoid treating a fictional incident as real company work.
- **Safety / integrity line:** protect rest, bodily autonomy, privacy, sanitation and safe access.
- **Character’s regular work artifact:** Carefully wrapped flashlight and chalk. Treat it as a prop, not a magical device or real company equipment.
- **Chapter spotlight use:** Prepare a role-appropriate chapter-day spotlight on working-day checks **12,32**. In one scene, show how the work is performed; in another, contrast it with a compatible role encountered in the historical or probe stream. Never claim the scene describes an actual Koware staff action or an authorized mission deployment.

## 07. Inner life, mannerisms and decision style

Cornelius Jekora is a senior character within the imagined Koware-linked ensemble. The character’s distinctive gift can be summarized as “Improvises simple tools that preserve safety”; the recurring blind spot is “Believes he must fix everything alone.” The central ambition is to become a certified facilities technician. The daily tension is not a superpower: it is whether professionalism survives an unfamiliar ethical demand.

- **Strength:** Improvises simple tools that preserve safety. **Complicating flaw:** Believes he must fix everything alone.
- **Long-range aspiration:** Become a certified facilities technician.
- **Default dialogue texture:** grounded professional language; favors this invented personal line: “Check twice; touch once.” It is **not** an approved recurring catchphrase.
- **Under pressure:** begins doing helpful work before clarifying authority.
- **Moral boundary:** verify what happened, do not use people’s vulnerability as plot decoration, and prefer accountable choices to instant certainty.

## 08. Cultural life, entertainment, habits and taste

- **Favorite artist:** Osibisa (fictional preference); **favorite song:** “Sunshine Day (Osibisa)” (title only; no lyrics).
- **Favorite film and series:** *The Hundred-Foot Journey* and *The Bear*; character takes inspiration from second chances.
- **Sports and games:** netball for movement; tabletop mysteries for thinking and sociability. Favorite weekly pastime: low-key poetry readings.
- **Food and drink:** kelewele and roasted peanuts; ginger tea. Weekend comfort ritual: sharing food after a long project day.
- **Favorite imagined hangout:** a old railway café; chosen for the people and stories.
- **Style code:** athletic streetwear adapted for field visits; performance/workwear varies by mission hazard and location. The signature accessory is carefully wrapped flashlight and chalk.
- **Strong likes:** competent teamwork, honest exchanges, local crafts and situations where the signature strength can matter (improvises simple tools that preserve safety). **Dislikes:** careless handling of equipment; unfair queue-jumping; being rushed into unverified promises.

## 09. Internal ensemble links

- **Organizational supervisor / mentor axis:** [Esther Justine](../ESTHER_JUSTINE/ESTHER_JUSTINE_character_cannon.md) — Cleaning Technician.
- **Nearby role connections in the chart:** [Pauline Mbuso](../PAULINE_MBUSO/PAULINE_MBUSO_character_cannon.md) — Maid. These are **fictional professional storytelling links**, not assertions of personal friendship, kinship or private contact.
- **Conflict that could become solidarity:** the trait “believes he must fix everything alone” clashes with a colleague who prizes a different form of truth; resolution must arise through earned conversation and consequence.
- **Trust model:** start as courteous professional peers; no invented romance, feud, familial link or confidential access with another named character becomes locked without a human editorial decision.

## 10. Story seeds, growth and continuity gates

- **First proposed scene:** He hears a lift moving in an unpowered wing. It is a **fictional scenario prompt**, not an occurred episode event.
- **Mystery hook:** Carefully wrapped flashlight and chalk becomes a mundane clue to a mismatch between production, historical-reference and probe/destination clocks; the clue does not prove supernatural causation.
- **Character choice:** investigate patiently, anchored by a strength (improvises simple tools that preserve safety), or act too quickly when the blind spot surfaces (believes he must fix everything alone).
- **Suggested payoff:** their aspiration to become a certified facilities technician gains an ethical cost; the next episode should carry forward a changed habit rather than an unexplained power upgrade.
- **Temporal caution:** destination/Edubeam events are mission proposals only until written in an approved chronicle; do not assign a fictional character to real-world travel, dates, meetings, payroll or membership.
- **Potential narrative function:** an ordinary skill becomes the overlooked factor that prevents a bigger systems mistake; team actions must have limitations, witnesses and a recordable cost.

## 11. Visual production brief — asset pending

- **Proposed future collage filename:** `CORNELIUS_JEKORA_CHARACTER_REFERENCE_COLLAGE.jpg` inside this folder. **NOT CREATED** (explicitly out of scope).
- **Future collage coverage:** front-facing neutral portrait; three-quarter expression study; full-body everyday outfit; role-specific workwear; close-up of hands and signature tool; three facial emotions; simple palette strip; daylight and indoor-light comparisons.
- **Style anchor:** Close-cropped curls, broad shoulders and work boots. Costume continuity: athletic streetwear adapted for field visits.
- **No images yet:** `visual_collage_url: null`. Never mistake a future filename for an existing or approved file, and never improvise a likeness of the real alias.
- **Visual locks require approval:** silhouette, hairstyle, color cues and distinguishing details become firm only after explicit editorial review and any required likeness consent.

## 12. Daily Diaries link and episode-state handover

- **Daily Diaries (authorized URL):** `PENDING — INSERT LINK AFTER VERIFICATION AND PERMISSION REVIEW`.
- **Diary reference schema:** `diary_url`, `owner`, `scope` (private/internal/public), `consent_basis`, `last_verified_iso`, `eligible_excerpt_ids`, `excluded_private_content`; values are deliberately **unassigned**.
- **Diary usage:** no private diary quotation, biographical extraction, home location, family fact or plot event may be inferred without explicit access, consent and provenance.
- **Episode continuity state:** `debut_episode: UNASSIGNED`; `active_mission: NONE CONFIRMED`; `last_scene: NOT ESTABLISHED`; `open_threads: PROPOSED ONLY`; `latest_visual_revision: NONE`.

## 13. Editorial clearance, conflicts and revision history

- **Organization role mapping:** grounded only in the supplied aliased chart; source annotations in parentheses are reference labels, **not proof of school attendance, qualifications, employment or private biography**.
- **Creative inventions:** all supplementary attributes in §§02–11 are standalone story pitches. They must not be presented as established real-world facts.
- **Consent state:** `UNKNOWN`; public use is blocked for identifiable portrayal until an authorized review confirms the character design/identity and applicable permissions.
- **Canon decision required:** approve, amend, fictionalize further, anonymize or reject each invented detail; then version and lock only approved decisions.
- **Framework awareness:** CC Structured Master Prompt v0.03.01 and Comic Prompt v0.03.01 are proposed references, not automatic approval to change franchise canon.
- **Revision 0.01.00 — 2026-11-05:** first proposed standalone character canon. **No images generated. No GitHub files changed by this package.**
