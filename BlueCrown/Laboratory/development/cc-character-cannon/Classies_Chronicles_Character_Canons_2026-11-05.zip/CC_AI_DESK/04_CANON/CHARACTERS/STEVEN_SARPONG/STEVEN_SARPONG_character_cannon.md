---
canon_id: "CHAR-STEVEN-SARPONG"
character_slug: "STEVEN_SARPONG"
character_display: "Steven Sarpong"
document_version: "0.01.00"
status: "DRAFT — AWAITING HUMAN EDITORIAL REVIEW"
classification: "FICTIONAL CHARACTER DESIGN — NOT REAL-PERSON BIOGRAPHY"
created: "2026-11-05"
chart_check_days: "14,34"
daily_diaries_url: null
visual_collage_url: null
publication_consent: "UNKNOWN — NOT GRANTED BY SOURCE ALIAS"
---

# Steven Sarpong — Character Canon (Proposed)

> **EDITORIAL / PERSONAL-DATA FIREWALL:** This is a **fictional character double** created for story design from an aliased organizational chart, **not a biography, verified employment record, real likeness, genealogy, or statement of the named person’s preferences**. Except the quoted chart role/alias/check day and explicit references to existing Classies canon, **all birthdays, places, ethnic/cultural details, schooling, family, romance, physical dimensions, previous jobs, tastes and story events below are invented**. Do not publish or publicly portray an identifiable individual without valid editorial consent.

## 01. Canon record and authority

- **In-universe role:** Academic Registrar.
- **Chart alias as written:** `Steven Sarpong (GIMPA Business School)`.
- **Organizational chapter working-day checks:** `14,34` (repeating 20-day slot, not episode day).
- **Reporting line / narrative hierarchy:** [James Evans](../JAMES_EVANS/JAMES_EVANS_character_cannon.md) — Director of Academic Programs.
- **Role checks source:** [Organizational_Chart_Structure-Aliased_Checks.txt](https://raw.githubusercontent.com/cupidblack/Koware_Management/refs/heads/main/Organizational_Chart_Structure-Aliased_Checks.txt), source line 48.
- **Repository target:** `CC_AI_DESK/04_CANON/CHARACTERS/STEVEN_SARPONG/STEVEN_SARPONG_character_cannon.md`.
- **Status:** Draft production proposal only. No profile assertion is an approved, locked or biographical fact.

## 02. Identity, origins and personal timeline (fictional)

- **Proposed date of birth:** 1985-05-06. Approximate age on 2026-11-05: **41**, based solely on fictional proposed date of birth.
- **Proposed place of birth:** Koforidua, Ghana.
- **Proposed nation/citizenship:** Ghanaian.
- **Proposed cultural/ethnic background:** Akuapem (purely fictional; do **not** infer ancestry, nationality or ethnicity of a real person from a name).
- **Languages used in draft scenes:** English; conversational Akuapem (fictional character proficiency, not evidence of ancestry).
- **Pronouns for the fictional role:** he/his.
- **Current story location:** unassigned; set from the approved episode’s location and temporal ledger rather than hard-coding headquarters.

## 03. Physical appearance and visual lock proposal

- **Proposed on-page build:** approximately 164 cm, about 51 kg; deep warm brown; dark brown eyes; black with copper highlights hair. These are *fictional visual-design cues*, not observed measurements.
- **Distinguishing silhouette:** Neat mid fade and crisp button-downs. A second silhouette cue is an unhurried stride and open shoulders.
- **Voice and movement:** warm rhythm with exact professional vocabulary; reacts under stress by seeking a quieter corner before answering.
- **Continuity invariants:** retain the face shape, hair length/color family, skin undertone, silhouette, eyewear if used, and the signature item across comic pages. No celebrity/real-person likeness is implied.

## 04. Family, relationships and support network

In this *fiction-only* timeline, Steven grew up with parent figures Akua and Daniel; a older brother lives in another town and calls on weekends. Their family values showing up for neighbours; family names and occupations are wholly invented and must not be associated with a real person.

**Proposed relationship status:** married to fictional partner Naomi. Names and life circumstances in this paragraph are narrative inventions, not personal data.

## 05. Education, training and earlier life

- **Early education (fully fictional):** Bright Harbor Primary (primary, ages 6–12); Tamarind Junior High (junior secondary, ages 12–15); West Estuary Senior High (secondary/senior high, ages 15–18). All are *invented in-universe institutions*; these are not assertions about the real alias.
- **Higher study or professional training:** Proposed diploma/degree focus in **Academic records and student information systems** at the **Fictional Meridian Institute of Technology**; later short courses in ethics, first aid and collaborative problem-solving (all imagined, no credential claim).
- **Previous work (in-universe fiction):** Registry officer at the fictional Cedarbridge Academy.
- **Reason for joining the Classies ensemble:** protect students whose records span borders while contributing to the Koware-connected fictional narrative; not evidence of an actual appointment.

## 06. Koware role, routine and accountability

- **Role purpose:** Academic Registrar translates individual professional craft into reliable work, humane decisions and clear handovers during the story.
- **Role competencies:** document chain-of-custody, quiet verification, discrepancy triage, access-controlled reports.
- **Potential mission interface:** paper and digital audit trail; preserve uncertain provenance and flag contradictory timestamps.
- **Safety / integrity line:** privacy, evidence quality and nonaccusatory reporting; no reading restricted diaries without authorization.
- **Character’s regular work artifact:** Canvas file case with blue seals. Treat it as a prop, not a magical device or real company equipment.
- **Chapter spotlight use:** Prepare a role-appropriate chapter-day spotlight on working-day checks **14,34**. In one scene, show how the work is performed; in another, contrast it with a compatible role encountered in the historical or probe stream. Never claim the scene describes an actual Koware staff action or an authorized mission deployment.

## 07. Inner life, mannerisms and decision style

Steven Sarpong is a senior character within the imagined Koware-linked ensemble. The character’s distinctive gift can be summarized as “Catches small enrolment anomalies early”; the recurring blind spot is “Overvalues forms over stories.” The central ambition is to protect students whose records span borders. The daily tension is not a superpower: it is whether professionalism survives an unfamiliar ethical demand.

- **Strength:** Catches small enrolment anomalies early. **Complicating flaw:** Overvalues forms over stories.
- **Long-range aspiration:** Protect students whose records span borders.
- **Default dialogue texture:** grounded professional language; favors this invented personal line: “A record needs context.” It is **not** an approved recurring catchphrase.
- **Under pressure:** retreats to a list and must be pulled back into conversation.
- **Moral boundary:** verify what happened, do not use people’s vulnerability as plot decoration, and prefer accountable choices to instant certainty.

## 08. Cultural life, entertainment, habits and taste

- **Favorite artist:** Arlo Parks (fictional preference); **favorite song:** “Hurt (Arlo Parks)” (title only; no lyrics).
- **Favorite film and series:** *The Farewell* and *Atypical*; character takes inspiration from people solving problems together.
- **Sports and games:** running for movement; Oware for thinking and sociability. Favorite weekly pastime: seed-sharing days.
- **Food and drink:** jollof with fresh salad; sobolo. Weekend comfort ritual: taking a slow walk before a home-cooked meal.
- **Favorite imagined hangout:** a quiet campus stationery stall; chosen for space to observe.
- **Style code:** soft earth-tone layers and flat leather shoes; performance/workwear varies by mission hazard and location. The signature accessory is canvas file case with blue seals.
- **Strong likes:** competent teamwork, honest exchanges, local crafts and situations where the signature strength can matter (catches small enrolment anomalies early). **Dislikes:** unfair queue-jumping; needless plastic packaging; being rushed into unverified promises.

## 09. Internal ensemble links

- **Organizational supervisor / mentor axis:** [James Evans](../JAMES_EVANS/JAMES_EVANS_character_cannon.md) — Director of Academic Programs.
- **Nearby role connections in the chart:** [Matthew Ebenezer](../MATTHEW_EBENEZER/MATTHEW_EBENEZER_character_cannon.md) — Academic Partnerships & Outreach Officer; [Moses Larbi](../MOSES_LARBI/MOSES_LARBI_character_cannon.md) — Quality Assurance & Compliance Manager. These are **fictional professional storytelling links**, not assertions of personal friendship, kinship or private contact.
- **Conflict that could become solidarity:** the trait “overvalues forms over stories” clashes with a colleague who prizes a different form of truth; resolution must arise through earned conversation and consequence.
- **Trust model:** start as courteous professional peers; no invented romance, feud, familial link or confidential access with another named character becomes locked without a human editorial decision.

## 10. Story seeds, growth and continuity gates

- **First proposed scene:** A transcript shows completion before admission. It is a **fictional scenario prompt**, not an occurred episode event.
- **Mystery hook:** Canvas file case with blue seals becomes a mundane clue to a mismatch between production, historical-reference and probe/destination clocks; the clue does not prove supernatural causation.
- **Character choice:** investigate patiently, anchored by a strength (catches small enrolment anomalies early), or act too quickly when the blind spot surfaces (overvalues forms over stories).
- **Suggested payoff:** their aspiration to protect students whose records span borders gains an ethical cost; the next episode should carry forward a changed habit rather than an unexplained power upgrade.
- **Temporal caution:** destination/Edubeam events are mission proposals only until written in an approved chronicle; do not assign a fictional character to real-world travel, dates, meetings, payroll or membership.
- **Potential narrative function:** an ordinary skill becomes the overlooked factor that prevents a bigger systems mistake; team actions must have limitations, witnesses and a recordable cost.

## 11. Visual production brief — asset pending

- **Proposed future collage filename:** `STEVEN_SARPONG_CHARACTER_REFERENCE_COLLAGE.jpg` inside this folder. **NOT CREATED** (explicitly out of scope).
- **Future collage coverage:** front-facing neutral portrait; three-quarter expression study; full-body everyday outfit; role-specific workwear; close-up of hands and signature tool; three facial emotions; simple palette strip; daylight and indoor-light comparisons.
- **Style anchor:** Neat mid fade and crisp button-downs. Costume continuity: soft earth-tone layers and flat leather shoes.
- **No images yet:** `visual_collage_url: null`. Never mistake a future filename for an existing or approved file, and never improvise a likeness of the real alias.
- **Visual locks require approval:** silhouette, hairstyle, color cues and distinguishing details become firm only after explicit editorial review and any required likeness consent.

## 12. Daily Diaries link and episode-state handover

- **Daily Diaries (authorized URL):** `PENDING — INSERT LINK AFTER VERIFICATION AND PERMISSION REVIEW`.
- **Diary reference schema:** `diary_url`, `owner`, `scope` (private/internal/public), `consent_basis`, `last_verified_iso`, `eligible_excerpt_ids`, `excluded_private_content`; values are deliberately **unassigned**.
- **Diary usage:** no private diary quotation, biographical extraction, home location, family fact or plot event may be inferred without explicit access, consent and provenance.
- **Episode continuity state:** `debut_episode: UNASSIGNED`; `active_mission: NONE CONFIRMED`; `last_scene: NOT ESTABLISHED`; `open_threads: PROPOSED ONLY`; `latest_visual_revision: NONE`.

## 13. Editorial clearance, conflicts and revision history

- **Organization role mapping:** grounded only in the supplied aliased chart; source annotations in parentheses are reference labels, **not proof of school attendance, qualifications, employment or private biography**.
- **Creative inventions:** all supplementary attributes in §§02–11 are standalone story pitches. They must not be presented as established real-world facts.
- **Consent state:** `UNKNOWN`; public use is blocked for identifiable portrayal until an authorized review confirms the character design/identity and applicable permissions.
- **Canon decision required:** approve, amend, fictionalize further, anonymize or reject each invented detail; then version and lock only approved decisions.
- **Framework awareness:** CC Structured Master Prompt v0.03.01 and Comic Prompt v0.03.01 are proposed references, not automatic approval to change franchise canon.
- **Revision 0.01.00 — 2026-11-05:** first proposed standalone character canon. **No images generated. No GitHub files changed by this package.**
