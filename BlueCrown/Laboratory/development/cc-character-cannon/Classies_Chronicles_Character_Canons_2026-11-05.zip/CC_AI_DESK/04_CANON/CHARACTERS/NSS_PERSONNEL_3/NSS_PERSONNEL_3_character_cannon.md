---
canon_id: "CHAR-NSS-PERSONNEL-3"
character_slug: "NSS_PERSONNEL_3"
character_display: "NSS Personnel-3"
document_version: "0.01.00"
status: "DRAFT — AWAITING HUMAN EDITORIAL REVIEW"
classification: "FICTIONAL CHARACTER DESIGN — NOT REAL-PERSON BIOGRAPHY"
created: "2026-11-05"
chart_check_days: "5,25"
daily_diaries_url: null
visual_collage_url: null
publication_consent: "UNKNOWN — NOT GRANTED BY SOURCE ALIAS"
---

# NSS Personnel-3 — Character Canon (Proposed)

> **EDITORIAL / PERSONAL-DATA FIREWALL:** This is a **fictional character double** created for story design from an aliased organizational chart, **not a biography, verified employment record, real likeness, genealogy, or statement of the named person’s preferences**. Except the quoted chart role/alias/check day and explicit references to existing Classies canon, **all birthdays, places, ethnic/cultural details, schooling, family, romance, physical dimensions, previous jobs, tastes and story events below are invented**. Do not publish or publicly portray an identifiable individual without valid editorial consent.

## 01. Canon record and authority

- **In-universe role:** Cooperative Intern.
- **Chart alias as written:** `NSS Personnel-3`.
- **Organizational chapter working-day checks:** `5,25` (repeating 20-day slot, not episode day).
- **Reporting line / narrative hierarchy:** [Pastor Michael McCauley](../MICHAEL_MCCAULEY/MICHAEL_MCCAULEY_character_cannon.md) — Legal Journalist (Pastor).
- **Role checks source:** [Organizational_Chart_Structure-Aliased_Checks.txt](https://raw.githubusercontent.com/cupidblack/Koware_Management/refs/heads/main/Organizational_Chart_Structure-Aliased_Checks.txt), source line 15.
- **Repository target:** `CC_AI_DESK/04_CANON/CHARACTERS/NSS_PERSONNEL_3/NSS_PERSONNEL_3_character_cannon.md`.
- **Status:** Draft production proposal only. No profile assertion is an approved, locked or biographical fact.
**Fictional stage-name candidate:** Mawuli Bortsie (invented; **not** the name of the real NSS staff member).

## 02. Identity, origins and personal timeline (fictional)

- **Proposed date of birth:** 2004-08-09. Approximate age on 2026-11-05: **22**, based solely on fictional proposed date of birth.
- **Proposed place of birth:** Tamale, Ghana.
- **Proposed nation/citizenship:** Ghanaian.
- **Proposed cultural/ethnic background:** Dagomba (purely fictional; do **not** infer ancestry, nationality or ethnicity of a real person from a name).
- **Languages used in draft scenes:** English; conversational Dagomba (fictional character proficiency, not evidence of ancestry).
- **Pronouns for the fictional role:** they/their.
- **Current story location:** unassigned; set from the approved episode’s location and temporal ledger rather than hard-coding headquarters.

## 03. Physical appearance and visual lock proposal

- **Proposed on-page build:** approximately 171 cm, about 60 kg; deep warm brown; dark brown eyes; near-black hair. These are *fictional visual-design cues*, not observed measurements.
- **Distinguishing silhouette:** Dense natural curls and bright patterned cuffs. A second silhouette cue is a careful forward lean while listening.
- **Voice and movement:** warm rhythm with exact professional vocabulary; reacts under stress by organizing objects into rows.
- **Continuity invariants:** retain the face shape, hair length/color family, skin undertone, silhouette, eyewear if used, and the signature item across comic pages. No celebrity/real-person likeness is implied.

## 04. Family, relationships and support network

In this *fiction-only* timeline, NSS grew up with parent figures Esi and Emmanuel; a younger sister lives in another town and calls on weekends. Their family values showing up for neighbours; family names and occupations are wholly invented and must not be associated with a real person.

**Proposed relationship status:** engaged to fictional partner Kofi. Names and life circumstances in this paragraph are narrative inventions, not personal data.

## 05. Education, training and earlier life

- **Early education (fully fictional):** Cedar Walk Primary (primary, ages 6–12); Copperleaf Junior High (junior secondary, ages 12–15); Copper Coast Secondary School (secondary/senior high, ages 15–18). All are *invented in-universe institutions*; these are not assertions about the real alias.
- **Higher study or professional training:** Proposed diploma/degree focus in **Cooperative business studies** at the **Fictional Westbridge Academy**; later short courses in ethics, first aid and collaborative problem-solving (all imagined, no credential claim).
- **Previous work (in-universe fiction):** Junior aide at the fictional Savanna Produce Union.
- **Reason for joining the Classies ensemble:** launch a fair-trade pop-up run by students while contributing to the Koware-connected fictional narrative; not evidence of an actual appointment.

## 06. Koware role, routine and accountability

- **Role purpose:** Cooperative Intern translates individual professional craft into reliable work, humane decisions and clear handovers during the story.
- **Role competencies:** liaison handovers, routing, listening and traceable decisions.
- **Potential mission interface:** record only verified mission observations, separate historical/current/probe clocks.
- **Safety / integrity line:** do not assume an alias establishes consent to public portrayal.
- **Character’s regular work artifact:** A seed-paper membership card. Treat it as a prop, not a magical device or real company equipment.
- **Chapter spotlight use:** Prepare a role-appropriate chapter-day spotlight on working-day checks **5,25**. In one scene, show how the work is performed; in another, contrast it with a compatible role encountered in the historical or probe stream. Never claim the scene describes an actual Koware staff action or an authorized mission deployment.

## 07. Inner life, mannerisms and decision style

NSS Personnel-3 is a early-career character within the imagined Koware-linked ensemble. The character’s distinctive gift can be summarized as “Understands how groups negotiate common needs”; the recurring blind spot is “Interprets disagreement as rejection.” The central ambition is to launch a fair-trade pop-up run by students. The daily tension is not a superpower: it is whether professionalism survives an unfamiliar ethical demand.

- **Strength:** Understands how groups negotiate common needs. **Complicating flaw:** Interprets disagreement as rejection.
- **Long-range aspiration:** Launch a fair-trade pop-up run by students.
- **Default dialogue texture:** grounded professional language; favors this invented personal line: “Nobody owns the table.” It is **not** an approved recurring catchphrase.
- **Under pressure:** retreats to a list and must be pulled back into conversation.
- **Moral boundary:** verify what happened, do not use people’s vulnerability as plot decoration, and prefer accountable choices to instant certainty.

## 08. Cultural life, entertainment, habits and taste

- **Favorite artist:** Aṣa (fictional preference); **favorite song:** “Jailer (Aṣa)” (title only; no lyrics).
- **Favorite film and series:** *Bend It Like Beckham* and *The Queen's Gambit*; character takes inspiration from people solving problems together.
- **Sports and games:** five-a-side football for movement; tabletop mysteries for thinking and sociability. Favorite weekly pastime: street football evenings.
- **Food and drink:** kenkey and fish; iced coffee. Weekend comfort ritual: sharing food after a long project day.
- **Favorite imagined hangout:** a student canteen under neem trees; chosen for space to observe.
- **Style code:** utility vest, natural fabrics and sturdy walking shoes; performance/workwear varies by mission hazard and location. The signature accessory is a seed-paper membership card.
- **Strong likes:** competent teamwork, honest exchanges, local crafts and situations where the signature strength can matter (understands how groups negotiate common needs). **Dislikes:** performative status games; needlessly late meetings; being rushed into unverified promises.

## 09. Internal ensemble links

- **Organizational supervisor / mentor axis:** [Pastor Michael McCauley](../MICHAEL_MCCAULEY/MICHAEL_MCCAULEY_character_cannon.md) — Legal Journalist (Pastor).
- **Nearby role connections in the chart:** [Enka YAMOAH](../ENKA_YAMOAH/ENKA_YAMOAH_character_cannon.md) — Corporate Manager. These are **fictional professional storytelling links**, not assertions of personal friendship, kinship or private contact.
- **Conflict that could become solidarity:** the trait “interprets disagreement as rejection” clashes with a colleague who prizes a different form of truth; resolution must arise through earned conversation and consequence.
- **Trust model:** start as courteous professional peers; no invented romance, feud, familial link or confidential access with another named character becomes locked without a human editorial decision.

## 10. Story seeds, growth and continuity gates

- **First proposed scene:** A group vote changes after a displaced member returns. It is a **fictional scenario prompt**, not an occurred episode event.
- **Mystery hook:** A seed-paper membership card becomes a mundane clue to a mismatch between production, historical-reference and probe/destination clocks; the clue does not prove supernatural causation.
- **Character choice:** investigate patiently, anchored by a strength (understands how groups negotiate common needs), or act too quickly when the blind spot surfaces (interprets disagreement as rejection).
- **Suggested payoff:** their aspiration to launch a fair-trade pop-up run by students gains an ethical cost; the next episode should carry forward a changed habit rather than an unexplained power upgrade.
- **Temporal caution:** destination/Edubeam events are mission proposals only until written in an approved chronicle; do not assign a fictional character to real-world travel, dates, meetings, payroll or membership.
- **Potential narrative function:** an ordinary skill becomes the overlooked factor that prevents a bigger systems mistake; team actions must have limitations, witnesses and a recordable cost.

## 11. Visual production brief — asset pending

- **Proposed future collage filename:** `NSS_PERSONNEL_3_CHARACTER_REFERENCE_COLLAGE.jpg` inside this folder. **NOT CREATED** (explicitly out of scope).
- **Future collage coverage:** front-facing neutral portrait; three-quarter expression study; full-body everyday outfit; role-specific workwear; close-up of hands and signature tool; three facial emotions; simple palette strip; daylight and indoor-light comparisons.
- **Style anchor:** Dense natural curls and bright patterned cuffs. Costume continuity: utility vest, natural fabrics and sturdy walking shoes.
- **No images yet:** `visual_collage_url: null`. Never mistake a future filename for an existing or approved file, and never improvise a likeness of the real alias.
- **Visual locks require approval:** silhouette, hairstyle, color cues and distinguishing details become firm only after explicit editorial review and any required likeness consent.

## 12. Daily Diaries link and episode-state handover

- **Daily Diaries (authorized URL):** `PENDING — INSERT LINK AFTER VERIFICATION AND PERMISSION REVIEW`.
- **Diary reference schema:** `diary_url`, `owner`, `scope` (private/internal/public), `consent_basis`, `last_verified_iso`, `eligible_excerpt_ids`, `excluded_private_content`; values are deliberately **unassigned**.
- **Diary usage:** no private diary quotation, biographical extraction, home location, family fact or plot event may be inferred without explicit access, consent and provenance.
- **Episode continuity state:** `debut_episode: UNASSIGNED`; `active_mission: NONE CONFIRMED`; `last_scene: NOT ESTABLISHED`; `open_threads: PROPOSED ONLY`; `latest_visual_revision: NONE`.

## 13. Editorial clearance, conflicts and revision history

- **Organization role mapping:** grounded only in the supplied aliased chart; source annotations in parentheses are reference labels, **not proof of school attendance, qualifications, employment or private biography**.
- **Creative inventions:** all supplementary attributes in §§02–11 are standalone story pitches. They must not be presented as established real-world facts.
- **Consent state:** `UNKNOWN`; public use is blocked for identifiable portrayal until an authorized review confirms the character design/identity and applicable permissions.
- **Canon decision required:** approve, amend, fictionalize further, anonymize or reject each invented detail; then version and lock only approved decisions.
- **Framework awareness:** CC Structured Master Prompt v0.03.01 and Comic Prompt v0.03.01 are proposed references, not automatic approval to change franchise canon.
- **Revision 0.01.00 — 2026-11-05:** first proposed standalone character canon. **No images generated. No GitHub files changed by this package.**
