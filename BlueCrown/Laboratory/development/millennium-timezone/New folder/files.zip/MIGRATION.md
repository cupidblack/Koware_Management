# Millennium Timezone refactor – migration guide

Drop the contents of `shared/` over your repository's `shared/` folder (same relative paths).

## 0. Status – read this first

* **Not executed.** The build environment had no PHP interpreter, so none of this code has been run. Every file
  passed a structural check (balanced brackets, strings, open/close tags) and a manual review, which is not the
  same as `php -l` or a test run. Do steps 1 and 5 on a staging copy before production.
* Target PHP: 7.4+ (uses `??`, `finally`, `intdiv`; no arrow functions, no PHP 8-only functions).

## 1. Pre-flight (on the server)

```bash
cd /path/to/buzzjuice.net
git checkout -b millennium-timezone-refactor      # your rollback point is the previous commit
# after copying the files in:
for f in $(find shared -name '*.php'); do php -l "$f" || echo "FAILED: $f"; done
```

## 2. File map

| Old | New |
|---|---|
| `shared/palmier/calendar/sabbatical-date.php` | `shared/millennium-timezone/millennium-timezone.php` |
| `shared/palmier/probe/millennium-probe.php` | `shared/millennium-timezone/millennium-probe.php` |
| – | `shared/millennium-timezone/mtz-common.php` (new: file logs, lock, DB-state wrappers) |
| – | `shared/millennium-timezone/logs/` (new: log files + deny-all `.htaccess`) |

`git rm` the two old files after deploying, or keep the redirect stubs in `compat/` for a transition period
(they 301 to the new URLs and preserve the query string).

## 3. What changed, file by file

**db_helpers.php**
1. `bzj_db_connect()`: all five `get_*_conn()` functions use it. On PHP 8.1+ `new mysqli()` throws, so the old
   `connect_errno` check never ran; failures now return `false` as the code always intended.
2. Optional `BZJ_DB_HELPERS_SOFT_FAIL` constant: a broken `.env` no longer `exit()`s endpoints that treat the DB as
   optional. Every other caller keeps the original hard stop.
3. `millennium_timezone_table($suffix)` → `` `koware_iapd`.`millennium_timezone_<suffix>` `` and `palmier_table()`.
4. Key/value state helpers: `mtz_state_get/set` (koware_iapd) and `palmier_state_get/set` (koware_palmier).

**millennium-timezone.php** (was sabbatical-date.php)
1. Same date arithmetic, now in `mtz_clock()`. Callable by other files; including it prints nothing.
2. Probe: no more HTTP call to the probe URL; `mprobe_get_state()` is called locally.
3. 12345-second rule: newest entry in `logs/millennium-timezone-YYYY-MM.log` is reused while younger than 12345 s;
   otherwise one request (lock-protected) refreshes the probe, appends a log entry, mirrors it to
   `koware_iapd.millennium_timezone_state`. A failed refresh never overwrites the last valid entry.
4. `?format=json` (or `?endpoint=full`) returns Day, Date, Month, Jubilee, Reference Year, Local, Current, Probe,
   `historical_iso`, `cache_age_seconds`, `cache_fresh`, `generated_at`. `?endpoint=last` shows the newest log entry
   without triggering a refresh. The HTML page is server-rendered, has a plain-text summary, `<meta description>`,
   an embedded JSON block and `data-field` attributes, so agents that do not run JavaScript get exact values.
5. Fixes: ordinal printed `01st`/`05th` in server HTML (now `1st`/`5th`, as the JS always did); float `%` deprecation.

**Why Local/Current are not served from the cache:** they are arithmetic on the server clock (no API involved), and
Local advances 1 s per 6 real seconds, so a 12345-second-old copy would be ~34 minutes wrong. Only the Probe is cached.

**millennium-probe.php**
1. New location; prefixed functions; includable; same phases, formula, graphs, navigation.
2. Oscillator read via `posc_get_data()` (local) instead of an HTTP request to our own domain.
3. History is JSON-lines per month, written under a lock (old file: whole-file rewrite, race-prone, capped at 180 entries).
4. If the oscillator cannot be read the probe now errors instead of caching a value computed with index 0.0.
5. Live-update fetch keeps the `?phase=` you are viewing and polls every 5 min (answers come from cache).

**palmier-oscillator.php** – functions/constants prefixed (`posc_`, `POSC_`), `posc_get_data()` added, UI/JSON only on
direct request, UTC-pinned maths, log stays in the same file. Fixes: slider started one week ahead and crashed in
ISO week 52/53; Chart.js pinned to 4.4.7.

**gold_calc_helpers.php / gold_calc.php** – historical date from `mtz_historical_datetime()` (the HISTORICAL date, not
current); calculation moved into `gold_calc_get_result()`; log read newest-first (so `?force` takes effect); safe
CSV parsing (PHP 8 `array_combine` throws on ragged rows); `USD_MRO_multiplied.csv` no longer treated as a currency;
result mirrored to `koware_palmier.palmier_state`; HTML is now a valid document and escaped. Optional env
`GOLD_CALC_FORCE_TOKEN` protects `?force=<token>`.

**palmier_calc.php** – **hard-coded API keys removed (rotate them)**; same-domain HTTP calls to `gold_calc.php` and
the oscillator replaced by local calls; `display_errors` off; weekend-closure slot fixed (`last Saturday` pointed a
week back on Saturday afternoons); log rotation fixed (old code created one new file per slot once the first file
reached 512 KB); stale-but-valid fallback; per-slot lock; DB mirror keys `palmier_calc_latest`, `palmier_value`.

**palmier_logger.php** – kept in the database on purpose (see header comment); uses the shared connection, is
exception-safe, and spools to `logs/palmier-activity-fallback.log` if the DB is down.

**palmier-helpers.php** – no change needed (WordPress/myCRED only, no timezone or API dependency).

**bulk_convert_currency_csvs.php / currency-bulk-multiplier.php** – CLI-only (they were web-reachable and rewrite/move
files); unparsable dates no longer become 1970-01-01; existing target file archived instead of overwritten.

## 4. Deploy order

1. Run `sql/01_koware_iapd_millennium_timezone.sql` and `sql/02_koware_palmier_palmier_state.sql`; grant
   SELECT/INSERT/UPDATE on those two tables to the PHP DB users. (If you skip this, everything still works; only
   the DB mirror is skipped, with entries in the PHP error log.)
2. Add to `.env`: `ALPHA_VANTAGE_API_KEY`, `TWELVE_DATA_API_KEY`, `EXCHANGERATE_API_KEY` (new, rotated values).
3. Copy `shared/` files; make `shared/millennium-timezone/logs/` writable by the PHP user.
   Nginx ignores `.htaccess`: add `location ~ /millennium-timezone/logs/ { deny all; }`.
4. Optionally copy `compat/` stubs; later `git rm` them.
5. Search the repo/WordPress for `sabbatical-date.php` and `palmier/probe/millennium-probe.php` and update references.

## 5. Verify

```bash
B=https://buzzjuice.net/shared
curl -s "$B/millennium-timezone/millennium-timezone.php?format=json"     # all fields, cache_fresh true after 1st call
curl -s "$B/millennium-timezone/millennium-timezone.php?endpoint=last"   # same generated_at on repeat calls
curl -s "$B/millennium-timezone/millennium-probe.php?probe=now"
curl -s "$B/palmier/oscillator/palmier-oscillator.php?oscillation=live"
curl -s "$B/palmier/gold_calc/gold_calc.php?format=average"
curl -s "$B/palmier/palmier_calc.php?endpoint=palmier"
curl -sI "$B/millennium-timezone/logs/millennium-timezone-$(date -u +%Y-%m).log"   # expect 403/404
```
Repeat the first call several times: `generated_at` must not change until 12345 s have passed, and the log must
gain one line per refresh, not per request. Compare `historical_iso` against the old
`sabbatical-date.php?endpoint=historical` output before removing the old file: they must match to the second.
Check gold: `historical_date` in the gold JSON should equal `historical_iso`.

## 6. Left unchanged on purpose

* `palmier_calc.php` still fetches the WOOCS currency list and base currency from the WordPress site over HTTP, once
  per 12345-second slot. Replacing that needs the exact WOOCS option names from your WordPress database.
* `mprobe_find_phase()`: Aug 6–14 (gap between phases 3 and 4) and Dec 21–31 resolve to the next year's phase 1.
  Original behaviour, kept; say if you want the gap handled differently.
* External provider calls (Alpha Vantage, Twelve Data, ExchangeRate-API) are real third-party APIs, not same-domain.

## 7. Rollback

`git checkout <previous commit> -- shared/` restores everything. The new tables and log files are additive and
can stay. Re-enable `compat/` redirects are not needed after a rollback (old files are back).
