<?php
/**
 * Buzzjuice Streams Payment Gateway Bridge v13 entry point.
 *
 * The Streams request routing remains responsible for loading config/init.
 * All payment-order preparation is delegated to the shared client.
 */
require_once dirname(__DIR__, 2) . '/config.php';
require_once dirname(__DIR__) . '/init.php';

if (empty($wo['loggedin'])) {
    $redirect_url = $wo['config']['site_url'] . '/login?redirect_url=' . urlencode($_SERVER['REQUEST_URI'] ?? '');
    if (!headers_sent()) {
        header('Location: ' . $redirect_url);
    } else {
        echo '<script>window.location.href=' . json_encode($redirect_url) . ';</script>';
    }
    exit;
}

$client = dirname(__DIR__, 3) . '/shared/payment-gateway/pgb-client-streams.php';

if (!file_exists($client)) {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Payment Gateway Client is unavailable.']);
    exit;
}

require_once $client;
