# Streams payment-settings v13

The existing payment-settings page should retain the settings that WoWonder itself needs to render payment options and map products:

- `wow_payment`
- `wow_store_url`
- `wow_market_id`
- `wow_pro_package_id`
- `wow_pro_package_id_2`
- `wow_pro_package_id_3`
- `wow_pro_package_id_4`
- `wow_wallet_topup_id`
- `wow_crowdfund_id`

Remove the requirement for these legacy bridge-only credentials:

- `wow_api_url`
- `wow_api_key`
- `wow_api_secret`
- `wow_webhook_secret`

The v13 bridge does not use WooCommerce REST authentication.

## Product mapping

The WordPress PGB admin page is authoritative for WooCommerce product/variation IDs. Streams values should still be retained for WoWonder's own UI/business logic, but they should not be used as WooCommerce REST credentials.

## Important

Do not change the existing Streams request security/session checks. The payment client must continue to run inside the authenticated WoWonder request.
