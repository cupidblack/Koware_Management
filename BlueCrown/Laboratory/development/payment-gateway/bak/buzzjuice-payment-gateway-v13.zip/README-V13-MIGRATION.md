# Buzzjuice Payment Gateway Bridge v13

## Purpose
This package replaces the Streams-side WooCommerce REST/cURL order-creation path with a durable database handoff.

### New flow
1. Streams validates the logged-in WoWonder user and payment request.
2. Streams inserts a complete pending transaction into the WordPress database table `wp_bzj_pgb_orders`.
3. Streams verifies the inserted row.
4. Streams creates a signed browser handoff:
   `/pgb-checkout/?pgb_order_id=...&ts=...&nonce=...&sig=...`
5. WordPress MU plugin validates the HMAC and retrieves the row directly from its own database.
6. WordPress creates a native `WC_Order` with `wc_create_order()`.
7. WordPress obtains the official payment URL from `$order->get_checkout_payment_url()`.
8. Browser is redirected to WooCommerce's order-pay endpoint.
9. Payment gateway completes the WooCommerce order.
10. `woocommerce_payment_complete` and `woocommerce_order_status_completed` invoke the PGB manager idempotently.
11. PGB records payment completion, runs WoWonder fulfillment, AffiliateWP, subscriptions, and integrations.
12. Streams is updated directly through the shared database connection; no HTTP callback is required.

## Important implementation corrections
- The WordPress MU plugin is one file only.
- No REST endpoint is required for the PGB handoff.
- No WooCommerce consumer key/secret is required for the payment bridge.
- `register_activation_hook()` is deliberately not used because MU plugins do not have a normal activation lifecycle.
- The pending-order table is created/verified from the MU plugin at runtime using `dbDelta()`.
- The HMAC secret must be configured in WordPress and in the server environment available to Streams.
- The code does not use a fallback secret.
- Unpaid Streams purchase records are not created by the new initiation client.
- Fulfillment is payment-driven and idempotent.
- Existing `wow-pgb_sync.php` should be archived and disabled only after the v13 test plan passes.

## Required environment value

Set the same high-entropy value in the WordPress/PHP environment and the Streams/PHP environment:

`BZJ_PGB_HANDOFF_SECRET`

Do not put this secret into a public repository.

## Required directories

`buzzjuice.net/shared/payment-gateway/`
- `core/`
- `addons/`
- `integrations/`
- `js/` (optional)
- `log/`

## Deployment order
1. Back up the database and the existing bridge files.
2. Install the v13 shared files.
3. Install `wp-content/mu-plugins/bzj-payment-gateway.php`.
4. Confirm the WordPress admin page appears under the existing Buzzjuice admin menu.
5. Configure the PGB handoff secret.
6. Configure product mappings.
7. Replace `streams/assets/wow-pgb/wow-pgb_init.php`.
8. Update the Streams payment-settings UI/request handler so obsolete Woo API credentials are no longer required by PGB.
9. Disable the old `wow-pgb_sync.php` execution path.
10. Keep `streams/wow-pgb_webhook.php` archived but inactive during the migration test window.
11. Test PRO, wallet, market/product and funding flows.
12. Test failed payment, abandoned checkout, duplicate handoff, refresh, double webhook/payment-complete, subscription renewal, and affiliate attribution.
13. Only then remove/archive the old bridge files.

## Important note
The current WoWonder source contains business-specific fulfillment fields/tables. The addon uses schema-aware direct updates and records an error instead of guessing when a required WoWonder column/table is absent. This is intentional: a payment must never be silently marked fulfilled when the destination schema cannot be verified.
