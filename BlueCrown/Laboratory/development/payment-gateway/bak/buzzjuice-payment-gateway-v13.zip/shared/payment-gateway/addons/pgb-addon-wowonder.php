<?php
if (!defined('ABSPATH')) exit;

/**
 * WoWonder fulfillment addon.
 *
 * This addon intentionally performs fulfillment only after WooCommerce reports
 * the order paid. It uses the shared DB helper and never calls the WoWonder API.
 */
add_filter('bzj_pgb_fulfillment_result', function ($result, $order, $row) {
    $logger = PGB_Logger::instance();
    $streams = PGB_Streams_DB::instance();
    $db = $streams->connection();

    if (!$db) return false;

    $wow_user_id = (int) $row['wow_user_id'];
    $kind = strtoupper((string) $row['transaction_kind']);
    $payload = json_decode($row['payload'], true) ?: [];

    $user = $streams->user_row($wow_user_id);
    if (!$user) {
        $logger->log('pgb-addon-wowonder', PGB_Logger::ERROR, 'WoWonder user not found', ['wow_user_id' => $wow_user_id]);
        return false;
    }

    $ok = true;

    if (in_array($kind, ['PRODUCT','PURCHASE','SALE'], true)) {
        $ok = pgb_wowonder_fulfill_market_purchase($streams, $row, $payload);
    } elseif ($kind === 'PRO') {
        $ok = pgb_wowonder_fulfill_pro($streams, $order, $row, $payload);
    } elseif (in_array($kind, ['WALLET','TOPUP'], true)) {
        $ok = pgb_wowonder_fulfill_wallet($streams, $row);
    } elseif (in_array($kind, ['DONATE','FUND','FUNDING'], true)) {
        $ok = pgb_wowonder_fulfill_funding($streams, $row, $payload);
    } else {
        $logger->log('pgb-addon-wowonder', PGB_Logger::WARNING, 'Unknown transaction kind; no WoWonder table mutation performed', ['kind' => $kind]);
        $ok = false;
    }

    if ($ok) {
        $logger->log('pgb-addon-wowonder', PGB_Logger::INFO, 'WoWonder fulfillment completed', [
            'wow_order_id' => $row['wow_order_id'],
            'kind' => $kind,
            'woo_order_id' => $order->get_id(),
        ]);
    }

    return $ok;
}, 10, 3);

function pgb_wowonder_fulfill_market_purchase(PGB_Streams_DB $streams, array $row, array $payload) {
    $db = $streams->connection();
    if (!$db) return false;

    $wow_order_id = (string) $row['wow_order_id'];
    $user_id = (int) $row['wow_user_id'];
    $owner_id = (int) $row['product_owner_id'];
    $post_id = (int) $row['wow_post_id'];
    $qty = max(1, (int) $row['quantity']);
    $amount = (float) $row['amount'];
    $price = (float) ($payload['product_price'] ?? $amount);
    $currency = (string) $row['currency_code'];
    $name = (string) ($row['product_name'] ?? 'Product');
    $now = time();

    $stmt = $db->prepare('SELECT order_hash_id FROM Wo_Purchases WHERE order_hash_id = ? LIMIT 1');
    if (!$stmt) return false;
    $stmt->bind_param('s', $wow_order_id);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows > 0;
    $stmt->close();

    if (!$exists) {
        $data = wp_json_encode([
            'name' => $name,
            'product_id' => $post_id,
            'units' => $qty,
            'currency' => $currency,
            'timestamp' => $now,
        ]);

        $commission = 0.0;
        $stmt = $db->prepare(
            'INSERT INTO Wo_Purchases
            (user_id, order_hash_id, owner_id, data, final_price, commission, price, timestamp, time)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        if (!$stmt) return false;
        $stmt->bind_param('isssddddd', $user_id, $wow_order_id, $owner_id, $data, $amount, $commission, $price, $now, $now);
        $ok = $stmt->execute();
        $stmt->close();
        if (!$ok) return false;
    }

    $stmt = $db->prepare('SELECT hash_id FROM Wo_UserOrders WHERE hash_id = ? LIMIT 1');
    if (!$stmt) return false;
    $stmt->bind_param('s', $wow_order_id);
    $stmt->execute();
    $exists_order = $stmt->get_result()->num_rows > 0;
    $stmt->close();

    if (!$exists_order) {
        $address_id = (int) ($payload['address_id'] ?? 0);
        $commission = 0.0;
        $status = 'placed';

        $stmt = $db->prepare(
            'INSERT INTO Wo_UserOrders
            (hash_id, user_id, product_owner_id, product_id, address_id, price, commission, final_price, units, status, time)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        if (!$stmt) return false;
        $stmt->bind_param('siiiidddisi', $wow_order_id, $user_id, $owner_id, $post_id, $address_id, $price, $commission, $amount, $qty, $status, $now);
        $ok = $stmt->execute();
        $stmt->close();
        if (!$ok) return false;
    }

    return true;
}

function pgb_wowonder_fulfill_pro(PGB_Streams_DB $streams, $order, array $row, array $payload) {
    $logger = PGB_Logger::instance();
    $wow_user_id = (int) $row['wow_user_id'];
    $pro_type = (int) ($row['wow_post_id'] ?: ($payload['wow_post_id'] ?? 0));

    if ($pro_type < 1 || $pro_type > 4) {
        $logger->log('pgb-addon-wowonder', PGB_Logger::ERROR, 'Invalid PRO package ID', ['pro_type' => $pro_type]);
        return false;
    }

    $role_map = [
        1 => 'classic_lifestyle',
        2 => 'silver_lifestyle',
        3 => 'rockstar_lifestyle',
        4 => 'premium_lifestyle',
    ];

    $wp_user_id = (int) $row['wp_user_id'];
    $wp_user = get_user_by('ID', $wp_user_id);
    if (!$wp_user) return false;

    $role = $role_map[$pro_type];
    if (!in_array($role, (array) $wp_user->roles, true)) {
        $wp_user->add_role($role);
    }

    /*
     * WoWonder schemas differ between releases. Update only columns that are
     * actually present; never invent a column or silently write elsewhere.
     */
    $values = [
        'is_pro' => 1,
        'pro_type' => $pro_type,
    ];

    $product = $order->get_items() ? wc_get_product(reset($order->get_items())->get_variation_id() ?: reset($order->get_items())->get_product_id()) : null;
    if ($product) {
        $period = (string) ($product->get_meta('_subscription_period', true) ?: 'month');
        $interval = max(1, (int) ($product->get_meta('_subscription_interval', true) ?: 1));
        $length = max(0, (int) ($product->get_meta('_subscription_length', true) ?: 0));
        $values['pro_time'] = strtotime("+{$interval} {$period}");
        if ($length > 0) {
            $values['pro_time'] = strtotime("+{$length} {$period}");
        }
    }

    return $streams->update_user_columns($wow_user_id, $values);
}

function pgb_wowonder_fulfill_wallet(PGB_Streams_DB $streams, array $row) {
    $db = $streams->connection();
    if (!$db) return false;

    $amount = (float) $row['amount'];
    $uid = (int) $row['wow_user_id'];

    /*
     * WoWonder installations commonly use either wallet or balance. We only
     * update a column after SHOW COLUMNS confirms that it exists.
     */
    $column = null;
    foreach (['wallet', 'balance'] as $candidate) {
        if ($streams->has_column('Wo_Users', $candidate)) {
            $column = $candidate;
            break;
        }
    }

    if (!$column) {
        PGB_Logger::instance()->log('pgb-addon-wowonder', PGB_Logger::ERROR, 'No supported Wo_Users wallet column found', ['wow_user_id' => $uid]);
        return false;
    }

    $sql = "UPDATE Wo_Users SET `{$column}` = COALESCE(`{$column}`, 0) + ? WHERE user_id = ? LIMIT 1";
    $stmt = $db->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param('di', $amount, $uid);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function pgb_wowonder_fulfill_funding(PGB_Streams_DB $streams, array $row, array $payload) {
    /*
     * Funding table schemas vary between WoWonder versions/customizations.
     * The v13 bridge records the payment ledger and will not guess a funding
     * table. If your installation exposes the existing funding table, add its
     * exact field mapping here after verifying the schema.
     *
     * The payment itself remains recorded in WooCommerce and the PGB ledger.
     */
    $logger = PGB_Logger::instance();
    $logger->log('pgb-addon-wowonder', PGB_Logger::WARNING, 'Funding payment requires installation-specific funding table mapping', [
        'wow_order_id' => $row['wow_order_id'],
        'wow_post_id' => $row['wow_post_id'],
    ]);
    return true;
}
