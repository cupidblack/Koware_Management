<?php
if (!defined('ABSPATH')) exit;

final class PGB_Config {
    private static $instance;
    private $data = [];

    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $secret = getenv('BZJ_PGB_HANDOFF_SECRET');
        if (!$secret) $secret = get_option('pgb_handoff_secret', '');

        $this->data = [
            'logging_enabled' => (bool) get_option('pgb_logging_enabled', true),
            'log_level' => (string) get_option('pgb_log_level', 'info'),
            'streams_url' => (string) get_option('pgb_streams_url', home_url('/streams/')),
            'handoff_secret' => (string) $secret,
            'pro_package_1' => (int) get_option('pgb_pro_package_1', 0),
            'pro_package_2' => (int) get_option('pgb_pro_package_2', 0),
            'pro_package_3' => (int) get_option('pgb_pro_package_3', 0),
            'pro_package_4' => (int) get_option('pgb_pro_package_4', 0),
            'wallet_product' => (int) get_option('pgb_wallet_product', 0),
            'fund_product' => (int) get_option('pgb_fund_product', 0),
            'market_product' => (int) get_option('pgb_market_product', 0),
        ];
    }

    public function get($key, $default = null) {
        return $this->data[$key] ?? $default;
    }

    public function all() {
        return $this->data;
    }

    public function save_from_admin($post) {
        $this->data['logging_enabled'] = !empty($post['logging_enabled']);
        update_option('pgb_logging_enabled', $this->data['logging_enabled']);

        $level = sanitize_key($post['log_level'] ?? 'info');
        if (!in_array($level, ['debug','info','warning','error','critical','off'], true)) $level = 'info';
        $this->data['log_level'] = $level;
        update_option('pgb_log_level', $level);

        $this->data['streams_url'] = esc_url_raw($post['streams_url'] ?? '');
        update_option('pgb_streams_url', $this->data['streams_url']);

        foreach ([
            'pro_package_1','pro_package_2','pro_package_3','pro_package_4',
            'wallet_product','fund_product','market_product'
        ] as $key) {
            $this->data[$key] = max(0, absint($post[$key] ?? 0));
            update_option('pgb_' . $key, $this->data[$key]);
        }
    }

    public function handoff_secret() {
        return (string) $this->data['handoff_secret'];
    }

    public function handoff_url() {
        return home_url('/pgb-checkout/');
    }
}
