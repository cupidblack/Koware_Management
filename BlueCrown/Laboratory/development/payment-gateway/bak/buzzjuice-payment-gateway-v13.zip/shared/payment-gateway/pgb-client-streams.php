<?php
/**
 * Buzzjuice Streams Payment Gateway Client v13.
 *
 * This file is intentionally independent of WordPress functions. Streams
 * supplies the WoWonder context and this client uses shared/db_helpers.php to
 * write the durable PGB ledger row in the WordPress database.
 */

if (!isset($GLOBALS['wo']) || !is_array($GLOBALS['wo'])) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'WoWonder context unavailable']);
    exit;
}

$wo = $GLOBALS['wo'];
$sqlConnect = $GLOBALS['sqlConnect'] ?? null;

$respond = static function ($status, $message, array $extra = []) {
    http_response_code((int) $status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge(['status' => $status === 200 ? 'success' : 'error', 'message' => $message], $extra), JSON_UNESCAPED_SLASHES);
    exit;
};

if (empty($wo['loggedin']) || empty($wo['user']['user_id'])) {
    $respond(401, 'Please log in to continue.');
}

if (!function_exists('get_wp_db_conn')) {
    $helpers = dirname(__DIR__, 2) . '/db_helpers.php';
    if (file_exists($helpers)) require_once $helpers;
}

$wpdb = function_exists('get_wp_db_conn') ? get_wp_db_conn() : false;
if (!$wpdb) $respond(500, 'Payment bridge database connection unavailable.');

$user_id = (int) $wo['user']['user_id'];
$email = filter_var((string) ($wo['user']['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$username = trim((string) ($wo['user']['username'] ?? ''));

if (!$user_id || !$email || $username === '') {
    $respond(400, 'Invalid WoWonder user information.');
}

$amount = isset($_POST['amount']) ? (float) $_POST['amount'] : 0.0;
$product_name = trim((string) ($_POST['product_name'] ?? ''));
$product_price = isset($_POST['product_price']) ? (float) $_POST['product_price'] : $amount;
$product_units = max(1, (int) ($_POST['product_units'] ?? 1));
$product_owner_id = max(0, (int) ($_POST['product_owner_id'] ?? 0));
$transaction_kind = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string) ($_POST['transaction_kind'] ?? '')));
$currency = strtoupper(preg_replace('/[^A-Z]/', '', (string) ($_POST['wow_currency_code'] ?? 'GHS')));
$wow_post_id = max(0, (int) ($_POST['wow_post_id'] ?? $_POST['address_id'] ?? 0));
$address_id = max(0, (int) ($_POST['address_id'] ?? 0));
$product_id = max(0, (int) ($_POST['product_id'] ?? $_POST['wow_product_kind'] ?? 0));
$variation_id = max(0, (int) ($_POST['variation_id'] ?? 0));

if ($amount <= 0) $respond(400, 'Invalid payment amount.');
if ($product_name === '') $respond(400, 'Product name is required.');
if (!preg_match('/^[A-Z]{3}$/', $currency)) $respond(400, 'Invalid currency.');
if (!in_array($transaction_kind, ['PRO','PRODUCT','PURCHASE','SALE','WALLET','TOPUP','DONATE','FUND','FUNDING'], true)) {
    $respond(400, 'Unsupported payment type.');
}

/*
 * WoWonder stores the WordPress mapping in Wo_Users.wp_user_id. Resolve it
 * directly from the Streams database instead of trusting browser input.
 */
$wp_user_id = 0;
if ($sqlConnect) {
    $stmt = $sqlConnect->prepare('SELECT wp_user_id FROM Wo_Users WHERE user_id = ? LIMIT 1');
    if ($stmt) {
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $r = $stmt->get_result();
        if ($r && ($u = $r->fetch_assoc())) $wp_user_id = (int) ($u['wp_user_id'] ?? 0);
        $stmt->close();
    }
}
if (!$wp_user_id) $respond(400, 'This Streams account is not linked to a WordPress account.');

$wow_order_id = 'wow_' . gmdate('YmdHis') . '_' . bin2hex(random_bytes(8));
$nonce = bin2hex(random_bytes(32));
$timestamp = time();
$expires = $timestamp + 900;

$secret = getenv('BZJ_PGB_HANDOFF_SECRET');
if (!$secret) $respond(500, 'Payment bridge security secret is not configured.');

$payload = [
    'wow_user_id' => $user_id,
    'wp_user_id' => $wp_user_id,
    'customer_email' => $email,
    'username' => $username,
    'amount' => $amount,
    'product_name' => $product_name,
    'product_price' => $product_price,
    'product_units' => $product_units,
    'product_owner_id' => $product_owner_id,
    'transaction_kind' => $transaction_kind,
    'currency' => $currency,
    'wow_post_id' => $wow_post_id,
    'address_id' => $address_id,
    'product_id' => $product_id,
    'variation_id' => $variation_id,
    'subscription_period' => (string) ($_POST['subscription_period'] ?? ''),
    'subscription_interval' => max(0, (int) ($_POST['subscription_interval'] ?? 0)),
    'subscription_length' => max(0, (int) ($_POST['subscription_length'] ?? 0)),
    'meta' => [
        'wow_post_id' => $wow_post_id,
        'qdw_transaction_kind' => (string) ($_POST['qdw_transaction_kind'] ?? ''),
        'qdw_order_id' => (string) ($_POST['qdw_order_id'] ?? ''),
        'qdw_membershipType' => (string) ($_POST['qdw_membershipType'] ?? ''),
        '_buzzjuice_origin' => 'streams',
    ],
];

$table = 'wp_bzj_pgb_orders';

/*
 * The table is installed by the WordPress MU plugin. Do not create it from
 * Streams because the WordPress DB user should not need DDL privileges.
 */
$exists = $wpdb->query("SHOW TABLES LIKE '" . $wpdb->real_escape_string($table) . "'");
if (!$exists) $respond(503, 'Payment bridge is not ready. Please try again shortly.');

$payload_json = wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$nonce_hash = hash('sha256', $nonce);
$created_at = gmdate('Y-m-d H:i:s');

$sql = "INSERT INTO {$table}
    (wow_order_id,wow_user_id,wp_user_id,transaction_kind,amount,currency_code,product_id,variation_id,wow_post_id,product_owner_id,quantity,product_name,payload,status,handoff_nonce,handoff_timestamp,handoff_expires,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'pending',?,?,?,?,?)";

$stmt = $wpdb->prepare($sql);
if (!$stmt) {
    error_log('[BZJ-PGB] Pending order prepare failed: ' . $wpdb->error);
    $respond(500, 'Unable to create the payment order.');
}

$stmt->bind_param(
    'siisdiiiiissssiiiss',
    $wow_order_id,
    $user_id,
    $wp_user_id,
    $transaction_kind,
    $amount,
    $currency,
    $product_id,
    $variation_id,
    $wow_post_id,
    $product_owner_id,
    $product_units,
    $product_name,
    $payload_json,
    $nonce_hash,
    $timestamp,
    $expires,
    $created_at,
    $created_at
);

if (!$stmt->execute()) {
    error_log('[BZJ-PGB] Pending order insert failed: ' . $stmt->error);
    $stmt->close();
    $respond(500, 'Unable to create the payment order.');
}
$stmt->close();

$verify = $wpdb->get_row($wpdb->prepare(
    "SELECT id,wow_order_id,status,handoff_nonce FROM {$table} WHERE wow_order_id = %s LIMIT 1",
    $wow_order_id
), ARRAY_A);

if (!$verify || $verify['status'] !== 'pending' || !hash_equals($verify['handoff_nonce'], hash('sha256', $nonce))) {
    error_log('[BZJ-PGB] Pending order verification failed for ' . $wow_order_id);
    $respond(500, 'Payment order verification failed.');
}

$signature = hash_hmac('sha256', $wow_order_id . '|' . $timestamp . '|' . $nonce, $secret);
$base = rtrim((string) ($wo['config']['wow_store_url'] ?? 'https://buzzjuice.net'), '/');
$redirect = $base . '/pgb-checkout/?' . http_build_query([
    'pgb_order_id' => $wow_order_id,
    'ts' => $timestamp,
    'nonce' => $nonce,
    'sig' => $signature,
]);

$respond(200, 'Payment initiated.', [
    'wow_order_id' => $wow_order_id,
    'redirect_url' => $redirect,
]);
