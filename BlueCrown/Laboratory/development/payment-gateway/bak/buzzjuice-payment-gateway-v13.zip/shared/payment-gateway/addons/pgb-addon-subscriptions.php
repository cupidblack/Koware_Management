<?php
if (!defined('ABSPATH')) exit;

/**
 * Native WooCommerce Subscriptions integration.
 *
 * This replaces the old /subscriptions REST call. WooCommerce Subscriptions
 * exposes a PHP API and lifecycle hooks, so the bridge remains entirely
 * server-side.
 */
add_action('bzj_pgb_payment_paid', function ($order, $row) {
    if (!function_exists('wcs_create_subscription')) return;
    if (strtoupper((string) $row['transaction_kind']) !== 'PRO') return;

    $existing = (int) $order->get_meta('_bzj_pgb_subscription_id', true);
    if ($existing && function_exists('wcs_get_subscription') && wcs_get_subscription($existing)) return;

    $items = $order->get_items('line_item');
    if (!$items) return;

    $first = reset($items);
    $product = $first ? $first->get_product() : false;
    if (!$product) return;

    $period = (string) ($product->get_meta('_subscription_period', true) ?: 'month');
    $interval = max(1, (int) ($product->get_meta('_subscription_interval', true) ?: 1));

    $start = current_time('mysql', true);
    $next = gmdate('Y-m-d H:i:s', strtotime("+{$interval} {$period}"));

    $subscription = wcs_create_subscription([
        'order_id' => $order->get_id(),
        'customer_id' => $order->get_customer_id(),
        'billing_period' => $period,
        'billing_interval' => $interval,
        'start_date' => $start,
        'next_payment' => $next,
        'status' => 'pending',
    ]);

    if (is_wp_error($subscription)) {
        PGB_Logger::instance()->log('pgb-addon-subscriptions', PGB_Logger::ERROR, 'Native subscription creation failed', [
            'order_id' => $order->get_id(),
            'error' => $subscription->get_error_message(),
        ]);
        return;
    }

    $subscription->add_product($product, max(1, $first->get_quantity()));
    $subscription->set_currency($order->get_currency());
    $subscription->set_payment_method($order->get_payment_method(), $order->get_payment_method_title());
    $subscription->calculate_totals(false);
    $subscription->save();

    $order->update_meta_data('_bzj_pgb_subscription_id', $subscription->get_id());
    $order->save();

    if ($subscription->get_status() !== 'active') {
        $subscription->update_status('active', 'Activated after confirmed Buzzjuice payment.');
    }

    PGB_Logger::instance()->log('pgb-addon-subscriptions', PGB_Logger::INFO, 'Native WooCommerce subscription created/activated', [
        'order_id' => $order->get_id(),
        'subscription_id' => $subscription->get_id(),
        'billing_period' => $period,
        'billing_interval' => $interval,
    ]);
}, 15, 2);
