<?php
if (!defined('ABSPATH')) exit;

final class PGB_Streams_DB {
    private static $instance;
    private $db = null;
    private $logger;

    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $this->logger = PGB_Logger::instance();
        $helpers = BZJ_PGB_ROOT . '/shared/db_helpers.php';
        if (file_exists($helpers)) require_once $helpers;

        if (function_exists('get_wowonder_db')) {
            $this->db = get_wowonder_db();
        }

        if (!$this->db) {
            $this->logger->log('class-pgb-streams-db', PGB_Logger::ERROR, 'WoWonder database connection unavailable');
        }
    }

    public function connection() {
        return $this->db;
    }

    public function transaction_row($wow_order_id) {
        if (!$this->db) return null;
        $stmt = $this->db->prepare('SELECT * FROM Wo_Payment_Transactions WHERE order_id = ? LIMIT 1');
        if (!$stmt) return null;
        $stmt->bind_param('s', $wow_order_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result ? $result->fetch_assoc() : null;
        $stmt->close();
        return $row;
    }

    public function user_row($wow_user_id) {
        if (!$this->db) return null;
        $stmt = $this->db->prepare('SELECT * FROM Wo_Users WHERE user_id = ? LIMIT 1');
        if (!$stmt) return null;
        $stmt->bind_param('i', $wow_user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result ? $result->fetch_assoc() : null;
        $stmt->close();
        return $row;
    }

    public function has_table($table) {
        if (!$this->db) return false;
        $table = preg_replace('/[^A-Za-z0-9_]/', '', $table);
        $result = $this->db->query("SHOW TABLES LIKE '" . $this->db->real_escape_string($table) . "'");
        return $result && $result->num_rows > 0;
    }

    public function has_column($table, $column) {
        if (!$this->db) return false;
        $table = preg_replace('/[^A-Za-z0-9_]/', '', $table);
        $column = preg_replace('/[^A-Za-z0-9_]/', '', $column);
        $stmt = $this->db->prepare("SHOW COLUMNS FROM `{$table}` LIKE ?");
        if (!$stmt) return false;
        $stmt->bind_param('s', $column);
        $stmt->execute();
        $result = $stmt->get_result();
        $exists = $result && $result->num_rows > 0;
        $stmt->close();
        return $exists;
    }

    public function update_user_columns($user_id, array $values) {
        if (!$this->db) return false;
        $allowed = [];
        foreach ($values as $column => $value) {
            if ($this->has_column('Wo_Users', $column)) {
                $allowed[$column] = $value;
            }
        }
        if (!$allowed) return false;

        $sets = [];
        $types = '';
        $params = [];
        foreach ($allowed as $column => $value) {
            $sets[] = "`{$column}` = ?";
            if (is_int($value)) $types .= 'i';
            else $types .= 's';
            $params[] = $value;
        }

        $sql = 'UPDATE Wo_Users SET ' . implode(', ', $sets) . ' WHERE user_id = ? LIMIT 1';
        $types .= 'i';
        $params[] = (int) $user_id;

        $stmt = $this->db->prepare($sql);
        if (!$stmt) return false;

        $bind = [$types];
        foreach ($params as $i => $v) $bind[] = &$params[$i];
        call_user_func_array([$stmt, 'bind_param'], $bind);

        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }

    public function insert_payment_transaction($data) {
        if (!$this->db) return false;

        $sql = 'INSERT INTO Wo_Payment_Transactions (userid, amount, order_id, kind, currency_code, notes)
                VALUES (?, ?, ?, ?, ?, ?)';
        $stmt = $this->db->prepare($sql);
        if (!$stmt) return false;

        $uid = (int) $data['userid'];
        $amount = (float) $data['amount'];
        $order_id = (string) $data['order_id'];
        $kind = (string) $data['kind'];
        $currency = (string) $data['currency_code'];
        $notes = (string) ($data['notes'] ?? '');

        $stmt->bind_param('idssss', $uid, $amount, $order_id, $kind, $currency, $notes);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }
}
