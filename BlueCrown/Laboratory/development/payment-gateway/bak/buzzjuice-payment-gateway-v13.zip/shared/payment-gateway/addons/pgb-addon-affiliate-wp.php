<?php
if (!defined('ABSPATH')) exit;

/**
 * AffiliateWP post-payment processor.
 *
 * The old bridge attempted to carry AffiliateWP browser context out of
 * Streams. v13 deliberately does not. AffiliateWP state is resolved from
 * WordPress/AffiliateWP after the paid WooCommerce order exists.
 */
add_action('bzj_pgb_payment_paid', function ($order, $row) {
    if (!function_exists('affwp_add_referral')) return;

    $logger = PGB_Logger::instance();
    $reference = (string) $order->get_id();

    global $wpdb;

    $existing = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT referral_id FROM {$wpdb->prefix}affiliate_wp_referrals
         WHERE reference = %s AND context = %s LIMIT 1",
        $reference,
        'woocommerce'
    ));

    if ($existing) {
        $logger->log('pgb-addon-affiliate-wp', PGB_Logger::DEBUG, 'AffiliateWP referral already exists', ['referral_id' => $existing, 'order_id' => $order->get_id()]);
        return;
    }

    $customer_id = 0;
    if (function_exists('affwp_get_customer')) {
        $customer = affwp_get_customer([
            'user_id' => $order->get_customer_id(),
        ]);
        if ($customer && !is_wp_error($customer)) {
            $customer_id = (int) ($customer->customer_id ?? 0);
        }
    }

    if (!$customer_id) {
        $customer_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT customer_id FROM {$wpdb->prefix}affiliate_wp_customers WHERE user_id = %d LIMIT 1",
            $order->get_customer_id()
        ));
    }

    if (!$customer_id) {
        $logger->log('pgb-addon-affiliate-wp', PGB_Logger::DEBUG, 'No AffiliateWP customer found; no commission created', ['wp_user_id' => $order->get_customer_id()]);
        return;
    }

    $affiliate_id = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT affiliate_id FROM {$wpdb->prefix}affiliate_wp_lifetime_customers
         WHERE affwp_customer_id = %d
         ORDER BY lifetime_customer_id DESC LIMIT 1",
        $customer_id
    ));

    if (!$affiliate_id && function_exists('affwp_get_affiliate_id')) {
        $affiliate_id = (int) affwp_get_affiliate_id($order->get_customer_id());
    }

    if (!$affiliate_id) {
        $logger->log('pgb-addon-affiliate-wp', PGB_Logger::DEBUG, 'No affiliate resolved', ['customer_id' => $customer_id]);
        return;
    }

    $commission = null;
    if (function_exists('affwp_calc_referral_amount')) {
        $commission = affwp_calc_referral_amount($order->get_total(), $affiliate_id);
    }

    if ($commission === null || (float) $commission <= 0) {
        $logger->log('pgb-addon-affiliate-wp', PGB_Logger::DEBUG, 'AffiliateWP calculated zero commission', ['affiliate_id' => $affiliate_id]);
        return;
    }

    $data = [
        'affiliate_id' => $affiliate_id,
        'customer_id' => $customer_id,
        'amount' => (float) $commission,
        'description' => 'Buzzjuice order #' . $order->get_id(),
        'reference' => $reference,
        'context' => 'woocommerce',
        'status' => 'unpaid',
        'currency' => $order->get_currency(),
        'campaign' => '',
        'products' => maybe_serialize([]),
        'date' => current_time('mysql'),
        'custom' => maybe_serialize([
            'bzj_pgb' => BZJ_PGB_VERSION,
            'wow_order_id' => $row['wow_order_id'],
        ]),
    ];

    $referral_id = affwp_add_referral($data);

    if (!$referral_id) {
        $logger->log('pgb-addon-affiliate-wp', PGB_Logger::ERROR, 'AffiliateWP referral creation failed', ['order_id' => $order->get_id(), 'affiliate_id' => $affiliate_id]);
        return;
    }

    $verify = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT referral_id FROM {$wpdb->prefix}affiliate_wp_referrals WHERE referral_id = %d LIMIT 1",
        $referral_id
    ));

    if (!$verify) {
        $logger->log('pgb-addon-affiliate-wp', PGB_Logger::ERROR, 'AffiliateWP referral verification failed', ['referral_id' => $referral_id]);
        return;
    }

    $logger->log('pgb-addon-affiliate-wp', PGB_Logger::INFO, 'AffiliateWP referral created and verified', [
        'order_id' => $order->get_id(),
        'affiliate_id' => $affiliate_id,
        'referral_id' => $referral_id,
        'amount' => $commission,
    ]);
}, 20, 2);
