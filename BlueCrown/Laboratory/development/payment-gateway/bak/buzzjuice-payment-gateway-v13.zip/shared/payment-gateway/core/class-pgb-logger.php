<?php
if (!defined('ABSPATH')) exit;

final class PGB_Logger {
    const DEBUG = 5;
    const INFO = 4;
    const WARNING = 3;
    const ERROR = 2;
    const CRITICAL = 1;

    private static $instance;
    private $enabled;
    private $level;

    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $this->enabled = (bool) get_option('pgb_logging_enabled', true);
        $this->level = $this->level_number((string) get_option('pgb_log_level', 'info'));
    }

    private function level_number($name) {
        return [
            'debug' => self::DEBUG,
            'info' => self::INFO,
            'warning' => self::WARNING,
            'error' => self::ERROR,
            'critical' => self::CRITICAL,
            'off' => 0,
        ][strtolower($name)] ?? self::INFO;
    }

    public function log($component, $level, $message, $context = []) {
        if (!$this->enabled || $this->level === 0 || $level > $this->level) return;

        $component = preg_replace('/[^a-zA-Z0-9_.-]/', '-', (string) $component);
        $file = BZJ_PGB_LOG . '/' . $component . '.log';

        $entry = [
            'time' => gmdate('c'),
            'level' => $this->level_name($level),
            'component' => $component,
            'message' => (string) $message,
            'context' => $this->redact($context),
        ];

        @file_put_contents(
            $file,
            wp_json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . PHP_EOL,
            FILE_APPEND | LOCK_EX
        );
    }

    private function level_name($level) {
        return [
            self::DEBUG => 'DEBUG',
            self::INFO => 'INFO',
            self::WARNING => 'WARNING',
            self::ERROR => 'ERROR',
            self::CRITICAL => 'CRITICAL',
        ][$level] ?? 'INFO';
    }

    private function redact($value) {
        $keys = ['password','secret','consumer_key','consumer_secret','api_key','api_secret','token','authorization','cookie','session_id'];
        if (is_array($value)) {
            $out = [];
            foreach ($value as $k => $v) {
                $out[$k] = in_array(strtolower((string) $k), $keys, true) ? '[REDACTED]' : $this->redact($v);
            }
            return $out;
        }
        if (is_object($value)) return '[OBJECT]';
        if (is_string($value) && strlen($value) > 2000) return substr($value, 0, 2000) . '…';
        return $value;
    }
}
