<?php
if (!defined('ABSPATH')) exit;

/**
 * Jewel Affiliate integration seam.
 *
 * The old bridge can now be migrated here without adding HTTP calls to the
 * payment path. If the existing Jewel webhook/function is available as a
 * callable PHP function, it can be invoked after payment.
 */
add_action('bzj_pgb_payment_paid', function ($order, $row) {
    $candidates = [
        'jewel_affiliate_process_order',
        'bzj_jewel_affiliate_process_order',
        'process_jewel_affiliate_order',
    ];

    foreach ($candidates as $function) {
        if (function_exists($function)) {
            try {
                call_user_func($function, $order->get_id(), $order, $row);
                PGB_Logger::instance()->log('pgb-int-jewel-affiliate', PGB_Logger::INFO, 'Jewel affiliate callable executed', ['function' => $function, 'order_id' => $order->get_id()]);
            } catch (Throwable $e) {
                PGB_Logger::instance()->log('pgb-int-jewel-affiliate', PGB_Logger::ERROR, 'Jewel affiliate callable failed', ['function' => $function, 'error' => $e->getMessage()]);
            }
            return;
        }
    }

    PGB_Logger::instance()->log('pgb-int-jewel-affiliate', PGB_Logger::DEBUG, 'No Jewel PHP callable registered; integration skipped', ['order_id' => $order->get_id()]);
}, 30, 2);
