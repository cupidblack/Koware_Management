<?php
if (!defined('ABSPATH')) exit;

final class PGB_Manager {
    private static $instance;
    private $logger;
    private $config;
    private $streams = null;

    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $this->logger = PGB_Logger::instance();
        $this->config = PGB_Config::instance();
    }

    public function bootstrap() {
        $this->logger->log('class-pgb-manager', PGB_Logger::DEBUG, 'PGB bootstrap complete', ['version' => BZJ_PGB_VERSION]);
    }

    public function table_name() {
        global $wpdb;
        return $wpdb->prefix . 'bzj_pgb_orders';
    }

    public function ensure_schema() {
        global $wpdb;
        $table = $this->table_name();
        $version = get_option('bzj_pgb_schema_version', '');

        if ($version === BZJ_PGB_VERSION) return;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            wow_order_id VARCHAR(191) NOT NULL,
            wow_user_id BIGINT UNSIGNED NOT NULL,
            wp_user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            transaction_kind VARCHAR(40) NOT NULL,
            amount DECIMAL(20,8) NOT NULL DEFAULT 0,
            currency_code VARCHAR(10) NOT NULL DEFAULT '',
            product_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            variation_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            wow_post_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            product_owner_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            quantity INT UNSIGNED NOT NULL DEFAULT 1,
            product_name TEXT NULL,
            payload LONGTEXT NOT NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'pending',
            woo_order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            woo_subscription_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            handoff_nonce CHAR(64) NOT NULL,
            handoff_timestamp BIGINT UNSIGNED NOT NULL DEFAULT 0,
            handoff_expires BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            paid_at DATETIME NULL,
            fulfilled_at DATETIME NULL,
            failure_message TEXT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_wow_order_id (wow_order_id),
            UNIQUE KEY uq_handoff_nonce (handoff_nonce),
            KEY idx_status (status),
            KEY idx_wow_user (wow_user_id),
            KEY idx_wp_user (wp_user_id),
            KEY idx_woo_order (woo_order_id)
        ) {$charset};";

        dbDelta($sql);
        update_option('bzj_pgb_schema_version', BZJ_PGB_VERSION);
        $this->logger->log('class-pgb-manager', PGB_Logger::INFO, 'PGB schema verified', ['table' => $table]);
    }

    public function create_pending(array $data) {
        global $wpdb;

        $now = gmdate('Y-m-d H:i:s');
        $table = $this->table_name();

        $insert = [
            'wow_order_id' => $data['wow_order_id'],
            'wow_user_id' => (int) $data['wow_user_id'],
            'wp_user_id' => (int) $data['wp_user_id'],
            'transaction_kind' => $data['transaction_kind'],
            'amount' => (float) $data['amount'],
            'currency_code' => $data['currency_code'],
            'product_id' => (int) $data['product_id'],
            'variation_id' => (int) $data['variation_id'],
            'wow_post_id' => (int) $data['wow_post_id'],
            'product_owner_id' => (int) $data['product_owner_id'],
            'quantity' => max(1, (int) $data['quantity']),
            'product_name' => $data['product_name'],
            'payload' => wp_json_encode($data['payload'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'status' => 'pending',
            'handoff_nonce' => hash('sha256', $data['nonce']),
            'handoff_timestamp' => (int) $data['timestamp'],
            'handoff_expires' => (int) $data['expires'],
            'created_at' => $now,
            'updated_at' => $now,
        ];

        $formats = ['%s','%d','%d','%s','%f','%s','%d','%d','%d','%d','%d','%s','%s','%s','%s','%d','%d','%s','%s'];

        $ok = $wpdb->insert($table, $insert, $formats);
        if (!$ok) {
            $this->logger->log('class-pgb-manager', PGB_Logger::ERROR, 'Failed to insert pending PGB order', ['db_error' => $wpdb->last_error]);
            return false;
        }

        return (int) $wpdb->insert_id;
    }

    public function get_pending($wow_order_id) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table_name()} WHERE wow_order_id = %s LIMIT 1", $wow_order_id),
            ARRAY_A
        );
    }

    private function valid_handoff($wow_order_id, $timestamp, $nonce, $sig) {
        $secret = $this->config->handoff_secret();
        if ($secret === '') {
            $this->logger->log('class-pgb-manager', PGB_Logger::CRITICAL, 'Handoff secret is missing');
            return false;
        }

        $timestamp = (int) $timestamp;
        if ($timestamp <= 0 || abs(time() - $timestamp) > 900) return false;

        $expected = hash_hmac('sha256', $wow_order_id . '|' . $timestamp . '|' . $nonce, $secret);
        return hash_equals($expected, (string) $sig);
    }

    public function handle_browser_handoff() {
        $wow_order_id = sanitize_text_field(wp_unslash($_GET['pgb_order_id'] ?? ''));
        $timestamp = absint($_GET['ts'] ?? 0);
        $nonce = sanitize_text_field(wp_unslash($_GET['nonce'] ?? ''));
        $sig = sanitize_text_field(wp_unslash($_GET['sig'] ?? ''));

        if (!$wow_order_id || !$timestamp || !$nonce || !$sig || !$this->valid_handoff($wow_order_id, $timestamp, $nonce, $sig)) {
            $this->logger->log('class-pgb-manager', PGB_Logger::WARNING, 'Invalid payment handoff', ['wow_order_id' => $wow_order_id]);
            wp_die('This payment session is invalid or has expired.', 'Payment Gateway Bridge', ['response' => 403]);
        }

        $row = $this->get_pending($wow_order_id);
        if (!$row) wp_die('Payment order not found.', 'Payment Gateway Bridge', ['response' => 404]);

        $nonce_hash = hash('sha256', $nonce);
        if (!hash_equals($row['handoff_nonce'], $nonce_hash)) {
            wp_die('Payment session validation failed.', 'Payment Gateway Bridge', ['response' => 403]);
        }

        if (!empty($row['woo_order_id'])) {
            $order = wc_get_order((int) $row['woo_order_id']);
            if ($order) {
                wp_safe_redirect($order->get_checkout_payment_url());
                exit;
            }
        }

        $result = $this->create_wc_order_from_pending($row);
        if (is_wp_error($result)) {
            $this->logger->log('class-pgb-manager', PGB_Logger::ERROR, 'Could not create WooCommerce order', ['error' => $result->get_error_message()]);
            wp_die('The payment order could not be prepared. Please try again.', 'Payment Gateway Bridge', ['response' => 500]);
        }

        wp_safe_redirect($result->get_checkout_payment_url());
        exit;
    }

    private function create_wc_order_from_pending(array $row) {
        global $wpdb;

        $order_data = json_decode($row['payload'], true);
        if (!is_array($order_data)) {
            return new WP_Error('invalid_payload', 'Invalid PGB order payload.');
        }

        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT woo_order_id FROM {$this->table_name()} WHERE id = %d LIMIT 1",
            (int) $row['id']
        ));
        if ($existing) {
            $order = wc_get_order((int) $existing);
            if ($order) return $order;
        }

        $product_id = (int) $row['product_id'];
        $variation_id = (int) $row['variation_id'];
        $product = $variation_id ? wc_get_product($variation_id) : wc_get_product($product_id);
        if (!$product) {
            return new WP_Error('product_not_found', 'Mapped WooCommerce product was not found.');
        }

        $order = wc_create_order(['customer_id' => (int) $row['wp_user_id']]);
        if (is_wp_error($order)) return $order;

        $qty = max(1, (int) $row['quantity']);
        $line_total = (float) $row['amount'];

        $item_id = $order->add_product($product, $qty, [
            'subtotal' => $line_total,
            'total' => $line_total,
        ]);

        if (!$item_id) {
            $order->delete(true);
            return new WP_Error('line_item_failed', 'Could not add the mapped product to the order.');
        }

        $order->set_currency((string) $row['currency_code']);
        $order->set_customer_id((int) $row['wp_user_id']);

        $meta = [
            '_bzj_pgb_order_id' => $row['wow_order_id'],
            '_wow_order_id' => $row['wow_order_id'],
            'wow_order_id' => $row['wow_order_id'],
            'wow_user_id' => (int) $row['wow_user_id'],
            'userid' => (int) $row['wow_user_id'],
            'wow_post_id' => (int) $row['wow_post_id'],
            'transaction_kind' => $row['transaction_kind'],
            'product_owner_id' => (int) $row['product_owner_id'],
            '_bzj_pgb_version' => BZJ_PGB_VERSION,
        ];

        foreach ($meta as $key => $value) $order->update_meta_data($key, $value);

        foreach ($order_data['meta'] ?? [] as $key => $value) {
            if ($key !== '' && strpos((string) $key, '_') === 0 || $key !== '') {
                $order->update_meta_data(sanitize_key($key), is_scalar($value) ? $value : wp_json_encode($value));
            }
        }

        $order->calculate_totals(false);
        $order->set_status('pending', 'Buzzjuice PGB order created; awaiting customer payment.');
        $order->save();

        $wpdb->update(
            $this->table_name(),
            [
                'woo_order_id' => $order->get_id(),
                'status' => 'checkout_ready',
                'updated_at' => gmdate('Y-m-d H:i:s'),
            ],
            ['id' => (int) $row['id'],
            ],
            ['%d','%s','%s'],
            ['%d']
        );

        $this->logger->log('class-pgb-manager', PGB_Logger::INFO, 'WooCommerce order created', [
            'wow_order_id' => $row['wow_order_id'],
            'woo_order_id' => $order->get_id(),
        ]);

        return $order;
    }

    public function handle_paid_order($order_id, $source) {
        $order = wc_get_order($order_id);
        if (!$order) return;

        $wow_order_id = (string) $order->get_meta('_bzj_pgb_order_id', true);
        if ($wow_order_id === '') return;

        $row = $this->get_pending($wow_order_id);
        if (!$row) {
            $this->logger->log('class-pgb-manager', PGB_Logger::WARNING, 'PGB order ledger row missing', ['woo_order_id' => $order_id, 'wow_order_id' => $wow_order_id]);
            return;
        }

        if (!$order->is_paid()) {
            $this->logger->log('class-pgb-manager', PGB_Logger::DEBUG, 'Payment hook received but order is not paid', ['woo_order_id' => $order_id, 'source' => $source]);
            return;
        }

        if (in_array($row['status'], ['paid','fulfilled'], true) && !empty($row['paid_at'])) {
            $this->run_post_payment_addons($order, $row);
            return;
        }

        global $wpdb;
        $wpdb->update(
            $this->table_name(),
            [
                'status' => 'paid',
                'paid_at' => gmdate('Y-m-d H:i:s'),
                'updated_at' => gmdate('Y-m-d H:i:s'),
            ],
            ['id' => (int) $row['id']],
            ['%s','%s','%s'],
            ['%d']
        );

        $order->update_meta_data('_bzj_pgb_paid_at', gmdate('c'));
        $order->save();

        $this->run_post_payment_addons($order, $row);
    }

    private function run_post_payment_addons($order, array $row) {
        do_action('bzj_pgb_payment_paid', $order, $row);

        $fulfilled = apply_filters('bzj_pgb_fulfillment_result', true, $order, $row);

        if ($fulfilled) {
            global $wpdb;
            $wpdb->update(
                $this->table_name(),
                [
                    'status' => 'fulfilled',
                    'fulfilled_at' => gmdate('Y-m-d H:i:s'),
                    'updated_at' => gmdate('Y-m-d H:i:s'),
                ],
                ['id' => (int) $row['id']],
                ['%s','%s','%s'],
                ['%d']
            );
        }
    }

    public function mark_failure($wow_order_id, $message) {
        global $wpdb;
        $wpdb->update(
            $this->table_name(),
            [
                'status' => 'failed',
                'failure_message' => sanitize_textarea_field($message),
                'updated_at' => gmdate('Y-m-d H:i:s'),
            ],
            ['wow_order_id' => $wow_order_id],
            ['%s','%s','%s'],
            ['%s']
        );
    }
}
