# Buzzjuice Payment Gateway Bridge v8.1.3

This package corrects the v8.1 deployment failure and contains the complete core tree required by `bzj-pgb-engine.php`.

## Critical installation rule

Extract the archive **from its root** so that these two paths exist on the server:

- `shared/payment-gateway/core/class-pgb-manager.php`
- `wp-content/mu-plugins/bzj-pgb-engine.php`

The MU engine now resolves the bridge root from several common WordPress layouts and reports the resolved path in **Buzzjuice → Payment Gateways**.

## Checkout behavior

`/wp-json/bzj-pgb/v1/checkout` validates the HMAC handoff, creates/reuses the WooCommerce order, then sends a browser HTTP 302 redirect to WooCommerce's payment URL. It no longer leaves the browser on a JSON REST endpoint.

## Important

Wallet, funding and market addons are intentionally diagnostic-only until the existing proven Streams fulfillment rules have been migrated into them. They do not silently create duplicate business records.

## 8.1.3 checkout flow correction

The Streams-side client remains WordPress-independent. Existing WoWonder payment settings are the authoritative source for the WooCommerce handler product IDs (`wow_market_id`, `wow_pro_package_id` through `_4`, `wow_wallet_topup_id`, and `wow_crowdfund_id`). Those IDs are copied into the signed transaction metadata before the browser handoff.

On WordPress, the bridge creates a native unpaid `WC_Order` and redirects with `WC_Order::get_checkout_payment_url(true)`. This produces WooCommerce's canonical order-pay/checkout URL, including the order key. `get_checkout_order_received_url()` is not used before payment because that URL represents the post-payment confirmation page.
