<?php
/** Include this from the WoWonder payment branch in requests.php. */
require_once dirname(__DIR__) . '/shared/payment-gateway/pgb-client-streams.php';
$result=pgb_streams_create_pending($_POST,$wo,$sqlConnect);
http_response_code((int)($result['status']??500));
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($result,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
exit;
