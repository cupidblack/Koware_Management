<?php
defined('ABSPATH') || exit;
/**
 * Jewel integration hook. The existing Streams webhook can be invoked from the
 * paid event if it is configured for a secure, idempotent operation.
 */
add_action('bzj_pgb_paid', function($order,$row){
    $url=get_option('bzj_pgb_jewel_webhook_url','');
    $secret=get_option('bzj_pgb_jewel_webhook_secret','');
    if(!$url || !$secret)return;
    $payload=['event'=>'payment.paid','wow_order_id'=>$row['order_id'],'woo_order_id'=>$order->get_id(),'user_id'=>(int)$row['userid'],'amount'=>(float)$order->get_total(),'currency'=>$order->get_currency()];
    $body=wp_json_encode($payload); $sig=hash_hmac('sha256',$body,$secret);
    $r=wp_safe_remote_post($url,['timeout'=>10,'headers'=>['Content-Type'=>'application/json','X-Buzzjuice-Signature'=>$sig],'body'=>$body]);
    if(is_wp_error($r))PGB_Logger::instance()->error('Jewel webhook failed',['error'=>$r->get_error_message()],__FILE__);
    else PGB_Logger::instance()->info('Jewel webhook sent',['status'=>wp_remote_retrieve_response_code($r)],__FILE__);
},30,2);
