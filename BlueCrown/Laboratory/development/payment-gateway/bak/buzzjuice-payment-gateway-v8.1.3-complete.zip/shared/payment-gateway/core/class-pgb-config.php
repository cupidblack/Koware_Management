<?php
defined('ABSPATH') || exit;
class PGB_Config {
    public static function option($key, $default = null) {
        return get_option('bzj_pgb_' . $key, $default);
    }
    public static function secret() {
        $secret = getenv('BUZZ_PGB_SECRET');
        if (!$secret && defined('BUZZ_PGB_SECRET')) $secret = BUZZ_PGB_SECRET;
        return (string)$secret;
    }
    public static function streams_url() {
        $url = getenv('BUZZ_STREAMS_URL');
        if (!$url && defined('BUZZ_STREAMS_URL')) $url = BUZZ_STREAMS_URL;
        return rtrim((string)$url, '/');
    }
    public static function logging_enabled() { return (bool)self::option('logging_enabled', false); }
    public static function log_level() { return (string)self::option('log_level', 'info'); }
    public static function require_secret() {
        if (self::secret() === '') throw new RuntimeException('BUZZ_PGB_SECRET is not configured.');
        return self::secret();
    }
}
