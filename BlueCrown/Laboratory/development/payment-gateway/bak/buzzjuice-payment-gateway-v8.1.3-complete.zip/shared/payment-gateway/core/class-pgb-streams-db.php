<?php
defined('ABSPATH') || exit;
class PGB_Streams_DB {
    private $db;
    private $table='Wo_Payment_Transactions';
    public function __construct() {
        if (is_readable(BZJ_PGB_DB_HELPERS)) require_once BZJ_PGB_DB_HELPERS;
        $this->db = function_exists('get_wowonder_db') ? get_wowonder_db() : false;
    }
    public function db(){ return $this->db; }
    private function valid_order_id($id){ return is_string($id) && preg_match('/^wow_[A-Za-z0-9_-]{10,80}$/',$id); }
    public function get($order_id) {
        if (!$this->db || !$this->valid_order_id($order_id)) return null;
        $stmt=$this->db->prepare("SELECT * FROM {$this->table} WHERE order_id=? LIMIT 1");
        if(!$stmt) return null;
        $stmt->bind_param('s',$order_id); $stmt->execute();
        $res=$stmt->get_result(); $row=$res?$res->fetch_assoc():null; $stmt->close(); return $row;
    }
    public function update($order_id,$fields) {
        if(!$this->db || !$this->valid_order_id($order_id) || !$fields) return false;
        $allowed=['payment_status','payment_method','woo_order_id','amount','transaction_dt','notes','pgb_state','pgb_fulfilled_at','pgb_last_error'];
        $sets=[];$vals=[];$types='';
        foreach($fields as $k=>$v){ if(in_array($k,$allowed,true)){ $sets[]="`$k`=?"; $vals[]=$v; $types .= is_int($v)?'i':(is_float($v)?'d':'s'); } }
        if(!$sets)return false;
        $vals[]=$order_id;$types.='s';
        $stmt=$this->db->prepare("UPDATE {$this->table} SET ".implode(',',$sets)." WHERE order_id=? LIMIT 1");
        if(!$stmt)return false; $stmt->bind_param($types,...$vals); $ok=$stmt->execute(); $stmt->close(); return $ok;
    }
    public function find_user_wp_id($wow_user_id) {
        if(!$this->db || !ctype_digit((string)$wow_user_id)) return 0;
        $stmt=$this->db->prepare("SELECT wp_user_id FROM Wo_Users WHERE user_id=? LIMIT 1");
        if(!$stmt)return 0; $id=(int)$wow_user_id;$stmt->bind_param('i',$id);$stmt->execute();$stmt->bind_result($wp);$stmt->fetch();$stmt->close();return (int)$wp;
    }
    public function insert_pending($data) {
        if(!$this->db)return false;
        $sql="INSERT INTO {$this->table} (userid,amount,order_id,kind,currency_code,payment_status,notes,transaction_dt) VALUES (?,?,?,?,?,?,?,NOW())";
        $stmt=$this->db->prepare($sql); if(!$stmt)return false;
        $userid=(int)$data['wow_user_id'];$amount=(float)$data['amount'];$order=$data['wow_order_id'];$kind=$data['transaction_kind'];$currency=$data['currency'];$status='pending';$notes=$data['notes'];
        $stmt->bind_param('idsssss',$userid,$amount,$order,$kind,$currency,$status,$notes);$ok=$stmt->execute();$stmt->close();return $ok;
    }
}
