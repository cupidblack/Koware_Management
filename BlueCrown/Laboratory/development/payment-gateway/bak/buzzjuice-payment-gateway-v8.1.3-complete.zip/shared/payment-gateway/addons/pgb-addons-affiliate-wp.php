<?php
defined('ABSPATH') || exit;
/**
 * AffiliateWP fulfillment addon.
 * Resolves the affiliate at fulfillment time, not at Streams initiation.
 */
add_action('bzj_pgb_paid', function($order,$row){
    $logger=PGB_Logger::instance();
    if(!function_exists('affwp_add_referral') && !function_exists('affiliate_wp')) { $logger->warning('AffiliateWP unavailable',['woo_order_id'=>$order->get_id()],__FILE__); return; }
    $existing=0;
    if(function_exists('affwp_get_referral')) {
        $ref=affwp_get_referral(['reference'=>(string)$order->get_id()]);
        if($ref && !empty($ref->referral_id)) $existing=(int)$ref->referral_id;
    }
    if($existing){$logger->debug('Affiliate referral already exists',['referral_id'=>$existing],__FILE__);return;}
    $user_id=(int)$order->get_customer_id(); $affiliate_id=0;
    if(function_exists('affwp_get_affiliate_id')) $affiliate_id=(int)affwp_get_affiliate_id($user_id);
    if(!$affiliate_id) {
        $email=$order->get_billing_email();
        if(function_exists('affwp_get_affiliate_id_by_email')) $affiliate_id=(int)affwp_get_affiliate_id_by_email($email);
    }
    if(!$affiliate_id){$logger->info('No affiliate resolved',['woo_order_id'=>$order->get_id()],__FILE__);return;}
    $settings=get_option('affwp_settings',[]);
    $rate=(float)($settings['referral_rate']??0); $type=$settings['referral_rate_type']??'percentage';
    $base=(float)$order->get_subtotal();
    $commission=$type==='percentage' ? round($base*$rate/100,2) : round($rate,2);
    if($commission<=0)return;
    if(function_exists('affwp_add_referral')) {
        $id=affwp_add_referral([
            'affiliate_id'=>$affiliate_id,'amount'=>$commission,'reference'=>(string)$order->get_id(),
            'description'=>'Buzzjuice Streams order '.$row['order_id'],'context'=>'woocommerce',
            'custom'=>['buzzjuice_order_id'=>$row['order_id']]
        ]);
        if($id) $logger->info('AffiliateWP referral created',['affiliate_id'=>$affiliate_id,'referral_id'=>$id,'amount'=>$commission],__FILE__);
        else $logger->error('AffiliateWP referral creation returned no ID',['affiliate_id'=>$affiliate_id,'woo_order_id'=>$order->get_id()],__FILE__);
    }
},20,2);
