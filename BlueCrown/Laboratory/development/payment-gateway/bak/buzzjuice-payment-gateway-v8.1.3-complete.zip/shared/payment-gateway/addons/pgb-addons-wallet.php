<?php
defined('ABSPATH') || exit;
add_action('bzj_pgb_paid', function($order,$row){
    if(strtoupper((string)($row['kind']??''))!=='WALLET')return;
    PGB_Logger::instance()->warning('Wallet fulfillment requires the existing Streams wallet business-rule migration before enabling automatic crediting. No wallet credit was applied by this addon.',['wow_order_id'=>$row['order_id'],'woo_order_id'=>$order->get_id()],__FILE__);
},20,2);
