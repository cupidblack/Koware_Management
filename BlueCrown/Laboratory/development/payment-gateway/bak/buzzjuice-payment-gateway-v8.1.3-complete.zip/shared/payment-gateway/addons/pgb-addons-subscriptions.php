<?php
defined('ABSPATH') || exit;
add_action('bzj_pgb_paid', function($order,$row){
    if(!function_exists('wcs_get_subscriptions_for_order')) return;
    $subscriptions=wcs_get_subscriptions_for_order($order->get_id(),['order_type'=>'parent']);
    if(!$subscriptions)return;
    foreach($subscriptions as $subscription){
        PGB_Logger::instance()->info('WooCommerce Subscriptions detected; lifecycle left to Subscriptions plugin',['woo_order_id'=>$order->get_id(),'subscription_id'=>$subscription->get_id(),'status'=>$subscription->get_status()],__FILE__);
    }
},10,2);
