<?php

defined('ABSPATH') || exit;

class PGB_Manager {
    private static $instance;
    private $db;
    private $logger;

    public static function instance(){ return self::$instance ?: (self::$instance=new self); }
    private function __construct(){ $this->logger=PGB_Logger::instance(); $this->db=new PGB_Streams_DB(); }

    public function register_hooks() {
        add_action('woocommerce_payment_complete',[$this,'payment_complete'],20);
        add_action('woocommerce_order_status_processing',[$this,'status_processing'],20);
        add_action('woocommerce_order_status_completed',[$this,'status_completed'],20);
        add_action('woocommerce_order_status_failed',[$this,'status_failed'],20);
        add_action('woocommerce_order_status_cancelled',[$this,'status_cancelled'],20);
        add_filter('woocommerce_get_return_url',[$this,'filter_return_url'],20,2);
    }

    public function checkout_from_streams(WP_REST_Request $r) {
        $id=sanitize_text_field((string)$r->get_param('order')); $token=(string)$r->get_param('token');
        if(!$id || !PGB_Order::verify_token($id,$token)) return new WP_Error('pgb_auth','Invalid payment handoff.',['status'=>403]);
        $row=$this->db->get($id); if(!$row)return new WP_Error('pgb_not_found','Payment transaction not found.',['status'=>404]);
        try {
            if(!empty($row['woo_order_id'])) $order=wc_get_order((int)$row['woo_order_id']); else $order=false;
            if(!$order) {
                $order=$this->create_order($row);
                $this->db->update($id,['woo_order_id'=>$order->get_id(),'pgb_state'=>'woo_order_created','pgb_last_error'=>'']);
                $this->logger->info('WooCommerce order created',['wow_order_id'=>$id,'woo_order_id'=>$order->get_id()],__FILE__);
            }

            // This is an unpaid order. WooCommerce's canonical URL for an
            // existing order awaiting payment is the order-pay/checkout URL.
            // get_checkout_order_received_url() is reserved for the post-payment
            // confirmation/thank-you page and must not be used here.
            $checkout=$order->get_checkout_payment_url(true);
            if(!$checkout) throw new RuntimeException('WooCommerce did not return a payment URL.');

            $this->logger->info('Redirecting Streams customer to WooCommerce payment page',[
                'wow_order_id'=>$id,
                'woo_order_id'=>$order->get_id(),
                'checkout_url'=>$checkout,
            ],__FILE__);

            if(!headers_sent()) { wp_safe_redirect($checkout,302); exit; }
            return new WP_REST_Response(['status'=>'success','checkout_url'=>$checkout,'woo_order_id'=>$order->get_id()],200);
        } catch(Throwable $e) {
            $this->db->update($id,['pgb_state'=>'error','pgb_last_error'=>$e->getMessage()]);
            $this->logger->error('Checkout preparation failed',['wow_order_id'=>$id,'error'=>$e->getMessage(),'trace'=>$e->getTraceAsString()],__FILE__);
            return new WP_Error('pgb_create_failed','Unable to prepare checkout.',['status'=>500]);
        }
    }

    public function status_from_streams(WP_REST_Request $r) {
        $id=sanitize_text_field((string)$r->get_param('order')); $token=(string)$r->get_param('token');
        if(!$id || !PGB_Order::verify_token($id,$token))return new WP_Error('pgb_auth','Invalid payment handoff.',['status'=>403]);
        $row=$this->db->get($id); if(!$row)return new WP_Error('pgb_not_found','Not found.',['status'=>404]);
        return new WP_REST_Response(['status'=>'success','payment_status'=>$row['payment_status']??'pending','pgb_state'=>$row['pgb_state']??'pending','woo_order_id'=>$row['woo_order_id']??''],200);
    }

    private function create_order($row) {
        if(!function_exists('wc_create_order') || !function_exists('wc_get_product'))throw new RuntimeException('WooCommerce is unavailable.');
        $woo_user=$this->db->find_user_wp_id((int)$row['userid']); if(!$woo_user)throw new RuntimeException('Mapped WordPress user not found.');
        $kind=strtoupper((string)$row['kind']);
        $meta=[];
        if(!empty($row['notes'])){ $decoded=json_decode((string)$row['notes'],true); if(is_array($decoded))$meta=$decoded; }

        $product_id=(int)($meta['woo_product_id']??0);
        $variation_id=(int)($meta['woo_variation_id']??0);
        if($product_id<=0) $product_id=$this->product_id_for_row($row,$kind);
        if(!$product_id)throw new RuntimeException('No WooCommerce product handler is configured for transaction kind '.$kind.'.');

        $product=wc_get_product($product_id); if(!$product)throw new RuntimeException('Configured WooCommerce product '.$product_id.' does not exist.');
        if($variation_id>0) {
            $variation=wc_get_product($variation_id);
            if($variation && $variation->is_type('variation')) $product=$variation;
        }

        $order=wc_create_order(['customer_id'=>$woo_user,'created_via'=>'buzzjuice_pgb']);
        $qty=max(1,(int)($row['quantity']??$meta['product_units']??1));
        $item_id=$order->add_product($product,$qty);
        if(!$item_id) throw new RuntimeException('WooCommerce could not add product '.$product_id.' to the order.');

        // The Streams transaction is authoritative for the amount presented to
        // the customer. The old REST integration explicitly supplied line-item
        // price/subtotal/total, so preserve that behavior while using native
        // WooCommerce order objects.
        $unit_price=(float)($meta['product_price']??$row['amount']??0);
        $line_total=(float)($row['amount']??($unit_price*$qty));
        $item=$order->get_item($item_id);
        if($item) {
            $item->set_subtotal(wc_format_decimal($unit_price*$qty));
            $item->set_total(wc_format_decimal($line_total));
            $item->save();
        }

        $currency=strtoupper((string)($row['currency_code']??'')); if(!preg_match('/^[A-Z]{3}$/',$currency))$currency=get_woocommerce_currency();
        $order->set_currency($currency); $order->set_customer_id($woo_user);
        $order->update_meta_data('_buzzjuice_wow_order_id',(string)$row['order_id']);
        $order->update_meta_data('_buzzjuice_wow_user_id',(string)$row['userid']);
        $order->update_meta_data('_buzzjuice_origin','streams');
        $order->update_meta_data('_buzzjuice_pgb_version',BZJ_PGB_VERSION);
        $order->update_meta_data('_buzzjuice_pgb_product_id',(string)$product_id);
        if($variation_id>0) $order->update_meta_data('_buzzjuice_pgb_variation_id',(string)$variation_id);
        if(!empty($row['notes'])) $order->update_meta_data('_buzzjuice_pgb_notes',(string)$row['notes']);
        $order->calculate_totals(false); $order->save();
        return $order;
    }

    private function product_id_for_row($row,$kind) {
        $meta=[]; if(!empty($row['notes'])){ $decoded=json_decode((string)$row['notes'],true); if(is_array($decoded))$meta=$decoded; }
        $key=null;
        if($kind==='PRO') {
            $pkg=(int)($meta['pro_type']??$meta['wow_post_id']??0);
            $key=$pkg>0?'wow_pro_package_id_'.$pkg:'wow_pro_package_id';
        } elseif(in_array($kind,['PRODUCT','PURCHASE','SALE'],true)) $key='wow_market_id';
        elseif($kind==='WALLET')$key='wow_wallet_topup_id'; elseif($kind==='DONATE')$key='wow_crowdfund_id';
        if(!$key)return 0;
        $id=(int)get_option('bzj_pgb_product_'.$key,0);
        if(!$id){$constant='BUZZ_PGB_'.$key;if(defined($constant))$id=(int)constant($constant);}
        return $id;
    }

    private function process_paid($order,$reason) {
        $wow_id=(string)PGB_Order::meta($order,'_buzzjuice_wow_order_id',''); if(!$wow_id)return;
        $row=$this->db->get($wow_id); if(!$row)return;
        if(!empty($row['pgb_fulfilled_at']))return;
        if(!$order->is_paid())return;
        $this->db->update($wow_id,['payment_status'=>$order->get_status(),'payment_method'=>$order->get_payment_method(),'amount'=>(float)$order->get_total(),'transaction_dt'=>current_time('mysql',true),'pgb_state'=>'paid']);
        do_action('bzj_pgb_paid',$order,$row);
        $this->db->update($wow_id,['pgb_state'=>'fulfilled','pgb_fulfilled_at'=>current_time('mysql',true)]);
        $this->logger->info('Paid order fulfilled',['wow_order_id'=>$wow_id,'woo_order_id'=>$order->get_id(),'reason'=>$reason],__FILE__);
    }
    public function payment_complete($order_id){$o=wc_get_order($order_id);if($o)$this->process_paid($o,'payment_complete');}
    public function status_processing($order_id){$o=wc_get_order($order_id);if($o)$this->process_paid($o,'processing');}
    public function status_completed($order_id){$o=wc_get_order($order_id);if($o)$this->process_paid($o,'completed');}
    public function status_failed($order_id){$o=wc_get_order($order_id);if(!$o)return;$id=PGB_Order::meta($o,'_buzzjuice_wow_order_id','');if($id)$this->db->update($id,['payment_status'=>'failed','pgb_state'=>'failed']);}
    public function status_cancelled($order_id){$o=wc_get_order($order_id);if(!$o)return;$id=PGB_Order::meta($o,'_buzzjuice_wow_order_id','');if($id)$this->db->update($id,['payment_status'=>'cancelled','pgb_state'=>'cancelled']);}
    public function filter_return_url($return_url,$order){
        if(!$order instanceof WC_Order)return $return_url;
        $wow_id=PGB_Order::meta($order,'_buzzjuice_wow_order_id',''); if(!$wow_id)return $return_url;
        $base=PGB_Config::streams_url(); if(!$base)return $return_url;
        return esc_url_raw($base.'/index.php?link1=purchased&pgb_order='.rawurlencode($wow_id));
    }
    public static function render_admin_page(){
        if(!current_user_can('manage_options'))return;
        ?><div class="wrap"><h1>Buzzjuice → Payment Gateways</h1>
        <form method="post" action="options.php"><?php settings_fields('bzj_pgb_settings'); ?><table class="form-table">
        <tr><th>Enable detailed logging</th><td><input type="checkbox" name="bzj_pgb_logging_enabled" value="1" <?php checked(PGB_Config::logging_enabled()); ?>></td></tr>
        <tr><th>Minimum log level</th><td><select name="bzj_pgb_log_level"><?php foreach(['debug','info','warning','error','critical'] as $v): ?><option value="<?php echo esc_attr($v); ?>" <?php selected(PGB_Config::log_level(),$v); ?>><?php echo esc_html(ucfirst($v)); ?></option><?php endforeach; ?></select></td></tr>
        </table><?php submit_button('Save Payment Gateway Settings'); ?></form>
        <h2>Bridge diagnostics</h2><p><strong>Version:</strong> <?php echo esc_html(BZJ_PGB_VERSION); ?></p><p><strong>Resolved bridge root:</strong> <code><?php echo esc_html(BZJ_PGB_ROOT); ?></code></p><p><strong>Core manager:</strong> <?php echo is_file(BZJ_PGB_CORE.'class-pgb-manager.php')?'OK':'MISSING'; ?></p><p><strong>Streams DB helper:</strong> <?php echo BZJ_PGB_DB_HELPERS?'OK':'MISSING'; ?></p></div><?php
    }
}
