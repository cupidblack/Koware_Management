<?php
defined('ABSPATH') || exit;

class PGB_Paths {
    private static $root = null;

    public static function root() {
        if (self::$root !== null) return self::$root;
        $candidates = [];
        if (defined('BZJ_PGB_ROOT_CANDIDATE') && BZJ_PGB_ROOT_CANDIDATE) $candidates[] = BZJ_PGB_ROOT_CANDIDATE;
        $candidates[] = trailingslashit(dirname(ABSPATH)) . 'shared/payment-gateway/';
        $candidates[] = trailingslashit(ABSPATH) . 'shared/payment-gateway/';
        if (defined('WP_CONTENT_DIR')) {
            $candidates[] = trailingslashit(dirname(WP_CONTENT_DIR)) . 'shared/payment-gateway/';
            $candidates[] = trailingslashit(WP_CONTENT_DIR) . '../shared/payment-gateway/';
        }
        if (!empty($_SERVER['DOCUMENT_ROOT'])) $candidates[] = trailingslashit(wp_normalize_path($_SERVER['DOCUMENT_ROOT'])) . 'shared/payment-gateway/';
        foreach ($candidates as $candidate) {
            $candidate = trailingslashit(wp_normalize_path($candidate));
            if (is_file($candidate . 'core/class-pgb-manager.php')) {
                self::$root = $candidate;
                return self::$root;
            }
        }
        self::$root = trailingslashit(wp_normalize_path($candidates[0] ?? ''));
        return self::$root;
    }

    public static function exists() { return is_file(self::root() . 'core/class-pgb-manager.php'); }
    public static function core($file) { return self::root() . 'core/' . ltrim($file, '/'); }
    public static function addon($file) { return self::root() . 'addons/' . ltrim($file, '/'); }
    public static function integration($file) { return self::root() . 'int/' . ltrim($file, '/'); }
    public static function log_dir() { return self::root() . 'log/'; }
}
