<?php
defined('ABSPATH') || exit;
class PGB_Logger {
    private static $instance;
    private $weights = ['debug'=>0,'info'=>1,'warning'=>2,'error'=>3,'critical'=>4];
    public static function instance(){ return self::$instance ?: (self::$instance = new self); }
    private function file_for($source) {
        $name = is_string($source) && $source !== '' ? basename($source) : 'pgb-unknown';
        $name = preg_replace('/\.php$/i','',$name);
        return BZJ_PGB_LOG . preg_replace('/[^A-Za-z0-9._-]/', '-', $name) . '.log';
    }
    private function red($v) {
        if (is_array($v)) {
            foreach ($v as $k=>$x) {
                if (preg_match('/pass|secret|token|key|authorization|signature|cookie|email/i',(string)$k)) $v[$k]='[REDACTED]';
                else $v[$k]=$this->red($x);
            }
        } elseif (is_string($v)) {
            $v = preg_replace('/(Bearer\s+)[A-Za-z0-9._\-]+/i','$1[REDACTED]',$v);
        }
        return $v;
    }
    public function log($level,$message,$context=[],$source='') {
        if (!PGB_Config::logging_enabled()) return;
        if (!isset($this->weights[$level])) $level='info';
        if ($this->weights[$level] < ($this->weights[PGB_Config::log_level()] ?? 1)) return;
        $row=['ts'=>gmdate('c'),'level'=>$level,'source'=>basename((string)$source),'message'=>$message,'context'=>$this->red($context)];
        $path=$this->file_for($source ?: 'pgb-unknown.php');
        if (file_exists($path) && filesize($path)>10*1024*1024) @rename($path,$path.'.'.gmdate('YmdHis'));
        @file_put_contents($path, wp_json_encode($row, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).PHP_EOL, FILE_APPEND|LOCK_EX);
        if ($level==='critical') error_log('[BZJ-PGB] '.$message);
    }
    public function debug($m,$c=[],$s=''){ $this->log('debug',$m,$c,$s); }
    public function info($m,$c=[],$s=''){ $this->log('info',$m,$c,$s); }
    public function warning($m,$c=[],$s=''){ $this->log('warning',$m,$c,$s); }
    public function error($m,$c=[],$s=''){ $this->log('error',$m,$c,$s); }
    public function critical($m,$c=[],$s=''){ $this->log('critical',$m,$c,$s); }
}
