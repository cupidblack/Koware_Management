<?php
defined('ABSPATH') || exit;
class PGB_Order {
    public static function signed_token($order_id) {
        return hash_hmac('sha256', $order_id, PGB_Config::require_secret());
    }
    public static function verify_token($order_id,$token) {
        return is_string($token) && hash_equals(self::signed_token($order_id),$token);
    }
    public static function meta($order,$key,$default='') {
        $v=$order->get_meta($key,true); return ($v === '' || $v === null) ? $default : $v;
    }
    public static function set_stream_meta($order,$data) {
        foreach($data as $k=>$v) $order->update_meta_data($k,is_scalar($v)?(string)$v:wp_json_encode($v));
    }
}
