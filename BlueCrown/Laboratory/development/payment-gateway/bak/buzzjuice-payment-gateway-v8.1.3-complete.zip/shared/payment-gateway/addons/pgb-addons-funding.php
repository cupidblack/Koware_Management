<?php
defined('ABSPATH') || exit;
add_action('bzj_pgb_paid', function($order,$row){
    if(strtoupper((string)($row['kind']??''))!=='DONATE')return;
    PGB_Logger::instance()->warning('Funding fulfillment requires migration of the existing Streams funding rules before enabling automatic contribution. No contribution was written by this addon.',['wow_order_id'=>$row['order_id'],'woo_order_id'=>$order->get_id()],__FILE__);
},20,2);
