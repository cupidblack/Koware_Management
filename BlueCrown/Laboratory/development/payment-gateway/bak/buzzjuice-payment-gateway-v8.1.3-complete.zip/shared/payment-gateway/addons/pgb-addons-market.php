<?php
defined('ABSPATH') || exit;
add_action('bzj_pgb_paid', function($order,$row){
    if(!in_array(strtoupper((string)($row['kind']??'')),['PURCHASE','PRODUCT','SALE'],true))return;
    PGB_Logger::instance()->warning('Market fulfillment requires migration of the existing Streams purchase/seller accounting rules before enabling automatic fulfillment. No purchase record was written by this addon.',['wow_order_id'=>$row['order_id'],'woo_order_id'=>$order->get_id()],__FILE__);
},20,2);
