ALTER TABLE Wo_Payment_Transactions ADD COLUMN pgb_state VARCHAR(32) NULL;
ALTER TABLE Wo_Payment_Transactions ADD COLUMN pgb_fulfilled_at DATETIME NULL;
ALTER TABLE Wo_Payment_Transactions ADD COLUMN pgb_last_error TEXT NULL;
