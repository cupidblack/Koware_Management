#!/bin/sh
set -eu
root="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
required="shared/payment-gateway/pgb-client.php shared/payment-gateway/pgb-client-streams.php shared/payment-gateway/core/class-pgb-paths.php shared/payment-gateway/core/class-pgb-logger.php shared/payment-gateway/core/class-pgb-config.php shared/payment-gateway/core/class-pgb-streams-db.php shared/payment-gateway/core/class-pgb-order.php shared/payment-gateway/core/class-pgb-manager.php shared/payment-gateway/addons/pgb-addons-affiliate-wp.php shared/payment-gateway/addons/pgb-addons-subscriptions.php shared/payment-gateway/addons/pgb-addons-wallet.php shared/payment-gateway/addons/pgb-addons-funding.php shared/payment-gateway/addons/pgb-addons-market.php shared/payment-gateway/int/pgb-int-jewel-affiliate.php wp-content/mu-plugins/bzj-pgb-engine.php"
for f in $required; do [ -f "$root/$f" ] || { echo "MISSING: $f"; exit 1; }; done
echo "Package verification: OK"
