# Buzzjuice Payment Gateway Bridge 5.1

## Install order
1. Back up WordPress DB, Streams DB, `shared/`, current PGB files, and WooCommerce webhook settings.
2. Create `shared/payment-gateway/` with the supplied structure.
3. Install only `wp-content/mu-plugins/bzj-payment-gateway.php` directly in `mu-plugins`.
4. Set the same strong `BZJ_PGB_SECRET` in the WordPress and Streams environments.
5. Ensure `shared/db_helpers.php` is readable from the bridge and Streams.
6. Confirm the Buzzjuice admin parent slug is `buzzjuice`. If the existing parent uses another slug, change only the first argument to `add_submenu_page()` in `admin/pgb-admin.php`.
7. Keep the legacy sync and webhook disabled until the v5.1 tests pass.
8. Add the `wow-pgb-init` routing to `streams/requests.php` and change the existing `wow_payment` path to call `pgb_streams_init_payment()`.
9. Remove direct WooCommerce consumer key/secret use from Streams after the new path is verified.
10. Fulfillment is driven by WooCommerce payment/order hooks, not browser return pages.

## Important
- Do not run both legacy and v5.1 fulfillment handlers at the same time.
- The transaction ledger is created automatically on WordPress `plugins_loaded`.
- Logs are per source file under `shared/payment-gateway/log/`.
- No payment secret belongs in Streams HTML, JavaScript, database settings, WooCommerce metadata, or logs.
