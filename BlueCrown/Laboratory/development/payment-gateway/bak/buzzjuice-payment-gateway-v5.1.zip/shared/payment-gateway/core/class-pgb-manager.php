<?php
if (!defined('ABSPATH')) exit;

class PGB_Manager {
    private $logger,$idempotency,$order,$fulfillment;
    public function __construct(PGB_Logger $logger){
        $this->logger=$logger; $this->idempotency=new PGB_Idempotency($logger);
        $this->order=new PGB_Order($logger); $this->fulfillment=new PGB_Fulfillment($logger,$this->idempotency);
    }
    public function create_payment(array $data){
        $existing=$this->idempotency->find($data['request_id']);
        if($existing){
            $woo=(int)$existing->woo_order_id;
            $url=$woo?wc_get_checkout_url().'order-pay/'.$woo.'/?key='.rawurlencode((string)wc_get_order($woo)->get_order_key()):'';
            return ['success'=>true,'duplicate'=>true,'transaction_id'=>(int)$existing->id,'order_id'=>$woo,'payment_url'=>$url];
        }
        $tx_id=$this->idempotency->lock_request($data['request_id'],$data);
        try{
            $order=$this->order->create($data);
            $url=$order->get_checkout_payment_url();
            $this->idempotency->update($tx_id,['woo_order_id'=>$order->get_id(),'status'=>'order_created']);
            do_action('pgb_order_created',$order,$tx_id);
            return ['success'=>true,'duplicate'=>false,'transaction_id'=>$tx_id,'order_id'=>$order->get_id(),'payment_url'=>$url];
        }catch(Throwable $e){
            $this->idempotency->update($tx_id,['status'=>'order_creation_failed','last_error'=>substr($e->getMessage(),0,2000)]);
            $this->logger->exception($e,__FILE__,['request_id'=>$data['request_id']]);
            return ['success'=>false,'error'=>$e->getMessage(),'transaction_id'=>$tx_id];
        }
    }
    public function handle_paid($order_id){
        $order=wc_get_order($order_id); if(!$order)return false;
        global $wpdb; $rid=(string)$order->get_meta('_bzj_pgb_request_id');
        if(!$rid)return false;
        $tx=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PGB_Schema::table()." WHERE request_id=%s LIMIT 1",$rid));
        if(!$tx)return false;
        if($tx->status==='paid' || $tx->status==='fulfilling' || $tx->status==='fulfilled') return true;
        $this->idempotency->update($tx->id,['status'=>'paid','paid_at'=>current_time('mysql',true)]);
        do_action('pgb_payment_confirmed',$order,$tx);
        try{$this->fulfillment->complete($order_id);}catch(Throwable $e){$this->fulfillment->fail($order_id,$e->getMessage());}
        return true;
    }
    public function handle_failed($order_id,$status='failed'){
        global $wpdb; $order=wc_get_order($order_id); if(!$order)return;
        $rid=(string)$order->get_meta('_bzj_pgb_request_id'); if(!$rid)return;
        $tx=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PGB_Schema::table()." WHERE request_id=%s LIMIT 1",$rid));
        if($tx)$this->idempotency->update($tx->id,['status'=>$status,'last_error'=>'WooCommerce order status: '.$status]);
    }
}
