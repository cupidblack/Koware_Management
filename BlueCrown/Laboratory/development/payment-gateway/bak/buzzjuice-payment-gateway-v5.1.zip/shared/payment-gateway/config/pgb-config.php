<?php
return [
    'logging_enabled' => true,
    'log_level' => 'info',
    'streams_base_url' => defined('BZJ_PGB_STREAMS_URL') ? BZJ_PGB_STREAMS_URL : '',
    'social_base_url' => defined('BZJ_PGB_SOCIAL_URL') ? BZJ_PGB_SOCIAL_URL : '',
];
