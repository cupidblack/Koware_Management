<?php
if (!defined('ABSPATH')) exit;
add_action('admin_menu',function(){
    add_submenu_page('buzzjuice','Payment Gateways','Payment Gateways','manage_options','buzzjuice-payment-gateways','pgb_admin_page');
},99);
add_action('admin_init',function(){
    register_setting('bzj_pgb','bzj_pgb_logging_enabled',['type'=>'boolean','sanitize_callback'=>'rest_sanitize_boolean','default'=>true]);
    register_setting('bzj_pgb','bzj_pgb_log_level',['type'=>'string','sanitize_callback'=>function($v){return in_array($v,['debug','info','warning','error','critical'],true)?$v:'info';},'default'=>'info']);
});
function pgb_admin_page(){
    if(!current_user_can('manage_options'))return;
    if(isset($_POST['bzj_pgb_test'])&&check_admin_referer('bzj_pgb_test')){
        PGB_Bootstrap::instance()->logger()->log('Manual diagnostic test',PGB_Logger::INFO,['admin_user'=>get_current_user_id()],__FILE__);
        echo '<div class="notice notice-success"><p>PGB diagnostic log written.</p></div>';
    }
    global $wpdb; $table=PGB_Schema::table(); $counts=$wpdb->get_results("SELECT status,COUNT(*) c FROM {$table} GROUP BY status");
    ?>
    <div class="wrap"><h1>Buzzjuice Payment Gateways</h1>
    <form method="post" action="options.php"><?php settings_fields('bzj_pgb'); ?>
    <table class="form-table"><tr><th>Bridge logging</th><td><input type="checkbox" name="bzj_pgb_logging_enabled" value="1" <?php checked(get_option('bzj_pgb_logging_enabled',true)); ?>></td></tr>
    <tr><th>Minimum log level</th><td><select name="bzj_pgb_log_level"><?php foreach(['debug','info','warning','error','critical'] as $v)echo '<option value="'.esc_attr($v).'" '.selected(get_option('bzj_pgb_log_level','info'),$v,false).'>'.esc_html($v).'</option>'; ?></select></td></tr></table>
    <?php submit_button('Save Payment Gateway Settings'); ?></form>
    <form method="post"><?php wp_nonce_field('bzj_pgb_test'); ?><input type="hidden" name="bzj_pgb_test" value="1"><?php submit_button('Write Diagnostic Log','secondary'); ?></form>
    <h2>Transaction Ledger</h2><table class="widefat"><thead><tr><th>Status</th><th>Count</th></tr></thead><tbody><?php foreach((array)$counts as $r)echo '<tr><td>'.esc_html($r->status).'</td><td>'.intval($r->c).'</td></tr>'; ?></tbody></table>
    <p><code><?php echo esc_html(BZJ_PGB_LOG_DIR); ?></code></p></div><?php
}
