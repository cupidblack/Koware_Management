<?php
if (!defined('ABSPATH')) exit;
function pgb_streams_url($path=''){
    $url=get_option('wowonder_url','');
    return rtrim($url,'/').'/'.ltrim($path,'/');
}
function pgb_streams_redirect_for_order($order,$tx){
    $base=rtrim(get_option('wowonder_url',''),'/' );
    $kind=strtoupper((string)$tx->transaction_kind);
    $post=(int)$order->get_meta('wow_post_id');
    if(in_array($kind,['PURCHASE','PRODUCT','MARKET','SALE'],true))return $base.'/purchased';
    if(in_array($kind,['PRO','SUBSCRIPTION'],true))return $base.'/upgraded';
    if($kind==='WALLET')return $base.'/wallet/?nocache='.time();
    if(in_array($kind,['DONATE','FUND'],true)&&$post)return $base.'/show_fund/'.rawurlencode($post);
    return $base.'/';
}
add_filter('pgb_return_url',function($url,$order,$tx){return pgb_streams_redirect_for_order($order,$tx);},10,3);
