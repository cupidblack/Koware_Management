<?php
if (!defined('ABSPATH')) exit;

function pgb_subscription_process($order,$tx){
    if(!function_exists('wcs_create_subscription') || !class_exists('WC_Subscriptions_Product'))return;
    if($order->get_meta('_bzj_pgb_subscription_id'))return;
    foreach($order->get_items('line_item') as $item){
        $product=$item->get_product(); if(!$product)continue;
        $pid=$product->get_id();
        if(!WC_Subscriptions_Product::is_subscription($pid))continue;
        $period=WC_Subscriptions_Product::get_period($pid);
        $interval=WC_Subscriptions_Product::get_interval($pid);
        $sub=wcs_create_subscription(['order_id'=>$order->get_id(),'customer_id'=>$order->get_user_id(),'billing_period'=>$period,'billing_interval'=>$interval,'currency'=>$order->get_currency(),'created_via'=>'buzzjuice_pgb','status'=>'pending']);
        if(is_wp_error($sub)){PGB_Bootstrap::instance()->logger()->log($sub->get_error_message(),PGB_Logger::ERROR,[],__FILE__);return;}
        $sub->add_product($product,max(1,$item->get_quantity()),['subtotal'=>$item->get_subtotal(),'total'=>$item->get_total()]);
        if(function_exists('wcs_copy_order_address'))wcs_copy_order_address($order,$sub);
        $sub->calculate_totals();
        $sub->set_payment_method($order->get_payment_method(),$order->get_payment_method_title());
        $sub->update_dates(['next_payment'=>gmdate('Y-m-d H:i:s',strtotime('+'.$interval.' '.$period))]);
        $sub->save();
        $order->update_meta_data('_bzj_pgb_subscription_id',$sub->get_id());$order->save();
        if($order->is_paid())$sub->update_status('active');
        PGB_Bootstrap::instance()->logger()->log('Subscription synchronized','info',['order_id'=>$order->get_id(),'subscription_id'=>$sub->get_id()],__FILE__);
        break;
    }
}
add_action('pgb_payment_confirmed','pgb_subscription_process',20,2);
