<?php
if (!defined('ABSPATH')) exit;

class PGB_Bootstrap {
    private static $instance; private $logger; private $manager; private $config=[];
    public static function instance(){return self::$instance ?: (self::$instance=new self);}
    private function __construct(){}
    public function boot(){
        if($this->logger)return;
        $this->load_config();
        require_once BZJ_PGB_DIR.'/core/class-pgb-logger.php';
        require_once BZJ_PGB_DIR.'/core/class-pgb-schema.php';
        require_once BZJ_PGB_DIR.'/core/class-pgb-idempotency.php';
        require_once BZJ_PGB_DIR.'/core/class-pgb-order.php';
        require_once BZJ_PGB_DIR.'/core/class-pgb-fulfillment.php';
        require_once BZJ_PGB_DIR.'/core/class-pgb-manager.php';
        $this->logger=new PGB_Logger($this->config);
        PGB_Schema::install($this->logger);
        $this->manager=new PGB_Manager($this->logger);
        $this->load_dir('addons','pgb-addon-');
        $this->load_dir('integrations','pgb-int-');
        $admin=BZJ_PGB_DIR.'/admin/pgb-admin.php'; if(is_readable($admin))require_once $admin;
        $this->register_hooks();
        $this->logger->log('PGB bootstrap ready',PGB_Logger::INFO,['version'=>BZJ_PGB_VERSION],__FILE__);
    }
    private function load_config(){
        $f=BZJ_PGB_DIR.'/config/pgb-config.php';
        $this->config=is_readable($f)?(require $f):[];
        if(!is_array($this->config))$this->config=[];
    }
    private function load_dir($dir,$prefix){
        $path=trailingslashit(BZJ_PGB_DIR).$dir.'/';
        foreach((array)glob($path.$prefix.'*.php') as $file){try{require_once $file;}catch(Throwable $e){if($this->logger)$this->logger->exception($e,$file);}}
    }
    private function register_hooks(){
        add_action('woocommerce_payment_complete',[$this->manager,'handle_paid'],20);
        add_action('woocommerce_order_status_completed',[$this->manager,'handle_paid'],20);
        add_action('woocommerce_order_status_processing',[$this->manager,'handle_paid'],20);
        add_action('woocommerce_order_status_failed',function($id){$this->manager->handle_failed($id,'failed');},20);
        add_action('woocommerce_order_status_cancelled',function($id){$this->manager->handle_failed($id,'cancelled');},20);
        add_action('woocommerce_order_status_refunded',function($id){$this->manager->handle_failed($id,'refunded');},20);
        add_action('rest_api_init',function(){
            register_rest_route('bzj-pgb/v1','/order',[
                'methods'=>'POST','callback'=>[$this,'rest_order'],'permission_callback'=>'__return_true'
            ]);
        });
    }
    public function rest_order(WP_REST_Request $request){
        $body=$request->get_body();
        $ts=$request->get_header('X-BZJ-PGB-Timestamp');
        $rid=$request->get_header('X-BZJ-PGB-Request-ID');
        $sig=$request->get_header('X-BZJ-PGB-Signature');
        if(!$this->verify($ts,$rid,$body,$sig))return new WP_Error('invalid_signature','Invalid payment bridge signature',['status'=>401]);
        $data=json_decode($body,true);
        if(!is_array($data))return new WP_Error('invalid_json','Invalid JSON',['status'=>400]);
        $required=['request_id','wow_order_id','wow_user_id','wp_user_id','transaction_kind','amount','currency','product_id','unit_price','quantity'];
        foreach($required as $key)if(!isset($data[$key])||$data[$key]==='')return new WP_Error('missing_'.$key,'Missing '.$key,['status'=>400]);
        if((string)$data['request_id']!==(string)$rid)return new WP_Error('request_mismatch','Request ID mismatch',['status'=>400]);
        $result=$this->manager->create_payment($data);
        if(!$result['success'])return new WP_Error('order_failed',$result['error'],['status'=>500]);
        return new WP_REST_Response($result,200);
    }
    private function verify($ts,$rid,$body,$sig){
        $secret=$this->secret();
        if(!$secret||!$ts||!$rid||!$sig)return false;
        if(abs(time()-(int)$ts)>300)return false;
        $expected=base64_encode(hash_hmac('sha256',$ts."\n".$rid."\n".$body,$secret,true));
        return hash_equals($expected,(string)$sig);
    }
    public function secret(){
        $v=getenv('BZJ_PGB_SECRET'); if($v)return $v;
        if(defined('BZJ_PGB_SECRET')&&BZJ_PGB_SECRET)return BZJ_PGB_SECRET;
        return '';
    }
    public function logger(){return $this->logger;}
    public function manager(){return $this->manager;}
    public function config($k,$d=null){return array_key_exists($k,$this->config)?$this->config[$k]:$d;}
}
