<?php
if (!defined('ABSPATH')) exit;

class PGB_Schema {
    public static function table(){ global $wpdb; return $wpdb->prefix.'bzj_pgb_transactions'; }
    public static function install(PGB_Logger $logger) {
        global $wpdb;
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $table=self::table(); $charset=$wpdb->get_charset_collate();
        $sql="CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            request_id varchar(80) NOT NULL,
            wow_order_id varchar(191) NOT NULL,
            wow_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            wp_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            woo_order_id bigint(20) unsigned NOT NULL DEFAULT 0,
            transaction_kind varchar(40) NOT NULL,
            status varchar(32) NOT NULL DEFAULT 'initiated',
            fulfillment_status varchar(32) NOT NULL DEFAULT 'pending',
            amount decimal(20,6) NOT NULL DEFAULT 0,
            currency varchar(12) NOT NULL DEFAULT '',
            return_url text NULL,
            payload longtext NULL,
            last_error text NULL,
            attempts int unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            paid_at datetime NULL,
            fulfilled_at datetime NULL,
            PRIMARY KEY(id),
            UNIQUE KEY request_id(request_id),
            UNIQUE KEY wow_order_id(wow_order_id),
            KEY woo_order_id(woo_order_id),
            KEY status(status),
            KEY wp_user_id(wp_user_id)
        ) {$charset};";
        $result=dbDelta($sql);
        update_option('bzj_pgb_schema_version',BZJ_PGB_VERSION,false);
        $logger->log('Transaction ledger ensured',PGB_Logger::INFO,['table'=>$table,'dbdelta'=>$result],__FILE__);
    }
}
