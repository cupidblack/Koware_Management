<?php
if (!defined('ABSPATH')) exit;

function pgb_affwp_log($message,$level='info',$context=[]){
    $logger=PGB_Bootstrap::instance()->logger(); if($logger)$logger->log($message,$level,$context,__FILE__);
}
function pgb_affwp_process($order,$tx){
    if(!function_exists('affwp_add_referral') && !class_exists('Affiliate_WP')){pgb_affwp_log('AffiliateWP unavailable','warning');return;}
    global $wpdb;
    $affiliate_id=0; $customer_id=0;
    if(function_exists('affwp_get_affiliate_id')){
        $affiliate_id=(int)affwp_get_affiliate_id($order->get_user_id());
    }
    if(!$affiliate_id){
        $customer_id=(int)$wpdb->get_var($wpdb->prepare("SELECT customer_id FROM {$wpdb->prefix}affiliate_wp_customers WHERE user_id=%d LIMIT 1",$order->get_user_id()));
        if($customer_id)$affiliate_id=(int)$wpdb->get_var($wpdb->prepare("SELECT affiliate_id FROM {$wpdb->prefix}affiliate_wp_lifetime_customers WHERE affwp_customer_id=%d ORDER BY lifetime_customer_id DESC LIMIT 1",$customer_id));
    }
    if(!$affiliate_id && $customer_id)$affiliate_id=(int)$wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->prefix}affiliate_wp_customermeta WHERE affwp_customer_id=%d AND meta_key IN ('affiliate_id','referring_affiliate_id') ORDER BY meta_id DESC LIMIT 1",$customer_id));
    if(!$affiliate_id){pgb_affwp_log('No affiliate resolved','warning');return;}
    $reference=(string)$order->get_id();
    $exists=(int)$wpdb->get_var($wpdb->prepare("SELECT referral_id FROM {$wpdb->prefix}affiliate_wp_referrals WHERE reference=%s AND affiliate_id=%d AND context=%s LIMIT 1",$reference,$affiliate_id,'woocommerce'));
    if($exists){$order->update_meta_data('_bzj_affwp_referral_id',$exists);$order->save();return;}
    $affiliate=function_exists('affwp_get_affiliate')?affwp_get_affiliate($affiliate_id):false;
    if(!$affiliate)return;
    $rate=(float)$affiliate->rate; $type=(string)$affiliate->rate_type;
    $base=(float)$order->get_total(); $commission=$type==='percentage'?round($base*($rate/100),4):round($rate,4);
    if($commission<=0)return;
    $data=['affiliate_id'=>$affiliate_id,'customer_id'=>$customer_id,'amount'=>$commission,'description'=>'Buzzjuice order #'.$order->get_id(),'reference'=>$reference,'context'=>'woocommerce','status'=>'unpaid','currency'=>$order->get_currency(),'products'=>maybe_serialize([]),'date'=>current_time('mysql')];
    $referral_id=function_exists('affwp_add_referral')?affwp_add_referral($data):0;
    if(!$referral_id){pgb_affwp_log('Referral creation failed','error',['order_id'=>$order->get_id(),'affiliate_id'=>$affiliate_id]);return;}
    $order->update_meta_data('_bzj_affwp_referral_id',(int)$referral_id);$order->update_meta_data('_bzj_affwp_processed_at',gmdate('c'));$order->save();
    pgb_affwp_log('Affiliate referral created','info',['order_id'=>$order->get_id(),'affiliate_id'=>$affiliate_id,'referral_id'=>$referral_id]);
}
add_action('pgb_payment_confirmed','pgb_affwp_process',30,2);
