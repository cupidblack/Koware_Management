<?php
if (!defined('ABSPATH')) exit;

class PGB_Order {
    private $logger;
    public function __construct(PGB_Logger $logger){$this->logger=$logger;}
    public function create(array $data){
        if(!function_exists('wc_create_order')) throw new RuntimeException('WooCommerce order API unavailable.');
        $product_id=(int)($data['product_id']??0);
        $variation_id=(int)($data['variation_id']??0);
        $qty=max(1,(int)($data['quantity']??1));
        $product=$variation_id ? wc_get_product($variation_id) : wc_get_product($product_id);
        if(!$product) throw new RuntimeException('WooCommerce product/variation not found.');
        $order=wc_create_order(['customer_id'=>(int)$data['wp_user_id'],'created_via'=>'buzzjuice_pgb']);
        if(is_wp_error($order)) throw new RuntimeException($order->get_error_message());
        $order->set_currency($data['currency']);
        $order->set_customer_id((int)$data['wp_user_id']);
        $this->set_address($order,$data);
        $item_id=$order->add_product($product,$qty,[
            'subtotal'=>(float)$data['unit_price']*$qty,
            'total'=>(float)$data['amount'],
        ]);
        if(!$item_id) throw new RuntimeException('Could not add product to WooCommerce order.');
        $meta=[
            'wow_order_id'=>$data['wow_order_id'],'wow_user_id'=>(int)$data['wow_user_id'],
            'userid'=>(int)$data['wow_user_id'],'wp_user_id'=>(int)$data['wp_user_id'],
            'transaction_kind'=>$data['transaction_kind'],'wow_post_id'=>(int)($data['wow_post_id']??0),
            'qdw_order_id'=>(string)($data['qdw_order_id']??''),'qdw_transaction_kind'=>(string)($data['qdw_transaction_kind']??''),
            '_bzj_pgb_request_id'=>$data['request_id'],
        ];
        foreach($meta as $k=>$v)$order->update_meta_data($k,$v);
        if(!empty($data['subscription_period']))$order->update_meta_data('_subscription_period',$data['subscription_period']);
        if(!empty($data['subscription_interval']))$order->update_meta_data('_subscription_interval',(int)$data['subscription_interval']);
        if(isset($data['subscription_length']))$order->update_meta_data('_subscription_length',(int)$data['subscription_length']);
        $order->calculate_totals();
        $order->save();
        $this->logger->log('WooCommerce order created',PGB_Logger::INFO,['woo_order_id'=>$order->get_id(),'wow_order_id'=>$data['wow_order_id']],__FILE__);
        return $order;
    }
    private function set_address($order,array $data){
        $a=$data['billing']??[];
        if(!$a)return;
        $address=[];
        foreach(['first_name','last_name','company','address_1','address_2','city','state','postcode','country','email','phone'] as $k){
            if(isset($a[$k]))$address[$k]=wc_clean((string)$a[$k]);
        }
        if($address)$order->set_address($address,'billing');
        if(!empty($data['shipping']))$order->set_address(array_map('wc_clean',$data['shipping']),'shipping');
    }
}
