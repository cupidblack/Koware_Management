<?php
if (!defined('ABSPATH')) exit;
/* Currency conversion remains a WooCommerce-side concern. The order currency and paid amount are authoritative. */
add_filter('pgb_before_order_create',function($data){return $data;},10,1);
