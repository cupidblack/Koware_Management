<?php
if (!defined('ABSPATH')) exit;

class PGB_Logger {
    const DEBUG='debug', INFO='info', WARNING='warning', ERROR='error', CRITICAL='critical';
    private $dir;
    private $enabled;
    private $min;
    private $priority=[self::DEBUG=>0,self::INFO=>1,self::WARNING=>2,self::ERROR=>3,self::CRITICAL=>4];

    public function __construct(array $config=[]) {
        $this->dir = trailingslashit(BZJ_PGB_LOG_DIR);
        $this->enabled = array_key_exists('logging_enabled',$config) ? (bool)$config['logging_enabled'] : true;
        $this->min = isset($config['log_level']) && isset($this->priority[$config['log_level']]) ? $config['log_level'] : self::INFO;
        if (!is_dir($this->dir)) @wp_mkdir_p($this->dir);
    }
    public function enabled(){ return $this->enabled; }
    public function log($message,$level=self::INFO,array $context=[],$source=null) {
        if (!$this->enabled || !isset($this->priority[$level]) || $this->priority[$level] < $this->priority[$this->min]) return;
        $source=$this->source($source ?: __FILE__);
        $context=$this->redact($context);
        $line=wp_json_encode(['time'=>gmdate('c'),'level'=>$level,'source'=>$source,'message'=>(string)$message,'context'=>$context],JSON_UNESCAPED_SLASHES).PHP_EOL;
        $file=$this->dir.$source.'.log';
        if (file_exists($file) && filesize($file)>10*1024*1024) @rename($file,$file.'.'.gmdate('YmdHis'));
        @file_put_contents($file,$line,FILE_APPEND|LOCK_EX);
        if ($level===self::ERROR || $level===self::CRITICAL) error_log('[BZJ-PGB]['.$level.']['.$source.'] '.(string)$message);
    }
    public function exception(Throwable $e,$source=null,array $context=[]) {
        $context['exception']=get_class($e);
        $context['file']=$e->getFile();
        $context['line']=$e->getLine();
        $this->log($e->getMessage(),self::ERROR,$context,$source);
    }
    private function source($file) {
        $name=basename($file);
        return preg_replace('/[^A-Za-z0-9._-]/','-',preg_replace('/\.php$/i','',$name)) ?: 'unknown';
    }
    private function redact($data) {
        if (!is_array($data)) return $data;
        $keys=['secret','password','token','signature','api_key','api_secret','consumer_key','consumer_secret','authorization','cookie','credit_card','cvv'];
        foreach($data as $k=>&$v){
            $lk=strtolower((string)$k);
            foreach($keys as $needle){
                if(strpos($lk,$needle)!==false){$v='[REDACTED]';continue 2;}
            }
            if(is_array($v)) $v=$this->redact($v);
        }
        return $data;
    }
}
