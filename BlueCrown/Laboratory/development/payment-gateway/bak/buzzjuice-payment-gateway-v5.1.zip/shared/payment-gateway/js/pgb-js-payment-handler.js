(function($){
"use strict";
window.BZJ_PGB={
    start:function(payload){
        return $.ajax({
            url:window.Wo_Ajax_Requests_File()+"?f=payment",
            method:"POST",data:$.extend({},payload,{payment_type:"wow_payment"})
        }).then(function(data){
            if(data&&data.status===200&&data.url){window.location.href=data.url;return data;}
            throw new Error((data&&data.message)||"Unable to initialize payment.");
        });
    }
};
})(jQuery);
