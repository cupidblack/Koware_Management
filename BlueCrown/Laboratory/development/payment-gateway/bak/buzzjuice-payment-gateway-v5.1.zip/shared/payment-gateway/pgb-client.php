<?php
if (!defined('ABSPATH')) exit;
/**
 * WordPress-side client API for other Buzzjuice components.
 */
function bzj_pgb_get_manager(){return PGB_Bootstrap::instance()->manager();}
function bzj_pgb_process_order($order_id){return bzj_pgb_get_manager()->handle_paid((int)$order_id);}
