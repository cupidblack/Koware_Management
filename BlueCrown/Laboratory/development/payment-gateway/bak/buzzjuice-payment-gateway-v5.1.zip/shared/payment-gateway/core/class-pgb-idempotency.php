<?php
if (!defined('ABSPATH')) exit;

class PGB_Idempotency {
    private $logger;
    public function __construct(PGB_Logger $logger){$this->logger=$logger;}
    public function find($request_id){
        global $wpdb; if(!$request_id)return null;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM ".PGB_Schema::table()." WHERE request_id=%s LIMIT 1",$request_id));
    }
    public function lock_request($request_id,array $data){
        global $wpdb;
        $now=current_time('mysql',true);
        $ok=$wpdb->insert(PGB_Schema::table(),[
            'request_id'=>$request_id,'wow_order_id'=>$data['wow_order_id'],'wow_user_id'=>(int)$data['wow_user_id'],
            'wp_user_id'=>(int)$data['wp_user_id'],'transaction_kind'=>$data['transaction_kind'],
            'status'=>'initiated','fulfillment_status'=>'pending','amount'=>(float)$data['amount'],
            'currency'=>$data['currency'],'return_url'=>$data['return_url']??'',
            'payload'=>wp_json_encode($data),'created_at'=>$now,'updated_at'=>$now
        ],['%s','%s','%d','%d','%s','%s','%s','%f','%s','%s','%s','%s']);
        if($ok)return $wpdb->insert_id;
        $existing=$this->find($request_id);
        if($existing)return (int)$existing->id;
        throw new RuntimeException('Could not create PGB transaction ledger row: '.$wpdb->last_error);
    }
    public function update($id,array $fields){
        global $wpdb;
        $fields['updated_at']=current_time('mysql',true);
        $formats=[];
        foreach($fields as $k=>$v){$formats[] = in_array($k,['attempts','woo_order_id','wow_user_id','wp_user_id'],true)?'%d':'%s';}
        return $wpdb->update(PGB_Schema::table(),$fields,['id'=>(int)$id],$formats,['%d']);
    }
}
