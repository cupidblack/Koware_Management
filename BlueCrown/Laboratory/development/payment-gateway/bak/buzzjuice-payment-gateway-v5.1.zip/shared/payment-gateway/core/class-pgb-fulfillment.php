<?php
if (!defined('ABSPATH')) exit;

class PGB_Fulfillment {
    private $logger; private $idempotency;
    public function __construct(PGB_Logger $logger,PGB_Idempotency $idempotency){$this->logger=$logger;$this->idempotency=$idempotency;}
    public function complete($woo_order_id){
        $order=wc_get_order($woo_order_id); if(!$order) throw new RuntimeException('Order not found.');
        $request_id=(string)$order->get_meta('_bzj_pgb_request_id');
        global $wpdb;
        $tx=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PGB_Schema::table()." WHERE request_id=%s LIMIT 1",$request_id));
        if(!$tx){$this->logger->log('Ledger row missing',PGB_Logger::ERROR,['woo_order_id'=>$woo_order_id],__FILE__);throw new RuntimeException('PGB ledger row missing.');}
        if($tx->fulfillment_status==='fulfilled')return true;
        $this->idempotency->update($tx->id,['status'=>'fulfilling','attempts'=>(int)$tx->attempts+1]);
        do_action('pgb_fulfill_order',$order,$tx);
        $this->idempotency->update($tx->id,['status'=>'fulfilled','fulfillment_status'=>'fulfilled','fulfilled_at'=>current_time('mysql',true),'last_error'=>'']);
        $order->update_meta_data('_bzj_pgb_fulfilled_at',gmdate('c')); $order->save();
        $this->logger->log('Order fulfilled',PGB_Logger::INFO,['woo_order_id'=>$woo_order_id,'transaction_kind'=>$tx->transaction_kind],__FILE__);
        return true;
    }
    public function fail($woo_order_id,$error){
        $order=wc_get_order($woo_order_id); if(!$order)return;
        global $wpdb; $rid=(string)$order->get_meta('_bzj_pgb_request_id');
        $tx=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".PGB_Schema::table()." WHERE request_id=%s LIMIT 1",$rid));
        if($tx)$this->idempotency->update($tx->id,['status'=>'fulfillment_failed','fulfillment_status'=>'failed','last_error'=>substr((string)$error,0,2000),'attempts'=>(int)$tx->attempts+1]);
        $this->logger->log('Fulfillment failed',PGB_Logger::ERROR,['woo_order_id'=>$woo_order_id,'error'=>$error],__FILE__);
    }
}
