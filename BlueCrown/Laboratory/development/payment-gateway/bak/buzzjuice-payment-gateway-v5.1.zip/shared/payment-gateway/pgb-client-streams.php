<?php
/**
 * WoWonder-side client. This file deliberately contains no WordPress code.
 */
require_once dirname(__DIR__,2).'/db_helpers.php';

function pgb_streams_log($message,$level='info',$context=[]){
    $enabled=true;
    if(defined('BZJ_PGB_STREAMS_LOGGING'))$enabled=(bool)BZJ_PGB_STREAMS_LOGGING;
    if(!$enabled)return;
    $dir=__DIR__.'/log'; if(!is_dir($dir))@mkdir($dir,0755,true);
    $row=['time'=>gmdate('c'),'level'=>$level,'source'=>'pgb-client-streams','message'=>$message,'context'=>$context];
    @file_put_contents($dir.'/pgb-client-streams.log',json_encode($row,JSON_UNESCAPED_SLASHES).PHP_EOL,FILE_APPEND|LOCK_EX);
}
function pgb_streams_secret(){
    $v=getenv('BZJ_PGB_SECRET'); return $v?:'';
}
function pgb_streams_request(array $data){
    $endpoint=rtrim((string)($GLOBALS['wo']['config']['wow_store_url']??''),'/').'/wp-json/bzj-pgb/v1/order';
    if(!$endpoint || !filter_var($endpoint,FILTER_VALIDATE_URL))throw new RuntimeException('Payment gateway WordPress URL is not configured.');
    $rid=(string)$data['request_id']; $ts=(string)time(); $body=json_encode($data,JSON_UNESCAPED_SLASHES);
    $secret=pgb_streams_secret(); if(!$secret)throw new RuntimeException('BZJ_PGB_SECRET is not configured.');
    $sig=base64_encode(hash_hmac('sha256',$ts."\n".$rid."\n".$body,$secret,true));
    $ch=curl_init($endpoint);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_HTTPHEADER=>['Content-Type: application/json','X-BZJ-PGB-Timestamp: '.$ts,'X-BZJ-PGB-Request-ID: '.$rid,'X-BZJ-PGB-Signature: '.$sig],CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>30,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
    $raw=curl_exec($ch); $http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $err=curl_error($ch); curl_close($ch);
    if($err)throw new RuntimeException('PGB connection error: '.$err);
    $json=json_decode((string)$raw,true);
    if($http<200||$http>=300||!is_array($json)||empty($json['success']))throw new RuntimeException('PGB request failed (HTTP '.$http.').');
    return $json;
}
function pgb_streams_init_payment(){
    global $wo;
    if(empty($wo['loggedin'])){http_response_code(401);echo json_encode(['status'=>'error','message'=>'Please login.']);exit;}
    $u=$wo['user']??[];
    $wow_user_id=(int)($u['user_id']??0); $email=filter_var($u['email']??'',FILTER_VALIDATE_EMAIL);
    if(!$wow_user_id||!$email){http_response_code(400);echo json_encode(['status'=>'error','message'=>'Invalid user.']);exit;}
    $kind=strtoupper(preg_replace('/[^A-Z0-9_-]/','',(string)($_POST['transaction_kind']??'')));
    $allowed=['PRODUCT','PURCHASE','PRO','WALLET','DONATE','FUND','SALE'];
    if(!in_array($kind,$allowed,true)){http_response_code(400);echo json_encode(['status'=>'error','message'=>'Invalid transaction kind.']);exit;}
    $wp_user_id=(int)($u['wp_user_id']??0);
    if(!$wp_user_id && function_exists('get_wp_db_conn')){
        $db=get_wp_db_conn();
        if($db){$stmt=$db->prepare("SELECT user_id FROM wp_usermeta WHERE meta_key='wo_user_id' AND meta_value=? LIMIT 1");$stmt->bind_param('s',$wow_user_id);$stmt->execute();$r=$stmt->get_result()->fetch_assoc();$wp_user_id=(int)($r['user_id']??0);$stmt->close();}
    }
    if(!$wp_user_id){http_response_code(400);echo json_encode(['status'=>'error','message'=>'WordPress user mapping not found.']);exit;}
    $request_id='pgb_'.bin2hex(random_bytes(16)); $wow_order_id='wow_'.bin2hex(random_bytes(12));
    $data=[
        'request_id'=>$request_id,'wow_order_id'=>$wow_order_id,'wow_user_id'=>$wow_user_id,'wp_user_id'=>$wp_user_id,
        'transaction_kind'=>$kind,'amount'=>(float)($_POST['amount']??0),'unit_price'=>(float)($_POST['product_price']??0),
        'quantity'=>max(1,(int)($_POST['product_units']??1)),'currency'=>strtoupper(preg_replace('/[^A-Z]/','',(string)($_POST['wow_currency_code']??''))),
        'product_id'=>(int)($_POST['product_id']??0),'variation_id'=>(int)($_POST['variation_id']??0),
        'wow_post_id'=>(int)($_POST['wow_post_id']??0),'qdw_order_id'=>(string)($_POST['qdw_order_id']??''),
        'qdw_transaction_kind'=>(string)($_POST['qdw_transaction_kind']??''),'subscription_period'=>(string)($_POST['subscription_period']??''),
        'subscription_interval'=>(int)($_POST['subscription_interval']??0),'subscription_length'=>(int)($_POST['subscription_length']??0),
        'billing'=>['first_name'=>$u['first_name']??$u['username']??'','last_name'=>$u['last_name']??'','email'=>$email,'phone'=>$u['phone_number']??'','country'=>$u['country_id']??'GH'],
        'return_url'=>(string)($_POST['return_url']??''),
    ];
    try{$result=pgb_streams_request($data);echo json_encode(['status'=>200,'url'=>$result['payment_url'],'order_id'=>$result['order_id']]);}
    catch(Throwable $e){pgb_streams_log($e->getMessage(),'error',['request_id'=>$request_id]);http_response_code(500);echo json_encode(['status'=>'error','message'=>'Unable to initialize payment.']);}
    exit;
}
