<?php
if (!defined('ABSPATH')) exit;
/* Jewel Affiliate is fulfilled only after WooCommerce confirms payment. */
function pgb_jewel_affiliate_fulfill($order,$tx){
    $kind=strtoupper((string)$tx->transaction_kind);
    if(!in_array($kind,['PRO','PURCHASE','PRODUCT'],true))return;
    $wow_user_id=(int)$tx->wow_user_id; if(!$wow_user_id)return;
    $db_file=ABSPATH.'shared/db_helpers.php'; if(is_readable($db_file))require_once $db_file;
    if(!function_exists('get_wowonder_db'))return;
    $db=get_wowonder_db(); if(!$db)return;
    /*
     * Existing Jewel-specific code should be attached to this action.
     * The bridge itself does not issue a second rebate, preventing duplicate credit.
     */
    do_action('pgb_jewel_payment_confirmed',$order,$tx,$db);
}
add_action('pgb_fulfill_order','pgb_jewel_affiliate_fulfill',40,2);
