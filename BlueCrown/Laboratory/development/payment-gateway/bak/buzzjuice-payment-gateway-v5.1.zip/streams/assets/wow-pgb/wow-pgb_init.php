<?php
/**
 * Buzzjuice PGB v5.1 compatibility entry point.
 * This replaces the old monolithic payment-init engine.
 */
require_once dirname(__DIR__,3) . '/shared/payment-gateway/pgb-client-streams.php';
pgb_streams_init_payment();
