<?php
defined('ABSPATH') || exit;

if (!class_exists('BZJ_PGB_Currency')) {
final class BZJ_PGB_Currency {
    public static function resolve_target_currency($source) {
        $source=strtoupper((string)$source);
        $target=$source;
        if (function_exists('woocs_get_currency')) {
            try {
                $current=woocs_get_currency();
                if (is_string($current) && $current!=='') $target=strtoupper($current);
            } catch(Throwable $e) {
                bzj_pgb_log('class-pgb-currency','warning','WOOCS current currency lookup failed',array('error'=>$e->getMessage()));
            }
        }
        if (!isset(get_woocommerce_currencies()[$target])) $target=strtoupper(get_woocommerce_currency());
        return $target;
    }

    public static function rate($from,$to) {
        $from=strtoupper($from); $to=strtoupper($to);
        if ($from===$to) return 1.0;

        if (function_exists('woocs_get_currencies')) {
            try {
                $currencies=woocs_get_currencies();
                if (isset($currencies[$to]['rate']) && is_numeric($currencies[$to]['rate'])) {
                    $to_rate=(float)$currencies[$to]['rate'];
                    $from_rate=(isset($currencies[$from]['rate']) && is_numeric($currencies[$from]['rate'])) ? (float)$currencies[$from]['rate'] : 1.0;
                    if ($to_rate>0 && $from_rate>0) return $to_rate/$from_rate;
                }
            } catch(Throwable $e) {
                bzj_pgb_log('class-pgb-currency','warning','WOOCS rate lookup failed',array('error'=>$e->getMessage()));
            }
        }
        $map=get_option('woocs_drop_down_view',array());
        unset($map);
        return false;
    }

    public static function convert($amount,$from,$to) {
        $rate=self::rate($from,$to);
        if ($rate===false) return new WP_Error('pgb_rate','No reliable WOOCS rate is available.');
        return array('amount'=>round((float)$amount*$rate,wc_get_price_decimals()),'rate'=>$rate);
    }
}
}
