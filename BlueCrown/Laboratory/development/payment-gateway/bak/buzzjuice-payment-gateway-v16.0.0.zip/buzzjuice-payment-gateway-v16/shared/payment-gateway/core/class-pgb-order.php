<?php
defined('ABSPATH') || exit;

if (!class_exists('BZJ_PGB_Order')) {
final class BZJ_PGB_Order {
    public static function create_from_handoff($handoff) {
        if (!function_exists('wc_create_order')) return new WP_Error('pgb_wc','WooCommerce unavailable.');
        $p=$handoff['payload_json'];
        if (!is_array($p)) return new WP_Error('pgb_payload','Invalid handoff payload.');

        $wp_user_id=absint($handoff['wp_user_id']);
        $kind=strtoupper((string)$handoff['transaction_kind']);
        $product_id=self::resolve_product_id($p,$kind);
        if (!$product_id) return new WP_Error('pgb_product','No WooCommerce product mapping was supplied.');
        $product=wc_get_product($product_id);
        if (!$product) return new WP_Error('pgb_product','Mapped WooCommerce product does not exist.');

        $target=BZJ_PGB_Currency::resolve_target_currency($handoff['source_currency']);
        $converted=BZJ_PGB_Currency::convert($handoff['source_amount'],$handoff['source_currency'],$target);
        if (is_wp_error($converted)) return $converted;

        $existing=self::find_existing($handoff['wow_order_id']);
        if ($existing) return $existing;

        $order=wc_create_order(array('customer_id'=>$wp_user_id,'created_via'=>'buzzjuice-pgb'));
        if (is_wp_error($order)) return $order;

        try {
            $order->set_currency($target);
            $qty=max(1,absint($p['product_units'] ?? 1));
            $line=$order->add_product($product,$qty,array(
                'subtotal'=>$converted['amount'],
                'total'=>$converted['amount'],
                'subtotal_tax'=>0,
                'total_tax'=>0,
            ));
            if (!$line) throw new Exception('Unable to add mapped product to order.');

            self::set_addresses($order,$p);
            $meta=array(
                '_buzzjuice_origin'=>'streams',
                '_buzzjuice_pgb_version'=>BZJ_PGB_VERSION,
                '_buzzjuice_bridge_id'=>(int)$handoff['id'],
                'wow_order_id'=>$handoff['wow_order_id'],
                'userid'=>(int)$handoff['wow_user_id'],
                'wow_user_id'=>(int)$handoff['wow_user_id'],
                '_buzzjuice_transaction_kind'=>$kind,
                '_buzzjuice_source_currency'=>$handoff['source_currency'],
                '_buzzjuice_source_amount'=>(string)$handoff['source_amount'],
                '_buzzjuice_exchange_rate'=>(string)$converted['rate'],
                '_buzzjuice_checkout_currency'=>$target,
            );
            if (!empty($p['wow_post_id'])) $meta['wow_post_id']=absint($p['wow_post_id']);
            if (!empty($p['qdw_order_id'])) $meta['qdw_order_id']=absint($p['qdw_order_id']);
            if (!empty($p['subscription_period'])) $meta['_subscription_period']=sanitize_key($p['subscription_period']);
            if (!empty($p['subscription_interval'])) $meta['_subscription_interval']=absint($p['subscription_interval']);
            if (isset($p['_buzzjuice_affwp_context_snapshot'])) $meta['_buzzjuice_affwp_context_snapshot']=$p['_buzzjuice_affwp_context_snapshot'];

            foreach($meta as $k=>$v) $order->update_meta_data($k,$v);
            $order->calculate_totals(false);
            $order->save();

            BZJ_PGB_Streams::update($handoff['id'],array('status'=>'checkout','woo_order_id'=>(int)$order->get_id()));
            bzj_pgb_log('class-pgb-order','info','WooCommerce order created',array('bridge_id'=>$handoff['id'],'woo_order_id'=>$order->get_id(),'currency'=>$target));
            return $order;
        } catch(Throwable $e) {
            $order->update_status('failed','Buzzjuice Payment Gateway creation error.');
            return new WP_Error('pgb_order',$e->getMessage());
        }
    }

    private static function find_existing($wow_order_id) {
        $orders=wc_get_orders(array('limit'=>1,'type'=>'shop_order','meta_key'=>'wow_order_id','meta_value'=>$wow_order_id,'return'=>'objects'));
        return !empty($orders[0]) ? $orders[0] : false;
    }

    private static function resolve_product_id($p,$kind) {
        if ($kind==='PRODUCT') return absint($p['woo_product_id'] ?? $p['wow_post_id'] ?? 0);
        if ($kind==='PRO') {
            $map=array(
                1=>absint(get_option('wow_pro_package_id',0)),
                2=>absint(get_option('wow_pro_package_id_2',0)),
                3=>absint(get_option('wow_pro_package_id_3',0)),
                4=>absint(get_option('wow_pro_package_id_4',0)),
            );
            $post=absint($p['wow_post_id'] ?? 0);
            return $map[$post] ?? 0;
        }
        if ($kind==='WALLET') return absint(get_option('wow_wallet_topup_id',0));
        if ($kind==='DONATE') return absint(get_option('wow_crowdfund_id',0));
        return 0;
    }

    private static function set_addresses($order,$p) {
        $billing=is_array($p['billing'] ?? null)?$p['billing']:array();
        $fields=array('first_name','last_name','company','address_1','address_2','city','state','postcode','country','email','phone');
        $b=array();
        foreach($fields as $f) if(isset($billing[$f])) $b[$f]=is_string($billing[$f])?sanitize_text_field($billing[$f]):$billing[$f];
        if (!empty($b)) $order->set_address($b,'billing');
    }
}
}
