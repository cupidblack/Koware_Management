<?php
/**
 * Generic client facade. Streams currently uses pgb-client-streams.php.
 */
if (!function_exists('bzj_pgb_client_version')) {
    function bzj_pgb_client_version(){ return '16.0.0'; }
}
