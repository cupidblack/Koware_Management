<?php
defined('ABSPATH') || exit;
if (!class_exists('BZJ_PGB_Fulfillment')) {
final class BZJ_PGB_Fulfillment {
    public static function run($order_id,$trigger='unknown') {
        $order=wc_get_order($order_id);
        if (!$order || $order->get_meta('_buzzjuice_origin',true)!=='streams') return false;
        if (!in_array($order->get_status(),array('processing','completed'),true)) return false;
        if ($order->get_meta('_bzj_pgb_fulfilled',true)) return true;

        $lock='bzj_pgb_lock_'.$order_id;
        if (get_transient($lock)) return true;
        set_transient($lock,1,MINUTE_IN_SECONDS);

        try {
            if (BZJ_PGB_Subscriptions::order_contains($order_id)) {
                $result=BZJ_PGB_Subscriptions::process($order_id);
                if (is_wp_error($result)) throw new Exception($result->get_error_message());
            }

            self::streams_fulfill($order);
            if (function_exists('bzj_pgb_affiliate_after_payment')) bzj_pgb_affiliate_after_payment($order_id);
            if (function_exists('bzj_pgb_jewel_after_payment')) bzj_pgb_jewel_after_payment($order);

            $order->update_meta_data('_bzj_pgb_fulfilled',gmdate('c'));
            $order->update_meta_data('_bzj_pgb_fulfillment_trigger',$trigger);
            $order->save();

            $bridge_id=absint($order->get_meta('_buzzjuice_bridge_id',true));
            if ($bridge_id) BZJ_PGB_Streams::update($bridge_id,array('status'=>'fulfilled','fulfilled_at'=>gmdate('Y-m-d H:i:s')));
            bzj_pgb_log('class-pgb-fulfillment','info','Fulfillment completed',array('order_id'=>$order_id,'trigger'=>$trigger));
            return true;
        } catch(Throwable $e) {
            bzj_pgb_log('class-pgb-fulfillment','error','Fulfillment failed',array('order_id'=>$order_id,'trigger'=>$trigger,'error'=>$e->getMessage()));
            $order->update_meta_data('_bzj_pgb_fulfillment_error',$e->getMessage());
            $order->save();
            return false;
        } finally {
            delete_transient($lock);
        }
    }

    private static function streams_db() {
        $file=ABSPATH.'shared/db_helpers.php';
        if (file_exists($file)) require_once $file;
        return function_exists('get_wowonder_db') ? get_wowonder_db() : false;
    }

    private static function streams_fulfill($order) {
        $kind=strtoupper((string)$order->get_meta('_buzzjuice_transaction_kind',true));
        $wow_user_id=absint($order->get_meta('wow_user_id',true));
        $db=self::streams_db();
        if (!$db || !$wow_user_id) return;

        if ($kind==='WALLET') {
            $amount=(float)$order->get_meta('_buzzjuice_source_amount',true);
            $stmt=$db->prepare("UPDATE Wo_Users SET wallet=wallet+? WHERE user_id=?");
            if ($stmt) { $stmt->bind_param('di',$amount,$wow_user_id); $stmt->execute(); }
        } elseif ($kind==='PRODUCT') {
            self::record_product($order,$db,$wow_user_id);
        } elseif ($kind==='PRO') {
            $post_id=absint($order->get_meta('wow_post_id',true));
            $role_map=array(1=>'classic_lifestyle',2=>'silver',3=>'rockstar_lifestyle',4=>'premium_lifestyle');
            $wp_id=absint($order->get_customer_id());
            if ($wp_id && isset($role_map[$post_id])) {
                $u=new WP_User($wp_id);
                if ($u && !in_array($role_map[$post_id],(array)$u->roles,true)) $u->add_role($role_map[$post_id]);
            }
            self::update_wow_pro($db,$wow_user_id,$post_id);
        }
    }

    private static function record_product($order,$db,$wow_user_id) {
        $existing=$db->query("SELECT id FROM Wo_Purchases WHERE order_hash_id='". $db->real_escape_string((string)$order->get_meta('wow_order_id',true))."' LIMIT 1");
        if ($existing && $existing->num_rows) return;
        $meta=array(
            'name'=>$order->get_meta('_buzzjuice_product_name',true) ?: $order->get_item_count(),
            'product_id'=>absint($order->get_meta('wow_post_id',true)),
            'units'=>1,
            'currency'=>$order->get_currency(),
            'timestamp'=>time()
        );
        $hash=(string)$order->get_meta('wow_order_id',true);
        $owner=absint($order->get_meta('_buzzjuice_product_owner_id',true));
        $data=wp_json_encode($meta);
        $final=(float)$order->get_total();
        $price=$final;
        $stmt=$db->prepare("INSERT INTO Wo_Purchases (user_id,order_hash_id,owner_id,data,final_price,commission,price,timestamp,time) VALUES (?,?,?,?,?,?,?,?,?)");
        if ($stmt) { $commission=0.0; $ts=(float)time(); $stmt->bind_param('isssddddd',$wow_user_id,$hash,$owner,$data,$final,$commission,$price,$ts,$ts); $stmt->execute(); }
    }

    private static function update_wow_pro($db,$wow_user_id,$post_id) {
        $stmt=$db->prepare("UPDATE Wo_Users SET is_pro=1,pro_type=? WHERE user_id=?");
        if ($stmt) { $stmt->bind_param('ii',$post_id,$wow_user_id); $stmt->execute(); }
    }
}
}
