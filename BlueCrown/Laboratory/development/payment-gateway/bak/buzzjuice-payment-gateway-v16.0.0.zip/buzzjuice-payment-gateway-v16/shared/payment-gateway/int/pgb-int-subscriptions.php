<?php
defined('ABSPATH') || exit;
if (!class_exists('BZJ_PGB_Subscriptions')) {
final class BZJ_PGB_Subscriptions {
    public static function order_contains($order_id) {
        return function_exists('wcs_order_contains_subscription') && wcs_order_contains_subscription($order_id);
    }

    public static function process($order_id) {
        if (!function_exists('wcs_get_subscriptions_for_order')) return array();
        try {
            $subs=wcs_get_subscriptions_for_order($order_id,array('order_type'=>'parent'));
            foreach($subs as $subscription) {
                if ($subscription && $subscription->has_status(array('pending','on-hold'))) {
                    $subscription->update_status('active','Activated by Buzzjuice Payment Gateway.');
                }
            }
            return $subs;
        } catch(Throwable $e) {
            bzj_pgb_log('pgb-int-subscriptions','error','Subscription processing failed',array('order_id'=>$order_id,'error'=>$e->getMessage()));
            return new WP_Error('pgb_subscription',$e->getMessage());
        }
    }
}
}
