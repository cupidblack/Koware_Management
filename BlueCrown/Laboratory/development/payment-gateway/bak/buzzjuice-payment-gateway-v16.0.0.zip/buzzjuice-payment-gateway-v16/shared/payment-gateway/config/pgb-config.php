<?php
/**
 * Buzzjuice Payment Gateway configuration.
 * WordPress-side only. No WooCommerce REST credentials are required.
 */
defined('ABSPATH') || exit;

if (!class_exists('BZJ_PGB_Config')) {
    final class BZJ_PGB_Config {
        public static function secret() {
            $secret = '';
            if (function_exists('getenv')) {
                $secret = (string) getenv('BUZZ_PGB_SECRET');
            }
            if ($secret === '' && isset($_ENV['BUZZ_PGB_SECRET'])) {
                $secret = (string) $_ENV['BUZZ_PGB_SECRET'];
            }
            if ($secret === '' && defined('BUZZ_PGB_SECRET')) {
                $secret = (string) BUZZ_PGB_SECRET;
            }
            return trim($secret);
        }

        public static function logging_enabled() {
            $env = function_exists('getenv') ? getenv('BUZZ_PGB_LOGGING') : false;
            if ($env !== false && $env !== '') {
                return in_array(strtolower((string)$env), array('1','true','yes','on'), true);
            }
            $saved = get_option('bzj_pgb_logging', null);
            return $saved === null ? false : (bool)$saved;
        }

        public static function log_level() {
            $env = function_exists('getenv') ? getenv('BUZZ_PGB_LOG_LEVEL') : false;
            $level = ($env !== false && $env !== '') ? $env : get_option('bzj_pgb_log_level', 'info');
            $level = strtolower((string)$level);
            return in_array($level, array('debug','info','warning','error','critical'), true) ? $level : 'info';
        }

        public static function ttl() {
            $ttl = absint(get_option('bzj_pgb_handoff_ttl', 900));
            return max(60, min($ttl ?: 900, HOUR_IN_SECONDS));
        }

        public static function checkout_path() {
            return 'pgb-checkout';
        }

        public static function store_url() {
            $value = function_exists('get_option') ? get_option('wowonder_url', '') : '';
            if (!$value && defined('BZJ_PGB_STREAMS_URL')) {
                $value = BZJ_PGB_STREAMS_URL;
            }
            return rtrim((string)$value, '/') . '/';
        }

        public static function validate() {
            $errors = array();
            if (self::secret() === '') {
                $errors[] = 'BUZZ_PGB_SECRET is not configured.';
            }
            if (!function_exists('wc_create_order')) {
                $errors[] = 'WooCommerce is not loaded.';
            }
            return $errors;
        }
    }
}
