<?php
defined('ABSPATH') || exit;
if (!function_exists('bzj_pgb_get_checkout_url')) {
    function bzj_pgb_get_checkout_url($order) {
        return $order->get_checkout_payment_url(false);
    }
}
