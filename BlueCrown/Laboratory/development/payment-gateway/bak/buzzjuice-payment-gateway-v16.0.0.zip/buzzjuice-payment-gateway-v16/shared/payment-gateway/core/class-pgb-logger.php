<?php
defined('ABSPATH') || exit;

if (!class_exists('BZJ_PGB_Logger')) {
final class BZJ_PGB_Logger {
    private static $levels = array('debug'=>0,'info'=>1,'warning'=>2,'error'=>3,'critical'=>4);

    public static function log($source, $level, $message, $context=array()) {
        if (!BZJ_PGB_Config::logging_enabled()) return;
        $level = strtolower((string)$level);
        if (!isset(self::$levels[$level])) $level='info';
        $min = self::$levels[BZJ_PGB_Config::log_level()];
        if (self::$levels[$level] < $min) return;

        $safe = self::redact($context);
        $dir = BZJ_PGB_PATH . '/log';
        if (!is_dir($dir)) wp_mkdir_p($dir);
        if (!is_dir($dir) || !is_writable($dir)) return;

        $file = preg_replace('/[^A-Za-z0-9._-]/', '-', basename((string)$source));
        if ($file === '') $file='pgb';
        $entry = array(
            'time'=>gmdate('c'),
            'level'=>$level,
            'message'=>(string)$message,
            'context'=>$safe,
        );
        @file_put_contents($dir.'/'.$file.'.log', wp_json_encode($entry, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).PHP_EOL, FILE_APPEND|LOCK_EX);
    }

    public static function redact($value) {
        $keys = array('token','sig','secret','authorization','cookie','session','password','consumer_key','consumer_secret','api_key','api_secret');
        if (is_array($value)) {
            $out=array();
            foreach ($value as $k=>$v) {
                $lk=strtolower((string)$k);
                $blocked=false;
                foreach($keys as $needle) if (strpos($lk,$needle)!==false) {$blocked=true;break;}
                $out[$k]=$blocked ? '[REDACTED]' : self::redact($v);
            }
            return $out;
        }
        if (is_object($value)) return self::redact((array)$value);
        if (is_string($value) && strlen($value)>1000) return substr($value,0,1000).'…';
        return $value;
    }
}
}
