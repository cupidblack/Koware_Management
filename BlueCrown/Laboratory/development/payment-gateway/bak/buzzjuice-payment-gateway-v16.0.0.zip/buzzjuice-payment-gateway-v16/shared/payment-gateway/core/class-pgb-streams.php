<?php
defined('ABSPATH') || exit;

if (!class_exists('BZJ_PGB_Streams')) {
final class BZJ_PGB_Streams {
    private static function db() {
        static $db=null;
        if ($db instanceof mysqli) return $db;
        $file = ABSPATH.'shared/db_helpers.php';
        if (!file_exists($file)) return false;
        require_once $file;
        if (function_exists('get_wowonder_db')) $db=get_wowonder_db();
        return ($db instanceof mysqli) ? $db : false;
    }

    public static function install() {
        $db=self::db();
        if (!$db) return false;
        $table='Wo_Payment_Gateway_Bridge';
        $sql="CREATE TABLE IF NOT EXISTS `{$table}` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `token_hash` CHAR(64) NOT NULL,
            `wow_order_id` VARCHAR(80) NOT NULL,
            `wow_user_id` INT UNSIGNED NOT NULL,
            `wp_user_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `transaction_kind` VARCHAR(32) NOT NULL,
            `source_currency` VARCHAR(10) NOT NULL,
            `source_amount` DECIMAL(20,6) NOT NULL DEFAULT 0,
            `payload_json` LONGTEXT NOT NULL,
            `status` VARCHAR(24) NOT NULL DEFAULT 'ready',
            `woo_order_id` BIGINT UNSIGNED NULL,
            `error_code` VARCHAR(64) NULL,
            `error_message` TEXT NULL,
            `created_at` DATETIME NOT NULL,
            `expires_at` DATETIME NOT NULL,
            `claimed_at` DATETIME NULL,
            `fulfilled_at` DATETIME NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_token_hash` (`token_hash`),
            UNIQUE KEY `uq_wow_order_id` (`wow_order_id`),
            KEY `idx_status_expires` (`status`,`expires_at`),
            KEY `idx_wow_user` (`wow_user_id`),
            KEY `idx_woo_order` (`woo_order_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ok=$db->query($sql);
        bzj_pgb_log('class-pgb-streams','info','Bridge table initialization',array('success'=>(bool)$ok));
        return (bool)$ok;
    }

    public static function create_handoff($data) {
        $db=self::db();
        if (!$db) return new WP_Error('pgb_db','Streams database unavailable.');
        self::install();

        $token=bin2hex(random_bytes(32));
        $hash=hash('sha256',$token);
        $wow_order_id=(string)$data['wow_order_id'];
        $payload=wp_json_encode($data, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        $now=current_time('mysql',true);
        $expires=gmdate('Y-m-d H:i:s',time()+BZJ_PGB_Config::ttl());

        $stmt=$db->prepare("INSERT INTO Wo_Payment_Gateway_Bridge
            (token_hash,wow_order_id,wow_user_id,wp_user_id,transaction_kind,source_currency,source_amount,payload_json,status,created_at,expires_at)
            VALUES (?,?,?,?,?,?,?,?,'ready',?,?)");
        if (!$stmt) return new WP_Error('pgb_prepare',$db->error);
        $kind=(string)$data['transaction_kind']; $cur=(string)$data['currency']; $amt=(float)$data['amount'];
        $wow=(int)$data['wow_user_id']; $wp=(int)$data['wp_user_id'];
        $stmt->bind_param('ssiissdsss',$hash,$wow_order_id,$wow,$wp,$kind,$cur,$amt,$payload,$now,$expires);
        if (!$stmt->execute()) return new WP_Error('pgb_insert',$stmt->error);

        $id=(int)$stmt->insert_id;
        $check=$db->query("SELECT id FROM Wo_Payment_Gateway_Bridge WHERE id=".$id." LIMIT 1");
        if (!$check || !$check->num_rows) return new WP_Error('pgb_verify','Bridge row verification failed.');

        $sig=hash_hmac('sha256',$token,BZJ_PGB_Config::secret());
        $url=add_query_arg(array('token'=>$token,'sig'=>$sig),home_url('/'.BZJ_PGB_Config::checkout_path().'/'));
        bzj_pgb_log('class-pgb-streams','info','Handoff created',array('bridge_id'=>$id,'wow_order_id'=>$wow_order_id,'kind'=>$kind));
        return array('id'=>$id,'token'=>$token,'url'=>$url);
    }

    public static function claim($token) {
        $db=self::db();
        if (!$db) return new WP_Error('pgb_db','Streams database unavailable.');
        $hash=hash('sha256',(string)$token);
        $db->begin_transaction();
        try {
            $stmt=$db->prepare("SELECT * FROM Wo_Payment_Gateway_Bridge WHERE token_hash=? LIMIT 1 FOR UPDATE");
            $stmt->bind_param('s',$hash); $stmt->execute();
            $row=$stmt->get_result()->fetch_assoc();
            if (!$row) throw new Exception('Handoff not found.');
            if (strtotime($row['expires_at'].' UTC') < time() && $row['status'] === 'ready') {
                $db->query("UPDATE Wo_Payment_Gateway_Bridge SET status='expired',error_code='expired' WHERE id=".(int)$row['id']);
                throw new Exception('Handoff expired.');
            }
            if (!in_array($row['status'],array('ready','claimed','checkout','failed'),true)) {
                throw new Exception('Handoff is no longer usable.');
            }
            if ($row['status']==='ready') {
                $db->query("UPDATE Wo_Payment_Gateway_Bridge SET status='claimed',claimed_at=UTC_TIMESTAMP() WHERE id=".(int)$row['id']." AND status='ready'");
            }
            $db->commit();
            $row['payload_json']=json_decode($row['payload_json'],true);
            return $row;
        } catch (Throwable $e) {
            $db->rollback();
            return new WP_Error('pgb_claim',$e->getMessage());
        }
    }

    public static function update($id,$fields) {
        $db=self::db(); if (!$db) return false;
        $allowed=array('status','woo_order_id','error_code','error_message','fulfilled_at');
        $sets=array(); $vals=array(); $types='';
        foreach($fields as $key=>$value) {
            if (!in_array($key,$allowed,true)) continue;
            $sets[]="`$key`=?"; $vals[]=$value; $types.=(is_int($value)?'i':'s');
        }
        if (!$sets) return true;
        $vals[]=(int)$id; $types.='i';
        $stmt=$db->prepare("UPDATE Wo_Payment_Gateway_Bridge SET ".implode(',',$sets)." WHERE id=?");
        if (!$stmt) return false;
        $stmt->bind_param($types,...$vals);
        return $stmt->execute();
    }
}
}
