<?php
defined('ABSPATH') || exit;

if (!defined('BZJ_PGB_PATH')) {
    define('BZJ_PGB_PATH', dirname(__DIR__));
}
if (!defined('BZJ_PGB_VERSION')) define('BZJ_PGB_VERSION','16.0.0');

require_once BZJ_PGB_PATH.'/config/pgb-config.php';
require_once BZJ_PGB_PATH.'/core/class-pgb-logger.php';

if (!function_exists('bzj_pgb_log')) {
    function bzj_pgb_log($source,$level,$message,$context=array()) {
        BZJ_PGB_Logger::log($source,$level,$message,$context);
    }
}

require_once BZJ_PGB_PATH.'/core/class-pgb-streams.php';
require_once BZJ_PGB_PATH.'/core/class-pgb-currency.php';
require_once BZJ_PGB_PATH.'/core/class-pgb-order.php';
require_once BZJ_PGB_PATH.'/core/class-pgb-fulfillment.php';
require_once BZJ_PGB_PATH.'/core/class-pgb-hooks.php';
require_once BZJ_PGB_PATH.'/int/pgb-int-woocommerce.php';
require_once BZJ_PGB_PATH.'/int/pgb-int-subscriptions.php';
require_once BZJ_PGB_PATH.'/int/pgb-int-jewel-affiliate.php';

foreach (glob(BZJ_PGB_PATH.'/addons/pgb-addon-*.php') ?: array() as $addon) {
    require_once $addon;
}
