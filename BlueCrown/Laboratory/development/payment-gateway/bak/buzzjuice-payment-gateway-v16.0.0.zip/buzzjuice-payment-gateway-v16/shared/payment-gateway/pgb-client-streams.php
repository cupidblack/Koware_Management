<?php
/**
 * WoWonder/Streams-side client. No WordPress functions and no HTTP call to WP.
 */
if (!function_exists('bzj_pgb_streams_log')) {
function bzj_pgb_streams_log($level,$message,$context=array()) {
    $enabled=true;
    if (function_exists('getenv')) {
        $v=getenv('BUZZ_PGB_STREAMS_LOGGING');
        if ($v!==false && $v!=='') $enabled=in_array(strtolower((string)$v),array('1','true','yes','on'),true);
    }
    if (!$enabled) return;
    $dir=dirname(__DIR__).'/payment-gateway/log';
    if (!is_dir($dir)) @mkdir($dir,0750,true);
    if (!is_dir($dir)||!is_writable($dir)) return;
    $entry=array('time'=>gmdate('c'),'level'=>$level,'message'=>$message,'context'=>$context);
    @file_put_contents($dir.'/pgb-client-streams.log',json_encode($entry,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).PHP_EOL,FILE_APPEND|LOCK_EX);
}}
if (!function_exists('bzj_pgb_streams_create_handoff')) {
function bzj_pgb_streams_create_handoff($data) {
    $db_file=dirname(__DIR__).'/db_helpers.php';
    if (!file_exists($db_file)) return array('status'=>'error','message'=>'Payment Gateway database helper unavailable.');
    require_once $db_file;
    $db=function_exists('get_wowonder_db')?get_wowonder_db():false;
    if (!$db) return array('status'=>'error','message'=>'Payment Gateway database unavailable.');

    $kind=strtoupper(trim((string)($data['transaction_kind']??'')));
    if (!in_array($kind,array('PRODUCT','PRO','WALLET','DONATE'),true)) return array('status'=>'error','message'=>'Invalid transaction kind.');
    $user=(int)($data['wow_user_id']??0);
    $wp=(int)($data['wp_user_id']??0);
    $amount=(float)($data['amount']??0);
    $currency=strtoupper(preg_replace('/[^A-Z]/','',(string)($data['currency']??'GHS')));
    if (!$user||!$wp||$amount<0||$currency==='') return array('status'=>'error','message'=>'Invalid payment data.');

    $wow_order_id='wow_'.bin2hex(random_bytes(16));
    $now=time();
    $payload=$data;
    $payload['wow_order_id']=$wow_order_id;
    $payload['created_at']=gmdate('c');

    /* Preserve the existing Streams financial transaction ledger. */
    $stmt=$db->prepare("INSERT INTO Wo_Payment_Transactions (userid,amount,order_id,kind,currency_code) VALUES (?,?,?,?,?)");
    if (!$stmt) return array('status'=>'error','message'=>'Unable to prepare transaction.');
    $stmt->bind_param('idsss',$user,$amount,$wow_order_id,$kind,$currency);
    if (!$stmt->execute()) return array('status'=>'error','message'=>'Unable to record transaction.');

    /* Product records are intentionally NOT fulfilled here. They become payable
       state only; purchase/role/wallet effects happen after WooCommerce payment. */

    $token=bin2hex(random_bytes(32));
    $hash=hash('sha256',$token);
    $expires=gmdate('Y-m-d H:i:s',$now+900);
    $json=json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);

    $sql="CREATE TABLE IF NOT EXISTS Wo_Payment_Gateway_Bridge (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      token_hash CHAR(64) NOT NULL UNIQUE,
      wow_order_id VARCHAR(80) NOT NULL UNIQUE,
      wow_user_id INT UNSIGNED NOT NULL,
      wp_user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
      transaction_kind VARCHAR(32) NOT NULL,
      source_currency VARCHAR(10) NOT NULL,
      source_amount DECIMAL(20,6) NOT NULL DEFAULT 0,
      payload_json LONGTEXT NOT NULL,
      status VARCHAR(24) NOT NULL DEFAULT 'ready',
      woo_order_id BIGINT UNSIGNED NULL,
      error_code VARCHAR(64) NULL,
      error_message TEXT NULL,
      created_at DATETIME NOT NULL,
      expires_at DATETIME NOT NULL,
      claimed_at DATETIME NULL,
      fulfilled_at DATETIME NULL,
      PRIMARY KEY(id), KEY idx_status_expires(status,expires_at), KEY idx_wow_user(wow_user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    if (!$db->query($sql)) return array('status'=>'error','message'=>'Unable to initialize payment bridge.');

    $stmt=$db->prepare("INSERT INTO Wo_Payment_Gateway_Bridge
      (token_hash,wow_order_id,wow_user_id,wp_user_id,transaction_kind,source_currency,source_amount,payload_json,status,created_at,expires_at)
      VALUES (?,?,?,?,?,?,?,?,'ready',?,?)");
    if (!$stmt) return array('status'=>'error','message'=>'Unable to prepare handoff.');
    $stmt->bind_param('ssiissdsss',$hash,$wow_order_id,$user,$wp,$kind,$currency,$amount,$json,$created_at,$expires);
    $created_at=gmdate('Y-m-d H:i:s',$now);
    if (!$stmt->execute()) return array('status'=>'error','message'=>'Unable to store payment handoff.');

    /* The signature is deliberately not stored in Streams. */
    $secret='';
    if (function_exists('getenv')) $secret=(string)getenv('BUZZ_PGB_SECRET');
    if (!$secret && isset($_ENV['BUZZ_PGB_SECRET'])) $secret=(string)$_ENV['BUZZ_PGB_SECRET'];
    if (!$secret) return array('status'=>'error','message'=>'Payment Gateway secret is not configured on the server.');

    $sig=hash_hmac('sha256',$token,$secret);
    $store=rtrim((string)($GLOBALS['wo']['config']['wow_store_url']??''),'/');
    if ($store==='') $store='https://buzzjuice.net';
    $url=$store.'/pgb-checkout/?token='.rawurlencode($token).'&sig='.rawurlencode($sig);

    bzj_pgb_streams_log('info','Payment handoff created',array('wow_order_id'=>$wow_order_id,'kind'=>$kind,'user_id'=>$user));
    return array('status'=>200,'url'=>$url,'wow_order_id'=>$wow_order_id);
}}
