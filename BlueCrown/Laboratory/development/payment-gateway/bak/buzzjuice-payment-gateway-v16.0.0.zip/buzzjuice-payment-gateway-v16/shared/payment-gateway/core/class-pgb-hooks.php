<?php
defined('ABSPATH') || exit;
if (!class_exists('BZJ_PGB_Hooks')) {
final class BZJ_PGB_Hooks {
    public static function register() {
        add_action('woocommerce_payment_complete',array(__CLASS__,'payment_complete'),999,1);
        add_action('woocommerce_order_status_processing',array(__CLASS__,'status_processing'),999,1);
        add_action('woocommerce_order_status_completed',array(__CLASS__,'status_completed'),999,1);
        add_action('woocommerce_thankyou',array(__CLASS__,'thankyou'),999,1);
    }
    public static function payment_complete($id){ BZJ_PGB_Fulfillment::run($id,'woocommerce_payment_complete'); }
    public static function status_processing($id){ BZJ_PGB_Fulfillment::run($id,'woocommerce_order_status_processing'); }
    public static function status_completed($id){ BZJ_PGB_Fulfillment::run($id,'woocommerce_order_status_completed'); }
    public static function thankyou($id){ BZJ_PGB_Fulfillment::run($id,'woocommerce_thankyou'); }
}
BZJ_PGB_Hooks::register();
}
