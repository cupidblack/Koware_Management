<?php
defined('ABSPATH') || exit;
/**
 * AffiliateWP addon.
 * Reuses the proven Buzzjuice AffiliateWP implementation during migration.
 * The old MU completion handler is NOT loaded.
 */
if (!function_exists('bzj_pgb_affiliate_after_payment')) {
function bzj_pgb_affiliate_after_payment($order_id) {
    if ($order_id<=0) return false;
    $order=wc_get_order($order_id);
    if (!$order || $order->get_meta('_buzzjuice_origin',true)!=='streams') return false;
    if ($order->get_meta('_affwp_bridge_processed',true)) return true;

    $legacy=ABSPATH.'wp-content/plugins/blue-crown-wp/wow-pgb_sync/wow-pgb_sync.php';
    if (!function_exists('bluecrown_affiliatewp_post_checkout_verification') && file_exists($legacy)) {
        require_once $legacy;
    }
    if (!function_exists('bluecrown_affiliatewp_post_checkout_verification')) {
        bzj_pgb_log('pgb-addon-affiliate-wp','warning','Proven AffiliateWP routine is unavailable',array('order_id'=>$order_id));
        return false;
    }
    try {
        $result=bluecrown_affiliatewp_post_checkout_verification($order_id);
        if ($result!==false) {
            $order->update_meta_data('_affwp_bridge_processed',1);
            $order->save();
            bzj_pgb_log('pgb-addon-affiliate-wp','info','AffiliateWP processing completed',array('order_id'=>$order_id));
            return true;
        }
    } catch(Throwable $e) {
        bzj_pgb_log('pgb-addon-affiliate-wp','error','AffiliateWP exception',array('order_id'=>$order_id,'error'=>$e->getMessage()));
    }
    return false;
}
}
