<?php
defined('ABSPATH') || exit;
/**
 * Jewel affiliate integration seam.
 * The existing Streams Jewel webhook remains authoritative until its exact
 * business rules are migrated into this integration. This adapter intentionally
 * does not invent a rebate formula.
 */
if (!function_exists('bzj_pgb_jewel_after_payment')) {
    function bzj_pgb_jewel_after_payment($order) {
        do_action('bzj_pgb_jewel_after_payment',$order);
        return true;
    }
}
