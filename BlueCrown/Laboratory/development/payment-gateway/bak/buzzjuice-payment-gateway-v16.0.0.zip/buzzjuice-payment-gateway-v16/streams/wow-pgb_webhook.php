<?php
http_response_code(410);
header('Content-Type: application/json; charset=utf-8');
echo json_encode(array(
    'status'=>410,
    'message'=>'The Buzzjuice Payment Gateway webhook is retired. WooCommerce payment events are now processed directly by WordPress.'
));
exit;
