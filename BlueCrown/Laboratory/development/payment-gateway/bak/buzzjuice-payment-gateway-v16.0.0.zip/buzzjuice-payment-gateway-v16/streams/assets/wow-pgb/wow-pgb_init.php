<?php
/**
 * Buzzjuice Streams payment gateway initializer.
 *
 * IMPORTANT:
 * - No cURL to buzzjuice.net.
 * - No WooCommerce REST API.
 * - No WooCommerce credentials in Streams.
 * - Creates only the Streams-side transaction ledger and a durable handoff row.
 */
require_once dirname(__DIR__,2).'/config.php';
require_once dirname(__DIR__,2).'/init.php';
require_once dirname(__DIR__,3).'/shared/payment-gateway/pgb-client-streams.php';

if (empty($wo['loggedin'])) {
    $redirect=$wo['config']['site_url'].'/login?redirect_url='.urlencode($_SERVER['REQUEST_URI']);
    header('Location: '.$redirect); exit;
}
header('Content-Type: application/json; charset=utf-8');

$uid=absint($wo['user']['user_id']??0);
$email=filter_var($wo['user']['email']??'',FILTER_VALIDATE_EMAIL);
$wp_user_id=absint($wo['user']['wp_user_id']??0);
if (!$wp_user_id) {
    require_once dirname(__DIR__,3).'/shared/db_helpers.php';
    $wp_user_id=absint(function_exists('bz_get_wp_user_id')?bz_get_wp_user_id($uid):0);
    if (!$wp_user_id && !empty($wo['user']['wp_user_id'])) $wp_user_id=absint($wo['user']['wp_user_id']);
}
if (!$uid || !$email || !$wp_user_id) {
    http_response_code(400); echo json_encode(array('status'=>'error','message'=>'Payment account mapping is incomplete.')); exit;
}

$post=function($key,$default=null) {
    return isset($_POST[$key]) ? trim((string)$_POST[$key]) : $default;
};
$kind=strtoupper(preg_replace('/[^A-Za-z_]/','',$post('transaction_kind','')));
$allowed=array('PRODUCT','PRO','WALLET','DONATE');
if (!in_array($kind,$allowed,true)) {
    http_response_code(400); echo json_encode(array('status'=>'error','message'=>'Invalid transaction kind.')); exit;
}
$amount=(float)$post('amount',0);
$price=(float)$post('product_price',$amount);
$units=max(1,(int)$post('product_units',1));
$currency=strtoupper(preg_replace('/[^A-Z]/','',$post('wow_currency_code',$wo['config']['currency']??'GHS')));
if ($amount<0 || $currency==='') {
    http_response_code(400); echo json_encode(array('status'=>'error','message'=>'Invalid payment amount or currency.')); exit;
}

$payload=array(
    'wow_user_id'=>$uid,
    'wp_user_id'=>$wp_user_id,
    'wow_user_email'=>$email,
    'transaction_kind'=>$kind,
    'amount'=>$amount,
    'product_price'=>$price,
    'product_units'=>$units,
    'product_name'=>htmlspecialchars($post('product_name','Buzzjuice Purchase'),ENT_QUOTES,'UTF-8'),
    'product_owner_id'=>absint($post('product_owner_id',0)),
    'wow_post_id'=>absint($post('wow_post_id',0)),
    'woo_product_id'=>absint($post('woo_product_id',0)),
    'address_id'=>absint($post('address_id',0)),
    'subscription_period'=>preg_replace('/[^A-Za-z0-9_-]/','',$post('subscription_period','')),
    'subscription_interval'=>absint($post('subscription_interval',0)),
    'subscription_length'=>absint($post('subscription_length',0)),
    'qdw_order_id'=>absint($post('qdw_order_id',0)),
    'currency'=>$currency,
);

/* Preserve the proven AffiliateWP attribution snapshot only as audit context.
   It is not used to decide the affiliate here. */
$snapshot=array();
foreach(array('affwp_ref','affwp_visit','affwp_visit_id','affwp_affiliate_id','affwp_campaign','affwp_coupon','affwp_referrer') as $k) {
    if (!empty($_COOKIE[$k])) $snapshot[$k]=(string)$_COOKIE[$k];
}
$snapshot['timestamp']=gmdate('c');
$snapshot['wp_user_id']=$wp_user_id;
$snapshot['customer_email']=$email;
$payload['_buzzjuice_affwp_context_snapshot']=json_encode($snapshot);

$result=bzj_pgb_streams_create_handoff($payload);
if (($result['status']??'error')!==200) {
    http_response_code(500);
    echo json_encode($result);
    exit;
}
echo json_encode($result,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
exit;
