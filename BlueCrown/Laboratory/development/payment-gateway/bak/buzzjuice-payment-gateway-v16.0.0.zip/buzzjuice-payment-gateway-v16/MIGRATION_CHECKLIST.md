# Buzzjuice Payment Gateway Bridge v16

## Architecture

Streams -> Wo_Payment_Transactions + Wo_Payment_Gateway_Bridge -> browser HTTPS -> WordPress MU -> WooCommerce CRUD -> checkout -> payment -> WooCommerce hooks -> fulfillment/addons.

No Streams-side cURL request to buzzjuice.net is used.

## Files

### Add/replace
- `wp-content/mu-plugins/bzj-payment-gateway.php`
- `shared/payment-gateway/pgb-client.php`
- `shared/payment-gateway/pgb-client-streams.php`
- `shared/payment-gateway/config/pgb-config.php`
- `shared/payment-gateway/core/class-pgb-bootstrap.php`
- `shared/payment-gateway/core/class-pgb-logger.php`
- `shared/payment-gateway/core/class-pgb-streams.php`
- `shared/payment-gateway/core/class-pgb-currency.php`
- `shared/payment-gateway/core/class-pgb-order.php`
- `shared/payment-gateway/core/class-pgb-fulfillment.php`
- `shared/payment-gateway/core/class-pgb-hooks.php`
- `shared/payment-gateway/int/pgb-int-woocommerce.php`
- `shared/payment-gateway/int/pgb-int-subscriptions.php`
- `shared/payment-gateway/int/pgb-int-jewel-affiliate.php`
- `shared/payment-gateway/addons/pgb-addon-affiliate-wp.php`
- `streams/assets/wow-pgb/wow-pgb_init.php`
- `streams/wow-pgb_webhook.php`

### Retire
- `wp-content/mu-plugins/buzzjuice-affwp-order-complete.php`

### Keep temporarily
- `wp-content/plugins/blue-crown-wp/wow-pgb_sync/wow-pgb_sync.php`
  - It is used only as a compatibility library for the proven AffiliateWP routine.
  - Do NOT let it remain as an independent payment completion hook.
  - After AffiliateWP logic is fully extracted into the addon, remove this dependency.

## Important correction

Do not use `dirname(ABSPATH)` to find `/shared`; use `trailingslashit(ABSPATH).'shared/payment-gateway'`.

Do not directly write WooCommerce order tables. Use `wc_create_order()`, `WC_Order` CRUD, `add_product()`, `set_currency()`, `update_meta_data()`, `calculate_totals()`, `save()`.

Do not manually build `/checkout/order-pay/...`. Use `$order->get_checkout_payment_url(false)`.

## Secret

Add to `.env` (never commit):
`BUZZ_PGB_SECRET=<64+ random hex characters>`

Example:
`openssl rand -hex 64`

## Streams settings

Keep:
- `wow_payment`
- `wow_store_url`
- market product mapping
- four Pro product mappings
- wallet product mapping
- crowdfund product mapping

Retire from the payment gateway UI:
- `wow_api_url`
- `wow_api_key`
- `wow_api_secret`
- `wow_webhook_secret`

They are no longer required for order creation.

## Test sequence

1. Back up both databases and the current payment files.
2. Install the new files without deleting the old bridge.
3. Add `BUZZ_PGB_SECRET`.
4. Confirm the WordPress MU plugin loads.
5. Open Buzzjuice -> Payment Gateways and save settings.
6. Trigger one PRO payment.
7. Verify `Wo_Payment_Transactions`.
8. Verify `Wo_Payment_Gateway_Bridge` reaches `checkout`.
9. Verify WooCommerce order metadata:
   - `_buzzjuice_origin=streams`
   - `wow_order_id`
   - `_buzzjuice_bridge_id`
   - `_buzzjuice_transaction_kind`
10. Complete payment.
11. Verify subscription state.
12. Verify Streams role/pro state.
13. Verify AffiliateWP exactly once.
14. Verify Jewel integration exactly once.
15. Test wallet, market/product and donation flows.
16. Only after all tests succeed, remove old AffiliateWP MU handler and retire the old webhook.
17. Finally extract the proven AffiliateWP routine from `wow-pgb_sync.php` into `pgb-addon-affiliate-wp.php` and retire `wow-pgb_sync.php`.

## Rollback

Restore:
- old `wow-pgb_init.php`
- old `wow-pgb_sync.php`
- old `buzzjuice-affwp-order-complete.php`

and remove the new MU plugin/files. Do not delete bridge rows; they are auditable migration records.
