<?php
/**
 * Deprecated Streams entry point.
 * This file contains no WordPress code and no WooCommerce REST/cURL calls.
 */
require_once dirname(__DIR__,3).'/shared/payment-gateway/clients/class-pgb-client-streams.php';
require_once dirname(__DIR__,3).'/shared/db_helpers.php';

$wowDb=function_exists('get_wowonder_db') ? get_wowonder_db() : false;
if (!($wowDb instanceof mysqli)) {
    // Fall back to Streams' live connection only when it is available.
    $wowDb=(isset($sqlConnect) && $sqlConnect instanceof mysqli) ? $sqlConnect : false;
}
if (!($wowDb instanceof mysqli)) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array('status'=>'error','message'=>'WoWonder database connection is unavailable.'));
    exit;
}

$cfg=array(
    'wow_payment'=>$wo['config']['wow_payment']??'no',
    'wow_store_url'=>$wo['config']['wow_store_url']??'',
    'wow_market_id'=>$wo['config']['wow_market_id']??0,
    'wow_pro_package_id'=>$wo['config']['wow_pro_package_id']??0,
    'wow_pro_package_id_2'=>$wo['config']['wow_pro_package_id_2']??0,
    'wow_pro_package_id_3'=>$wo['config']['wow_pro_package_id_3']??0,
    'wow_pro_package_id_4'=>$wo['config']['wow_pro_package_id_4']??0,
    'wow_wallet_topup_id'=>$wo['config']['wow_wallet_topup_id']??0,
    'wow_crowdfund_id'=>$wo['config']['wow_crowdfund_id']??0,
    'wow_pgb_secret'=>$wo['config']['wow_pgb_secret']??'',
    'wow_webhook_secret'=>$wo['config']['wow_webhook_secret']??'',
    'currency'=>$wo['config']['currency']??'GHS',
    'debug'=>false,
    'log_enabled'=>true,
    'token_ttl'=>600,
);

$client=new BZJ_PGB_Streams_Client($wowDb,$cfg);
$client->initiate($wo);
