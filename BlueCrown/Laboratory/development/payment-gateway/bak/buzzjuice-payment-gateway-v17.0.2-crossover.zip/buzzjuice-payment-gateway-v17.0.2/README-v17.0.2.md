# Buzzjuice Payment Gateway Bridge v17.0.2

## Architecture

WoWonder creates a durable `Wo_PGB_Orders` hand-off record. The browser then visits WordPress with a short-lived HMAC-signed request. The MU plugin reads the hand-off directly from the WoWonder database, creates a native WooCommerce order with CRUD APIs, and redirects to:

`$order->get_checkout_payment_url(false)`

No WooCommerce REST API request and no server-side cURL request from WoWonder are required.

## Files

- `wp-content/mu-plugins/bzj-payment-gateway.php` — the only MU plugin.
- `shared/payment-gateway/core/*` — engine, configuration, schema, logging, currency.
- `shared/payment-gateway/clients/class-pgb-client-wordpress.php` — WordPress/WooCommerce execution.
- `shared/payment-gateway/clients/class-pgb-client-streams.php` — WoWonder hand-off client.
- `shared/payment-gateway/helpers/*` — order/subscription helpers.
- `shared/payment-gateway/addons/pgb-addon-affiliate-wp.php` — AffiliateWP.
- `shared/payment-gateway/int/pgb-int-jewel-affiliate.php` — Jewel integration.
- `shared/payment-gateway/js/*` — optional Streams JavaScript.
- `streams/assets/wow-pgb/wow-pgb_init.php` — thin legacy-compatible Streams wrapper.

## Important

The `Wo_PGB_Orders` and `Wo_PGB_Events` tables are automatically created by both contexts. The WordPress engine re-checks schema when the addon/integration manifest changes.

The bridge secret should be configured as the same value in:
1. Streams `wow_pgb_secret` (recommended), and
2. WordPress `Buzzjuice > Payment Gateways`, or `PGB_SHARED_SECRET` environment variable.

For transition, `wow_webhook_secret` is accepted if `wow_pgb_secret` is empty.

## Deployment order

1. Back up the site and database.
2. Deploy the `shared/payment-gateway` tree.
3. Deploy `wp-content/mu-plugins/bzj-payment-gateway.php`.
4. Do NOT delete the old bridge yet.
5. Add the Streams wrapper and payment-settings changes.
6. Configure the same bridge secret.
7. Test a PRO purchase in staging.
8. Confirm a Woo order is created and the payment URL opens.
9. Complete payment and verify `Wo_PGB_Orders.status=completed`.
10. Verify subscription, AffiliateWP and Jewel processing.
11. Only then remove/deprecate the old `wow-pgb_sync.php`, old API credentials, and obsolete webhook path.

## Rollback

Restore the old Streams wrapper and old MU plugin/bridge from the backup. The v17 tables are additive and can remain in the database; they do not modify existing WoWonder payment tables until an order is successfully paid.


## v17.0.2 WooCommerce lifecycle and product-resolution hardening

- The Streams client no longer assumes optional Wo_Users columns such as `company` exist.
- Wo_Users columns are inspected at runtime and only existing fields are selected. Missing optional fields are returned as empty values.
- PGB tables are checked before each Streams payment initiation.
- Missing PGB columns/indexes are added non-destructively. Existing PGB records are preserved.
- WordPress admin now shows PGB table status and provides **Check & Repair PGB Tables**.
- No automatic DROP/TRUNCATE operation is performed. A destructive rebuild must be an explicit maintenance operation after database backup.


## v17.0.2 checkout handoff hardening
- Browser payment-entry handling now runs on `template_redirect`, after WooCommerce initialization and product/taxonomy registration.
- The configured `product_id` is authoritative for the WooCommerce mapping.
- A request `variation_id` is used only when it is a real WooCommerce variation whose parent matches the mapped product; otherwise the mapped product is used.
- Product-resolution failures are logged with request, mapped product, requested variation, and resolved product details.
