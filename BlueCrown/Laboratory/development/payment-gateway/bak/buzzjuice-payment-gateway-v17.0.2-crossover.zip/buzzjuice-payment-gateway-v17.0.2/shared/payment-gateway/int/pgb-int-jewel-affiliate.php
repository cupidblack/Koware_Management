<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Jewel integration.
 *
 * It prefers the existing Streams-side jewel implementation by invoking it
 * through the WoWonder database connection only after WooCommerce marks the
 * order paid. It also carries the required WoWonder user id and rebate data
 * in order meta so the integration does not have to infer identity from email.
 */
class BZJ_PGB_Int_Jewel_Affiliate {
    private $logger;
    public function __construct() { $this->logger=BZJ_PGB_Logger::instance('pgb-int-jewel-affiliate'); }

    public function register() {
        add_action('woocommerce_order_status_completed',array($this,'process'),950,1);
    }

    public function process($order_id) {
        if (!BZJ_PGB_Config::instance()->get('enable_jewel_affiliate',true)) return;
        $order=wc_get_order($order_id); if (!$order) return;
        $db=BZJ_PGB_Database::instance();
        $key='jewel:'.$order_id;
        if (!$db->claim_event($key,'jewel',$order_id)) return;

        try {
            $wow_user_id=(int)$order->get_meta('_bzj_wow_user_id',true);
            if (!$wow_user_id) throw new Exception('WoWonder user id is missing from order meta.');

            $wow_db=$db->connection();
            if (!$wow_db) throw new Exception('WoWonder DB unavailable.');

            // If the existing Streams implementation is still present, reuse its
            // battle-tested mapping/rebate routines without loading wp-load.php.
            $legacy=ABSPATH.'streams/jewel-affiliate-webhook.php';
            if (file_exists($legacy)) {
                require_once $legacy;
                if (function_exists('jewel_affiliate_process')) {
                    $payload=$this->order_payload($order);
                    jewel_affiliate_process($payload,$wow_db);
                    $db->finish_event($key,'complete','Existing Jewel processor invoked.');
                    return;
                }
            }

            // No legacy processor: perform only the safe, idempotent rebate portion
            // if explicit rebate meta exists. Mapping/role activation remains opt-in.
            $cents=(int)$order->get_meta('bz_rebate_credit_cents',true);
            if ($cents>0 && function_exists('bzj_pgb_apply_rebate')) {
                bzj_pgb_apply_rebate($wow_db,$wow_user_id,$cents,$order_id);
            }
            $db->finish_event($key,'complete','Jewel integration completed.');
        } catch (Throwable $e) {
            $db->finish_event($key,'failed',$e->getMessage());
            $this->logger->error('Jewel processing failed',array('order_id'=>$order_id,'error'=>$e->getMessage()));
        }
    }

    private function order_payload($order) {
        $meta=array();
        foreach ($order->get_meta_data() as $m) $meta[]=array('key'=>$m->key,'value'=>$m->value);
        $items=array();
        foreach ($order->get_items('line_item') as $item) {
            $items[]=array(
                'product_id'=>(int)$item->get_product_id(),
                'variation_id'=>(int)$item->get_variation_id(),
                'name'=>$item->get_name(),
                'quantity'=>(int)$item->get_quantity(),
                'total'=>(string)$item->get_total(),
            );
        }
        return array(
            'id'=>$order->get_id(),
            'status'=>$order->get_status(),
            'total'=>$order->get_total(),
            'billing'=>array('email'=>$order->get_billing_email()),
            'meta_data'=>$meta,
            'line_items'=>$items,
        );
    }
}
