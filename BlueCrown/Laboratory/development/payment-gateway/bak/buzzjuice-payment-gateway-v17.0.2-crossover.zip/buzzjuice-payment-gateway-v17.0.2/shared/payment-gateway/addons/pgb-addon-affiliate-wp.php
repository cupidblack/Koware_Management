<?php
if (!defined('ABSPATH')) { exit; }

class BZJ_PGB_Addon_Affiliate_WP {
    private $logger;
    public function __construct() { $this->logger=BZJ_PGB_Logger::instance('pgb-addon-affiliate-wp'); }

    public function register() {
        add_action('woocommerce_order_status_completed',array($this,'process'),999,1);
        add_action('woocommerce_order_status_processing',array($this,'process'),999,1);
    }

    private function enabled() {
        return BZJ_PGB_Config::instance()->get('enable_affiliate_wp',true) && function_exists('affwp_add_referral');
    }

    public function process($order_id) {
        if (!$this->enabled()) return;
        $order=wc_get_order($order_id);
        if (!$order) return;

        $key='affiliate:'.$order_id;
        $db=BZJ_PGB_Database::instance();
        if (!$db->claim_event($key,'affiliate',$order_id)) {
            $this->logger->debug('Affiliate event already claimed',array('order_id'=>$order_id));
            return;
        }

        try {
            $customer_id=$this->resolve_customer($order);
            $affiliate_id=$this->resolve_affiliate($order,$customer_id);
            if (!$affiliate_id) {
                $db->finish_event($key,'skipped','No affiliate linked to customer.');
                return;
            }

            $commission=$this->calculate_commission($order);
            if ($commission <= 0) {
                $db->finish_event($key,'skipped','Commission is zero.');
                return;
            }

            $existing=$this->existing_referral($order_id);
            if ($existing) {
                $db->finish_event($key,'complete','Existing referral '.$existing);
                return;
            }

            $args=array(
                'affiliate_id'=>(int)$affiliate_id,
                'amount'=>$commission,
                'reference'=>(string)$order_id,
                'description'=>'Buzzjuice WooCommerce order #'.$order_id,
                'context'=>'woocommerce',
                'status'=>'unpaid',
                'customer_id'=>(int)$customer_id,
                'order_total'=>(float)$order->get_total(),
                'currency'=>$order->get_currency(),
                'products'=>$this->products_meta($order),
            );
            $referral_id=affwp_add_referral($args);
            if (!$referral_id || is_wp_error($referral_id)) {
                throw new Exception('AffiliateWP referral creation failed.');
            }

            // Lifetime Commissions: let the extension associate this customer where supported.
            if (function_exists('affiliate_wp_lifetime_commissions')) {
                try {
                    $lifetime=affiliate_wp_lifetime_commissions();
                    if (isset($lifetime->lifetime_customers) && method_exists($lifetime->lifetime_customers,'add')) {
                        $lifetime->lifetime_customers->add(array(
                            'affwp_customer_id'=>(int)$customer_id,
                            'affiliate_id'=>(int)$affiliate_id,
                            'date_created'=>current_time('mysql'),
                        ));
                    }
                } catch (Throwable $e) {
                    $this->logger->warning('Lifetime customer association was not available',array('error'=>$e->getMessage()));
                }
            }

            $db->finish_event($key,'complete','Referral '.$referral_id.' created.');
            $this->logger->info('Affiliate referral created',array('order_id'=>$order_id,'affiliate_id'=>$affiliate_id,'customer_id'=>$customer_id,'commission'=>$commission,'referral_id'=>$referral_id));
        } catch (Throwable $e) {
            $db->finish_event($key,'failed',$e->getMessage());
            $this->logger->error('Affiliate processing failed',array('order_id'=>$order_id,'error'=>$e->getMessage()));
        }
    }

    private function resolve_customer($order) {
        $wp_user_id=(int)$order->get_customer_id();
        if ($wp_user_id && function_exists('affwp_get_customer_id')) {
            $id=(int)affwp_get_customer_id($wp_user_id);
            if ($id) return $id;
        }
        global $wpdb;
        if ($wp_user_id) {
            $id=(int)$wpdb->get_var($wpdb->prepare(
                "SELECT customer_id FROM {$wpdb->prefix}affiliate_wp_customers WHERE user_id=%d LIMIT 1",$wp_user_id
            ));
            if ($id) return $id;
        }
        $email=$order->get_billing_email();
        if ($email) {
            $id=(int)$wpdb->get_var($wpdb->prepare(
                "SELECT c.customer_id FROM {$wpdb->prefix}affiliate_wp_customers c WHERE c.email=%s LIMIT 1",$email
            ));
            if ($id) return $id;
        }
        return 0;
    }

    private function resolve_affiliate($order,$customer_id) {
        global $wpdb;
        $meta_keys=array('affiliate_id','referring_affiliate_id');
        foreach ($meta_keys as $key) {
            $id=(int)$wpdb->get_var($wpdb->prepare(
                "SELECT meta_value FROM {$wpdb->prefix}affiliate_wp_customermeta WHERE affwp_customer_id=%d AND meta_key=%s LIMIT 1",
                $customer_id,$key
            ));
            if ($id>0) return $id;
        }
        $snapshot=$order->get_meta('_bzj_affwp_affiliate_id',true);
        if ($snapshot) return (int)$snapshot;
        return 0;
    }

    private function calculate_commission($order) {
        $settings=get_option('affwp_settings',array());
        $default_rate=(float)($settings['referral_rate']??0);
        $default_type=(string)($settings['referral_rate_type']??'percentage');
        $total=0;
        foreach ($order->get_items('line_item') as $item) {
            $target=(int)$item->get_variation_id() ?: (int)$item->get_product_id();
            $rate=get_post_meta($target,'_affwp_woocommerce_product_rate',true);
            $type=get_post_meta($target,'_affwp_woocommerce_product_rate_type',true);
            if ($rate !== '' && is_numeric($rate) && in_array($type,array('percentage','flat'),true)) {
                $r=(float)$rate;
                $total += $type==='percentage' ? (float)$item->get_total()*$r/100 : $r;
            } elseif ($default_rate>0) {
                $total += $default_type==='percentage' ? (float)$item->get_total()*$default_rate/100 : $default_rate;
            }
        }
        return round($total,4);
    }

    private function existing_referral($order_id) {
        global $wpdb;
        return (int)$wpdb->get_var($wpdb->prepare(
            "SELECT referral_id FROM {$wpdb->prefix}affiliate_wp_referrals WHERE reference=%s LIMIT 1",(string)$order_id
        ));
    }

    private function products_meta($order) {
        $out=array();
        foreach ($order->get_items('line_item') as $item) {
            $out[]=array(
                'product_id'=>(int)$item->get_product_id(),
                'variation_id'=>(int)$item->get_variation_id(),
                'name'=>$item->get_name(),
                'total'=>(float)$item->get_total(),
                'quantity'=>(int)$item->get_quantity(),
            );
        }
        return $out;
    }
}
