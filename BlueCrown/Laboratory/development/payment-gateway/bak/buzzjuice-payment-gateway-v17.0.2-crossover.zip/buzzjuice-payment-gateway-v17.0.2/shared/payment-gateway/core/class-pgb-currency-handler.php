<?php
if (!defined('ABSPATH')) { exit; }

if (!class_exists('BZJ_PGB_Currency_Handler')) {
class BZJ_PGB_Currency_Handler {
    private $logger;
    public function __construct() { $this->logger=BZJ_PGB_Logger::instance('class-pgb-currency-handler'); }

    public function target_currency() {
        // get_woocommerce_currency() reflects the currency WooCommerce is actually using
        // for this request, including currency-switcher integrations that filter it.
        return strtoupper((string)get_woocommerce_currency());
    }

    public function convert($amount,$from,$to) {
        $amount=(float)$amount; $from=strtoupper(trim((string)$from)); $to=strtoupper(trim((string)$to));
        if ($amount < 0) throw new Exception('Negative payment amount is not permitted.');
        if ($from === $to) return round($amount, wc_get_price_decimals());

        // Prefer a public WOOCS conversion API if one is available.
        global $WOOCS;
        if (is_object($WOOCS)) {
            foreach (array('convert_from_currency','convert_price','woocs_exchange_value') as $method) {
                if (method_exists($WOOCS,$method)) {
                    try {
                        if ($method === 'convert_from_currency') {
                            $value=$WOOCS->$method($amount,$from,$to);
                        } elseif ($method === 'convert_price') {
                            $value=$WOOCS->$method($amount,$from,$to);
                        } else {
                            $value=$WOOCS->$method($amount,$to);
                        }
                        if (is_numeric($value)) return round((float)$value,wc_get_price_decimals());
                    } catch (Throwable $e) {
                        $this->logger->debug('WOOCS method failed; falling back to stored rates',array('method'=>$method,'error'=>$e->getMessage()));
                    }
                }
            }
        }

        // Read the currently stored Fox WOOCS currencies/rates.
        $currencies=false;
        if (is_object($WOOCS) && method_exists($WOOCS,'get_currencies')) {
            $currencies=$WOOCS->get_currencies();
        }
        if (!$currencies) {
            $currencies=get_option('woocs',false);
        }
        if (!is_array($currencies)) {
            $currencies=get_option('woocs_currencies',false);
        }
        if (!is_array($currencies)) throw new Exception("WOOCS rates are unavailable for {$from} -> {$to}.");

        $rates=array();
        foreach ($currencies as $row) {
            if (!is_array($row)) continue;
            $code=strtoupper((string)($row['name'] ?? $row['currency'] ?? $row['code'] ?? ''));
            $rate=(float)($row['rate'] ?? 0);
            if ($code && $rate > 0) $rates[$code]=$rate;
        }
        if (!isset($rates[$from]) || !isset($rates[$to])) {
            throw new Exception("WOOCS rate missing for {$from} or {$to}.");
        }
        // WOOCS rates are relative to its etalon/base currency.
        $converted=($amount/$rates[$from])*$rates[$to];
        $this->logger->info('Currency converted',array('from'=>$from,'to'=>$to,'source'=>$amount,'target'=>$converted));
        return round($converted,wc_get_price_decimals());
    }
}}
