<?php
if (!defined('ABSPATH')) { exit; }

class BZJ_PGB_Client_WordPress {
    private $logger;
    private $config;
    private $db;
    private $currency;

    public function __construct() {
        $this->logger=BZJ_PGB_Logger::instance('pgb-client-wordpress');
        $this->config=BZJ_PGB_Config::instance();
        $this->db=BZJ_PGB_Database::instance();
        $this->currency=new BZJ_PGB_Currency_Handler();
    }

    public function register() {
        add_action('template_redirect',array($this,'handle_browser_entry'),1);
        add_action('woocommerce_order_status_completed',array($this,'finalize_order'),900,1);
        add_action('woocommerce_payment_complete',array($this,'finalize_order'),900,1);
    }

    public function handle_browser_entry() {
        if (empty($_GET['bzj_pgb']) || (string)$_GET['bzj_pgb']!=='1') return;
        if (!$this->config->get('enabled',true)) wp_die('Payment Gateway Bridge is disabled.', 'Buzzjuice',array('response'=>503));

        $request=sanitize_text_field(wp_unslash($_GET['request']??''));
        $sig=sanitize_text_field(wp_unslash($_GET['sig']??''));
        if (!$request || !$sig) wp_die('Invalid payment request.', 'Buzzjuice',array('response'=>400));
        if (!$this->verify_signature($request,$sig)) wp_die('Payment request signature is invalid or expired.', 'Buzzjuice',array('response'=>403));

        $row=$this->db->get_by_request($request);
        if (!$row) wp_die('Payment request was not found.', 'Buzzjuice',array('response'=>404));
        if (!empty($row['token_expires_at']) && strtotime($row['token_expires_at'])<time() && empty($row['woo_order_id'])) {
            $this->db->set_status((int)$row['id'],'expired','Payment token expired.');
            wp_die('This payment request has expired. Please start again.', 'Buzzjuice',array('response'=>410));
        }

        try {
            if (!empty($row['woo_order_id'])) {
                $order=wc_get_order((int)$row['woo_order_id']);
            } else {
                $lock_key='bzj_pgb_lock_'.preg_replace('/[^A-Za-z0-9_-]/','',(string)$row['request_id']);
                if (get_option($lock_key,false)!==false || !add_option($lock_key,time(),'','no')) {
                    // A concurrent browser request is already creating this order.
                    usleep(250000);
                    $fresh=$this->db->get_by_request($request);
                    $order=!empty($fresh['woo_order_id']) ? wc_get_order((int)$fresh['woo_order_id']) : false;
                    if (!$order) throw new Exception('This payment request is already being prepared. Please retry in a moment.');
                } else {
                    try {
                        $order=$this->create_woocommerce_order($row);
                    } finally {
                        delete_option($lock_key);
                    }
                }
            }
            if (!$order) throw new Exception('WooCommerce order could not be loaded or created.');

            $url=$order->get_checkout_payment_url(false);
            $this->logger->info('Redirecting to WooCommerce payment URL',array('request_id'=>$request,'order_id'=>$order->get_id()));
            wp_safe_redirect($url,302);
            exit;
        } catch (Throwable $e) {
            $this->db->set_status((int)$row['id'],'failed',$e->getMessage());
            $this->logger->error('Browser entry failed',array('request_id'=>$request,'error'=>$e->getMessage()));
            wp_die(esc_html($e->getMessage()),'Buzzjuice Payment Gateway',array('response'=>500));
        }
    }

    private function verify_signature($request,$sig) {
        $secret=$this->shared_secret();
        if (!$secret) return false;
        $expected=hash_hmac('sha256',$request,$secret);
        return hash_equals($expected,$sig);
    }

    public function shared_secret() {
        $secret=(string)$this->config->get('shared_secret','');
        if ($secret) return $secret;

        // Transitional compatibility: read the Streams config directly.
        $this->db->ensure_schema();
        $conn=$this->db->connection();
        if ($conn) {
            $stmt=$conn->prepare("SELECT value FROM Wo_Config WHERE name='wow_pgb_secret' LIMIT 1");
            if ($stmt) {
                $stmt->execute(); $stmt->bind_result($value);
                if ($stmt->fetch() && $value) { $stmt->close(); return (string)$value; }
                $stmt->close();
            }
            $stmt=$conn->prepare("SELECT value FROM Wo_Config WHERE name='wow_webhook_secret' LIMIT 1");
            if ($stmt) {
                $stmt->execute(); $stmt->bind_result($value);
                if ($stmt->fetch() && $value) { $stmt->close(); return (string)$value; }
                $stmt->close();
            }
        }
        return '';
    }

    private function create_woocommerce_order($row) {
        $product_id=(int)($row['product_id'] ?? 0);
        $variation_id=(int)($row['variation_id'] ?? 0);
        $product=bzj_pgb_get_product_for_queue($row);
        if (!$product) {
            $this->logger->error('WooCommerce product resolution failed',array(
                'request_id'=>(string)($row['request_id'] ?? ''),
                'mapped_product_id'=>$product_id,
                'requested_variation_id'=>$variation_id,
            ));
            throw new Exception('Mapped WooCommerce product does not exist.');
        }
        $this->logger->info('WooCommerce product resolved',array(
            'request_id'=>(string)($row['request_id'] ?? ''),
            'mapped_product_id'=>$product_id,
            'requested_variation_id'=>$variation_id,
            'resolved_product_id'=>(int)$product->get_id(),
            'resolved_parent_id'=>(int)$product->get_parent_id(),
            'resolved_type'=>(string)$product->get_type(),
        ));
        if ((int)$row['wp_user_id']>0 && !get_user_by('id',(int)$row['wp_user_id'])) {
            throw new Exception('Mapped WordPress customer does not exist.');
        }

        $target_currency=$this->currency->target_currency();
        $source_amount=(float)$row['source_amount'];
        $woo_amount=$this->currency->convert($source_amount,(string)$row['source_currency'],$target_currency);

        $order=wc_create_order(array('customer_id'=>(int)$row['wp_user_id'],'created_via'=>'buzzjuice-pgb'));
        if (is_wp_error($order)) throw new Exception($order->get_error_message());

        $order->set_currency($target_currency);
        bzj_pgb_apply_billing($order,json_decode((string)$row['payload_json'],true) ?: array());

        bzj_pgb_add_order_line($order,$product,$row,$woo_amount);
        $order->add_meta_data('_bzj_pgb_request_id',(string)$row['request_id'],true);
        $order->add_meta_data('_bzj_wow_user_id',(int)$row['wow_user_id'],true);
        $order->add_meta_data('_bzj_transaction_kind',(string)$row['transaction_kind'],true);
        $order->add_meta_data('_bzj_streams_amount',(string)$row['source_amount'],true);
        $order->add_meta_data('_bzj_streams_currency',(string)$row['source_currency'],true);
        $order->add_meta_data('_bzj_woo_amount',(string)$woo_amount,true);
        $order->add_meta_data('_bzj_woo_currency',$target_currency,true);

        $payload=json_decode((string)$row['payload_json'],true);
        if (is_array($payload) && !empty($payload['affiliate_id'])) {
            $order->add_meta_data('_bzj_affwp_affiliate_id',(int)$payload['affiliate_id'],true);
        }
        if (is_array($payload) && isset($payload['rebate_credit_cents'])) {
            $order->add_meta_data('bz_rebate_credit_cents',(int)$payload['rebate_credit_cents'],true);
        }

        $order->calculate_totals(false);
        $order->update_status('pending','Buzzjuice Payment Gateway Bridge order awaiting customer payment.');
        $order->save();

        // Create a pending subscription now if the line item is a subscription.
        if ($this->config->get('enable_subscriptions',true) && bzj_pgb_order_has_subscription_product($order)) {
            $subs=bzj_pgb_create_subscription_for_order($order);
            foreach ($subs as $subscription) {
                $subscription->add_meta_data('_bzj_pgb_request_id',(string)$row['request_id'],true);
                $subscription->save();
            }
        }

        $this->db->set_woo_order((int)$row['id'],$order->get_id(),$target_currency,$woo_amount);
        return $order;
    }

    public function finalize_order($order_id) {
        $order=wc_get_order($order_id);
        if (!$order) return;
        $status=$order->get_status();
        if (!in_array($status,array('processing','completed'),true) && !$order->is_paid()) return;

        $db=BZJ_PGB_Database::instance();
        $request=(string)$order->get_meta('_bzj_pgb_request_id',true);
        if (!$request) return;
        $row=$db->get_by_request($request);
        if (!$row) return;

        $key='finalize:'.$order_id;
        if (!$db->claim_event($key,'finalize',$order_id)) return;

        try {
            $this->finalize_streams($order,$row);
            if (BZJ_PGB_Config::instance()->get('enable_subscriptions',true)) bzj_pgb_activate_subscriptions($order);
            $db->complete((int)$row['id']);
            $db->finish_event($key,'complete','Streams finalization completed.');
        } catch (Throwable $e) {
            $db->finish_event($key,'failed',$e->getMessage());
            $this->logger->error('Order finalization failed',array('order_id'=>$order_id,'error'=>$e->getMessage()));
        }
    }

    private function finalize_streams($order,$row) {
        $db=$this->db->connection();
        if (!$db) throw new Exception('WoWonder DB connection unavailable.');
        $wow=(int)$row['wow_user_id'];
        $kind=strtoupper((string)$row['transaction_kind']);
        $amount=(float)$row['source_amount'];
        $currency=(string)$row['source_currency'];
        $woo=(int)$order->get_id();
        $now=time();

        // Record payment against the existing WoWonder transaction system.
        $notes='WooCommerce payment completed; Woo order #'.$woo;
        $stmt=$db->prepare("INSERT INTO Wo_Payment_Transactions (userid,amount,order_id,kind,currency_code,notes) VALUES (?,?,?,?,?,?)");
        if ($stmt) {
            $order_ref=(string)$row['request_id'];
            $stmt->bind_param('idssss',$wow,$amount,$order_ref,$kind,$currency,$notes);
            if (!$stmt->execute()) {
                $this->logger->warning('Wo_Payment_Transactions insert failed; queue remains completed',array('error'=>$stmt->error));
            }
            $stmt->close();
        } else {
            $this->logger->warning('Could not prepare Wo_Payment_Transactions insert',array('error'=>$db->error));
        }

        // PRO package: activate the selected WoWonder package and set expiry.
        if ($kind==='PRO') {
            $payload=json_decode((string)$row['payload_json'],true) ?: array();
            $pro=(int)($payload['wow_post_id']??0);
            $user=$db->prepare("SELECT user_id FROM Wo_Users WHERE user_id=? LIMIT 1");
            if (!$user) throw new Exception('Wo_Users lookup failed: '.$db->error);
            $user->bind_param('i',$wow); $user->execute(); $user->store_result();
            if ($user->num_rows===0) { $user->close(); throw new Exception('WoWonder user not found.'); }
            $user->close();

            // Existing WoWonder subscription semantics are preserved by updating
            // only the package identity and payment timestamp. The existing
            // package duration is read from the WordPress-side product metadata
            // when available and otherwise left to the existing Streams package logic.
            $upd=$db->prepare("UPDATE Wo_Users SET is_pro='1', pro_type=?, pro_time=? WHERE user_id=? LIMIT 1");
            if ($upd) { $upd->bind_param('iii',$pro,$now,$wow); $upd->execute(); $upd->close(); }
        }
    }
}
