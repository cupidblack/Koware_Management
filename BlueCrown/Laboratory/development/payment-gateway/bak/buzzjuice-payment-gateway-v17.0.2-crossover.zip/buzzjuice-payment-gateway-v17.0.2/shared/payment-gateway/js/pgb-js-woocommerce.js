/* Buzzjuice Payment Gateway Bridge v17 - Streams browser client.
 * This replaces only the WooCommerce bridge function; it does not call WooCommerce.
 */
(function(window,$){
    'use strict';
    if (!$) return;

    window.Wo_PrepareWooCommerceLink = function(pro_type) {
        var $alert=$('.pay-go-pro-alert');
        var pkg=window.WoPgbPackages && window.WoPgbPackages[String(pro_type)] ? window.WoPgbPackages[String(pro_type)] : {};
        var amount=parseFloat(pkg.price || 0);
        var name=pkg.name || ('Pro Package '+pro_type);
        var currency=(window.WoPgbCurrency || 'GHS').toUpperCase();

        if (!amount || amount <= 0) {
            $alert.html('<div class="alert alert-danger">Unable to determine the package price. Please refresh and try again.</div>');
            return;
        }

        var $button=$('.btn-woocommerce');
        $button.prop('disabled',true);
        $alert.html('<div class="alert alert-info">Preparing secure checkout&hellip;</div>');

        $.ajax({
            url: Wo_Ajax_Requests_File()+'?f=payment&hash='+encodeURIComponent($('.main_session').val() || ''),
            method:'POST',
            dataType:'json',
            data:{
                payment_type:'wow_payment',
                transaction_kind:'PRO',
                wow_post_id:parseInt(pro_type,10),
                amount:amount,
                product_name:name,
                product_price:amount,
                product_units:1,
                wow_currency_code:currency
            }
        }).done(function(data){
            if (data && parseInt(data.status,10)===200 && data.url) {
                window.location.href=data.url;
                return;
            }
            $button.prop('disabled',false);
            $alert.html('<div class="alert alert-danger">'+((data&&data.message)?data.message:'Payment request failed.')+'</div>');
        }).fail(function(xhr){
            $button.prop('disabled',false);
            var msg='Unable to start checkout.';
            if(xhr.responseJSON && xhr.responseJSON.message) msg=xhr.responseJSON.message;
            $alert.html('<div class="alert alert-danger">'+msg+'</div>');
        });
    };
})(window,window.jQuery);
