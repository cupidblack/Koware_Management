<?php
/**
 * Buzzjuice Payment Gateway Bridge - Streams-side queue/database.
 *
 * WordPress is the execution authority. These tables are only a durable,
 * idempotent hand-off between WoWonder and WordPress.
 */
if (!defined('ABSPATH')) { exit; }

if (!class_exists('BZJ_PGB_Database')) {
class BZJ_PGB_Database {
    private static $instance;
    private $db;
    private $logger;

    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $this->logger = BZJ_PGB_Logger::instance('class-pgb-database');
        $this->load_helpers();
        $this->db = function_exists('get_wowonder_db') ? get_wowonder_db() : false;
    }

    private function load_helpers() {
        $file = ABSPATH . 'shared/db_helpers.php';
        if (file_exists($file)) require_once $file;
    }

    public function connection() { return $this->db; }

    public function ensure_schema() {
        if (!$this->db) {
            $this->logger->error('WoWonder DB connection unavailable');
            return false;
        }

        $orders = "CREATE TABLE IF NOT EXISTS `Wo_PGB_Orders` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `request_id` VARCHAR(64) NOT NULL,
            `wow_user_id` BIGINT UNSIGNED NOT NULL,
            `wp_user_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `transaction_kind` VARCHAR(40) NOT NULL,
            `product_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `variation_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `product_name` VARCHAR(255) NOT NULL,
            `quantity` INT UNSIGNED NOT NULL DEFAULT 1,
            `source_currency` CHAR(3) NOT NULL,
            `source_amount` DECIMAL(20,8) NOT NULL DEFAULT 0,
            `woo_currency` CHAR(3) NOT NULL DEFAULT '',
            `woo_amount` DECIMAL(20,8) NOT NULL DEFAULT 0,
            `payload_json` LONGTEXT NULL,
            `status` VARCHAR(30) NOT NULL DEFAULT 'pending',
            `woo_order_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `token_expires_at` DATETIME NULL,
            `failure_reason` TEXT NULL,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NOT NULL,
            `completed_at` DATETIME NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_request_id` (`request_id`),
            KEY `idx_wow_user` (`wow_user_id`),
            KEY `idx_woo_order` (`woo_order_id`),
            KEY `idx_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

        $events = "CREATE TABLE IF NOT EXISTS `Wo_PGB_Events` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `event_key` VARCHAR(191) NOT NULL,
            `event_type` VARCHAR(80) NOT NULL,
            `woo_order_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `status` VARCHAR(30) NOT NULL DEFAULT 'processing',
            `message` TEXT NULL,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_event_key` (`event_key`),
            KEY `idx_order_event` (`woo_order_id`,`event_type`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

        try {
            if (!$this->db->query($orders)) {
                $this->logger->error('Could not create Wo_PGB_Orders', array('db_error'=>$this->db->error));
                return false;
            }
            if (!$this->db->query($events)) {
                $this->logger->error('Could not create Wo_PGB_Events', array('db_error'=>$this->db->error));
                return false;
            }
            $this->repair_table('Wo_PGB_Orders', array(
                'request_id'=>"VARCHAR(64) NOT NULL",
                'wow_user_id'=>"BIGINT UNSIGNED NOT NULL DEFAULT 0",
                'wp_user_id'=>"BIGINT UNSIGNED NOT NULL DEFAULT 0",
                'transaction_kind'=>"VARCHAR(40) NOT NULL DEFAULT ''",
                'product_id'=>"BIGINT UNSIGNED NOT NULL DEFAULT 0",
                'variation_id'=>"BIGINT UNSIGNED NOT NULL DEFAULT 0",
                'product_name'=>"VARCHAR(255) NOT NULL DEFAULT ''",
                'quantity'=>"INT UNSIGNED NOT NULL DEFAULT 1",
                'source_currency'=>"CHAR(3) NOT NULL DEFAULT ''",
                'source_amount'=>"DECIMAL(20,8) NOT NULL DEFAULT 0",
                'woo_currency'=>"CHAR(3) NOT NULL DEFAULT ''",
                'woo_amount'=>"DECIMAL(20,8) NOT NULL DEFAULT 0",
                'payload_json'=>"LONGTEXT NULL",
                'status'=>"VARCHAR(30) NOT NULL DEFAULT 'pending'",
                'woo_order_id'=>"BIGINT UNSIGNED NOT NULL DEFAULT 0",
                'token_expires_at'=>"DATETIME NULL",
                'failure_reason'=>"TEXT NULL",
                'created_at'=>"DATETIME NULL",
                'updated_at'=>"DATETIME NULL",
                'completed_at'=>"DATETIME NULL"
            ), array('uq_request_id'=>"UNIQUE KEY `uq_request_id` (`request_id`)", 'idx_wow_user'=>"KEY `idx_wow_user` (`wow_user_id`)", 'idx_woo_order'=>"KEY `idx_woo_order` (`woo_order_id`)", 'idx_status'=>"KEY `idx_status` (`status`)"));
            $this->repair_table('Wo_PGB_Events', array(
                'event_key'=>"VARCHAR(191) NOT NULL",
                'event_type'=>"VARCHAR(80) NOT NULL DEFAULT ''",
                'woo_order_id'=>"BIGINT UNSIGNED NOT NULL DEFAULT 0",
                'status'=>"VARCHAR(30) NOT NULL DEFAULT 'processing'",
                'message'=>"TEXT NULL",
                'created_at'=>"DATETIME NULL",
                'updated_at'=>"DATETIME NULL"
            ), array('uq_event_key'=>"UNIQUE KEY `uq_event_key` (`event_key`)", 'idx_order_event'=>"KEY `idx_order_event` (`woo_order_id`,`event_type`)"));
            return true;
        } catch (Throwable $e) {
            $this->logger->error('PGB schema integrity check failed', array('error'=>$e->getMessage()));
            return false;
        }
    }

    /**
     * Non-destructive repair. Missing PGB columns and indexes are added;
     * existing rows are never deleted or rewritten by this routine.
     */
    private function repair_table($table, $columns, $indexes=array()) {
        $allowed=array('Wo_PGB_Orders','Wo_PGB_Events');
        if (!in_array($table,$allowed,true)) return false;

        $existing_columns=array();
        $result=$this->db->query("SHOW COLUMNS FROM `{$table}`");
        if ($result) {
            while ($row=$result->fetch_assoc()) {
                if (!empty($row['Field'])) $existing_columns[$row['Field']]=true;
            }
            $result->free();
        }
        foreach ($columns as $name=>$definition) {
            if (isset($existing_columns[$name])) continue;
            $sql="ALTER TABLE `{$table}` ADD COLUMN `{$name}` {$definition}";
            if (!$this->db->query($sql)) {
                $this->logger->error('Could not add missing PGB column', array('table'=>$table,'column'=>$name,'db_error'=>$this->db->error));
                return false;
            }
            $this->logger->info('Added missing PGB column', array('table'=>$table,'column'=>$name));
        }

        $existing_indexes=array();
        $result=$this->db->query("SHOW INDEX FROM `{$table}`");
        if ($result) {
            while ($row=$result->fetch_assoc()) {
                if (!empty($row['Key_name'])) $existing_indexes[$row['Key_name']]=true;
            }
            $result->free();
        }
        foreach ($indexes as $name=>$definition) {
            if (isset($existing_indexes[$name])) continue;
            if (!$this->db->query("ALTER TABLE `{$table}` ADD {$definition}")) {
                // A legacy duplicate/partial index should not stop payment processing.
                $this->logger->warning('Could not add PGB index', array('table'=>$table,'index'=>$name,'db_error'=>$this->db->error));
            }
        }
        return true;
    }

    public function schema_status() {
        $status=array('connection'=>!empty($this->db),'tables'=>array());
        foreach (array('Wo_PGB_Orders','Wo_PGB_Events') as $table) {
            $info=array('exists'=>false,'columns'=>array(),'indexes'=>array(),'rows'=>null);
            if ($this->db) {
                $result=$this->db->query("SHOW TABLES LIKE '".$this->db->real_escape_string($table)."'");
                $info['exists']=($result && $result->num_rows>0);
                if ($result) $result->free();
                if ($info['exists']) {
                    $result=$this->db->query("SHOW COLUMNS FROM `{$table}`");
                    if ($result) { while ($row=$result->fetch_assoc()) $info['columns'][]=$row['Field']; $result->free(); }
                    $result=$this->db->query("SHOW INDEX FROM `{$table}`");
                    if ($result) { while ($row=$result->fetch_assoc()) $info['indexes'][$row['Key_name']]=true; $result->free(); }
                    $result=$this->db->query("SELECT COUNT(*) AS c FROM `{$table}`");
                    if ($result && ($row=$result->fetch_assoc())) $info['rows']=(int)$row['c'];
                    if ($result) $result->free();
                }
            }
            $status['tables'][$table]=$info;
        }
        return $status;
    }

    /**
     * Explicit destructive rebuild. Never called automatically.
     * Caller must pass true after confirming that all PGB rows can be discarded.
     */
    public function destructive_rebuild($confirmed=false) {
        if (!$confirmed || !$this->db) return false;
        foreach (array('Wo_PGB_Events','Wo_PGB_Orders') as $table) {
            if (!$this->db->query("DROP TABLE IF EXISTS `{$table}`")) {
                $this->logger->error('Destructive PGB rebuild failed', array('table'=>$table,'db_error'=>$this->db->error));
                return false;
            }
        }
        return $this->ensure_schema();
    }

    public function create_order($data) {
        if (!$this->ensure_schema()) return false;
        $now = gmdate('Y-m-d H:i:s');
        $expiry = gmdate('Y-m-d H:i:s', time() + (int)$data['token_ttl']);
        $payload = wp_json_encode($data['payload'], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        $sql = "INSERT INTO Wo_PGB_Orders
            (request_id,wow_user_id,wp_user_id,transaction_kind,product_id,variation_id,product_name,quantity,source_currency,source_amount,woo_currency,woo_amount,payload_json,status,token_expires_at,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'pending',?,?,?)";
        $stmt = $this->db->prepare($sql);
        if (!$stmt) throw new Exception('Queue prepare failed: '.$this->db->error);
        $request_id=(string)$data['request_id']; $wow=(int)$data['wow_user_id']; $wp=(int)$data['wp_user_id'];
        $kind=(string)$data['transaction_kind']; $pid=(int)$data['product_id']; $vid=(int)$data['variation_id'];
        $name=(string)$data['product_name']; $qty=(int)$data['quantity']; $sc=(string)$data['source_currency'];
        $sa=(float)$data['source_amount']; $wc=(string)$data['woo_currency']; $wa=(float)$data['woo_amount'];
        $stmt->bind_param('siisiisisdsdssss', $request_id,$wow,$wp,$kind,$pid,$vid,$name,$qty,$sc,$sa,$wc,$wa,$payload,$expiry,$now,$now);
        if (!$stmt->execute()) { $err=$stmt->error; $stmt->close(); throw new Exception('Queue insert failed: '.$err); }
        $id=(int)$stmt->insert_id; $stmt->close();
        return $id;
    }

    public function get_by_request($request_id) {
        if (!$this->db) return false;
        $stmt=$this->db->prepare("SELECT * FROM Wo_PGB_Orders WHERE request_id=? LIMIT 1");
        if (!$stmt) return false;
        $stmt->bind_param('s',$request_id); $stmt->execute();
        $result=$stmt->get_result(); $row=$result?$result->fetch_assoc():false; $stmt->close();
        return $row ?: false;
    }

    public function get_by_id($id) {
        if (!$this->db) return false;
        $stmt=$this->db->prepare("SELECT * FROM Wo_PGB_Orders WHERE id=? LIMIT 1");
        if (!$stmt) return false;
        $stmt->bind_param('i',$id); $stmt->execute();
        $result=$stmt->get_result(); $row=$result?$result->fetch_assoc():false; $stmt->close();
        return $row ?: false;
    }

    public function set_woo_order($id,$woo_order_id,$woo_currency,$woo_amount) {
        $stmt=$this->db->prepare("UPDATE Wo_PGB_Orders SET woo_order_id=?,woo_currency=?,woo_amount=?,status='order_created',updated_at=? WHERE id=?");
        if (!$stmt) return false;
        $now=gmdate('Y-m-d H:i:s'); $woo_order_id=(int)$woo_order_id; $woo_currency=(string)$woo_currency; $woo_amount=(float)$woo_amount;
        $stmt->bind_param('isdsi',$woo_order_id,$woo_currency,$woo_amount,$now,$id); $ok=$stmt->execute(); $stmt->close(); return $ok;
    }

    public function set_status($id,$status,$reason='') {
        $stmt=$this->db->prepare("UPDATE Wo_PGB_Orders SET status=?,failure_reason=?,updated_at=? WHERE id=?");
        if (!$stmt) return false;
        $now=gmdate('Y-m-d H:i:s'); $stmt->bind_param('sssi',$status,$reason,$now,$id); $ok=$stmt->execute(); $stmt->close(); return $ok;
    }

    public function complete($id) {
        $stmt=$this->db->prepare("UPDATE Wo_PGB_Orders SET status='completed',completed_at=?,updated_at=? WHERE id=?");
        if (!$stmt) return false;
        $now=gmdate('Y-m-d H:i:s'); $stmt->bind_param('ssi',$now,$now,$id); $ok=$stmt->execute(); $stmt->close(); return $ok;
    }

    public function claim_event($key,$type,$order_id) {
        if (!$this->ensure_schema()) return false;
        $now=gmdate('Y-m-d H:i:s');
        $stmt=$this->db->prepare("SELECT status FROM Wo_PGB_Events WHERE event_key=? LIMIT 1");
        if (!$stmt) return false;
        $stmt->bind_param('s',$key); $stmt->execute(); $stmt->bind_result($status);
        $exists=$stmt->fetch(); $stmt->close();
        if ($exists) {
            if ($status==='complete' || $status==='processing') return false;
            $upd=$this->db->prepare("UPDATE Wo_PGB_Events SET status='processing',message=NULL,updated_at=? WHERE event_key=?");
            if (!$upd) return false;
            $upd->bind_param('ss',$now,$key); $ok=$upd->execute(); $upd->close(); return $ok;
        }
        $stmt=$this->db->prepare("INSERT INTO Wo_PGB_Events (event_key,event_type,woo_order_id,status,created_at,updated_at) VALUES (?,?,?,'processing',?,?)");
        if (!$stmt) return false;
        $order_id=(int)$order_id; $stmt->bind_param('ssis',$key,$type,$order_id,$now,$now);
        $ok=$stmt->execute(); $stmt->close();
        return $ok;
    }

    public function finish_event($key,$status,$message='') {
        $stmt=$this->db->prepare("UPDATE Wo_PGB_Events SET status=?,message=?,updated_at=? WHERE event_key=?");
        if (!$stmt) return false;
        $now=gmdate('Y-m-d H:i:s'); $stmt->bind_param('ssss',$status,$message,$now,$key); $ok=$stmt->execute(); $stmt->close(); return $ok;
    }

    public function get_user($wow_user_id) {
        if (!$this->db) return false;
        $stmt=$this->db->prepare("SELECT user_id,wp_user_id,email,username,first_name,last_name,phone_number,country_id,state,city,address,zip,company FROM Wo_Users WHERE user_id=? LIMIT 1");
        if (!$stmt) return false;
        $wow_user_id=(int)$wow_user_id; $stmt->bind_param('i',$wow_user_id); $stmt->execute();
        $result=$stmt->get_result(); $row=$result?$result->fetch_assoc():false; $stmt->close(); return $row ?: false;
    }

    public function update_user_after_payment($wow_user_id,$transaction_kind,$woo_order_id,$product_id,$amount,$currency,$subscription_type=0) {
        // This method intentionally performs only authoritative, minimal updates.
        // Product/PRO-specific business logic is delegated to the Streams finalizer.
        return true;
    }
}}
