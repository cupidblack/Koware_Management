<?php
if (!defined('ABSPATH')) { exit; }

function bzj_pgb_normalize_country($country) {
    $country=strtoupper(trim((string)$country));
    if (strlen($country)!==2) return 'GH';
    return $country;
}

function bzj_pgb_apply_billing($order,$payload) {
    $user=$payload['user'] ?? array();
    $billing=array(
        'first_name'=>(string)($user['first_name'] ?? $user['username'] ?? 'Customer'),
        'last_name'=>(string)($user['last_name'] ?? ''),
        'company'=>(string)($user['company'] ?? ''),
        'address_1'=>(string)($user['address'] ?? ''),
        'city'=>(string)($user['city'] ?? ''),
        'state'=>(string)($user['state'] ?? ''),
        'postcode'=>(string)($user['zip'] ?? ''),
        'country'=>bzj_pgb_normalize_country($user['country_id'] ?? 'GH'),
        'email'=>(string)($user['email'] ?? ''),
        'phone'=>(string)($user['phone_number'] ?? ''),
    );
    $order->set_address($billing,'billing');
    $order->set_address($billing,'shipping');
}

function bzj_pgb_get_product_for_queue($row) {
    // product_id is the authoritative WooCommerce mapping written by the
    // Streams-side product_mapping(). variation_id is accepted only when it
    // resolves to a real WooCommerce variation belonging to that product.
    $product_id=(int)($row['product_id'] ?? 0);
    $variation_id=(int)($row['variation_id'] ?? 0);

    if ($product_id<=0 || !function_exists('wc_get_product')) return false;

    $product=wc_get_product($product_id);
    if (!$product) {
        // The configured mapping itself is invalid; do not accidentally treat
        // a Streams variation/post ID as a WooCommerce product.
        return false;
    }

    if ($variation_id>0 && function_exists('wc_get_product')) {
        $variation=wc_get_product($variation_id);
        if ($variation && $variation instanceof WC_Product_Variation &&
            (int)$variation->get_parent_id()===(int)$product->get_id()) {
            return $variation;
        }
    }

    return $product;
}

function bzj_pgb_add_order_line($order,$product,$row,$amount) {
    $qty=max(1,(int)$row['quantity']);
    $item=new WC_Order_Item_Product();
    $item->set_product($product);
    $item->set_quantity($qty);
    $unit=$amount/$qty;
    $item->set_subtotal($amount);
    $item->set_total($amount);
    $item->add_meta_data('_bzj_pgb_request_id',(string)$row['request_id'],true);
    $item->add_meta_data('_bzj_pgb_wow_user_id',(int)$row['wow_user_id'],true);
    $item->add_meta_data('_bzj_pgb_source_currency',(string)$row['source_currency'],true);
    $item->add_meta_data('_bzj_pgb_source_amount',(string)$row['source_amount'],true);
    $order->add_item($item);
    return $item;
}
