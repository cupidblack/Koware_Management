<?php
/**
 * Streams-side Payment Gateway client.
 * IMPORTANT: This file must never load WordPress or call WordPress functions.
 */
if (!defined('PGB_STREAMS_CONTEXT')) define('PGB_STREAMS_CONTEXT',true);

class BZJ_PGB_Streams_Client {
    private $db;
    private $config;
    private $logger_file;

    public function __construct($db,$config) {
        $this->db=$db;
        $this->config=$config;
        $this->logger_file=dirname(__DIR__).'/log/pgb-client-streams.log';
        $this->ensure_log_dir();
    }

    private function ensure_log_dir() {
        $dir=dirname($this->logger_file);
        if (!is_dir($dir)) @mkdir($dir,0755,true);
    }

    private function log($level,$message,$context=array()) {
        if (empty($this->config['log_enabled'])) return;
        if ($level==='debug' && empty($this->config['debug'])) return;
        $line=json_encode(array('time'=>gmdate('c'),'level'=>$level,'message'=>$message,'context'=>$this->sanitize($context)),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).PHP_EOL;
        @file_put_contents($this->logger_file,$line,FILE_APPEND|LOCK_EX);
    }

    private function sanitize($data) {
        if (!is_array($data)) return $data;
        foreach ($data as $k=>$v) {
            if (stripos($k,'secret')!==false || stripos($k,'token')!==false || stripos($k,'password')!==false) $data[$k]='[redacted]';
            elseif (is_array($v)) $data[$k]=$this->sanitize($v);
        }
        return $data;
    }

    private function input($key,$default='') {
        return isset($_POST[$key]) ? trim((string)$_POST[$key]) : $default;
    }

    private function money($value) {
        $value=str_replace(',','',(string)$value);
        if (!is_numeric($value)) return false;
        $value=(float)$value;
        return $value>0 ? round($value,8) : false;
    }

    private function product_mapping($kind,$post_id) {
        $kind=strtoupper($kind);
        switch ($kind) {
            case 'PRO':
                $map=array(
                    1=>(int)($this->config['wow_pro_package_id']??0),
                    2=>(int)($this->config['wow_pro_package_id_2']??0),
                    3=>(int)($this->config['wow_pro_package_id_3']??0),
                    4=>(int)($this->config['wow_pro_package_id_4']??0),
                );
                return isset($map[(int)$post_id])?$map[(int)$post_id]:0;
            case 'WALLET': return (int)($this->config['wow_wallet_topup_id']??0);
            case 'DONATE': return (int)($this->config['wow_crowdfund_id']??0);
            case 'PRODUCT':
            case 'SALE':
            case 'PURCHASE': return (int)($this->config['wow_market_id']??0);
            default: return 0;
        }
    }

    public function initiate($wo) {
        header('Content-Type: application/json; charset=utf-8');

        if (empty($wo['loggedin']) || empty($wo['user']['user_id'])) return $this->error(401,'Authentication required.');
        if (($this->config['wow_payment']??'no')!=='yes') return $this->error(403,'WooCommerce payment is disabled.');

        $kind=preg_replace('/[^A-Za-z0-9_-]/','',strtoupper($this->input('transaction_kind')));
        $post_id=(int)$this->input('wow_post_id',0);
        $amount=$this->money($this->input('amount'));
        $unit=$this->money($this->input('product_price'));
        $qty=max(1,(int)$this->input('product_units',1));
        $currency=strtoupper(preg_replace('/[^A-Z]/','', $this->input('wow_currency_code',$this->config['currency']??'GHS')));
        $name=substr(strip_tags($this->input('product_name','Buzzjuice Payment')),0,255);
        $variation=(int)$this->input('variation_id',0);

        if (!$kind || !$amount || !$unit || !$currency || !$name) return $this->error(400,'Invalid payment data.');
        $woo_product_id=$this->product_mapping($kind,$post_id);
        if ($woo_product_id<=0) return $this->error(400,'No WooCommerce product mapping is configured for this payment type.');

        $wow_user_id=(int)$wo['user']['user_id'];
        try {
            if (!$this->ensure_schema()) return $this->error(500,'Payment bridge database integrity check failed.');
        } catch (Throwable $e) {
            $this->log('error','PGB schema check failed',array('error'=>$e->getMessage()));
            return $this->error(500,'Payment bridge database integrity check failed.');
        }
        $user=$this->get_user($wow_user_id);
        if (!$user) return $this->error(500,'Could not load the WoWonder user.');
        $wp_user_id=(int)($user['wp_user_id']??0);
        if ($wp_user_id<=0) return $this->error(409,'Your account is not linked to a WordPress customer account.');

        $request_id=bin2hex(random_bytes(24));
        $payload=array(
            'user'=>$user,
            'wow_post_id'=>$post_id,
            'variation_id'=>$variation,
            'address_id'=>(int)$this->input('address_id',0),
            'product_price'=>$unit,
            'product_units'=>$qty,
            'source_amount'=>$amount,
            'source_currency'=>$currency,
            'product_name'=>$name,
            'woo_product_id'=>$woo_product_id,
        );

        $secret=$this->shared_secret();
        if (!$secret) return $this->error(500,'Payment bridge secret is not configured.');
        $ttl=max(60,min(3600,(int)($this->config['token_ttl']??600)));
        $now=gmdate('Y-m-d H:i:s'); $expires=gmdate('Y-m-d H:i:s',time()+$ttl);

        $stmt=$this->db->prepare("INSERT INTO Wo_PGB_Orders (request_id,wow_user_id,wp_user_id,transaction_kind,product_id,variation_id,product_name,quantity,source_currency,source_amount,woo_currency,woo_amount,payload_json,status,token_expires_at,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'pending',?,?,?)");
        if (!$stmt) return $this->error(500,'Could not prepare payment queue.');
        $woo_currency=''; $woo_amount=0; $payload_json=json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        $stmt->bind_param('siisiisisdsdssss',$request_id,$wow_user_id,$wp_user_id,$kind,$woo_product_id,$variation,$name,$qty,$currency,$amount,$woo_currency,$woo_amount,$payload_json,$expires,$now,$now);
        if (!$stmt->execute()) { $e=$stmt->error; $stmt->close(); return $this->error(500,'Could not store payment request.'); }
        $stmt->close();

        $base=rtrim((string)$this->config['wow_store_url'],'/');
        $url=$base.'/?bzj_pgb=1&request='.rawurlencode($request_id).'&sig='.rawurlencode(hash_hmac('sha256',$request_id,$secret));

        $this->log('info','Payment request queued',array('request_id'=>$request_id,'wow_user_id'=>$wow_user_id,'wp_user_id'=>$wp_user_id,'kind'=>$kind,'woo_product_id'=>$woo_product_id));
        echo json_encode(array('status'=>200,'url'=>$url,'request_id'=>$request_id));
        exit;
    }

    private function get_user($id) {
        if (!$this->db) return false;

        // WoWonder installations do not always have identical Wo_Users schemas.
        // Never assume optional columns such as company, address or phone_number exist.
        $required=array('user_id','wp_user_id','email','username','first_name','last_name');
        $optional=array('phone_number','country_id','state','city','address','zip','company');
        $available=$this->table_columns('Wo_Users');
        if (empty($available) || !in_array('user_id',$available,true)) {
            $this->log('error','Wo_Users table or user_id column unavailable',array('table_columns'=>$available));
            return false;
        }

        $select=array();
        foreach (array_merge($required,$optional) as $column) {
            if (in_array($column,$available,true)) {
                $select[]='`'.$column.'`';
            } elseif (in_array($column,$required,true)) {
                // Missing required integration columns are represented as safe defaults.
                $select[]="'' AS `".$column."`";
            } else {
                $select[]="'' AS `".$column."`";
            }
        }

        $sql='SELECT '.implode(',',$select).' FROM `Wo_Users` WHERE `user_id`=? LIMIT 1';
        $stmt=$this->db->prepare($sql);
        if (!$stmt) {
            $this->log('error','Could not prepare Wo_Users lookup',array('db_error'=>$this->db->error));
            return false;
        }
        $id=(int)$id;
        $stmt->bind_param('i',$id);
        if (!$stmt->execute()) {
            $this->log('error','Wo_Users lookup failed',array('db_error'=>$stmt->error,'user_id'=>$id));
            $stmt->close();
            return false;
        }
        $result=$stmt->get_result();
        $row=$result?$result->fetch_assoc():false;
        $stmt->close();
        return $row?:false;
    }

    private function table_columns($table) {
        $allowed=array('Wo_Users');
        if (!in_array($table,$allowed,true)) return array();
        $columns=array();
        try {
            $result=$this->db->query('SHOW COLUMNS FROM `'.$table.'`');
            if ($result) {
                while ($row=$result->fetch_assoc()) {
                    if (!empty($row['Field'])) $columns[]=$row['Field'];
                }
                $result->free();
            }
        } catch (Throwable $e) {
            $this->log('error','Could not inspect Wo_Users schema',array('error'=>$e->getMessage()));
        }
        return $columns;
    }

    private function ensure_schema() {
        if (!$this->db) return false;
        $orders="CREATE TABLE IF NOT EXISTS `Wo_PGB_Orders` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `request_id` VARCHAR(64) NOT NULL,
            `wow_user_id` BIGINT UNSIGNED NOT NULL,
            `wp_user_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `transaction_kind` VARCHAR(40) NOT NULL DEFAULT '',
            `product_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `variation_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `product_name` VARCHAR(255) NOT NULL DEFAULT '',
            `quantity` INT UNSIGNED NOT NULL DEFAULT 1,
            `source_currency` CHAR(3) NOT NULL DEFAULT '',
            `source_amount` DECIMAL(20,8) NOT NULL DEFAULT 0,
            `woo_currency` CHAR(3) NOT NULL DEFAULT '',
            `woo_amount` DECIMAL(20,8) NOT NULL DEFAULT 0,
            `payload_json` LONGTEXT NULL,
            `status` VARCHAR(30) NOT NULL DEFAULT 'pending',
            `woo_order_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `token_expires_at` DATETIME NULL,
            `failure_reason` TEXT NULL,
            `created_at` DATETIME NULL,
            `updated_at` DATETIME NULL,
            `completed_at` DATETIME NULL,
            PRIMARY KEY (`id`), UNIQUE KEY `uq_request_id` (`request_id`), KEY `idx_wow_user` (`wow_user_id`), KEY `idx_woo_order` (`woo_order_id`), KEY `idx_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        $events="CREATE TABLE IF NOT EXISTS `Wo_PGB_Events` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `event_key` VARCHAR(191) NOT NULL,
            `event_type` VARCHAR(80) NOT NULL DEFAULT '',
            `woo_order_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
            `status` VARCHAR(30) NOT NULL DEFAULT 'processing',
            `message` TEXT NULL,
            `created_at` DATETIME NULL,
            `updated_at` DATETIME NULL,
            PRIMARY KEY (`id`), UNIQUE KEY `uq_event_key` (`event_key`), KEY `idx_order_event` (`woo_order_id`,`event_type`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        if (!$this->db->query($orders)) throw new Exception('PGB orders schema error: '.$this->db->error);
        if (!$this->db->query($events)) throw new Exception('PGB events schema error: '.$this->db->error);
        $this->repair_table('Wo_PGB_Orders',array(
            'request_id'=>"VARCHAR(64) NOT NULL",'wow_user_id'=>"BIGINT UNSIGNED NOT NULL DEFAULT 0",'wp_user_id'=>"BIGINT UNSIGNED NOT NULL DEFAULT 0",'transaction_kind'=>"VARCHAR(40) NOT NULL DEFAULT ''",'product_id'=>"BIGINT UNSIGNED NOT NULL DEFAULT 0",'variation_id'=>"BIGINT UNSIGNED NOT NULL DEFAULT 0",'product_name'=>"VARCHAR(255) NOT NULL DEFAULT ''",'quantity'=>"INT UNSIGNED NOT NULL DEFAULT 1",'source_currency'=>"CHAR(3) NOT NULL DEFAULT ''",'source_amount'=>"DECIMAL(20,8) NOT NULL DEFAULT 0",'woo_currency'=>"CHAR(3) NOT NULL DEFAULT ''",'woo_amount'=>"DECIMAL(20,8) NOT NULL DEFAULT 0",'payload_json'=>"LONGTEXT NULL",'status'=>"VARCHAR(30) NOT NULL DEFAULT 'pending'",'woo_order_id'=>"BIGINT UNSIGNED NOT NULL DEFAULT 0",'token_expires_at'=>"DATETIME NULL",'failure_reason'=>"TEXT NULL",'created_at'=>"DATETIME NULL",'updated_at'=>"DATETIME NULL",'completed_at'=>"DATETIME NULL"
        ),array('uq_request_id'=>"UNIQUE KEY `uq_request_id` (`request_id`)",'idx_wow_user'=>"KEY `idx_wow_user` (`wow_user_id`)",'idx_woo_order'=>"KEY `idx_woo_order` (`woo_order_id`)",'idx_status'=>"KEY `idx_status` (`status`)"));
        $this->repair_table('Wo_PGB_Events',array(
            'event_key'=>"VARCHAR(191) NOT NULL",'event_type'=>"VARCHAR(80) NOT NULL DEFAULT ''",'woo_order_id'=>"BIGINT UNSIGNED NOT NULL DEFAULT 0",'status'=>"VARCHAR(30) NOT NULL DEFAULT 'processing'",'message'=>"TEXT NULL",'created_at'=>"DATETIME NULL",'updated_at'=>"DATETIME NULL"
        ),array('uq_event_key'=>"UNIQUE KEY `uq_event_key` (`event_key`)",'idx_order_event'=>"KEY `idx_order_event` (`woo_order_id`,`event_type`)"));
        return true;
    }

    private function repair_table($table,$columns,$indexes=array()) {
        $allowed=array('Wo_PGB_Orders','Wo_PGB_Events');
        if (!in_array($table,$allowed,true)) return false;
        $existing=array(); $result=$this->db->query("SHOW COLUMNS FROM `{$table}`");
        if ($result) { while ($row=$result->fetch_assoc()) $existing[$row['Field']]=true; $result->free(); }
        foreach ($columns as $name=>$definition) {
            if (isset($existing[$name])) continue;
            if (!$this->db->query("ALTER TABLE `{$table}` ADD COLUMN `{$name}` {$definition}")) throw new Exception('Could not add PGB column '.$table.'.'.$name.': '.$this->db->error);
            $this->log('info','Added missing PGB column',array('table'=>$table,'column'=>$name));
        }
        $existing_indexes=array(); $result=$this->db->query("SHOW INDEX FROM `{$table}`");
        if ($result) { while ($row=$result->fetch_assoc()) $existing_indexes[$row['Key_name']]=true; $result->free(); }
        foreach ($indexes as $name=>$definition) {
            if (isset($existing_indexes[$name])) continue;
            if (!$this->db->query("ALTER TABLE `{$table}` ADD {$definition}")) $this->log('warning','Could not add PGB index',array('table'=>$table,'index'=>$name,'db_error'=>$this->db->error));
        }
        return true;
    }

    private function shared_secret() {
        if (!empty($this->config['wow_pgb_secret'])) return (string)$this->config['wow_pgb_secret'];
        if (!empty($this->config['wow_webhook_secret'])) return (string)$this->config['wow_webhook_secret'];
        return '';
    }

    private function error($code,$message) {
        http_response_code($code);
        echo json_encode(array('status'=>'error','message'=>$message));
        exit;
    }
}
