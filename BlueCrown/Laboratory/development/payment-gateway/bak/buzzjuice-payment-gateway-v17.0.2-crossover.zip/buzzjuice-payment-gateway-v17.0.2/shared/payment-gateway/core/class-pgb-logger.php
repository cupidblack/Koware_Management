<?php
/**
 * Buzzjuice Payment Gateway Bridge - Logger
 */
if (!defined('ABSPATH')) { exit; }

if (!class_exists('BZJ_PGB_Logger')) {
class BZJ_PGB_Logger {
    private static $instances = array();
    private $component;
    private $file;
    private $enabled;
    private $debug;

    public static function instance($component = 'pgb-core') {
        if (!isset(self::$instances[$component])) {
            self::$instances[$component] = new self($component);
        }
        return self::$instances[$component];
    }

    private function __construct($component) {
        $this->component = preg_replace('/[^A-Za-z0-9_.-]/', '-', (string)$component);
        $dir = defined('PGB_SHARED_DIR') ? PGB_SHARED_DIR . '/log' : dirname(__DIR__) . '/log';
        if (!is_dir($dir)) { @mkdir($dir, 0755, true); }
        $this->file = $dir . '/' . $this->component . '.log';
        $settings=get_option('bzj_pgb_settings',array());
        $this->enabled=array_key_exists('log_enabled',$settings) ? (bool)$settings['log_enabled'] : (defined('PGB_LOG_ENABLED') ? (bool)PGB_LOG_ENABLED : true);
        $this->debug=array_key_exists('debug',$settings) ? (bool)$settings['debug'] : (defined('PGB_DEBUG') ? (bool)PGB_DEBUG : false);
    }

    public function log($level, $message, $context = array()) {
        if (!$this->enabled) return false;
        if ($level === 'debug' && !$this->debug) return false;
        if (!is_array($context)) $context = array('value' => $context);
        $entry = array(
            'time' => gmdate('c'),
            'level' => strtoupper((string)$level),
            'component' => $this->component,
            'message' => (string)$message,
            'context' => self::sanitize($context),
        );
        $line = wp_json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . PHP_EOL;
        return @file_put_contents($this->file, $line, FILE_APPEND | LOCK_EX) !== false;
    }

    public function info($message, $context=array()) { return $this->log('info',$message,$context); }
    public function warning($message, $context=array()) { return $this->log('warning',$message,$context); }
    public function error($message, $context=array()) { return $this->log('error',$message,$context); }
    public function debug($message, $context=array()) { return $this->log('debug',$message,$context); }

    public static function sanitize($data) {
        if (!is_array($data)) return $data;
        $secret_keys = array('password','api_key','api_secret','secret','token','auth','cookie','session','consumer_key','consumer_secret');
        $out = array();
        foreach ($data as $key => $value) {
            $lower = strtolower((string)$key);
            $sensitive = false;
            foreach ($secret_keys as $needle) {
                if (strpos($lower, $needle) !== false) { $sensitive = true; break; }
            }
            if ($sensitive) {
                $out[$key] = '[redacted]';
            } elseif (is_array($value)) {
                $out[$key] = self::sanitize($value);
            } else {
                $text = (string)$value;
                $out[$key] = strlen($text) > 500 ? substr($text,0,497).'...' : $value;
            }
        }
        return $out;
    }
}}
