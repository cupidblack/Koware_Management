<?php
if (!defined('ABSPATH')) { exit; }

function bzj_pgb_subscription_supported() {
    return function_exists('wcs_create_subscription') && class_exists('WC_Subscriptions_Product');
}

function bzj_pgb_order_has_subscription_product($order) {
    if (!bzj_pgb_subscription_supported()) return false;
    foreach ($order->get_items('line_item') as $item) {
        $product=$item->get_product();
        if ($product && WC_Subscriptions_Product::is_subscription($product)) return true;
    }
    return false;
}

function bzj_pgb_create_subscription_for_order($order) {
    if (!bzj_pgb_subscription_supported()) return array();
    $existing=wcs_get_subscriptions_for_order($order->get_id(),array('order_type'=>'parent'));
    if (!empty($existing)) return $existing;

    $created=array();
    foreach ($order->get_items('line_item') as $item) {
        $product=$item->get_product();
        if (!$product || !WC_Subscriptions_Product::is_subscription($product)) continue;

        $start=gmdate('Y-m-d H:i:s');
        $subscription=wcs_create_subscription(array(
            'order_id'=>$order->get_id(),
            'created_via'=>'buzzjuice-pgb',
            'status'=>'pending',
            'customer_id'=>$order->get_customer_id(),
            'billing_period'=>WC_Subscriptions_Product::get_period($product),
            'billing_interval'=>WC_Subscriptions_Product::get_interval($product),
            'start_date'=>$start,
            'currency'=>$order->get_currency(),
            'customer_note'=>$order->get_customer_note(),
        ));
        if (is_wp_error($subscription)) {
            throw new Exception('Subscription creation failed: '.$subscription->get_error_message());
        }

        if (function_exists('wcs_copy_order_address')) wcs_copy_order_address($order,$subscription);
        $subscription->set_payment_method($order->get_payment_method());
        $subscription->add_product($product,(int)$item->get_quantity(),array(
            'subtotal'=>(float)$item->get_subtotal(),
            'total'=>(float)$item->get_total(),
        ));

        $dates=array();
        if (method_exists('WC_Subscriptions_Product','get_trial_expiration_date')) {
            $dates['trial_end']=WC_Subscriptions_Product::get_trial_expiration_date($product,$start);
        }
        if (method_exists('WC_Subscriptions_Product','get_first_renewal_payment_date')) {
            $dates['next_payment']=WC_Subscriptions_Product::get_first_renewal_payment_date($product,$start);
        }
        if (method_exists('WC_Subscriptions_Product','get_expiration_date')) {
            $dates['end']=WC_Subscriptions_Product::get_expiration_date($product,$start);
        }
        if (!empty($dates)) $subscription->update_dates($dates);

        $subscription->calculate_totals();
        $subscription->save();
        $created[$subscription->get_id()]=$subscription;
    }
    return $created;
}

function bzj_pgb_activate_subscriptions($order) {
    if (!function_exists('wcs_order_contains_subscription')) return false;
    if (!wcs_order_contains_subscription($order,'parent')) return false;
    if (class_exists('WC_Subscriptions_Manager') && method_exists('WC_Subscriptions_Manager','activate_subscriptions_for_order')) {
        WC_Subscriptions_Manager::activate_subscriptions_for_order($order);
        return true;
    }
    $subs=wcs_get_subscriptions_for_order($order->get_id(),array('order_type'=>'parent'));
    foreach ($subs as $subscription) {
        if (method_exists($subscription,'update_status')) $subscription->update_status('active');
        elseif (method_exists($subscription,'set_status')) { $subscription->set_status('active'); $subscription->save(); }
    }
    return true;
}
