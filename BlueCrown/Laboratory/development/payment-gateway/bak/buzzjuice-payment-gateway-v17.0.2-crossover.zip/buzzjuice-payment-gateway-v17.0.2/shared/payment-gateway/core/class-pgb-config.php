<?php
/**
 * Buzzjuice Payment Gateway Bridge - configuration.
 */
if (!defined('ABSPATH')) { exit; }

if (!class_exists('BZJ_PGB_Config')) {
class BZJ_PGB_Config {
    private static $instance;
    private $logger;
    private $data = array();

    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $this->logger = BZJ_PGB_Logger::instance('class-pgb-config');
        $this->load();
    }

    private function load() {
        $defaults = array(
            'enabled' => true,
            'debug' => false,
            'log_enabled' => true,
            'store_url' => '',
            'shared_secret' => '',
            'endpoint_path' => '/',
            'default_streams_currency' => 'GHS',
            'enable_subscriptions' => true,
            'enable_affiliate_wp' => true,
            'enable_jewel_affiliate' => true,
            'token_ttl' => 600,
        );
        $this->data = $defaults;

        $option = get_option('bzj_pgb_settings', array());
        if (is_array($option)) $this->data = array_merge($this->data, $option);

        // Environment variables override stored settings where supplied.
        $env = array(
            'PGB_ENABLED'=>'enabled',
            'PGB_DEBUG'=>'debug',
            'PGB_LOG_ENABLED'=>'log_enabled',
            'PGB_STORE_URL'=>'store_url',
            'PGB_SHARED_SECRET'=>'shared_secret',
            'PGB_ENDPOINT_PATH'=>'endpoint_path',
            'PGB_DEFAULT_STREAMS_CURRENCY'=>'default_streams_currency',
            'PGB_TOKEN_TTL'=>'token_ttl',
        );
        foreach ($env as $ek => $ck) {
            $v = getenv($ek);
            if ($v !== false && $v !== '') $this->data[$ck] = $v;
        }

        $this->data['enabled'] = $this->bool($this->data['enabled']);
        $this->data['debug'] = $this->bool($this->data['debug']);
        $this->data['log_enabled'] = $this->bool($this->data['log_enabled']);
        $this->data['enable_subscriptions'] = $this->bool($this->data['enable_subscriptions']);
        $this->data['enable_affiliate_wp'] = $this->bool($this->data['enable_affiliate_wp']);
        $this->data['enable_jewel_affiliate'] = $this->bool($this->data['enable_jewel_affiliate']);
        $this->data['token_ttl'] = max(60, min(3600, (int)$this->data['token_ttl']));
    }

    private function bool($v) {
        if (is_bool($v)) return $v;
        return in_array(strtolower((string)$v), array('1','true','yes','on'), true);
    }

    public function get($key, $default=null) {
        return array_key_exists($key, $this->data) ? $this->data[$key] : $default;
    }
    public function all() { return $this->data; }

    public function save($data) {
        $current = get_option('bzj_pgb_settings', array());
        if (!is_array($current)) $current = array();
        $allowed = array('enabled','debug','log_enabled','store_url','shared_secret','endpoint_path','default_streams_currency','enable_subscriptions','enable_affiliate_wp','enable_jewel_affiliate','token_ttl');
        foreach ($allowed as $key) {
            if (array_key_exists($key, $data)) $current[$key] = $data[$key];
        }
        update_option('bzj_pgb_settings', $current, false);
        $this->load();
        return true;
    }

    public function valid() {
        return $this->get('enabled') && !empty($this->get('shared_secret'));
    }
}}
