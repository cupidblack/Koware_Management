<?php
if (!defined('ABSPATH')) { exit; }

class BZJ_PGB_Bootstrap {
    private static $instance;
    private $logger;
    private $config;
    private $components=array();

    public static function instance() {
        if (!self::$instance) self::$instance=new self();
        return self::$instance;
    }

    private function __construct() {
        $this->logger=BZJ_PGB_Logger::instance('class-pgb-bootstrap');
        $this->config=BZJ_PGB_Config::instance();
    }

    public function init() {
        if (!$this->config->get('enabled',true)) return;
        try {
            $this->load_helpers();
            $this->scan_schema();
            $this->load_addons_and_integrations();
            $this->register_admin();
            $this->logger->info('Payment Gateway Bridge initialized');
        } catch (Throwable $e) {
            $this->logger->error('Bootstrap failed',array('error'=>$e->getMessage(),'file'=>$e->getFile(),'line'=>$e->getLine()));
        }
    }

    private function load_helpers() {
        $files=array(
            'pgb-helpers-order.php',
            'pgb-helpers-subscription.php',
        );
        foreach ($files as $file) {
            $path=PGB_SHARED_DIR.'/helpers/'.$file;
            if (file_exists($path)) require_once $path;
        }
        $db=BZJ_PGB_Database::instance();
        $db->ensure_schema();
    }

    private function scan_schema() {
        $dirs=array(PGB_SHARED_DIR.'/addons',PGB_SHARED_DIR.'/int');
        $files=array();
        foreach ($dirs as $dir) {
            if (!is_dir($dir)) continue;
            foreach (glob($dir.'/*.php') ?: array() as $file) {
                $files[]=array('file'=>basename($file),'mtime'=>@filemtime($file),'size'=>@filesize($file),'hash'=>@sha1_file($file));
            }
        }
        usort($files,function($a,$b){return strcmp($a['file'],$b['file']);});
        $manifest=sha1(wp_json_encode($files));
        $old=get_option('bzj_pgb_component_manifest','');
        if ($old!==$manifest) {
            BZJ_PGB_Database::instance()->ensure_schema();
            update_option('bzj_pgb_component_manifest',$manifest,false);
            $this->logger->info('Addon/integration manifest changed; schema integrity check completed',array('files'=>$files));
        }
    }

    private function load_addons_and_integrations() {
        foreach (glob(PGB_SHARED_DIR.'/addons/pgb-addon-*.php') ?: array() as $file) {
            require_once $file;
            $class=$this->class_from_filename($file,'addon');
            if (class_exists($class)) {
                $obj=new $class();
                if (method_exists($obj,'register')) $obj->register();
                $this->components[]=$class;
            }
        }
        foreach (glob(PGB_SHARED_DIR.'/int/pgb-int-*.php') ?: array() as $file) {
            require_once $file;
            $class=$this->class_from_filename($file,'int');
            if (class_exists($class)) {
                $obj=new $class();
                if (method_exists($obj,'register')) $obj->register();
                $this->components[]=$class;
            }
        }
    }

    private function class_from_filename($file,$type) {
        $base=basename($file,'.php');
        $base=preg_replace('/^pgb-(addon|int)-/','',$base);
        $parts=preg_split('/[-_]+/',$base);
        $name='';
        foreach ($parts as $part) $name.=ucfirst($part);
        return 'BZJ_PGB_'.($type==='addon'?'Addon_':'Int_').$name;
    }

    private function register_admin() {
        add_action('admin_menu',array($this,'admin_menu'),30);
        add_action('admin_init',array($this,'admin_save'),30);
    }

    public function admin_menu() {
        // Use an existing Buzzjuice top-level menu if one exists; otherwise create it.
        global $menu,$submenu;
        $parent='buzzjuice';
        $exists=false;
        if (is_array($menu)) {
            foreach ($menu as $item) {
                if (!empty($item[2]) && in_array($item[2],array('buzzjuice','buzzjuice-settings','buzzjuice-admin'),true)) { $exists=true; $parent=$item[2]; break; }
            }
        }
        if (!$exists) {
            add_menu_page('Buzzjuice','Buzzjuice','manage_options','buzzjuice','__return_null','dashicons-admin-generic',58);
            $parent='buzzjuice';
        }
        add_submenu_page($parent,'Payment Gateways','Payment Gateways','manage_options','buzzjuice-payment-gateways',array($this,'admin_page'));
    }

    public function admin_save() {
        if (!is_admin() || empty($_POST['bzj_pgb_save'])) return;
        if (!current_user_can('manage_options')) return;
        check_admin_referer('bzj_pgb_settings');
        $data=array(
            'enabled'=>!empty($_POST['enabled']),
            'debug'=>!empty($_POST['debug']),
            'log_enabled'=>!empty($_POST['log_enabled']),
            'store_url'=>esc_url_raw(wp_unslash($_POST['store_url']??'')),
            'shared_secret'=>sanitize_text_field(wp_unslash($_POST['shared_secret']??'')),
            'endpoint_path'=>sanitize_text_field(wp_unslash($_POST['endpoint_path']??'/')),
            'enable_subscriptions'=>!empty($_POST['enable_subscriptions']),
            'enable_affiliate_wp'=>!empty($_POST['enable_affiliate_wp']),
            'enable_jewel_affiliate'=>!empty($_POST['enable_jewel_affiliate']),
            'token_ttl'=>max(60,min(3600,(int)($_POST['token_ttl']??600))),
        );
        BZJ_PGB_Config::instance()->save($data);
        add_settings_error('bzj_pgb','saved','Payment Gateway settings saved.','updated');
    }

    public function admin_page() {
        settings_errors('bzj_pgb');
        $c=BZJ_PGB_Config::instance();
        $logdir=PGB_SHARED_DIR.'/log';
        ?>
        <div class="wrap">
        <h1>Buzzjuice &rsaquo; Payment Gateways</h1>
        <p>This bridge uses a database-backed hand-off from WoWonder to WordPress. WooCommerce REST/cURL is not required.</p>
        <form method="post">
        <?php wp_nonce_field('bzj_pgb_settings'); ?>
        <input type="hidden" name="bzj_pgb_save" value="1">
        <table class="form-table">
        <tr><th>Bridge enabled</th><td><label><input type="checkbox" name="enabled" value="1" <?php checked($c->get('enabled'),true); ?>> Enable</label></td></tr>
        <tr><th>Logging</th><td><label><input type="checkbox" name="log_enabled" value="1" <?php checked($c->get('log_enabled'),true); ?>> Enable component logs</label></td></tr>
        <tr><th>Debug logging</th><td><label><input type="checkbox" name="debug" value="1" <?php checked($c->get('debug'),true); ?>> Enable verbose debugging</label></td></tr>
        <tr><th>WooCommerce store URL</th><td><input class="regular-text" name="store_url" value="<?php echo esc_attr($c->get('store_url')); ?>"></td></tr>
        <tr><th>Bridge shared secret</th><td><input type="password" class="regular-text" name="shared_secret" value="<?php echo esc_attr($c->get('shared_secret')); ?>"><p class="description">Must match WoWonder's <code>wow_pgb_secret</code> (or transitional <code>wow_webhook_secret</code>).</p></td></tr>
        <tr><th>Endpoint path</th><td><input class="regular-text" name="endpoint_path" value="<?php echo esc_attr($c->get('endpoint_path','/')); ?>"><p class="description">The browser entry is implemented by the MU plugin and does not require a custom WordPress page.</p></td></tr>
        <tr><th>Token lifetime</th><td><input type="number" min="60" max="3600" name="token_ttl" value="<?php echo esc_attr($c->get('token_ttl',600)); ?>"> seconds</td></tr>
        <tr><th>Woo Subscriptions</th><td><label><input type="checkbox" name="enable_subscriptions" value="1" <?php checked($c->get('enable_subscriptions'),true); ?>> Enable</label></td></tr>
        <tr><th>AffiliateWP</th><td><label><input type="checkbox" name="enable_affiliate_wp" value="1" <?php checked($c->get('enable_affiliate_wp'),true); ?>> Enable</label></td></tr>
        <tr><th>Jewel Affiliate</th><td><label><input type="checkbox" name="enable_jewel_affiliate" value="1" <?php checked($c->get('enable_jewel_affiliate'),true); ?>> Enable</label></td></tr>
        </table>
        <?php submit_button('Save Payment Gateway Settings'); ?>
        </form>
        <h2>Log directory</h2><p><code><?php echo esc_html($logdir); ?></code></p>
        </div>
        <?php
    }
}
