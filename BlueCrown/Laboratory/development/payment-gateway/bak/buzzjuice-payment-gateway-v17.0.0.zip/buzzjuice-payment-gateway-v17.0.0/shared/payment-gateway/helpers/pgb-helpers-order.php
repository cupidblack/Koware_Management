<?php
if (!defined('ABSPATH')) { exit; }

function bzj_pgb_normalize_country($country) {
    $country=strtoupper(trim((string)$country));
    if (strlen($country)!==2) return 'GH';
    return $country;
}

function bzj_pgb_apply_billing($order,$payload) {
    $user=$payload['user'] ?? array();
    $billing=array(
        'first_name'=>(string)($user['first_name'] ?? $user['username'] ?? 'Customer'),
        'last_name'=>(string)($user['last_name'] ?? ''),
        'company'=>(string)($user['company'] ?? ''),
        'address_1'=>(string)($user['address'] ?? ''),
        'city'=>(string)($user['city'] ?? ''),
        'state'=>(string)($user['state'] ?? ''),
        'postcode'=>(string)($user['zip'] ?? ''),
        'country'=>bzj_pgb_normalize_country($user['country_id'] ?? 'GH'),
        'email'=>(string)($user['email'] ?? ''),
        'phone'=>(string)($user['phone_number'] ?? ''),
    );
    $order->set_address($billing,'billing');
    $order->set_address($billing,'shipping');
}

function bzj_pgb_get_product_for_queue($row) {
    $variation=(int)($row['variation_id'] ?? 0);
    $product=(int)($row['product_id'] ?? 0);
    $id=$variation>0?$variation:$product;
    if ($id<=0) return false;
    return wc_get_product($id);
}

function bzj_pgb_add_order_line($order,$product,$row,$amount) {
    $qty=max(1,(int)$row['quantity']);
    $item=new WC_Order_Item_Product();
    $item->set_product($product);
    $item->set_quantity($qty);
    $unit=$amount/$qty;
    $item->set_subtotal($amount);
    $item->set_total($amount);
    $item->add_meta_data('_bzj_pgb_request_id',(string)$row['request_id'],true);
    $item->add_meta_data('_bzj_pgb_wow_user_id',(int)$row['wow_user_id'],true);
    $item->add_meta_data('_bzj_pgb_source_currency',(string)$row['source_currency'],true);
    $item->add_meta_data('_bzj_pgb_source_amount',(string)$row['source_amount'],true);
    $order->add_item($item);
    return $item;
}
